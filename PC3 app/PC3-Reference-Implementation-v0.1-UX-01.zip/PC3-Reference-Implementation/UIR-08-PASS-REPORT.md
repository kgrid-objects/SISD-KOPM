# UIR-08 Pass Report — Compact Realization Identity Rows

Status: **externally verified and accepted**  
Implementation identity: **0.0.0-uir-08 / UIR-08**  
Date: **2026-07-20**

## Objective

Make compact IR, SR, and DP list entries understandable without changing realization data, identity, selection, ordering, or execution behavior.

## Implemented result

- Prefers the realization title explicitly declared in publication metadata.
- If no title is declared, retains the identifier as the primary label rather than inventing a friendly name.
- Shortens the supporting list-only identifier only when it begins with the exact active publication and layer prefix: `<publication>-RCI-`, `<publication>-SR-`, or `<publication>-DP-`.
- Does not hardcode `UKO-001`, parse identifier tokens into claimed semantics, or shorten partial and ambiguous matches.
- Uses a compact two-line identity hierarchy. The primary title may wrap to two lines; the secondary identifier remains a concise monospaced line.
- Keeps the publication-readiness classification as a small supporting chip without the redundant word “Publication.”
- Fixes the Exercise column width so actions align consistently down the list.
- Removes the long multi-realization pathway string from list entries. Pathway relationships remain visible in the selected Instrument Display and Detail Panel.
- Keeps the complete unchanged identifier in the row tooltip and accessible name, as well as in all non-list identity surfaces.

## Preserved boundaries

UIR-08 changes presentation and exposes an already explicit realization title field. It changes no publication identity, realization identifier, relationship, PTC/RTCM resolution, readiness classification, Limit filtering, selection, ordering, Exercise eligibility, invocation, Observation, comparison, or attestation behavior. It infers no semantics from identifier tokens, filenames, or directory placement.

## Automated verification

`npm run verify` passes completely:

- architectural dependency boundary check passed;
- server and web typechecks passed;
- 134 server tests passed, including declared realization-title preservation;
- 112 web tests passed, including three focused UIR-08 assertions;
- shared package tests passed;
- production builds for shared, server, and web passed.

Focused coverage protects declared-title precedence, exact publication/layer prefix shortening, absence of a hardcoded publication identifier, complete accessible identity, removal of pathway-chain prose from list rows, the two-line layout, and fixed Exercise alignment.

## External verification checklist

1. Load accepted.F and open Realizations.
2. Inspect IR, SR, and DP levels and confirm rows show publication-declared human-readable titles.
3. Confirm the supporting identifiers omit only the repeated `UKO-001-RCI-`, `UKO-001-SR-`, or `UKO-001-DP-` portion.
4. Confirm the rows remain appreciably more compact than Test Case and Observation entries.
5. Confirm long IR-to-SR-to-DP pathway chains no longer occupy list rows.
6. Confirm Exercise buttons form one aligned right-hand column and retain their previous enabled/disabled states.
7. Hover a row and inspect the selected realization elsewhere to confirm the complete identifier remains available and unchanged.
8. Confirm Limit filtering, realization selection, exercising, Observation capture, and Detail Panel content behave as before.

## External acceptance

UIR-08 passed external verification and was accepted on 2026-07-20.
