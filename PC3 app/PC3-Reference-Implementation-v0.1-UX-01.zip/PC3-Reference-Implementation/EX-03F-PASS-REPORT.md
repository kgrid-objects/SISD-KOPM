# EX-03F Pass Report

Status: **externally verified and accepted**.

## Result

EX-03F adds a bounded negative Publication Test Case pathway to the externally accepted Python REST execution architecture.

- Negative PTC input conditions and RTCM negative derivations are retained as explicit interpreted declarations.
- Canonical negative Attempts are identified as `publication-derived-negative`, distinct from ordinary canonical Input Objects and exploratory input.
- The planner composes omission, invalid lexical value, or invalid aggregate shape only when the PTC, exact RTCM, request mapping, and unique standard error mapping agree.
- The immutable plan retains the operation, semantic and mapped subjects, expected rejection, exact request and SHA-256, and PTC/RTCM/binding provenance.
- A completed declared HTTP `4xx` remains a completed Interaction and immutable response-body Observation.
- Semantic comparison separately evaluates no finite risk, declared error code, mapped subject, and must-not-conflate distinction.
- The Observation detail panel exposes the negative plan and semantic assertions without adding an endpoint form or malformed-input editor.

## Governing accepted.F disposition

The actual `UKO-001-Version-1.1-Accepted.F.zip` was loaded during implementation verification. It produced six PTCs and 298 resolved exercises. For `UKO-001-SR-PYTHON-REST`:

- PTC-005 is Exercise-enabled;
- PTC-006 is Exercise-enabled; and
- PTC-004 is disabled as `negative_derivation_subject_mismatch` because its canonical PTC requires omission of `mean_humphrey_equivalent_psd_db` while its RTCM directs omission of `age_years`.

PC3 neither repairs nor substitutes either declaration.

## Automated verification

The EX-03F test set proves:

- invalid-age request derivation and passing structured rejection comparison;
- invalid-aggregate request derivation and passing non-conflation comparison;
- PTC-004 subject-mismatch blocking;
- a wrong structured rejection produces `fail`;
- a finite risk result for a negative PTC produces `fail`;
- an unusable rejection response produces `comparison-error` while the raw response remains unchanged; and
- positive HTTP, CLI, library, .NET, Observation, Comparison, Attestation, dashboard, and publication-isolation behavior remains covered by the full regression suite.

The Codex execution environment did not expose a reachable Docker daemon during its final live accepted.F attempt, so no runtime result was fabricated from the successful planner and fixture-backed boundary tests. External Docker-backed verification of PTC-005 and PTC-006 subsequently passed and EX-03F was accepted.

## Accepted external verification

1. Start Docker and ensure the accepted pinned Python image is present.
2. Load `UKO-001-Version-1.1-Accepted.F.zip`.
3. Select PTC-005 and `UKO-001-SR-PYTHON-REST`; confirm Exercise is enabled and produces a completed HTTP `400` Observation with `REST_INVALID_PARAMETER`, subject `age_years`, no risk result, and comparison `pass`.
4. Select PTC-006 and the same realization; confirm Exercise is enabled and produces `REST_INVALID_REQUEST_SHAPE`, no risk result, the invalid-aggregate distinction, and comparison `pass`.
5. Select PTC-004 and confirm the same realization remains disabled with the PSD-versus-age subject-mismatch explanation.
6. Inspect progressive detail for the exact request, request digest, negative operation, subjects, PTC/RTCM/binding provenance, HTTP status, raw response, and semantic assertions.
7. Re-exercise a positive Python REST PTC and confirm EX-03E-C1 behavior is unchanged.

These are comparison results and execution-support decisions, not conformance determinations.
