# UII-06 Pass Report

Status: **passed external verification and accepted on 2026-07-19**.

## Delivered

- Added a deterministic server-owned `PTC identifier × unique realization identifier` coverage projection.
- Added IR, SR, DP, and TOTAL rows for Possible, Applicable, RTCM, Enabled, Blocked, N/A, Unclassified, and Coverage.
- Deduplicated realization identities, pair identities, and repeated resolved-exercise declarations rather than counting paths or corroborating declarations; duplicate exact support tuples are surfaced as projection errors.
- Used the exact invocation-support assessment that controls the row-level Exercise action.
- Enforced the Possible partition, Applicable partition, and Enabled ≤ RTCM ≤ Applicable ≤ Possible hierarchy.
- Exposed projection errors for conflicting applicability, inconsistent resolved exercises, duplicate support tuples, and realization identities declared at multiple levels.
- Preserved all twelve accepted UII-05 readouts without changing their data or meaning.
- Added a low-profile semantic table, tabular numerals, restrained status accents, one progressive legend, and complete narrow-width access without a dataset toggle.

## Verification

- Server unit tests cover level arithmetic, pair deduplication, repeated declarations, applicable/N/A/unclassified partitioning, RTCM resolution, enabled support, blocked values, total summation, projection errors, and the PTC-less zero state.
- Activation API tests prove that the projection is returned with the active context and latest support assessment.
- UI tests prove simultaneous metric rendering, unchanged UII-05 readouts, accessible definitions, projection-error disclosure, em-dash zero denominators, and responsive overflow.
- All accepted execution, Python CLI, Python library return-value, observation, comparison, attestation, isolation, and publication tests remain in the complete verification suite.

## Boundaries

UII-06 changes no applicability, RTCM resolution, invocation support, Docker state, Exercise action, observation, comparison, attestation, or publication content. Enabled means Exercise-enabled at the active context's latest support assessment; it is not execution history, pass coverage, conformance, correctness, or scientific validity.
