# EX-03B Pass Report

Status: **externally verified and accepted on 2026-07-19**

Baseline: externally accepted **EX-03A — Generic RTCM Invocation Planning**

Implementation identity: **0.0.0-ex-03b / EX-03B**

## Delivered behavior

- Moves runtime compatibility knowledge out of the generic RTCM planner and into registered adapter capability descriptions.
- Describes the accepted local-process adapter's invocation mode, supported realization layers, stdout preservation contract, canonical runtime, bounded runtime aliases, and launcher executable.
- Resolves an exact generic RTCM plan to exactly one registered adapter capability.
- Rejects zero matches with `adapter_capability_not_found` and multiple matches with `adapter_capability_ambiguous`.
- Never chooses by registration order and performs no fallback, filename inference, realization-identity inference, or executable inspection.
- Uses the same resolver for publication-activation Exercise support and the execution route.
- Retains adapter ID, adapter version, capability ID, canonical runtime, declared runtime requirement, launcher, and `registered-adapter-capability-match` basis in the immutable Execution Interaction.
- Preserves the accepted Python CLI Attempt, Interaction, Observation, comparison, and attestation chain.
- Keeps unsupported Rust, C#/.NET, REST, missing-declaration, and ambiguous-capability cases explicit and non-executable.

## Verification

`npm run verify` passes:

- architectural dependency boundary check;
- shared, server, and web type checks;
- **110/110 server tests**;
- **90/90 web tests**;
- shared test suite (no standalone cases);
- production builds.

Focused tests prove exact capability matching, bounded zero-match behavior, ambiguity rejection without registration-order preference, activation support projection, metadata exposure, and retention of the selected capability in the execution record.

## External validation path

1. Run `npm ci`, then `npm run dev`, and open the printed web address.
2. Load the accepted UKO 1.1 publication.
3. Confirm the accepted Python command-line SR has an enabled Exercise action and produces a new Observation and Expected Outcome comparison.
4. Confirm Rust, C#/.NET, and unsupported invocation rows remain visible but disabled; their accessible reason should say that no registered adapter capability matches.
5. Request `GET /api/execution-adapters` and confirm `pc3.local-process.stdio.v1` exposes capability `python-cli-stdout.v1`, Python aliases, stdout preservation, and the `python3` launcher.
6. Inspect the completed reference-execution response and confirm `adapterResolution` identifies the adapter, version, capability, and canonical runtime, with resolution basis `registered-adapter-capability-match`.
7. Confirm application identity `0.0.0-ex-03b / EX-03B` and the accepted Pub Board behavior remains intact.

## Scope boundary

EX-03B resolves capabilities only. It does not add another adapter, install runtimes, provision Docker, execute C#/.NET or Rust, add HTTP/service invocation, broaden comparison, claim conformance, or modify the UKO.
