# SEC-01 Pass Report — Publication Intake and Execution Safety

Date: 2026-07-20  
Implementation identity: `0.0.0-sec-01 / SEC-01`  
Status: **passed external verification and accepted on 2026-07-20**

## Outcome

SEC-01 hardens the existing release candidate without adding an invocation modality or changing publication semantics. ZIP acquisition now preflights compressed size, entry count, per-entry expanded size, aggregate expanded size, unsafe paths, and portable case collisions. Local-directory acquisition applies corresponding limits before reading files. The accepted UKO 1.1 Accepted.F corpus remains loadable under the bounded defaults.

The pass also makes the established container safeguards explicit regression requirements, proves that an unmapped runtime cannot invoke an adapter, retains the five-megabyte external-output bound, and removes temporary host publication paths from operational environment records.

## Default intake bounds

| Control | Default |
|---|---:|
| Compressed browser/local ZIP | 256 MiB |
| Resource entries | 10,000 |
| Aggregate expanded bytes | 512 MiB |
| One expanded resource | 192 MiB |

The limits are configurable through the four documented `PC3_MAX_*` environment variables. Invalid values stop server startup rather than disabling the controls.

## Preserved execution isolation

- digest-pinned runtime images only;
- Docker readiness inspection without automatic image pulls;
- no network;
- read-only root and publication mount;
- dropped capabilities and no-new-privileges;
- non-root execution;
- CPU, memory, swap, PID, tmpfs, and timeout limits;
- forced cleanup with explicit cleanup failure;
- no adapter invocation when runtime mapping is unavailable;
- bounded combined stdout/stderr capture.

## Verification

- focused SEC-01 configuration, archive, local-directory, output-limit, runtime-mapping, and Docker-isolation tests pass;
- Accepted.F loads with 2,983 resources under the new limits;
- the full `npm run verify` gate passed, including architectural boundaries, type checks, all server/web/shared tests, and production builds;
- no UKO content was modified.

## Claims not made

SEC-01 does not assert that arbitrary executable content is safe, that Docker is an impenetrable sandbox, or that a publication, realization, result, comparison, or attestation is conforming, correct, scientifically valid, or safe.
