export const PC3_IMPLEMENTATION = {
  productName: "Published Computational Capability Console",
  shortName: "PC3",
  implementationName: "PC3 Architectural Reference Implementation",
  implementationVersion: "0.1.0",
  developmentPass: "UX-01",
  specificationBaseline: "PC3 v1.0 Pass 11.7 + PC3-SPEC-ADD-PTC-01",
  blueprintBaseline: "PC3 Architecture Blueprint v1.0 + PC3-BP-ADD-PTC-01"
} as const;

export type HealthStatus = "ok";

export interface HealthResponse {
  readonly status: HealthStatus;
  readonly service: "pc3-server";
  readonly implementationVersion: string;
  readonly developmentPass: string;
}

export interface ApplicationInfoResponse {
  readonly productName: string;
  readonly shortName: string;
  readonly implementationName: string;
  readonly implementationVersion: string;
  readonly developmentPass: string;
  readonly specificationBaseline: string;
  readonly blueprintBaseline: string;
}

export interface ApiErrorResponse {
  readonly error: {
    readonly code: string;
    readonly message: string;
    readonly requestId: string;
  };
}

export interface InterpretationProvenanceView {
  readonly resourcePath: string;
  readonly resourceSha256: string;
  readonly location: string;
  readonly basis: "explicit-declaration" | "provisional-structure-inference";
}

export interface CanonicalInputObjectView {
  readonly mediaType?: string; readonly objectType?: string; readonly validity?: string; readonly value: unknown;
  readonly canonicalFieldOrder: readonly string[]; readonly conventionReference?: string;
}
export interface CanonicalExpectedOutcomeView {
  readonly outcomeKind: string; readonly value: unknown; readonly normativeValuePath?: string; readonly authorityReference?: string;
}
export interface CanonicalComparisonSemanticsView {
  readonly comparisonType: string; readonly normativeValuePath?: string; readonly absoluteTolerance?: number; readonly relativeTolerance?: number;
  readonly requiredRepresentation?: string; readonly requiredUnit?: string; readonly roundingPermittedBeforeComparison?: boolean;
}
export interface PublicationTestCaseView {
  readonly identifier: string; readonly version?: string; readonly title?: string; readonly purpose?: string; readonly classification?: string; readonly status?: string;
  readonly publicationIdentifier?: string; readonly publishedCapabilitySpecificationReference?: string; readonly canonicalInput: CanonicalInputObjectView;
  readonly canonicalNegativeInputCondition?: { readonly conditionType: string; readonly baseInputReference?: string; readonly omittedCanonicalPredictor?: string; readonly invalidCanonicalPredictor?: string; readonly invalidSemanticContent?: string; readonly illustrativeLexicalValue?: unknown; readonly otherSuppliedCanonicalPredictors?: Readonly<Record<string, unknown>>; readonly suppliedCanonicalPredictors?: Readonly<Record<string, unknown>>; readonly illustrativeInvalidAggregate?: unknown; readonly distinctionFromPtc004?: string; readonly provenance: InterpretationProvenanceView };
  readonly canonicalExpectedOutcome: CanonicalExpectedOutcomeView; readonly comparisonSemantics: CanonicalComparisonSemanticsView;
  readonly canonicalSemanticRejection?: { readonly category: string; readonly subject: string; readonly reason?: string; readonly computationMustNotProduceRiskResult: boolean; readonly messageTextIsNormative: boolean; readonly transportStatusIsNormative: boolean; readonly requiredSemanticAssertions: readonly string[] };
  readonly applicability: { readonly applicableRealizationCount?: number; readonly notApplicableRealizationCount?: number; readonly nonApplicabilityPermitted: boolean };
  readonly provenance: InterpretationProvenanceView;
}
export interface RealizationTestCaseManifestationView {
  readonly identifier: string; readonly version?: string; readonly status?: string; readonly ptcIdentifier: string; readonly realizationIdentifier: string;
  readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly applicability: { readonly status: "applicable" | "not-applicable" | "undetermined"; readonly pairingKey?: string; readonly conformanceAssertion: boolean };
  readonly inputDerivation: { readonly canonicalInputReference?: string; readonly concreteMediaType?: string; readonly artifactReference?: string; readonly inlinePermitted?: boolean;
    readonly bindings: readonly { readonly canonicalField: string; readonly localBinding: string; readonly bindingKind?: string; readonly unitMapping?: string; readonly transformation?: string }[]; readonly constraints: readonly string[]; readonly negativeConditionDerivation?: { readonly semanticCondition: string; readonly concreteDerivation: string; readonly mustNotConflateWith?: string } };
  readonly invocation: { readonly mode: string; readonly entryPoint?: string; readonly operation?: string; readonly argumentOrder: readonly string[]; readonly requestArtifactReference?: string; readonly supportAdapterReference?: string; readonly externalEnvironmentRequirements: readonly string[]; readonly doesNotEmbedRuntime: boolean; readonly constructionBasis?: string };
  readonly observationDerivation: { readonly rawObservationLocation?: string; readonly extractionExpression?: string; readonly semanticOutcome?: string; readonly normalizations: readonly string[]; readonly rawObservationMustBePreserved: boolean };
  readonly comparison: { readonly canonicalExpectedOutcomeReference?: string; readonly comparisonType?: string; readonly toleranceReference?: string | number; readonly representationSpecificHandling: readonly string[]; readonly mustPermitFailResult: boolean };
  readonly evidenceLinkageRequirements: readonly string[]; readonly limitations: readonly string[]; readonly provenance: InterpretationProvenanceView;
}
export interface PublicationTestCaseApplicabilityView {
  readonly ptcIdentifier: string; readonly realizationIdentifier: string; readonly status: "applicable" | "not-applicable" | "undetermined";
  readonly basisReference?: string; readonly provenance: InterpretationProvenanceView;
}
export interface ExerciseReadinessView {
  readonly realizationIdentifier: string; readonly applicablePtcCount: number; readonly authoritativeRtcmCount: number;
  readonly missingRtcmPtcIdentifiers: readonly string[]; readonly status: "complete" | "partial" | "none" | "not-applicable"; readonly statement: string;
}
export interface PublicationExerciseDiscoveryIndexView {
  readonly ptcIdentifiers: readonly string[];
  readonly rtcmIdentifiers: readonly string[];
  readonly ptcToRealizationIdentifiers: Readonly<Record<string, readonly string[]>>;
  readonly realizationToPtcIdentifiers: Readonly<Record<string, readonly string[]>>;
  readonly pairingToRtcmIdentifier: Readonly<Record<string, string>>;
}
export interface PublicationValidationIssueView {
  readonly code: string;
  readonly severity: "error" | "warning";
  readonly category: "referential-integrity" | "applicability-consistency" | "inventory-synchronization" | "declaration-completeness" | "publication-invariant";
  readonly message: string;
  readonly ptcIdentifier?: string;
  readonly realizationIdentifier?: string;
  readonly rtcmIdentifier?: string;
  readonly resourcePath?: string;
  readonly location?: string;
}
export interface PublicationValidationReportView {
  readonly status: "valid" | "valid-with-warnings" | "invalid" | "not-applicable";
  readonly validationScope: "publication-declarations";
  readonly checkedPtcCount: number;
  readonly checkedRtcmCount: number;
  readonly checkedRealizationCount: number;
  readonly checkedApplicabilityPairingCount: number;
  readonly issueCount: number;
  readonly errorCount: number;
  readonly warningCount: number;
  readonly checks: readonly {
    readonly category: PublicationValidationIssueView["category"];
    readonly status: "passed" | "failed";
    readonly issueCount: number;
    readonly errorCount: number;
    readonly warningCount: number;
  }[];
  readonly issues: readonly PublicationValidationIssueView[];
  readonly statement: string;
}
export interface PublicationCapabilityProfileView {
  readonly kind: "ptc" | "legacy-input" | "ambiguous-mixed" | "none";
  readonly exerciseAuthority: "publication-test-cases" | "standalone-input-objects" | "unresolved" | "none";
  readonly ptcCapability: "authoritative" | "incomplete-or-invalid" | "absent";
  readonly standaloneInputCapability: "primary" | "subordinate" | "preserved" | "absent";
  readonly ptcCount: number;
  readonly standaloneInputObjectCount: number;
  readonly rationale: string;
  readonly limitations: readonly string[];
  readonly basis: readonly InterpretationProvenanceView[];
}
export interface ResolvedExerciseView {
  readonly ptc: PublicationTestCaseView; readonly realization: { readonly identifier: string; readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package"; readonly artifactReference?: string; readonly invocationMechanism?: string };
  readonly rtcm: RealizationTestCaseManifestationView; readonly canonicalInput: CanonicalInputObjectView; readonly canonicalExpectedOutcome: CanonicalExpectedOutcomeView; readonly comparisonSemantics: CanonicalComparisonSemanticsView;
  readonly readiness: "publication-exercise-ready"; readonly executionBoundary: "external-to-publication"; readonly statement: string;
}

export interface PublicationInterpretationResponse {
  readonly load: {
    readonly id: string;
    readonly loadedAt: string;
    readonly sourceName: string;
    readonly resourceCount: number;
  };
  readonly interpretation: {
    readonly id: string;
    readonly interpretedAt: string;
    readonly publicationIdentity?: {
      readonly declaredIdentifier: string;
      readonly declaredVersion?: string;
      readonly title?: string;
      readonly provenance: InterpretationProvenanceView;
    };
    readonly publicationTestCases: readonly PublicationTestCaseView[];
    readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestationView[];
    readonly publicationTestCaseApplicability: readonly PublicationTestCaseApplicabilityView[];
    readonly exerciseReadiness: readonly ExerciseReadinessView[];
    readonly exerciseDiscoveryIndex: PublicationExerciseDiscoveryIndexView;
    readonly publicationValidation: PublicationValidationReportView;
    readonly capabilityProfile: PublicationCapabilityProfileView;
    readonly resolvedExercises: readonly ResolvedExerciseView[];
    readonly inputObjects: readonly {
      readonly identifier: string;
      readonly title?: string;
      readonly description?: string;
      readonly mediaType: string;
      readonly value?: string;
      readonly artifactReference?: string;
      readonly schemaReference?: string;
      readonly contentDisposition: "explicit-inline" | "referenced-resource" | "metadata-only";
      readonly provenance: InterpretationProvenanceView;
    }[];
    readonly realizations: readonly {
      readonly identifier: string;
      readonly title?: string;
      readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
      readonly artifactReference?: string;
      readonly invocationMechanism?: string;
      readonly provenance: InterpretationProvenanceView;
    }[];
    readonly relationships: readonly {
      readonly relationshipType: string;
      readonly sourceIdentifier: string;
      readonly targetIdentifier: string;
      readonly provenance: InterpretationProvenanceView;
    }[];
    readonly limitations: readonly {
      readonly code: string;
      readonly message: string;
      readonly resourcePath?: string;
      readonly location?: string;
    }[];
    readonly interpretedResourcePaths: readonly string[];
  };
  readonly ior: {
    readonly id: string;
    readonly createdAt: string;
    readonly publicationIdentifier?: string;
    readonly realizationNodeCount: number;
    readonly relationshipEdgeCount: number;
    readonly unresolvedRelationshipCount: number;
    readonly constructionLimitations: readonly {
      readonly code: string;
      readonly message: string;
      readonly sourceResourcePath?: string;
    }[];
  };
}


export interface SessionResponse {
  readonly id: string;
  readonly createdAt: string;
}

export interface ActiveOperationalContextResponse {
  readonly sessionId: string;
  readonly contextId?: string;
  readonly activatedAt?: string;
  readonly sourceName?: string;
  readonly publicationLoadId?: string;
  readonly publicationIdentifier?: string;
  readonly iorId?: string;
  readonly realizationNodeCount?: number;
  readonly relationshipEdgeCount?: number;
  readonly interpretationLimitationCount?: number;
  readonly iorConstructionLimitationCount?: number;
  readonly selectedPathwayId?: string;
}

export interface PublicationActivationResponse extends PublicationInterpretationResponse {
  readonly activeContext: ActiveOperationalContextResponse;
  readonly replacedContextId?: string;
  readonly invocationSupport: readonly RtcmInvocationSupportView[];
  readonly exerciseOpportunityCoverage: ExerciseOpportunityCoverageView;
}

export interface ExerciseOpportunityCoverageRowView {
  readonly level: "implementation-representation" | "service-realization" | "deployment-package" | "total";
  readonly possible: number;
  readonly applicable: number;
  readonly rtcmResolved: number;
  readonly exerciseEnabled: number;
  readonly blocked: number;
  readonly notApplicable: number;
  readonly unclassified: number;
  readonly coveragePercent: number | null;
}
export interface ExerciseOpportunityCoverageView {
  readonly status: "available" | "projection-error";
  readonly population: "ptc-by-unique-realization";
  readonly supportAssessmentBasis: "active-context-latest-assessment";
  readonly rows: readonly ExerciseOpportunityCoverageRowView[];
  readonly errors: readonly string[];
  readonly statement: string;
}

export interface RtcmInvocationSupportView {
  readonly ptcIdentifier: string;
  readonly realizationIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly executable: boolean;
  readonly code: string;
  readonly reason: string;
}


export interface ExecutableRealizationMatrixResponse {
  readonly sessionId: string;
  readonly contextId: string;
  readonly iorId: string;
  readonly selectedPathwayId?: string;
  readonly realizationCount: number;
  readonly pathwayCount: number;
  readonly realizationPathwayCount: number;
  readonly pathwayIntegrityIssueCount: number;
  readonly unresolvedServiceRealizationCount: number;
  readonly unresolvedDeploymentPackageCount: number;
  readonly invalidTransitionCount: number;
  readonly irEndpointPathwayCount: number;
  readonly srEndpointPathwayCount: number;
  readonly dpEndpointPathwayCount: number;
  readonly representedImplementationRepresentationCount: number;
  readonly totalImplementationRepresentationCount: number;
  readonly unsupportedRealizationCount: number;
  readonly projectionLimitations: readonly string[];
  readonly pathways: readonly {
    readonly id: string; readonly selected: boolean;
    readonly kind: "realization-pathway" | "pathway-integrity-issue";
    readonly endpointType: "implementation-representation" | "service-realization" | "deployment-package";
    readonly endpointIdentifier: string; readonly selectable: boolean;
    readonly exerciseSupport: "supported" | "unsupported"; readonly unsupportedExplanations: readonly string[]; readonly relationshipTypes: readonly string[];
    readonly integrityIssue?: { readonly code: "service-realization-missing-ir-predecessor" | "deployment-package-missing-sr-predecessor" | "unresolved-relationship-endpoint" | "non-adjacent-or-reversed-transition"; readonly message: string };
    readonly steps: readonly { readonly identifier: string; readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package"; readonly artifactReference?: string; readonly invocationMechanism?: string; readonly support: { readonly status: "supported"; readonly supportDescriptor: string } | { readonly status: "unsupported"; readonly explanation: string }; }[];
  }[];
}

export interface PathwaySelectionResponse {
  readonly sessionId: string;
  readonly contextId: string;
  readonly selectedPathwayId: string;
}


export interface ExerciseAttemptInputSnapshot {
  readonly mediaType: string;
  readonly value: string;
  readonly source: "publication-canonical" | "publication-derived-negative" | "user-exploratory";
}

export interface ExerciseAttemptPublicationBinding {
  readonly ptcIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly realizationIdentifier: string;
  readonly resolutionDisposition: "unique-authoritative-rtcm";
}

export interface PrepareExerciseAttemptInput {
  readonly mediaType?: string;
  readonly value?: string;
  readonly ptcIdentifier?: string;
  readonly exerciseDisposition?: "canonical" | "exploratory";
}

export interface ExerciseAttemptResponse {
  readonly id: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly publicationLoadId: string;
  readonly iorId: string;
  readonly pathwayId: string;
  readonly endpointIdentifier: string;
  readonly endpointType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly input: ExerciseAttemptInputSnapshot;
  readonly exerciseDisposition: "canonical" | "exploratory";
  readonly publicationExerciseBinding?: ExerciseAttemptPublicationBinding;
  readonly requestedAt: string;
  readonly status: "prepared";
  readonly executionDisposition: "not-started";
  readonly explanation: string;
}

export interface ExerciseAttemptListResponse {
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly attempts: readonly ExerciseAttemptResponse[];
}

export type RuntimeOutcome = "completed" | "failed" | "indeterminate";

export interface ExternalExecutionResponseInput {
  readonly externalInteractionId: string;
  readonly receivedFrom: string;
  readonly outcome: RuntimeOutcome;
  readonly responseMediaType: string;
  readonly responseValue: string;
  readonly runtimeReportedAt?: string;
  readonly environmentIdentity?: string;
  readonly executionEnvironmentDescriptionId?: string;
}

export interface RuntimeObservationResponse {
  readonly id: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly sessionSequence: number;
  readonly attemptId: string;
  readonly pathwayId: string;
  readonly endpointIdentifier: string;
  readonly publicationExerciseScope?: ExerciseAttemptPublicationBinding;
  readonly executionInteractionId: string;
  readonly externalInteractionId: string;
  readonly receivedFrom: string;
  readonly environmentIdentity?: string;
  readonly executionEnvironmentDescriptionId?: string;
  readonly outcome: RuntimeOutcome;
  readonly response: { readonly mediaType: string; readonly value: string };
  readonly rawObservation: {
    readonly id: string; readonly mediaType: string; readonly value: string; readonly sha256: string; readonly location: string;
    readonly preservationDisposition: "immutable-raw-preserved";
    readonly sourceClassification: "directly-observed" | "externally-reported";
  };
  readonly extractionProvenance: {
    readonly disposition: "rtcm-declaration-captured-not-applied" | "not-available-to-interaction";
    readonly rtcmIdentifier?: string; readonly rawObservationLocation?: string; readonly extractionExpression?: string; readonly semanticOutcome?: string;
    readonly declarationProvenance?: InterpretationProvenanceView; readonly statement: string;
  };
  readonly normalizationRecords: readonly { readonly declaration: string; readonly disposition: "declared-not-applied"; readonly inputRawObservationId: string; readonly statement: string }[];
  readonly propertyClassifications: readonly { readonly classification: "directly-observed" | "externally-reported" | "pc3-derived"; readonly properties: readonly string[]; readonly basis: string }[];
  readonly runtimeReportedAt?: string;
  readonly capturedAt: string;
  readonly status: "ephemeral";
  readonly captureDisposition: "automatically-derived-from-interaction";
  readonly verificationDisposition: "received-not-independently-verified";
  readonly persistenceDisposition: "not-saved";
  readonly explanation: string;
}


export interface ExecutionInteractionResponse {
  readonly id: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly attemptId: string;
  readonly publicationLoadId: string;
  readonly iorId: string;
  readonly pathwayId: string;
  readonly endpointIdentifier: string;
  readonly externalInteractionId: string;
  readonly publicationExerciseBinding?: ExerciseAttemptPublicationBinding;
  readonly request: { readonly mediaType: string; readonly value: string; readonly requestedAt: string };
  readonly response: { readonly receivedFrom: string; readonly environmentIdentity?: string; readonly outcome: RuntimeOutcome; readonly mediaType: string; readonly value: string; readonly runtimeReportedAt?: string; readonly receivedAt: string; readonly preservationDisposition?: "raw-unmodified"; readonly observationLocation?: "stdout" | "return-value" | "response-body" };
  readonly externalProcess?: { readonly executable: string; readonly arguments: readonly string[]; readonly exitCode: number | null; readonly signal: string | null; readonly timedOut: boolean; readonly stderr: string };
  readonly referenceExecution?: ReferenceExecutionRecordResponse;
  readonly status: "response-received";
  readonly executionResponsibility: "external-environment";
  readonly coordinationDisposition: "response-intake-only";
  readonly verificationDisposition: "received-not-independently-verified";
  readonly explanation: string;
}

export interface ExecutionInteractionCaptureResponse { readonly interaction: ExecutionInteractionResponse; readonly observation: RuntimeObservationResponse }
export interface ExecutionInteractionListResponse { readonly sessionId: string; readonly activeContextId: string; readonly interactions: readonly ExecutionInteractionResponse[] }


export type EnvironmentPropertyAssuranceResponse = "observed" | "reported" | "unavailable";
export interface DescribedEnvironmentPropertyResponse {
  readonly value?: string;
  readonly assurance: EnvironmentPropertyAssuranceResponse;
  readonly basis: string;
}
export interface ExecutionEnvironmentDescriptionResponse {
  readonly id: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly attemptId: string;
  readonly pathwayId: string;
  readonly adapter: { readonly id: string; readonly name: string; readonly version: string };
  readonly environmentType: "local-process" | "docker-container" | "externally-reported";
  readonly executionBoundary: "external-process" | "external-container" | "external-environment";
  readonly externalEnvironmentIdentifier: DescribedEnvironmentPropertyResponse;
  readonly operatingSystem: {
    readonly platform: DescribedEnvironmentPropertyResponse;
    readonly release: DescribedEnvironmentPropertyResponse;
    readonly architecture: DescribedEnvironmentPropertyResponse;
  };
  readonly runtime: {
    readonly executable: DescribedEnvironmentPropertyResponse;
    readonly version: DescribedEnvironmentPropertyResponse;
  };
  readonly workingDirectory: DescribedEnvironmentPropertyResponse;
  readonly container?: {
    readonly providerId: string;
    readonly imageReference: DescribedEnvironmentPropertyResponse;
    readonly imageId: DescribedEnvironmentPropertyResponse;
    readonly containerName: DescribedEnvironmentPropertyResponse;
    readonly networkMode: "none";
    readonly rootFilesystem: "read-only";
    readonly publicationMount: { readonly hostPath: DescribedEnvironmentPropertyResponse; readonly containerPath: "/workspace"; readonly mode: "read-only" };
    readonly limits: { readonly cpus: string; readonly memory: string; readonly pids: string; readonly tmpfs: string; readonly timeoutMilliseconds: number };
    readonly cleanupDisposition: "removed" | "cleanup-failed";
  };
  readonly describedAt: string;
  readonly descriptionDisposition: "pc3-described-not-provisioned" | "pc3-provisioned-disposable-container";
  readonly identityAssurance: { readonly level: "observed-and-reported" | "reported-only"; readonly statement: string };
  readonly explanation: string;
}
export interface ExecutionEnvironmentDescriptionListResponse {
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly environments: readonly ExecutionEnvironmentDescriptionResponse[];
}

export interface ExecutionAdapterDescriptorResponse {
  readonly id: string; readonly name: string; readonly version: string; readonly kind: "local-process"; readonly transport: "stdio";
  readonly supports: readonly ["exercise-attempt"]; readonly executionBoundary: "external-process";
  readonly capabilities: readonly {
    readonly id: string;
    readonly invocationModes: readonly ("cli" | "library" | "http")[];
    readonly realizationTypes: readonly ("implementation-representation" | "service-realization" | "deployment-package")[];
    readonly observation: { readonly location: "stdout" | "return-value" | "response-body"; readonly rawMustBePreserved: true };
    readonly runtimeBindings: readonly { readonly canonicalRuntime: string; readonly aliases: readonly string[]; readonly executable: string }[];
  }[];
  readonly explanation: string;
}
export interface ExecutionAdapterListResponse { readonly adapters: readonly ExecutionAdapterDescriptorResponse[] }
export interface ExecuteExerciseAttemptInput {
  readonly adapterId: string; readonly executable: string; readonly arguments?: readonly string[]; readonly workingDirectory?: string;
  readonly timeoutMilliseconds?: number; readonly environmentIdentity?: string;
}
export interface ExecuteExerciseAttemptResponse extends ExecutionInteractionCaptureResponse {
  readonly environment: ExecutionEnvironmentDescriptionResponse;
  readonly adapter: ExecutionAdapterDescriptorResponse;
  readonly process: { readonly executable: string; readonly arguments: readonly string[]; readonly exitCode: number | null; readonly signal: string | null; readonly timedOut: boolean; readonly stderr: string };
  readonly realizationIdentityAssurance: { readonly level: "reported"; readonly statement: string };
}

export interface ReferenceExecutionRecordResponse {
  readonly pathIdentifier: string;
  readonly declarationResourcePath: string;
  readonly declarationIdentityField: "realization_id" | "implementation_representation_id" | "representation_id" | "service_realization_id" | "deployment_package_id" | "describes.identifier";
  readonly adapterArtifactReference?: string;
  readonly realizationIdentifier: string;
  readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly runtimeDeclaration?: { readonly value: string; readonly field: "language_or_ecosystem" | "runtime" | "runtime_requirement" | "language"; readonly resourcePath: string };
  readonly ptcIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly invocation: {
    readonly mode: "cli" | "library" | "http";
    readonly executable: string;
    readonly runtimeRequirement: string;
    readonly runtimeResolutionBasis: "registered-adapter-capability-match";
    readonly adapterResolution: { readonly adapterId: string; readonly adapterVersion: string; readonly capabilityId: string; readonly canonicalRuntime: string };
    readonly arguments: readonly string[];
    readonly orderedBindings: readonly { readonly canonicalField: string; readonly option: string; readonly value: string }[];
    readonly libraryInvocation?: { readonly bridgeId: "pc3.python-library-return.v1"; readonly sourceRootReference: string; readonly entryPoint: string; readonly entryPointKind: "language_function"; readonly namedBindings: readonly { readonly canonicalField: string; readonly rtcmLocalBinding: string; readonly parameter: string; readonly value: unknown }[]; readonly executionContractResourcePath: string };
    readonly dotnetCliInvocation?: { readonly bridgeId: "pc3.dotnet-cli-source.v1"; readonly projectFileReference: string; readonly adapterEntryPointReference: string; readonly implementationSourceRootReference: string; readonly implementationProjectReference: string; readonly serviceDeclarationReference: string; readonly targetFramework: "net8.0" };
    readonly httpInvocation?: { readonly bridgeId: "pc3.python-http-loopback.v1"; readonly serviceDeclarationReference: string; readonly bindingDeclarationReference: string; readonly implementationRepresentationIdentifier: string; readonly implementationSourceRootReference: string; readonly implementationEntryPoint: string; readonly method: "POST"; readonly route: string; readonly requestMediaType: "application/json"; readonly responseMediaType: "application/json"; readonly responseValuePath: string; readonly requestBody: string; readonly requestBodySha256: string; readonly requestBindings: readonly { readonly canonicalField: string; readonly localBinding: string; readonly value: unknown }[] };
    readonly negativeConditionPlan?: { readonly inputSource: "publication-derived-negative"; readonly operation: "omit-required-binding" | "supply-invalid-lexical-value" | "supply-invalid-aggregate-shape"; readonly conditionType: string; readonly semanticSubject: string; readonly localSubject?: string; readonly semanticCondition: string; readonly concreteDerivation: string; readonly mustNotConflateWith?: string; readonly expectedCategory: string; readonly expectedErrorCondition: "missing_required_parameter" | "invalid_parameter_type" | "invalid_request_shape"; readonly expectedErrorCode: string; readonly declaredStatus: number; readonly requestBodySha256: string; readonly ptcDeclarationProvenance: InterpretationProvenanceView; readonly rtcmDeclarationProvenance: InterpretationProvenanceView; readonly bindingDeclarationResourcePath: string };
  };
  readonly observation: { readonly location: "stdout" | "return-value" | "response-body"; readonly rawMustBePreserved: true; readonly preservationDisposition: "raw-unmodified" };
  readonly extractionExpression?: string;
  readonly semanticOutcome?: string;
  readonly normalizationDeclarations: readonly string[];
  readonly rtcmDeclarationProvenance: InterpretationProvenanceView;
  readonly comparisonDeclaration?: { readonly comparisonType?: string; readonly absoluteTolerance?: number; readonly relativeTolerance?: number; readonly disposition: "declared-not-yet-evaluated" };
  readonly expectedOutcomeValue: unknown;
  readonly expectedOutcomeKind: string;
  readonly normativeExpectedValuePath?: string;
  readonly expectedOutcomeAuthorityReference?: string;
  readonly requiredRepresentation?: string;
  readonly requiredUnit?: string;
  readonly roundingPermittedBeforeComparison?: boolean;
  readonly semanticExtractionStrategy: "json-result-risk" | "direct-json-return-value" | "json-declared-path" | "semantic-rejection";
  readonly semanticObservationPath?: string;
  readonly returnTransfer?: { readonly bridgeId: "pc3.python-library-return.v1"; readonly transferredEnvelope: string; readonly transferredEnvelopeSha256: string; readonly value: unknown; readonly valueJson: string; readonly diagnosticStdout: string; readonly diagnosticStderr: string };
  readonly httpTransfer?: { readonly bridgeId: "pc3.python-http-loopback.v1"; readonly transferredEnvelope: string; readonly transferredEnvelopeSha256: string; readonly method: "POST"; readonly route: string; readonly requestBody: string; readonly statusCode: number; readonly responseHeaders: Readonly<Record<string, string>>; readonly responseBody: string; readonly adapterEnvelope: string; readonly adapterEnvelopeSha256: string; readonly adapterStderr: string; readonly adapterEvidence: unknown };
}
export interface ExecuteReferenceExerciseAttemptResponse extends ExecuteExerciseAttemptResponse {
  readonly referenceExecution: ReferenceExecutionRecordResponse;
  readonly comparison: ExpectedOutcomeComparisonResponse;
}

export type ExpectedOutcomeComparisonStatusResponse = "pass" | "fail" | "indeterminate" | "comparison-error";
export interface ExpectedOutcomeComparisonResponse {
  readonly id: string; readonly sessionId: string; readonly activeContextId: string; readonly observationId: string; readonly executionInteractionId: string; readonly evaluatedAt: string;
  readonly publicationExerciseScope: { readonly ptcIdentifier: string; readonly rtcmIdentifier: string; readonly realizationIdentifier: string };
  readonly status: ExpectedOutcomeComparisonStatusResponse;
  readonly rawRepresentation: { readonly rawObservationId: string; readonly mediaType: string; readonly value: string; readonly sha256: string; readonly preservationDisposition: "immutable-raw-preserved" };
  readonly normalizedRepresentation: { readonly disposition: "not-required" | "applied-separately" | "not-produced"; readonly mediaType: string; readonly value?: string; readonly appliedNormalizations: readonly string[] };
  readonly extractedRepresentation: { readonly disposition: "extracted" | "not-extracted"; readonly strategy: "json-result-risk" | "direct-json-return-value" | "json-declared-path" | "semantic-rejection"; readonly declaredExpression?: string; readonly sourcePath: string; readonly value?: unknown };
  readonly expectedRepresentation: { readonly outcomeKind: string; readonly value: unknown; readonly normativeValuePath?: string; readonly authorityReference?: string; readonly requiredRepresentation?: string; readonly requiredUnit?: string };
  readonly comparisonRepresentation: { readonly comparisonType?: string; readonly absoluteTolerance?: number; readonly relativeTolerance?: number; readonly absoluteDifference?: number; readonly roundingApplied: false; readonly satisfied?: boolean; readonly semanticAssertions?: readonly { readonly assertion: "no-valid-risk-result" | "declared-error-code" | "declared-error-subject" | "must-not-conflate"; readonly satisfied: boolean; readonly observed: string }[] };
  readonly error?: { readonly code: string; readonly message: string };
  readonly claimDisposition: "comparison-result-not-conformance";
  readonly statement: string;
}
export interface ExpectedOutcomeComparisonListResponse { readonly sessionId: string; readonly activeContextId: string; readonly comparisons: readonly ExpectedOutcomeComparisonResponse[] }

export interface RuntimeObservationListResponse {
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly observations: readonly RuntimeObservationResponse[];
}

export interface SavedRuntimeObservationRecord {
  readonly recordType: "pc3-saved-runtime-observation";
  readonly recordSchemaVersion: "1.3";
  readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly savedAt: string;
  readonly observation: RuntimeObservationResponse;
  readonly statement: string;
}


export interface ExecutionEvidenceResponse {
  readonly id: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly status: "attested-ephemeral";
  readonly persistenceDisposition: "not-saved";
  readonly attestedAt: string;
  readonly attestation: { readonly attester: "PC3"; readonly implementation: string; readonly implementationVersion: string; readonly developmentPass: string; readonly scope: "faithful-record-attestation"; readonly statement: string; readonly cryptographicSignatureDisposition: "not-implemented" };
  readonly pc3Identity: { readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly evidenceScope: "complete-ptc-exercise-chain" | "runtime-observation-with-provenance";
  readonly inputDisposition: { readonly exerciseDisposition: "canonical" | "exploratory"; readonly source: "publication-canonical" | "publication-derived-negative" | "user-exploratory"; readonly snapshot: { readonly mediaType: string; readonly value: string; readonly sha256: string } };
  readonly ptcExerciseChain?: { readonly publicationLoadId: string; readonly publicationIdentifier?: string; readonly ptcIdentifier: string; readonly rtcmIdentifier: string; readonly realizationIdentifier: string; readonly attemptId: string; readonly interactionId: string; readonly observationId: string; readonly comparisonId: string };
  readonly runtimeObservation: RuntimeObservationResponse;
  readonly expectedOutcomeComparison?: ExpectedOutcomeComparisonResponse;
  readonly provenance: {
    readonly publication: { readonly activeContextId: string; readonly publicationLoadId: string; readonly publicationIdentifier?: string; readonly sourceName: string; readonly iorId: string };
    readonly realizationPathway: { readonly id: string; readonly endpointIdentifier: string; readonly endpointType: "implementation-representation" | "service-realization" | "deployment-package"; readonly relationshipTypes: readonly string[]; readonly steps: readonly { readonly identifier: string; readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package"; readonly artifactReference?: string; readonly invocationMechanism?: string }[] };
    readonly exerciseAttempt: ExerciseAttemptResponse;
    readonly executionInteraction: ExecutionInteractionResponse;
    readonly executionEnvironmentDescription?: ExecutionEnvironmentDescriptionResponse;
  };
  readonly integrity: { readonly algorithm: "SHA-256"; readonly canonicalization: "pc3-canonical-json-v1"; readonly digest: string; readonly coveredContent: "attested-exercise-record-and-pc3-identity" };
  readonly explanation: string;
}
export interface ExecutionEvidenceListResponse { readonly sessionId: string; readonly activeContextId: string; readonly evidence: readonly ExecutionEvidenceResponse[] }
export interface SavedExecutionEvidenceRecord { readonly recordType: "pc3-execution-evidence"; readonly recordSchemaVersion: "2.0"; readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string }; readonly savedAt: string; readonly evidence: ExecutionEvidenceResponse; readonly statement: string }
export interface SavedObservationCollectionAttestationRecord {
  readonly recordType: "pc3-observation-collection-attestation";
  readonly recordSchemaVersion: "1.0";
  readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly savedAt: string;
  readonly sessionId: string;
  readonly activeContextId: string;
  readonly observationCount: number;
  readonly evidence: readonly ExecutionEvidenceResponse[];
  readonly integrity: { readonly algorithm: "SHA-256"; readonly canonicalization: "pc3-canonical-json-v1"; readonly digest: string; readonly coveredContent: "ordered-current-observation-evidence-and-pc3-identity" };
  readonly statement: string;
}
