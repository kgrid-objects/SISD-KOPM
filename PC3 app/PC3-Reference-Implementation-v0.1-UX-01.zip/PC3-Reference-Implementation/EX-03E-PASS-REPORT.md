# EX-03E Pass Report

Status: **not accepted; superseded by EX-03E-C1**.

External verification found that the HTTP exchange completed but comparison incorrectly imposed the CLI-shaped `result.risk` extraction path on the accepted.F scalar REST response at `result`. EX-03E-C1 corrects this defect.

## Delivered

- Added `http` as a distinct RTCM invocation mode and `response-body` as a distinct raw Observation location.
- Resolves one exact Service Realization through `describes.identifier`, its explicit complementary service and binding metadata, declared Python adapter, bound Implementation Representation declaration, source root, and canonical entry point.
- Requires a declared JSON `POST` route, `body.inputs` request mapping, non-empty identity bindings resolved by an exact canonical-field or RTCM-local-field identity, and preserved response-field observation. Missing, ambiguous, inconsistent, unsupported, or unsafe declarations remain disabled and attributable.
- Added exact capability `python-http-response-body.v1`; it is limited to Python, Service Realizations, HTTP, preserved response bodies, and the existing pinned Python environment.
- Materializes a computation-free `pc3.python-http-loopback.v1` bridge outside the read-only UKO. The bridge hosts the declared adapter on container loopback, performs the declared HTTP exchange, and shuts down after one request.
- Preserves the HTTP request, status, headers, exact response body, adapter envelope and digest, adapter evidence, transfer envelope and digest, environment identity, process diagnostics, and cleanup disposition.
- Reuses the accepted one-click Exercise, Observation, Comparison, Attestation, and UII-06 dashboard paths. Transport mechanics appear only in progressive Observation detail.

## Boundaries

EX-03E does not invoke arbitrary or remote URLs, enable non-POST methods, supply production hosting, or add Java/JavaScript REST, gRPC, messaging, MCP, authentication, TLS, service discovery, or Deployment Package connectors. Container networking remains disabled; the HTTP exchange is loopback-only. This is an attributable Service Realization arrangement, not Deployment Verification, realization authentication, correctness proof, conformance, safety, or scientific validation.

## Verification

- The governing `UKO-001-Version-1.1-Accepted.F.zip` corpus activates as an authoritative six-PTC publication with no publication-validation issues. PC3 resolves 298 exercises and all six declared Python REST RTCMs; PTC-001, PTC-002, and PTC-003 are enabled by this pass when the Python image is ready. PTC-004 through PTC-006 remain disabled for attributable canonical-input-shape reasons rather than being silently repaired.
- Capability tests prove exact mode, layer, observation, runtime, and no-fallback matching.
- Planner tests prove explicit metadata association, service/binding consistency, adapter and implementation resolution, identity request mapping, and bounded method/media-type support.
- Bridge tests prove a real loopback HTTP server/client arrangement is materialized separately from the publication.
- Docker tests prove the read-only UKO mount, read-only bridge mount, pinned Python image, network-none boundary, declared request arguments, raw response-body preservation, and transfer provenance.
- API integration tests prove one-click execution, immutable Interaction and Observation, passing comparison, and progressive HTTP detail without endpoint-oriented UI controls.

## External verification

1. Ensure Docker Desktop is running and the accepted pinned Python image from EX-03C remains present.
2. Start PC3 and load `UKO-001-Version-1.1-Accepted.F.zip`.
3. Select `UKO-001-PTC-001`.
4. Open Realizations → SR and locate `UKO-001-SR-PYTHON-REST`.
5. Confirm Exercise is enabled and exercise it once.
6. Confirm Latest output is the JSON HTTP response body and a new Observation is created.
7. Open the Observation's progressive detail and confirm mode `http`, capability `python-http-response-body.v1`, bridge `pc3.python-http-loopback.v1`, POST route `/ohts-egps/5-year-risk`, status, REST binding `uko-001-python-rest-binding`, implementation `UKO-001-RCI-PYTHON-IR-001`, pinned Python image, network `none`, and cleanup `removed`.
8. Confirm Expected Outcome comparison remains separate and honest.
9. Confirm Java/JavaScript REST, other transports, remote endpoints, and Deployment Packages were not enabled by this pass.
