# UI-05-C1 Pass Report — PTC Entry and Visibility Correction

Date: 2026-07-19  
Implementation: `0.0.0-ui-05-c1` / `UI-05-C1`  
Baseline: UI-05

## Correction

UI-05 correctly substituted Test Cases for Inputs but retained the historical Realizations collection as the initial view. That made a successfully detected PTC publication appear operationally unchanged immediately after loading.

UI-05-C1 makes the selected publication capability visible and uses it to choose the initial collection:

- A valid PTC-profile publication opens directly on **Test Cases**.
- A persistent exercise-model readout reports **PTC · _n_ Test Cases**.
- A legacy-input publication opens directly on **Inputs**.
- A publication with neither capability continues to open on **Realizations**.
- Loading a replacement publication resets the active collection from the new interpretation rather than preserving the prior publication's collection.

The accepted UKO 1.1 therefore opens on **Test Cases** and visibly reports **PTC · 6 Test Cases**. Existing bidirectional PTC/realization navigation, RTCM resolution, legacy compatibility, and ambiguity behavior are unchanged.

## Verification

- Architectural dependency boundaries: passed.
- Type checking: passed.
- Server tests: 84 passed.
- Web tests: 49 passed.
- Production build: passed.
