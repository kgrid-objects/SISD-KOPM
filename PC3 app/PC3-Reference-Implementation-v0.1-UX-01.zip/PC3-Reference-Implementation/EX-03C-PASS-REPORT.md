# EX-03C Pass Report

Status: **externally verified and accepted on 2026-07-19, including live execution through the pinned Docker image**

Baseline: externally accepted **EX-03B — Adapter Capability Resolution**

Implementation identity: **0.0.0-ex-03c / EX-03C**

## Delivered behavior

- Adds a Docker environment provider behind the accepted generic RTCM planner and adapter-capability resolver.
- Maps canonical Python explicitly to `python:3.12-slim@sha256:57cd7c3a7a273101a6485ba99423ee568157882804b1124b4dd04266317710de`.
- Rejects mutable image references and performs no image inference from UKO identifiers, paths, filenames, or executable content.
- During publication activation, checks Docker daemon reachability and local presence of the exact pinned image without pulling or changing Docker state.
- Uses the same readiness provider again immediately before execution.
- Runs the publication-declared adapter artifact and exact RTCM arguments in a uniquely named disposable container.
- Enforces no network, a read-only root filesystem, a read-only publication-workspace mount, dropped capabilities, no-new-privileges, an unprivileged user, CPU/memory/process/tmpfs limits, and a 30-second timeout.
- Captures raw container stdout, stderr, process outcome, exit status, signal, and timeout disposition through the accepted adapter boundary.
- Attempts forced container cleanup in every outcome and makes cleanup failure a bounded execution failure.
- Retains provider identity, pinned image reference, observed local image ID, container identity, isolation policy, mount, limits, timeout, and cleanup disposition in the immutable Execution Environment Description and attested evidence chain.
- Adds progressive Docker environment inspection to the existing Detail Panel without adding primary UI controls.

## Verification

`npm run verify` passes:

- architectural dependency boundary check;
- shared, server, and web type checks;
- **114/114 server tests**;
- **91/91 web tests**;
- shared test suite (no standalone cases);
- production builds.

Focused tests prove digest enforcement, read-only readiness without pulls, daemon/image unavailable outcomes, constrained command construction, stdout/stderr preservation, exceptional outcomes, cleanup, cleanup failure, environment provenance, and attestation retention.

The build environment had the Docker client but no running Docker daemon, so automated local verification did not claim live container execution. External validation subsequently confirmed successful execution through the pinned Docker image.

## External validation path

1. Start Docker Desktop or another compatible Docker daemon.
2. Pull the exact immutable image before loading the publication:
   `docker pull python:3.12-slim@sha256:57cd7c3a7a273101a6485ba99423ee568157882804b1124b4dd04266317710de`
3. Run `npm ci`, then `npm run dev`, and open the printed web address.
4. Load the accepted UKO 1.1 publication after Docker and the image are ready.
5. Confirm the accepted Python command-line SR has an enabled Exercise action; exercise it and confirm a new Observation and Expected Outcome comparison.
6. In Observation engineering details → Execution environment, confirm Docker provider `pc3.docker.environment.v1`, the pinned image and observed image ID, network `none`, read-only root and publication mount, resource limits, and cleanup `removed`.
7. Run `docker ps -a --filter name=pc3-` and confirm no pass-created container remains.
8. Stop Docker or remove the pinned image, reload the publication, and confirm the Python Exercise action is disabled with the corresponding bounded reason. Publication loading must not pull the image.
9. Confirm identity `0.0.0-ex-03c / EX-03C` and all previously accepted Pub Board behavior remains intact.

## Scope boundary

EX-03C does not build or pull images, mount the Docker socket into a container, add C#/.NET or Rust images, add service transports, alter the UKO, broaden comparison, authenticate realizations, or claim reproducibility, correctness, safety, or conformance.
