# UII-03 Pass Report

## One-Click Canonical Exercise from Realization Lists

UII-03 adds the specified direct canonical Exercise action to the externally accepted UII-02 baseline while preserving the established Attempt, Interaction, Observation, Comparison, and optional Evidence boundaries.

### Delivered behavior

- Added one small **Exercise** action in a consistent location on every visible IR, SR, and DP realization row, separate from the row-selection control.
- Retained the Test Case selected in the sole UII-01 Test Cases list and passed its exact identifier into the coordinated action; realization exercise never changes Test Case selection.
- For the accepted `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` path, one action selects the target realization, prepares a fresh immutable `publication-canonical` Exercise Attempt, invokes the existing external reference executor, captures a new Runtime Observation, and refreshes the stored Expected Outcome comparison.
- Preserved every underlying architectural record as separately identifiable and inspectable.
- Added a row-local **Exercising…** busy state, disabled duplicate activation during the operation, and live completion or failure announcements.
- Refreshed realization status, the Instrument Display's latest output, and the Observations collection count without forcing navigation away from Realizations.
- Preserved any successfully prepared attempt when later execution coordination fails.
- Kept every unsupported or unresolved row visible with a disabled action and an accessible reason, without persistent explanatory text beneath the button.
- Removed the superseded right-hand Prepare and Run modules and reclaimed their layout space; the Instrument Display now concentrates on latest output, observation history, and attestation.
- Did not add invocation modes, infer inputs or adapters, modify the UKO, save observations, or attest evidence automatically.

### Supported execution boundary

UII-03 deliberately automates only the reference capability already accepted in EX-02. A row is enabled only when an active publication context, selected PTC, selectable pathway, materialized exact Resolved Exercise, supported CLI reference pairing, and available external adapter coincide. Other resolved exercises continue to qualify for the UII-02 **Show Exercisable** filter but their row action states **Invocation mode not yet supported by PC3**. Invocation breadth remains assigned to EX-03.

### Fresh-history proof

New end-to-end regression coverage performs two canonical preparations and reference executions in the same publication session. It proves the result contains two distinct immutable Exercise Attempts, Execution Interactions, and Runtime Observations with different identities and increasing observation sequence numbers. No prior record is reused or overwritten.

### External verification path

1. Start PC3 from this ZIP with `npm run dev`, open `http://127.0.0.1:5173`, and load the accepted UKO 1.1 publication.
2. In **Test Cases**, select `UKO-001-PTC-001`, then open **Realizations** and choose the **SR** level.
3. Confirm every visible realization row has one small, separate **Exercise** action with no readiness or unavailable sentence beneath it.
4. Confirm unsupported or unresolved rows have disabled actions and remain visible when **Show Exercisable** is Off; their reason remains available from the disabled control's accessibility metadata/title.
5. On `UKO-001-SR-PYTHON-COMMAND-LINE`, choose **Exercise** once. Confirm it reads **Exercising…** and cannot be activated again while busy.
6. Confirm completion stays in Realizations, the exercised row reports a completed result, the Observations count increases by one, and the Instrument Display shows the new immutable observation plus its Expected Outcome comparison.
7. Return to Test Cases and confirm `UKO-001-PTC-001` is still selected.
8. Exercise the same supported row again and confirm the Observations count increases again and both observations remain in the collection.
9. Confirm neither observation was automatically saved and no Execution Evidence was automatically attested.
10. Confirm the former right-hand Prepare and Run modules are absent and no empty space remains where they were; latest output, observation history, and attestation remain available.

### Verification

`npm run verify` passes architectural-boundary checks, TypeScript checks, **102 server tests**, **81 web tests**, the shared package checks, and the production build. Focused coverage verifies the cleaned Instrument Display, smaller text-free row controls, sole-selected-PTC authority, fresh canonical orchestration, accessible disabled reasons, busy behavior, observation/comparison refresh, and repeated immutable history.
