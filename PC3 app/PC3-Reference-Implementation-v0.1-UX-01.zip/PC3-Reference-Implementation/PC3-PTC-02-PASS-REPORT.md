# PC3-PTC-02 Pass Report — UKO 1.1 Discovery Architecture

## Baseline

`PC3-Reference-Implementation-v0.1-PC3-PTC-01` (externally verified)

## Result

PC3-PTC-02 teaches PC3 Interpretation to discover and assemble the explicit UKO Version 1.1 Publication Test Case architecture while preserving the verified UI and the publication/runtime boundary.

## Implemented

- Added declaration-driven discovery of complete canonical Publication Test Case specifications.
- Supports both positive canonical Input Objects and negative canonical Input Conditions.
- Interprets canonical Expected Outcomes and canonical comparison semantics without adding runtime meaning.
- Added discovery of authoritative Realization Test Case Manifestations, including:
  - canonical PTC origin;
  - complemented realization and layer;
  - pairing applicability;
  - canonical-to-local input bindings;
  - invocation declaration;
  - external environment requirements;
  - observation derivation;
  - comparison mapping;
  - evidence-linkage requirements;
  - limitations and declaration provenance.
- Builds explicit PTC/realization applicability from canonical PTC applicability determinations and RTCM declarations.
- Builds immutable lookup indexes for:
  - PTC to applicable realizations;
  - realization to applicable PTCs;
  - unique PTC/realization pairing to authoritative RTCM.
- Derives Exercise Readiness from explicit applicability and authoritative RTCM coverage.
- Exposes the discovery index through the shared interpretation API contract.
- Retains empty, bounded discovery results when paths appear suggestive but declarations are incomplete.
- Preserves UI-04 behavior; no visible navigation or interaction change was made.

## Accepted UKO 1.1 corpus verification

PC3-PTC-02 was exercised directly against `UKO-001-Version-1.1-Accepted-PTC7C-Rebuilt.zip`:

- resources: 2,983;
- executable realization instances: 52;
- canonical PTCs: 6;
- authoritative RTCMs: 298;
- explicit applicability declarations: 312;
  - applicable pairings: 298;
  - non-applicable pairings: 14;
- uniquely indexed authoritative pairings: 298;
- realization readiness:
  - complete: 52;
  - partial: 0;
  - none: 0;
  - not applicable: 0.

PTC coverage discovered:

- PTC-001: 52 realizations;
- PTC-002: 52 realizations;
- PTC-003: 52 realizations;
- PTC-004: 52 realizations;
- PTC-005: 52 realizations;
- PTC-006: 38 realizations, with 14 explicit non-applicable pairings.

The discovery layer reported no RTCM-to-PTC inconsistencies for the accepted corpus.

## Deliberately deferred

PC3-PTC-02 does not yet:

- perform the broader publication validation and integrity audit planned for PC3-PTC-03;
- select UKO 1.0 versus UKO 1.1 interaction modes;
- replace the Inputs collection with Test Cases;
- present PTCs, readiness, or RTCM detail in the UI;
- execute resolved exercises;
- capture or compare runtime observations.

## Verification

- Architectural dependency boundary check passed.
- TypeScript checks passed.
- Server tests: 70 passed.
- Web tests: 45 passed.
- Shared tests passed.
- Production build passed.
- Accepted UKO 1.1 corpus counts and relationship indexes passed.

Run `npm ci` and then `npm run verify` from the repository root.
