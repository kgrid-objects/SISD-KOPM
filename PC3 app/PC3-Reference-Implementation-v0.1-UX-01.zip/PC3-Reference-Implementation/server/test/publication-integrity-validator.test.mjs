import assert from "node:assert/strict";
import test from "node:test";
import { PublicationIntegrityValidator } from "../dist/publication/publication-integrity-validator.js";

const provenance = Object.freeze({
  resourcePath: "Publication-Test-Cases/PTC-001/publication-test-case.yaml",
  resourceSha256: "a".repeat(64),
  location: "$",
  basis: "explicit-declaration"
});
const rtcmProvenance = Object.freeze({
  resourcePath: "02-Implementation-Representations/ir-one/Publication-Test-Case-Manifestations/PTC-001/rtcm.yaml",
  resourceSha256: "b".repeat(64),
  location: "$",
  basis: "explicit-declaration"
});

function ptc(overrides = {}) {
  return Object.freeze({
    identifier: "PTC-001",
    version: "1.0.0",
    title: "Nominal exercise",
    purpose: "Exercise the capability.",
    classification: "computational-behavior",
    status: "authoritative",
    publicationIdentifier: "UKO-001",
    publishedCapabilitySpecificationReference: "../../01-Computable-Knowledge-Specification/cks.docx",
    canonicalInput: Object.freeze({ value: Object.freeze({ x: 2 }), canonicalFieldOrder: Object.freeze(["x"]) }),
    canonicalExpectedOutcome: Object.freeze({ outcomeKind: "successful computation", value: 4 }),
    comparisonSemantics: Object.freeze({ comparisonType: "exact" }),
    applicability: Object.freeze({ applicableRealizationCount: 1, notApplicableRealizationCount: 0, nonApplicabilityPermitted: true }),
    provenance,
    ...overrides
  });
}

function realization(overrides = {}) {
  return Object.freeze({
    identifier: "IR-ONE",
    realizationType: "implementation-representation",
    provenance: Object.freeze({ ...provenance, resourcePath: "02-Implementation-Representations/ir-one/instance-metadata.yaml" }),
    ...overrides
  });
}

function applicability(overrides = {}) {
  return Object.freeze({
    ptcIdentifier: "PTC-001",
    realizationIdentifier: "IR-ONE",
    status: "applicable",
    provenance: Object.freeze({ ...provenance, location: "$.applicabilityDetermination.applicableRealizationInstances" }),
    ...overrides
  });
}

function rtcm(overrides = {}) {
  return Object.freeze({
    identifier: "RTCM-001-IR-ONE",
    version: "1.0.0",
    status: "authoritative",
    ptcIdentifier: "PTC-001",
    realizationIdentifier: "IR-ONE",
    realizationType: "implementation-representation",
    applicability: Object.freeze({ status: "applicable", pairingKey: "PTC-001|IR-ONE", conformanceAssertion: false }),
    inputDerivation: Object.freeze({ canonicalInputReference: "canonicalInputObject", bindings: Object.freeze([]), constraints: Object.freeze([]) }),
    invocation: Object.freeze({ mode: "library", entryPoint: "calculate", argumentOrder: Object.freeze(["x"]), externalEnvironmentRequirements: Object.freeze(["external runtime"]), doesNotEmbedRuntime: true }),
    observationDerivation: Object.freeze({ rawObservationLocation: "return-value", extractionExpression: "result", normalizations: Object.freeze([]), rawObservationMustBePreserved: true }),
    comparison: Object.freeze({ canonicalExpectedOutcomeReference: "canonicalExpectedOutcome", comparisonType: "exact", representationSpecificHandling: Object.freeze([]), mustPermitFailResult: true }),
    evidenceLinkageRequirements: Object.freeze(["rawObservation"]),
    limitations: Object.freeze(["Declarative only."]),
    provenance: rtcmProvenance,
    ...overrides
  });
}

function validInput(overrides = {}) {
  const publicationTestCases = [ptc()];
  const realizationTestCaseManifestations = [rtcm()];
  const applicabilityDeclarations = [applicability()];
  return {
    publicationIdentifier: "UKO-001",
    publicationTestCases,
    realizationTestCaseManifestations,
    applicabilityDeclarations,
    rawPublicationTestCases: publicationTestCases,
    rawRealizationTestCaseManifestations: realizationTestCaseManifestations,
    declaredApplicabilityDeclarations: applicabilityDeclarations,
    realizations: [realization()],
    discoveryIndex: Object.freeze({
      ptcIdentifiers: Object.freeze(["PTC-001"]),
      rtcmIdentifiers: Object.freeze(["RTCM-001-IR-ONE"]),
      ptcToRealizationIdentifiers: Object.freeze({ "PTC-001": Object.freeze(["IR-ONE"]) }),
      realizationToPtcIdentifiers: Object.freeze({ "IR-ONE": Object.freeze(["PTC-001"]) }),
      pairingToRtcmIdentifier: Object.freeze({ "PTC-001|IR-ONE": "RTCM-001-IR-ONE" })
    }),
    publicationResourcePaths: [
      provenance.resourcePath,
      rtcmProvenance.resourcePath,
      "01-Computable-Knowledge-Specification/cks.docx",
      "02-Implementation-Representations/ir-one/instance-metadata.yaml"
    ],
    ...overrides
  };
}

const validator = new PublicationIntegrityValidator();

test("validates a complete declaration graph without implying runtime or conformance", () => {
  const report = validator.validate(validInput());
  assert.equal(report.status, "valid");
  assert.equal(report.errorCount, 0);
  assert.equal(report.warningCount, 0);
  assert.equal(report.checkedApplicabilityPairingCount, 1);
  assert.ok(report.checks.every((check) => check.status === "passed"));
  assert.match(report.statement, /does not assert runtime availability/);
  assert.equal(Object.isFrozen(report), true);
  assert.equal(Object.isFrozen(report.issues), true);
});

test("reports referential, applicability, inventory, completeness, and invariant failures", () => {
  const invalidPtc = ptc({
    publicationIdentifier: "UKO-OTHER",
    purpose: undefined,
    publishedCapabilitySpecificationReference: "../../missing/cks.docx",
    applicability: Object.freeze({ applicableRealizationCount: 2, notApplicableRealizationCount: 2, nonApplicabilityPermitted: false })
  });
  const invalidRtcm = rtcm({
    realizationType: "service-realization",
    applicability: Object.freeze({ status: "applicable", pairingKey: "wrong", conformanceAssertion: true }),
    inputDerivation: Object.freeze({ bindings: Object.freeze([]), constraints: Object.freeze([]) }),
    invocation: Object.freeze({ mode: "unspecified", argumentOrder: Object.freeze([]), externalEnvironmentRequirements: Object.freeze([]), doesNotEmbedRuntime: false }),
    observationDerivation: Object.freeze({ normalizations: Object.freeze([]), rawObservationMustBePreserved: false }),
    comparison: Object.freeze({ representationSpecificHandling: Object.freeze([]), mustPermitFailResult: false })
  });
  const declared = applicability({ status: "not-applicable" });
  const report = validator.validate(validInput({
    publicationTestCases: [invalidPtc],
    rawPublicationTestCases: [invalidPtc],
    realizationTestCaseManifestations: [invalidRtcm],
    rawRealizationTestCaseManifestations: [invalidRtcm],
    applicabilityDeclarations: [declared],
    declaredApplicabilityDeclarations: [declared],
    discoveryIndex: Object.freeze({
      ptcIdentifiers: Object.freeze(["PTC-001"]), rtcmIdentifiers: Object.freeze(["RTCM-001-IR-ONE"]),
      ptcToRealizationIdentifiers: Object.freeze({}), realizationToPtcIdentifiers: Object.freeze({}),
      pairingToRtcmIdentifier: Object.freeze({ "PTC-001|IR-ONE": "RTCM-WRONG" })
    })
  }));
  assert.equal(report.status, "invalid");
  const codes = new Set(report.issues.map((issue) => issue.code));
  for (const expected of [
    "ptc_publication_identifier_mismatch",
    "referenced_publication_resource_not_found",
    "rtcm_realization_type_mismatch",
    "rtcm_applicability_conflict",
    "rtcm_pairing_key_mismatch",
    "ptc_applicable_inventory_count_mismatch",
    "ptc_not_applicable_inventory_count_mismatch",
    "ptc_declaration_incomplete",
    "rtcm_declaration_incomplete",
    "rtcm_embeds_runtime",
    "rtcm_does_not_preserve_raw_observation",
    "rtcm_does_not_permit_fail_result",
    "rtcm_asserts_conformance",
    "discovery_index_out_of_sync"
  ]) assert.ok(codes.has(expected), `expected ${expected}`);
  assert.ok(report.checks.every((check) => check.status === "failed"));
});

test("detects duplicate declaration candidates before discovery collapses them", () => {
  const duplicatePtc = ptc({ provenance: Object.freeze({ ...provenance, resourcePath: "duplicate-ptc.yaml" }) });
  const duplicateRtcm = rtcm({ provenance: Object.freeze({ ...rtcmProvenance, resourcePath: "duplicate-rtcm.yaml" }) });
  const report = validator.validate(validInput({
    rawPublicationTestCases: [ptc(), duplicatePtc],
    rawRealizationTestCaseManifestations: [rtcm(), duplicateRtcm],
    declaredApplicabilityDeclarations: [applicability(), applicability()]
  }));
  assert.equal(report.status, "invalid");
  assert.ok(report.issues.some((issue) => issue.code === "duplicate_ptc_identifier"));
  assert.ok(report.issues.some((issue) => issue.code === "duplicate_rtcm_identifier"));
  assert.ok(report.issues.some((issue) => issue.code === "duplicate_applicability_declaration"));
});

test("returns a bounded not-applicable result when no PTC architecture is declared", () => {
  const report = validator.validate({
    publicationTestCases: [], realizationTestCaseManifestations: [], applicabilityDeclarations: [], realizations: [],
    discoveryIndex: { ptcIdentifiers: [], rtcmIdentifiers: [], ptcToRealizationIdentifiers: {}, realizationToPtcIdentifiers: {}, pairingToRtcmIdentifier: {} },
    publicationResourcePaths: []
  });
  assert.equal(report.status, "not-applicable");
  assert.equal(report.issueCount, 0);
  assert.match(report.statement, /not applicable/i);
});
