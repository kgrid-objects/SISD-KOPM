import test from "node:test";
import assert from "node:assert/strict";
import { ExerciseAttemptManager } from "../dist/operation/exercise-attempt-manager.js";

function deps() { let n=0; return { clock:{now:()=>"2026-07-16T21:00:00.000Z"}, identifiers:{next:()=>`attempt-${++n}`} }; }
const active = {
  contextId:"context-1", sessionId:"session-1", activatedAt:"2026-07-16T20:00:00.000Z", sourceName:"uko.zip",
  publicationLoad:{id:"load-1",loadedAt:"2026-07-16T20:00:00.000Z",source:{kind:"uploaded-archive",locator:"uko.zip"},resourceCount:1,totalBytes:1},
  interpretation:{id:"interpretation-1",publicationLoadId:"load-1",interpretedAt:"2026-07-16T20:00:00.000Z",realizations:[],relationships:[],limitations:[],interpretedResourcePaths:[]},
  ior:{id:"ior-1",publicationLoadId:"load-1",interpretationId:"interpretation-1",createdAt:"2026-07-16T20:00:00.000Z",realizationNodes:[],relationshipEdges:[],constructionLimitations:[]},
  selectedPathwayId:"path-1"
};
const pathway = { id:"path-1",kind:"realization-pathway",endpointType:"implementation-representation",endpointIdentifier:"IR-1",steps:[],relationshipTypes:[],selectable:true,exerciseSupport:"unsupported",unsupportedExplanations:[] };
const binding = Object.freeze({ ptcIdentifier:"PTC-1",rtcmIdentifier:"RTCM-1",realizationIdentifier:"IR-1",resolutionDisposition:"unique-authoritative-rtcm" });

test("prepares an immutable context-bound attempt without executing",()=>{
  const manager=new ExerciseAttemptManager(deps());
  const result=manager.prepare({active,expectedActiveContextId:"context-1",pathway,mediaType:"application/json",value:'{"x":1}'});
  assert.equal(result.status,"prepared");
  assert.equal(result.attempt.pathwayId,"path-1");
  assert.equal(result.attempt.endpointIdentifier,"IR-1");
  assert.equal(result.attempt.executionDisposition,"not-started");
  assert.equal(result.attempt.input.value,'{"x":1}');
  assert.equal(result.attempt.input.source,"user-exploratory");
  assert.equal(result.attempt.exerciseDisposition,"exploratory");
  assert.equal(Object.isFrozen(result.attempt),true);
  assert.equal(manager.list("session-1","context-1").length,1);
});

test("prepares an immutable canonical PTC-bound attempt only from a matching resolution",()=>{
  const manager=new ExerciseAttemptManager(deps());
  const result=manager.prepare({active,expectedActiveContextId:"context-1",pathway,mediaType:"application/json",value:'{"x":2}',exerciseDisposition:"canonical",ptcBindingRequired:true,publicationExerciseBinding:binding});
  assert.equal(result.status,"prepared");
  assert.equal(result.attempt.exerciseDisposition,"canonical");
  assert.equal(result.attempt.input.source,"publication-canonical");
  assert.equal(result.attempt.publicationExerciseBinding.ptcIdentifier,"PTC-1");
  assert.equal(result.attempt.publicationExerciseBinding.rtcmIdentifier,"RTCM-1");
  assert.equal(Object.isFrozen(result.attempt.publicationExerciseBinding),true);
});

test("rejects missing and mismatched PTC resolutions before storing an attempt",()=>{
  const manager=new ExerciseAttemptManager(deps());
  assert.equal(manager.prepare({active,expectedActiveContextId:"context-1",pathway,mediaType:"application/json",value:"{}",exerciseDisposition:"canonical",ptcBindingRequired:true}).status,"exercise-resolution-required");
  assert.equal(manager.prepare({active,expectedActiveContextId:"context-1",pathway,mediaType:"application/json",value:"{}",exerciseDisposition:"exploratory",ptcBindingRequired:true,publicationExerciseBinding:{...binding,realizationIdentifier:"IR-OTHER"}}).status,"exercise-binding-mismatch");
  assert.equal(manager.list("session-1","context-1").length,0);
});

test("rejects stale context and selection mismatch",()=>{
  const manager=new ExerciseAttemptManager(deps());
  assert.equal(manager.prepare({active,expectedActiveContextId:"stale",pathway,mediaType:"application/json",value:""}).status,"stale-context");
  assert.equal(manager.prepare({active,pathway:{...pathway,id:"path-2"},expectedActiveContextId:"context-1",mediaType:"application/json",value:""}).status,"selected-pathway-mismatch");
});
