import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { zipSync } from "fflate";
import { isoInstant } from "../dist/domain/index.js";
import { LocalFilesystemPublicationSourceAdapter } from "../dist/infrastructure/publication/local-filesystem-publication-source-adapter.js";
import { InMemoryZipPublicationSourceAdapter } from "../dist/infrastructure/publication/in-memory-zip-publication-source-adapter.js";
import { PublicationLoader } from "../dist/publication/publication-loader.js";

const fixedClock = { now: () => isoInstant("2026-07-16T16:00:00.000Z") };
const fixedIds = { next: () => "publication-load-001" };
const adapter = new LocalFilesystemPublicationSourceAdapter();
const loader = new PublicationLoader({ adapters: [adapter], clock: fixedClock, identifiers: fixedIds });

async function workspace(t) {
  const root = await mkdtemp(join(tmpdir(), "pc3-dev3-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  return root;
}

test("loads a publication directory read-only with stable resource metadata", async (t) => {
  const root = await workspace(t);
  await mkdir(join(root, "Metadata"));
  await writeFile(join(root, "publication.json"), '{"id":"UKO-001"}\n');
  await writeFile(join(root, "Metadata", "manifest.yaml"), "version: 1.0\n");
  const before = await readFile(join(root, "publication.json"));

  const outcome = await loader.load({ kind: "local-directory", locator: root });
  assert.equal(outcome.status, "loaded");
  assert.equal(outcome.publication.id, "publication-load-001");
  assert.equal(outcome.publication.resourceCount, 2);
  assert.deepEqual(outcome.publication.resources.map((r) => r.path), ["Metadata/manifest.yaml", "publication.json"]);
  assert.match(outcome.publication.resources[0].sha256, /^[a-f0-9]{64}$/);
  assert.deepEqual(await readFile(join(root, "publication.json")), before);
});

test("loads a ZIP without extracting or changing the archive", async (t) => {
  const root = await workspace(t);
  const archive = join(root, "uko.zip");
  await writeFile(archive, zipSync({ "publication.json": new TextEncoder().encode('{"id":"UKO-001"}') }));
  const before = await readFile(archive);
  const outcome = await loader.load({ kind: "uploaded-archive", locator: archive });
  assert.equal(outcome.status, "loaded");
  assert.equal(outcome.publication.resourceCount, 1);
  assert.deepEqual(await readFile(archive), before);
});

test("reports unsupported and missing sources as bounded loading failures", async () => {
  const unsupported = await loader.load({ kind: "repository", locator: "https://example.invalid/uko" });
  assert.equal(unsupported.status, "failed");
  assert.equal(unsupported.failure.code, "unsupported_source");

  const missing = await loader.load({ kind: "uploaded-archive", locator: "/definitely/missing/uko.zip" });
  assert.equal(missing.status, "failed");
  assert.equal(missing.failure.code, "source_not_found");
});

test("rejects unsafe symbolic links and invalid archives without repair", async (t) => {
  const root = await workspace(t);
  const directory = join(root, "publication");
  await mkdir(directory);
  const { symlink } = await import("node:fs/promises");
  await symlink("/tmp", join(directory, "escape"));
  const unsafe = await loader.load({ kind: "local-directory", locator: directory });
  assert.equal(unsafe.status, "failed");
  assert.equal(unsafe.failure.code, "unsafe_resource_path");

  const invalid = join(root, "invalid.zip");
  await writeFile(invalid, "not a zip");
  const invalidOutcome = await loader.load({ kind: "uploaded-archive", locator: invalid });
  assert.equal(invalidOutcome.status, "failed");
  assert.equal(invalidOutcome.failure.code, "invalid_archive");
});

test("resource byte reads return defensive copies", async (t) => {
  const root = await workspace(t);
  await writeFile(join(root, "a.txt"), "abc");
  const acquired = await adapter.acquire({ kind: "local-directory", locator: root });
  const first = await acquired.resources[0].readBytes();
  first[0] = 0;
  const second = await acquired.resources[0].readBytes();
  assert.equal(new TextDecoder().decode(second), "abc");
});

test("SEC-01 rejects unsafe archive paths before accepting resources", async () => {
  const archive = zipSync({ "../escape.txt": new TextEncoder().encode("no") });
  const intake = new InMemoryZipPublicationSourceAdapter(archive, "unsafe.zip");
  await assert.rejects(
    () => intake.acquire({ kind: "uploaded-archive", locator: "unsafe.zip" }),
    (error) => error.code === "unsafe_resource_path"
  );
});

test("SEC-01 rejects archive paths that collide after portable case folding", async () => {
  const archive = zipSync({ "Case.txt": new TextEncoder().encode("one"), "case.txt": new TextEncoder().encode("two") });
  const intake = new InMemoryZipPublicationSourceAdapter(archive, "collision.zip");
  await assert.rejects(
    () => intake.acquire({ kind: "uploaded-archive", locator: "collision.zip" }),
    (error) => error.code === "duplicate_resource_path"
  );
});

test("SEC-01 enforces compressed, count, per-resource, and expanded archive bounds", async () => {
  const archive = zipSync({
    "a.txt": new TextEncoder().encode("1234"),
    "b.txt": new TextEncoder().encode("5678")
  });
  const source = { kind: "uploaded-archive", locator: "bounded.zip" };
  const cases = [
    { maximumArchiveBytes: archive.byteLength - 1 },
    { maximumResourceCount: 1 },
    { maximumResourceBytes: 3 },
    { maximumTotalBytes: 7 }
  ];
  for (const limits of cases) {
    const intake = new InMemoryZipPublicationSourceAdapter(archive, source.locator, limits);
    await assert.rejects(() => intake.acquire(source), (error) => error.code === "resource_limit_exceeded");
  }
});

test("SEC-01 applies resource limits before reading local publication files", async (t) => {
  const root = await workspace(t);
  await writeFile(join(root, "large.bin"), Buffer.alloc(9));
  const bounded = new LocalFilesystemPublicationSourceAdapter({ maximumResourceBytes: 8 });
  await assert.rejects(
    () => bounded.acquire({ kind: "local-directory", locator: root }),
    (error) => error.code === "resource_limit_exceeded"
  );
});
