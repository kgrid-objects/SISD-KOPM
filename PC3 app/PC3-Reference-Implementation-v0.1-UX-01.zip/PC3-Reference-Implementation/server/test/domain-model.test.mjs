import test from "node:test";
import assert from "node:assert/strict";
import {
  activeOperationalContextId,
  environmentAssociationId,
  executionEvidenceId,
  exerciseAttemptId,
  iorId,
  isoInstant,
  publicationLoadId,
  publicationInterpretationId,
  realizationPathwayId,
  runtimeObservationId,
  sessionId
} from "../dist/domain/index.js";

const factories = [
  sessionId,
  publicationLoadId,
  publicationInterpretationId,
  iorId,
  activeOperationalContextId,
  realizationPathwayId,
  environmentAssociationId,
  exerciseAttemptId,
  runtimeObservationId,
  executionEvidenceId
];

test("all PC3 identifier factories reject empty identifiers", () => {
  for (const factory of factories) assert.throws(() => factory("   "));
});

test("identifier factories preserve a valid external identifier", () => {
  assert.equal(String(sessionId("session-001")), "session-001");
  assert.equal(String(exerciseAttemptId("attempt-001")), "attempt-001");
});

test("ISO instants are normalized and invalid instants are rejected", () => {
  assert.equal(String(isoInstant("2026-07-16T12:00:00-04:00")), "2026-07-16T16:00:00.000Z");
  assert.throws(() => isoInstant("not-a-date"));
});
