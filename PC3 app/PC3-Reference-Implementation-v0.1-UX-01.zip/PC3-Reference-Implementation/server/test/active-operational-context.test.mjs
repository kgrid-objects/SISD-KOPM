import test from "node:test";
import assert from "node:assert/strict";
import { ActiveOperationalContextManager } from "../dist/operation/active-operational-context-manager.js";
import { publicationLoadId, publicationInterpretationId, iorId } from "../dist/domain/identifiers.js";

function dependencies() {
  let n = 0;
  return {
    clock: { now: () => "2026-07-16T20:00:00.000Z" },
    identifiers: { next: () => `id-${++n}` }
  };
}
function candidate(suffix = "a") {
  const loadId = publicationLoadId(`load-${suffix}`);
  return {
    sourceName: `${suffix}.zip`,
    publicationLoad: { id: loadId, loadedAt: "2026-07-16T20:00:00.000Z", source: { kind: "uploaded-archive", locator: `${suffix}.zip` }, resourceCount: 1, totalBytes: 1 },
    interpretation: { id: publicationInterpretationId(`interpretation-${suffix}`), publicationLoadId: loadId, interpretedAt: "2026-07-16T20:00:00.000Z", realizations: [], relationships: [], limitations: [], interpretedResourcePaths: [] },
    ior: { id: iorId(`ior-${suffix}`), publicationLoadId: loadId, interpretationId: publicationInterpretationId(`interpretation-${suffix}`), createdAt: "2026-07-16T20:00:00.000Z", realizationNodes: [], relationshipEdges: [], constructionLimitations: [] }
  };
}

test("one session owns at most one active publication and replacement is atomic", () => {
  const manager = new ActiveOperationalContextManager(dependencies());
  const session = manager.createSession();
  const first = manager.activate({ sessionId: session.id, ...candidate("one") });
  assert.equal(first.status, "activated");
  const firstId = first.active.contextId;
  const second = manager.activate({ sessionId: session.id, expectedActiveContextId: firstId, ...candidate("two") });
  assert.equal(second.status, "activated");
  assert.equal(second.replacedContextId, firstId);
  assert.equal(manager.getActive(session.id).sourceName, "two.zip");
});

test("stale activation cannot replace the current context", () => {
  const manager = new ActiveOperationalContextManager(dependencies());
  const session = manager.createSession();
  const first = manager.activate({ sessionId: session.id, ...candidate("one") });
  assert.equal(first.status, "activated");
  const stale = manager.activate({ sessionId: session.id, ...candidate("two"), expectedActiveContextId: "wrong-context" });
  assert.equal(stale.status, "stale-context");
  assert.equal(manager.getActive(session.id).contextId, first.active.contextId);
});

test("sessions remain isolated and closing clears active state", () => {
  const manager = new ActiveOperationalContextManager(dependencies());
  const a = manager.createSession();
  const b = manager.createSession();
  manager.activate({ sessionId: a.id, ...candidate("a") });
  manager.activate({ sessionId: b.id, ...candidate("b") });
  assert.notEqual(manager.getActive(a.id).contextId, manager.getActive(b.id).contextId);
  assert.equal(manager.closeSession(a.id), true);
  assert.equal(manager.getActive(a.id), undefined);
  assert.ok(manager.getActive(b.id));
});


test("pathway selection updates only the current active context", () => {
  const manager = new ActiveOperationalContextManager(dependencies());
  const session = manager.createSession();
  const activated = manager.activate({ sessionId: session.id, ...candidate("one") });
  assert.equal(activated.status, "activated");
  const selected = manager.selectPathway({ sessionId: session.id, expectedActiveContextId: activated.active.contextId, pathwayId: "pathway-1" });
  assert.equal(selected.status, "selected");
  assert.equal(manager.getActive(session.id).selectedPathwayId, "pathway-1");
  assert.equal(manager.getActive(session.id).contextId, activated.active.contextId);
});
