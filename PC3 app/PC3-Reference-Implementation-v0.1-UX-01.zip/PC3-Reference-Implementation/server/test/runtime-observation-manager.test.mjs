import test from "node:test";
import assert from "node:assert/strict";
import { ExecutionInteractionManager } from "../dist/interaction/execution-interaction-manager.js";
import { RuntimeObservationManager } from "../dist/observation/runtime-observation-manager.js";

function dependencies() { let n=0; return { clock:{now:()=>"2026-07-17T12:00:00.000Z"}, identifiers:{next:()=>`id-${++n}`} }; }
const attempt={id:"attempt-1",sessionId:"session-1",activeContextId:"context-1",publicationLoadId:"load-1",iorId:"ior-1",pathwayId:"path-1",endpointIdentifier:"IR-1",endpointType:"implementation-representation",input:{mediaType:"application/json",value:"{}"},requestedAt:"2026-07-17T11:00:00.000Z",status:"prepared",executionDisposition:"not-started",explanation:"none"};
function response(id="external-1") { return {externalInteractionId:id,receivedFrom:"adapter:test",outcome:"completed",responseMediaType:"application/json",responseValue:'{"result":0.42}',runtimeReportedAt:"2026-07-17T11:30:00Z",environmentIdentity:"external-test-runtime"}; }

test("records an immutable execution interaction and derives one ephemeral observation",()=>{
  const deps=dependencies(); const interactions=new ExecutionInteractionManager(deps); const observations=new RuntimeObservationManager(deps);
  const received=interactions.receive({attempt,expectedActiveContextId:"context-1",response:response()});
  assert.equal(received.status,"received");
  assert.equal(received.interaction.externalInteractionId,"external-1");
  assert.equal(received.interaction.request.value,"{}");
  assert.equal(received.interaction.response.value,'{"result":0.42}');
  assert.equal(received.interaction.executionResponsibility,"external-environment");
  assert.equal(Object.isFrozen(received.interaction),true);
  const observation=observations.derive(received.interaction);
  assert.equal(observation.executionInteractionId,received.interaction.id);
  assert.equal(observation.sessionSequence,1);
  assert.equal(observation.captureDisposition,"automatically-derived-from-interaction");
  assert.equal(observations.derive(received.interaction).id,observation.id);
});

test("supports multiple interactions per attempt and rejects stale, invalid, and duplicate external identities",()=>{
  const manager=new ExecutionInteractionManager(dependencies());
  assert.equal(manager.receive({attempt,expectedActiveContextId:"stale",response:response()}).status,"stale-context");
  assert.equal(manager.receive({attempt,expectedActiveContextId:"context-1",response:{...response(),externalInteractionId:""}}).status,"invalid-response");
  assert.equal(manager.receive({attempt,expectedActiveContextId:"context-1",response:response("one")}).status,"received");
  assert.equal(manager.receive({attempt,expectedActiveContextId:"context-1",response:response("one")}).status,"duplicate-external-interaction");
  assert.equal(manager.receive({attempt,expectedActiveContextId:"context-1",response:response("two")}).status,"received");
  assert.equal(manager.list("session-1","context-1","attempt-1").length,2);
});

test("optional save remains external and discard removes only the ephemeral observation",()=>{
  const deps=dependencies(); const interactions=new ExecutionInteractionManager(deps); const observations=new RuntimeObservationManager(deps);
  const received=interactions.receive({attempt,expectedActiveContextId:"context-1",response:response()});
  assert.equal(received.status,"received");
  const observation=observations.derive(received.interaction);
  const saved=observations.saveRecord(observation,{implementation:"PC3 Architectural Reference Implementation",version:"0.0.0-dev9",developmentPass:"DEV-9"});
  assert.equal(saved.recordSchemaVersion,"1.3"); assert.equal(saved.source.version,"0.0.0-dev9"); assert.match(saved.statement,/Saving was optional/);
  assert.equal(observations.discard("session-1","context-1",observation.id),"discarded");
  assert.equal(interactions.list("session-1","context-1").length,1);
});

test("OBS-01 preserves an independently identifiable raw observation with exact PTC and RTCM scope",()=>{
  const deps=dependencies(); const interactions=new ExecutionInteractionManager(deps); const observations=new RuntimeObservationManager(deps);
  const boundAttempt={...attempt,exerciseDisposition:"canonical",input:{...attempt.input,source:"publication-canonical"},publicationExerciseBinding:{ptcIdentifier:"UKO-001-PTC-001",rtcmIdentifier:"RTCM-001",realizationIdentifier:"UKO-001-SR-PYTHON-COMMAND-LINE",resolutionDisposition:"unique-authoritative-rtcm"}};
  const referenceExecution={
    pathIdentifier:"UKO-001-PTC-001×UKO-001-SR-PYTHON-COMMAND-LINE",declarationResourcePath:"service.yaml",declarationIdentityField:"service_realization_id",adapterArtifactReference:"adapter.py",realizationIdentifier:"UKO-001-SR-PYTHON-COMMAND-LINE",realizationType:"service-realization",ptcIdentifier:"UKO-001-PTC-001",rtcmIdentifier:"RTCM-001",invocationMode:"cli",executable:"python3",runtimeRequirement:"Python",runtimeResolutionBasis:"registered-adapter-capability-match",adapterResolution:{adapterId:"pc3.local-process.stdio.v1",adapterVersion:"1.0.0",capabilityId:"python-cli-stdout.v1",canonicalRuntime:"Python"},arguments:["--x","1"],orderedBindings:[{canonicalField:"x",option:"--x",value:"1"}],responseMediaType:"application/json",observationLocation:"stdout",rawObservationMustBePreserved:true,extractionExpression:"$.result.risk",semanticOutcome:"risk",normalizationDeclarations:["trim trailing newline"],rtcmDeclarationProvenance:{resourcePath:"rtcm.yaml",resourceSha256:"abc",location:"$",basis:"explicit-declaration"}
  };
  const received=interactions.receive({attempt:boundAttempt,expectedActiveContextId:"context-1",response:{...response(),externalProcess:{executable:"python3",arguments:["adapter.py"],exitCode:0,signal:null,timedOut:false,stderr:""},referenceExecution}});
  assert.equal(received.status,"received");
  const observation=observations.derive(received.interaction);
  assert.deepEqual(observation.publicationExerciseScope,boundAttempt.publicationExerciseBinding);
  assert.equal(observation.rawObservation.id,`raw-observation:${received.interaction.id}`);
  assert.equal(observation.rawObservation.value,'{"result":0.42}');
  assert.equal(observation.response.value,observation.rawObservation.value);
  assert.equal(observation.rawObservation.sha256,"66cb5e0380d80c60823500ddd1f6b3bf5ae6b263bbd886517d3a17c24b27ff66");
  assert.equal(observation.rawObservation.sourceClassification,"directly-observed");
  assert.equal(observation.extractionProvenance.disposition,"rtcm-declaration-captured-not-applied");
  assert.equal(observation.extractionProvenance.extractionExpression,"$.result.risk");
  assert.deepEqual(observation.normalizationRecords.map((item)=>[item.declaration,item.disposition]),[["trim trailing newline","declared-not-applied"]]);
  assert.equal(observation.rawObservation.value.endsWith("\n"),false);
  assert.equal(Object.isFrozen(observation.rawObservation),true);
  assert.equal(Object.isFrozen(observation.normalizationRecords),true);
  assert.deepEqual(observation.propertyClassifications.map((item)=>item.classification),["directly-observed","externally-reported","pc3-derived"]);
});

test("OBS-01 classifies generic response intake as externally reported and does not invent extraction provenance",()=>{
  const deps=dependencies(); const interactions=new ExecutionInteractionManager(deps); const observations=new RuntimeObservationManager(deps);
  const received=interactions.receive({attempt,expectedActiveContextId:"context-1",response:response("generic")});
  assert.equal(received.status,"received");
  const observation=observations.derive(received.interaction);
  assert.equal(observation.publicationExerciseScope,undefined);
  assert.equal(observation.rawObservation.sourceClassification,"externally-reported");
  assert.equal(observation.extractionProvenance.disposition,"not-available-to-interaction");
  assert.deepEqual(observation.normalizationRecords,[]);
});


test("assigns a monotonic session sequence across realizations and never reuses discarded numbers",()=>{
  const deps=dependencies(); const interactions=new ExecutionInteractionManager(deps); const observations=new RuntimeObservationManager(deps);
  const first=interactions.receive({attempt,expectedActiveContextId:"context-1",response:response("sequence-one")});
  assert.equal(first.status,"received");
  const observationOne=observations.derive(first.interaction);
  const secondAttempt={...attempt,id:"attempt-2",pathwayId:"path-2",endpointIdentifier:"SR-1",endpointType:"service-realization"};
  const second=interactions.receive({attempt:secondAttempt,expectedActiveContextId:"context-1",response:response("sequence-two")});
  assert.equal(second.status,"received");
  const observationTwo=observations.derive(second.interaction);
  assert.equal(observationOne.sessionSequence,1);
  assert.equal(observationTwo.sessionSequence,2);
  assert.equal(observations.discard("session-1","context-1",observationOne.id),"discarded");
  const thirdAttempt={...attempt,id:"attempt-3",pathwayId:"path-3",endpointIdentifier:"DP-1",endpointType:"deployment-package"};
  const third=interactions.receive({attempt:thirdAttempt,expectedActiveContextId:"context-1",response:response("sequence-three")});
  assert.equal(third.status,"received");
  const observationThree=observations.derive(third.interaction);
  assert.equal(observationThree.sessionSequence,3);
  assert.deepEqual(observations.list("session-1","context-1").map((item)=>item.sessionSequence),[2,3]);
});
