import test from "node:test";
import assert from "node:assert/strict";
import { PublicationExerciseModelManager } from "../dist/publication/publication-exercise-model-manager.js";

const provenance = Object.freeze({ resourcePath: "Publication-Test-Cases/x.yaml", resourceSha256: "a".repeat(64), location: "$", basis: "explicit-declaration" });
const ptc = (identifier) => Object.freeze({
  identifier, version: "1.0.0", status: "authoritative",
  canonicalInput: Object.freeze({ value: Object.freeze({ x: 1 }), canonicalFieldOrder: Object.freeze(["x"]) }),
  canonicalExpectedOutcome: Object.freeze({ outcomeKind: "successful computation", value: 2 }),
  comparisonSemantics: Object.freeze({ comparisonType: "exact" }),
  applicability: Object.freeze({ nonApplicabilityPermitted: true }), provenance
});
const realization = (identifier) => Object.freeze({ identifier, realizationType: "implementation-representation", provenance });
const applicability = (ptcIdentifier, realizationIdentifier, status = "applicable") => Object.freeze({ ptcIdentifier, realizationIdentifier, status, provenance });
const rtcm = (identifier, ptcIdentifier, realizationIdentifier, status = "authoritative") => Object.freeze({
  identifier, version: "1.0.0", status, ptcIdentifier, realizationIdentifier, realizationType: "implementation-representation",
  applicability: Object.freeze({ status: "applicable", conformanceAssertion: false }),
  inputDerivation: Object.freeze({ bindings: Object.freeze([]), constraints: Object.freeze([]) }),
  invocation: Object.freeze({ mode: "library", argumentOrder: Object.freeze([]), externalEnvironmentRequirements: Object.freeze([]), doesNotEmbedRuntime: true }),
  observationDerivation: Object.freeze({ normalizations: Object.freeze([]), rawObservationMustBePreserved: true }),
  comparison: Object.freeze({ representationSpecificHandling: Object.freeze([]), mustPermitFailResult: true }),
  evidenceLinkageRequirements: Object.freeze([]), limitations: Object.freeze([]), provenance
});

const manager = new PublicationExerciseModelManager();

test("derives complete, partial, none, and not-applicable readiness without asserting runtime success", () => {
  const realizations = [realization("IR-A"), realization("IR-B"), realization("IR-C"), realization("IR-D")];
  const model = {
    publicationTestCases: [ptc("PTC-1"), ptc("PTC-2")],
    applicabilityDeclarations: [
      applicability("PTC-1", "IR-A"), applicability("PTC-2", "IR-A"),
      applicability("PTC-1", "IR-B"), applicability("PTC-2", "IR-B"),
      applicability("PTC-1", "IR-C")
    ],
    realizationTestCaseManifestations: [
      rtcm("R-A1", "PTC-1", "IR-A"), rtcm("R-A2", "PTC-2", "IR-A"),
      rtcm("R-B1", "PTC-1", "IR-B")
    ]
  };
  const readiness = manager.summarizeReadiness(model, realizations);
  assert.deepEqual(readiness.map((item) => item.status), ["complete", "partial", "none", "not-applicable"]);
  assert.deepEqual(readiness[1].missingRtcmPtcIdentifiers, ["PTC-2"]);
  assert.match(readiness[0].statement, /Publication exercise readiness/);
  assert.doesNotMatch(readiness[0].statement, /execution success|conformance/i);
});

test("resolves one authoritative RTCM into an immutable external-boundary exercise", () => {
  const model = {
    publicationTestCases: [ptc("PTC-1")],
    applicabilityDeclarations: [applicability("PTC-1", "IR-A")],
    realizationTestCaseManifestations: [rtcm("RTCM-1", "PTC-1", "IR-A")]
  };
  const outcome = manager.resolve(model, [realization("IR-A")], "PTC-1", "IR-A");
  assert.equal(outcome.status, "resolved");
  assert.equal(outcome.exercise.rtcm.identifier, "RTCM-1");
  assert.equal(outcome.exercise.readiness, "publication-exercise-ready");
  assert.equal(outcome.exercise.executionBoundary, "external-to-publication");
  assert.equal(Object.isFrozen(outcome.exercise), true);
  assert.match(outcome.exercise.statement, /does not assert runtime availability/);
});

test("reports non-applicable, absent, and ambiguous pairings without inference", () => {
  const base = { publicationTestCases: [ptc("PTC-1")], applicabilityDeclarations: [], realizationTestCaseManifestations: [] };
  assert.equal(manager.resolve(base, [realization("IR-A")], "MISSING", "IR-A").status, "ptc-not-found");
  assert.equal(manager.resolve(base, [realization("IR-A")], "PTC-1", "MISSING").status, "realization-not-found");
  assert.equal(manager.resolve({ ...base, applicabilityDeclarations: [applicability("PTC-1", "IR-A", "not-applicable")] }, [realization("IR-A")], "PTC-1", "IR-A").status, "not-applicable");
  assert.equal(manager.resolve(base, [realization("IR-A")], "PTC-1", "IR-A").status, "rtcm-not-found");
  const ambiguous = manager.resolve({ ...base, applicabilityDeclarations: [applicability("PTC-1", "IR-A")], realizationTestCaseManifestations: [rtcm("B", "PTC-1", "IR-A"), rtcm("A", "PTC-1", "IR-A")] }, [realization("IR-A")], "PTC-1", "IR-A");
  assert.equal(ambiguous.status, "ambiguous-rtcm");
  assert.deepEqual(ambiguous.rtcmIdentifiers, ["A", "B"]);
});
