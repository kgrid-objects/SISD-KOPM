import test from "node:test";
import assert from "node:assert/strict";
import { ExecutionInteractionManager } from "../dist/interaction/execution-interaction-manager.js";

function dependencies() {
  let n = 0;
  return {
    clock: { now: () => "2026-07-17T12:00:00.000Z" },
    identifiers: { next: () => `interaction-${++n}` }
  };
}

const attempt = {
  id: "attempt-1",
  sessionId: "session-1",
  activeContextId: "context-1",
  publicationLoadId: "load-1",
  iorId: "ior-1",
  pathwayId: "path-1",
  endpointIdentifier: "IR-1",
  endpointType: "implementation-representation",
  input: { mediaType: "application/json", value: '{"x":1}' },
  requestedAt: "2026-07-17T11:00:00.000Z",
  status: "prepared",
  executionDisposition: "not-started",
  explanation: "none"
};

function response(id = "adapter-interaction-1") {
  return {
    externalInteractionId: id,
    receivedFrom: "adapter:test",
    outcome: "completed",
    responseMediaType: "application/json",
    responseValue: '{"result":0.42}',
    runtimeReportedAt: "2026-07-17T11:30:00Z",
    environmentIdentity: "external-test-runtime"
  };
}

test("records an immutable first-class Execution Interaction with request and response", () => {
  const manager = new ExecutionInteractionManager(dependencies());
  const result = manager.receive({ attempt, expectedActiveContextId: "context-1", response: response() });

  assert.equal(result.status, "received");
  assert.equal(result.interaction.id, "interaction-1");
  assert.equal(result.interaction.externalInteractionId, "adapter-interaction-1");
  assert.deepEqual(result.interaction.request, {
    mediaType: "application/json",
    value: '{"x":1}',
    requestedAt: "2026-07-17T11:00:00.000Z"
  });
  assert.equal(result.interaction.response.outcome, "completed");
  assert.equal(result.interaction.executionResponsibility, "external-environment");
  assert.equal(result.interaction.coordinationDisposition, "response-intake-only");
  assert.equal(result.interaction.verificationDisposition, "received-not-independently-verified");
  assert.equal(Object.isFrozen(result.interaction), true);
  assert.equal(Object.isFrozen(result.interaction.request), true);
  assert.equal(Object.isFrozen(result.interaction.response), true);
});

test("rejects stale, invalid, and duplicate external interaction identifiers while allowing retries", () => {
  const manager = new ExecutionInteractionManager(dependencies());

  assert.equal(manager.receive({ attempt, expectedActiveContextId: "stale", response: response() }).status, "stale-context");
  assert.equal(manager.receive({ attempt, expectedActiveContextId: "context-1", response: { ...response(), externalInteractionId: "" } }).status, "invalid-response");
  assert.equal(manager.receive({ attempt, expectedActiveContextId: "context-1", response: response("one") }).status, "received");
  assert.equal(manager.receive({ attempt, expectedActiveContextId: "context-1", response: response("one") }).status, "duplicate-external-interaction");
  assert.equal(manager.receive({ attempt, expectedActiveContextId: "context-1", response: response("two") }).status, "received");
  assert.equal(manager.list("session-1", "context-1", "attempt-1").length, 2);
});
