import assert from "node:assert/strict";
import test from "node:test";
import { LocalProcessExecutionAdapter } from "../dist/adapter/local-process-execution-adapter.js";
import { AdapterCapabilityResolutionError, ExecutionAdapterRegistry } from "../dist/adapter/execution-adapter-registry.js";

const attempt = {
  id:"attempt-1", sessionId:"session-1", activeContextId:"context-1", publicationLoadId:"load-1", iorId:"ior-1",
  pathwayId:"pathway-1", endpointIdentifier:"IR-ECHO", endpointType:"implementation-representation",
  input:{mediaType:"text/plain",value:"hello adapter"}, requestedAt:"2026-07-17T12:00:00.000Z", status:"prepared", executionDisposition:"not-started", explanation:"test"
};

test("local-process adapter executes outside PC3 and captures stdio", async () => {
  const adapter = new LocalProcessExecutionAdapter();
  const result = await adapter.execute(attempt, { executable: process.execPath, arguments:["-e","process.stdin.pipe(process.stdout)"] });
  assert.equal(result.outcome,"completed");
  assert.equal(result.responseValue,"hello adapter");
  assert.equal(result.process.exitCode,0);
  assert.equal(result.adapter.executionBoundary,"external-process");
  assert.equal(result.environmentDescription.environmentType,"local-process");
  assert.equal(result.environmentDescription.operatingSystem.architecture,process.arch);
  assert.equal(result.environmentDescription.runtime.executable,process.execPath);
});

test("local-process adapter records failed process without converting it to PC3 failure", async () => {
  const adapter = new LocalProcessExecutionAdapter();
  const result = await adapter.execute(attempt, { executable: process.execPath, arguments:["-e","process.stderr.write('bad'); process.exit(7)"] });
  assert.equal(result.outcome,"failed");
  assert.equal(result.process.exitCode,7);
  assert.equal(result.process.stderr,"bad");
});

test("SEC-01 terminates external output that exceeds the bounded capture", async () => {
  const adapter = new LocalProcessExecutionAdapter();
  await assert.rejects(
    () => adapter.execute(attempt, { executable: process.execPath, arguments:["-e","process.stdout.write(Buffer.alloc(5000001))"] }),
    /five-megabyte capture limit/
  );
});

test("EX-03B resolves one exact registered adapter capability without registration-order fallback", () => {
  const registry = new ExecutionAdapterRegistry([new LocalProcessExecutionAdapter()]);
  const match = registry.resolveCapability({ invocationMode:"cli", realizationType:"service-realization", observationLocation:"stdout", rawObservationMustBePreserved:true, runtimeRequirement:"Python 3" });
  assert.equal(match.adapter.descriptor.id,"pc3.local-process.stdio.v1");
  assert.equal(match.capabilityId,"python-cli-stdout.v1");
  assert.equal(match.canonicalRuntime,"Python");
  assert.equal(match.executable,"python3");
});

test("EX-03D exposes one bounded .NET 8 CLI Service Realization capability",()=>{
  const registry=new ExecutionAdapterRegistry([new LocalProcessExecutionAdapter()]);
  const match=registry.resolveCapability({invocationMode:"cli",realizationType:"service-realization",observationLocation:"stdout",rawObservationMustBePreserved:true,runtimeRequirement:"C# / .NET / Native AOT target"});
  assert.equal(match.capabilityId,"dotnet8-cli-stdout.v1");
  assert.equal(match.canonicalRuntime,".NET 8");
  assert.equal(match.executable,"dotnet");
  assert.throws(()=>registry.resolveCapability({invocationMode:"cli",realizationType:"implementation-representation",observationLocation:"stdout",rawObservationMustBePreserved:true,runtimeRequirement:".NET 8"}),error=>error.code==="adapter_capability_not_found");
});

test("EX-03E exposes one bounded Python HTTP response-body Service Realization capability",()=>{
  const registry=new ExecutionAdapterRegistry([new LocalProcessExecutionAdapter()]);
  const match=registry.resolveCapability({invocationMode:"http",realizationType:"service-realization",observationLocation:"response-body",rawObservationMustBePreserved:true,runtimeRequirement:"Python"});
  assert.equal(match.capabilityId,"python-http-response-body.v1");
  assert.equal(match.canonicalRuntime,"Python");
  assert.equal(match.executable,"python3");
  for(const request of [
    {invocationMode:"http",realizationType:"implementation-representation",observationLocation:"response-body",rawObservationMustBePreserved:true,runtimeRequirement:"Python"},
    {invocationMode:"http",realizationType:"service-realization",observationLocation:"stdout",rawObservationMustBePreserved:true,runtimeRequirement:"Python"},
    {invocationMode:"http",realizationType:"service-realization",observationLocation:"response-body",rawObservationMustBePreserved:true,runtimeRequirement:"Java"}
  ]) assert.throws(()=>registry.resolveCapability(request),error=>error.code==="adapter_capability_not_found");
});

test("EX-03B rejects zero and multiple capability matches with distinct bounded outcomes", () => {
  const adapter = new LocalProcessExecutionAdapter();
  const registry = new ExecutionAdapterRegistry([adapter]);
  assert.throws(
    () => registry.resolveCapability({ invocationMode:"cli", realizationType:"service-realization", observationLocation:"stdout", rawObservationMustBePreserved:true, runtimeRequirement:"Rust" }),
    (error) => error instanceof AdapterCapabilityResolutionError && error.code === "adapter_capability_not_found"
  );
  const duplicate = { descriptor:{ ...adapter.descriptor, id:"test.duplicate-python-adapter" }, execute: (...args) => adapter.execute(...args) };
  const ambiguous = new ExecutionAdapterRegistry([adapter, duplicate]);
  assert.throws(
    () => ambiguous.resolveCapability({ invocationMode:"cli", realizationType:"service-realization", observationLocation:"stdout", rawObservationMustBePreserved:true, runtimeRequirement:"Python" }),
    (error) => error instanceof AdapterCapabilityResolutionError && error.code === "adapter_capability_ambiguous" && /will not choose by registration order/.test(error.message)
  );
});
