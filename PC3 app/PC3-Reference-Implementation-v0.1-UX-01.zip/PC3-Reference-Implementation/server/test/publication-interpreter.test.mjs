import assert from "node:assert/strict";
import test from "node:test";
import { zipSync } from "fflate";
import { isoInstant, publicationLoadId } from "../dist/domain/index.js";
import { InMemoryZipPublicationSourceAdapter } from "../dist/infrastructure/publication/in-memory-zip-publication-source-adapter.js";
import { PublicationInterpreter } from "../dist/publication/publication-interpreter.js";

const clock = { now: () => isoInstant("2026-07-16T18:00:00.000Z") };
const identifiers = { next: () => "interpretation-001" };
const interpreter = new PublicationInterpreter({ clock, identifiers });

async function acquire(files) {
  const bytes = zipSync(Object.fromEntries(Object.entries(files).map(([path, text]) => [path, new TextEncoder().encode(text)])));
  return new InMemoryZipPublicationSourceAdapter(bytes, "fixture.zip").acquire({ kind: "uploaded-archive", locator: "fixture.zip" });
}

function loadRecord(resources) {
  return {
    id: publicationLoadId("load-001"),
    source: { kind: "uploaded-archive", locator: "fixture.zip" },
    loadedAt: isoInstant("2026-07-16T17:59:00.000Z"),
    resourceCount: resources.length,
    resources: resources.map(({ path, byteLength, sha256 }) => ({ path, byteLength, sha256 }))
  };
}

test("interprets explicit JSON and YAML declarations with provenance", async () => {
  const acquired = await acquire({
    "metadata/publication.yaml": `publication:\n  identifier: UKO-001\n  version: 1.0\n  title: OHTS Risk\nimplementationRepresentations:\n  - identifier: IR-PY\n    artifactReference: impl/model.py\nserviceRealizations:\n  - identifier: SR-REST\nrelationships:\n  - type: built-up-from\n    source: SR-REST\n    target: IR-PY\n`,
    "notes/readme.txt": "not interpreted"
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationIdentity.value.declaredIdentifier, "UKO-001");
  assert.equal(result.realizations.length, 2);
  assert.equal(result.relationships.length, 1);
  assert.equal(result.realizations[0].provenance.basis, "explicit-declaration");
  assert.equal(result.realizations[0].provenance.resourcePath, "metadata/publication.yaml");
  assert.deepEqual(result.interpretedResourcePaths, ["metadata/publication.yaml"]);
});

test("does not promote directory names or filenames into architectural meaning", async () => {
  const acquired = await acquire({
    "Implementation Portfolio/IR-PY/model.py": "print('hello')",
    "Service Realizations/SR-REST/readme.txt": "service"
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.realizations.length, 0);
  assert.equal(result.relationships.length, 0);
  assert.equal(result.limitations[0].code, "no_supported_declarations");
});

test("retains deterministic interpretation while reporting conflicts and malformed metadata", async () => {
  const acquired = await acquire({
    "a.json": JSON.stringify({ publication: { identifier: "UKO-001", version: "1.0" } }),
    "b.yaml": "publication:\n  identifier: UKO-002\n  version: 2.0\n",
    "broken-metadata.json": "{bad"
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationIdentity.value.declaredIdentifier, "UKO-001");
  assert.ok(result.limitations.some((item) => item.code === "conflicting_publication_identity"));
  assert.ok(result.limitations.some((item) => item.code === "malformed_declaration_document"));
});

test("ranks authoritative describes Publication identity above lower-authority summaries", async () => {
  const acquired = await acquire({
    "Publication-Metadata/uko-publication-metadata.yaml": `describes:\n  '@type': uko:Publication\n  identifier: UKO-001\n  version: 1.1\n  title: Accepted publication\n`,
    "Publication-Test-Cases/PTC-INTEGRITY-SUMMARY.yaml": `publication:\n  identifier: UKO-001-PTC-INTEGRITY-VERIFICATION-SUMMARY\n  version: 1.0\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationIdentity.value.declaredIdentifier, "UKO-001");
  assert.equal(result.publicationIdentity.provenance.location, "$.describes");
  assert.equal(result.limitations.some((item) => item.code === "conflicting_publication_identity"), false);
});

test("keeps _Development resources acquired but excludes them from operational discovery", async () => {
  const acquired = await acquire({
    "Publication-Metadata/uko-publication-metadata.yaml": `describes:\n  '@type': uko:Publication\n  identifier: UKO-001\n`,
    "_Development/template.yaml": `realizations:\n  - type: service-realization\nrelationships:\n  - source: IR-DRAFT\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(acquired.resources.length, 2);
  assert.equal(result.realizations.length, 0);
  assert.equal(result.limitations.some((item) => item.code === "incomplete_realization_declaration"), false);
  assert.equal(result.limitations.some((item) => item.code === "incomplete_relationship_declaration"), false);
});

test("treats repeated identical relationships as corroboration and conflicting predicates as limitations", async () => {
  const acquired = await acquire({
    "metadata.yaml": `implementationRepresentations:\n  - identifier: IR-ONE\nserviceRealizations:\n  - identifier: SR-ONE\nrelationships:\n  - type: is-served-by\n    source: IR-ONE\n    target: SR-ONE\n  - type: is-served-by\n    source: IR-ONE\n    target: SR-ONE\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.relationships.length, 1);
  assert.equal(result.limitations.some((item) => item.code === "duplicate_declaration"), false);

  const conflicting = await acquire({
    "metadata.yaml": `relationships:\n  - type: is-served-by\n    source: IR-ONE\n    target: SR-ONE\n  - type: contradicts\n    source: IR-ONE\n    target: SR-ONE\n`
  });
  const conflictResult = await interpreter.interpret(loadRecord(conflicting.resources), conflicting);
  assert.equal(conflictResult.limitations.some((item) => item.code === "publication_relationship_inconsistency"), true);
});

test("reports incomplete and unsupported declarations rather than repairing them", async () => {
  const acquired = await acquire({
    "metadata.yaml": `realizations:\n  - identifier: X\n    type: mystery-runtime\n  - type: service-realization\nrelationships:\n  - type: built-up-from\n    source: SR-X\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.realizations.length, 0);
  assert.equal(result.relationships.length, 0);
  assert.ok(result.limitations.some((item) => item.code === "unsupported_realization_type"));
  assert.ok(result.limitations.some((item) => item.code === "incomplete_realization_declaration"));
  assert.ok(result.limitations.some((item) => item.code === "incomplete_relationship_declaration"));
});

test("interprets authoritative nested UKO Instance Metadata and adjacent-layer references", async () => {
  const acquired = await acquire({
    "03-Service-Realizations/categories/gRPC/realizations/python-grpc/instance-metadata.yaml": `describes:\n  identifier: UKO-001-SR-PYTHON-GRPC\n  title: Python gRPC Service Realization\n  parentLayerIdentifier: UKO-LAYER-SR\n  repositoryPath: 03-Service-Realizations/categories/gRPC/realizations/python-grpc\n  instanceArchitecture:\n    adjacentLayerRelationships:\n      precedingLayer:\n        relationship: depends upon and makes invocable\n        explicitlyReferencedInstances:\n          - identifier: UKO-001-RCI-PYTHON-IR-001\n      followingLayer:\n        relationship: is packaged by\n        explicitlyReferencedInstances:\n          - identifier: UKO-001-DP-OCI-PYTHON-GRPC\n`,
    "02-Implementation-Representations/python/instance-metadata.yaml": `describes:\n  identifier: UKO-001-RCI-PYTHON-IR-001\n  parentLayerIdentifier: UKO-LAYER-IR\n  repositoryPath: 02-Implementation-Representations/python\n`,
    "04-Deployment-Packages/grpc/instance-metadata.yaml": `describes:\n  identifier: UKO-001-DP-OCI-PYTHON-GRPC\n  parentLayerIdentifier: UKO-LAYER-DP\n  repositoryPath: 04-Deployment-Packages/grpc\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.realizations.length, 3);
  assert.deepEqual(result.realizations.map((item) => item.realizationType).sort(), ["deployment-package", "implementation-representation", "service-realization"]);
  assert.ok(result.realizations.every((item) => item.provenance.location === "$.describes"));
  assert.equal(result.realizations.find((item) => item.identifier === "UKO-001-SR-PYTHON-GRPC")?.title, "Python gRPC Service Realization");
  assert.ok(result.relationships.some((item) => item.sourceIdentifier === "UKO-001-RCI-PYTHON-IR-001" && item.targetIdentifier === "UKO-001-SR-PYTHON-GRPC"));
  assert.ok(result.relationships.some((item) => item.sourceIdentifier === "UKO-001-SR-PYTHON-GRPC" && item.targetIdentifier === "UKO-001-DP-OCI-PYTHON-GRPC"));
});

test("does not treat CKS Instance Metadata as an executable realization", async () => {
  const acquired = await acquire({
    "01-Computable-Knowledge-Specification/instance-metadata.yaml": `describes:\n  identifier: UKO-001-CKS-001\n  parentLayerIdentifier: UKO-LAYER-CKS\n  repositoryPath: 01-Computable-Knowledge-Specification\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.realizations.length, 0);
});

test("does not mistake generic artifact identifiers or type fields for publication or realization declarations", async () => {
  const acquired = await acquire({
    "artifact.json": JSON.stringify({ identifier: "artifact-001", type: "service", value: 42 }),
    "results/output.json": "not-json-output"
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationIdentity, undefined);
  assert.equal(result.realizations.length, 0);
  assert.equal(result.limitations.filter((item) => item.code === "malformed_declaration_document").length, 0);
});

test("resolves complementary SR bindings and DP target declarations through authoritative repository references", async () => {
  const acquired = await acquire({
    "02-Implementation-Representations/python/instance-metadata.yaml": `describes:\n  identifier: IR-PY\n  parentLayerIdentifier: UKO-LAYER-IR\n  repositoryPath: 02-Implementation-Representations/python\n`,
    "03-Service-Realizations/REST/python-rest/instance-metadata.yaml": `describes:\n  identifier: SR-REST\n  parentLayerIdentifier: UKO-LAYER-SR\n  repositoryPath: 03-Service-Realizations/REST/python-rest\n`,
    "03-Service-Realizations/REST/python-rest/binding.yaml": `service_realization_id: python-rest\nbindsToImplementationRepresentations:\n  - IR-PY\n`,
    "04-Deployment-Packages/DP-REST/instance-metadata.yaml": `describes:\n  identifier: DP-REST\n  parentLayerIdentifier: UKO-LAYER-DP\n  repositoryPath: 04-Deployment-Packages/DP-REST\n`,
    "04-Deployment-Packages/DP-REST/package.yaml": `targetsServiceRealizations:\n  - repositoryPath: 03-Service-Realizations/REST/python-rest\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.ok(result.relationships.some((item) => item.sourceIdentifier === "IR-PY" && item.targetIdentifier === "SR-REST"));
  assert.ok(result.relationships.some((item) => item.sourceIdentifier === "SR-REST" && item.targetIdentifier === "DP-REST"));
  assert.equal(result.limitations.filter((item) => item.code === "publication_relationship_inconsistency").length, 0);
});

test("interprets publication-defined input objects with inline and referenced content", async () => {
  const acquired = await acquire({
    "metadata/publication.yaml": `publication:\n  identifier: UKO-INPUTS\ninputObjects:\n  - identifier: INPUT-INLINE\n    title: Inline input\n    mediaType: application/json\n    value:\n      risk: 0.2\n  - identifier: INPUT-FILE\n    title: Referenced input\n    artifactReference: ../inputs/example.json\n    schemaReference: schemas/input.schema.json\n`,
    "inputs/example.json": `{"risk":0.4}`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.inputObjects.length, 2);
  assert.equal(result.inputObjects[0].identifier, "INPUT-INLINE");
  assert.equal(result.inputObjects[0].contentDisposition, "explicit-inline");
  assert.match(result.inputObjects[0].value, /"risk": 0.2/);
  assert.equal(result.inputObjects[1].contentDisposition, "referenced-resource");
  assert.equal(result.inputObjects[1].value, `{"risk":0.4}`);
  assert.equal(result.inputObjects[1].provenance.resourcePath, "metadata/publication.yaml");
  assert.equal(result.capabilityProfile.kind, "legacy-input");
  assert.equal(result.capabilityProfile.exerciseAuthority, "standalone-input-objects");
});

test("retains metadata-only input declarations without inventing content", async () => {
  const acquired = await acquire({
    "inputs/instance-metadata.yaml": `describes:\n  identifier: INPUT-DECLARED\n  title: Declared input\n  type: InputObject\n  mediaType: application/fhir+json\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.inputObjects.length, 1);
  assert.equal(result.inputObjects[0].contentDisposition, "metadata-only");
  assert.equal(result.inputObjects[0].value, undefined);
});

test("discovers authoritative PTCs and RTCMs and builds bidirectional exercise indexes", async () => {
  const acquired = await acquire({
    "metadata/publication.yaml": `publication:\n  identifier: UKO-PTC\n  version: 1.1\n`,
    "01-Computable-Knowledge-Specification/cks.docx": "canonical capability specification",
    "02-Implementation-Representations/ir-one/instance-metadata.yaml": `describes:\n  identifier: IR-ONE\n  parentLayerIdentifier: UKO-LAYER-IR\n  repositoryPath: 02-Implementation-Representations/ir-one\n`,
    "Publication-Test-Cases/PTC-001/publication-test-case.yaml": `identifier: PTC-001\nversion: 1.0.0\ntitle: Nominal Exercise\nstatus: authoritative\npublicationIdentifier: UKO-PTC\npublishedCapabilitySpecification: ../../01-Computable-Knowledge-Specification/cks.docx\nclassification: computational-behavior\npurpose: Exercise the capability.\napplicability:\n  applicableRealizationCount: 1\n  notApplicableRealizationCount: 0\n  nonApplicabilityIsPermitted: true\ncanonicalInputObject:\n  canonicalPredictorOrder: [x]\n  objectType: predictor set\n  validity: valid\n  properties:\n    x: 2\ncanonicalExpectedOutcome:\n  outcomeKind: successful computation\n  semanticResult:\n    value: 4\n  expectedValueAuthority: CKS\ncomparisonSemantics:\n  comparisonType: exact\n  normativeValuePath: semanticResult.value\n  absoluteTolerance: 0\n  roundingPermittedBeforeComparison: false\napplicabilityDetermination:\n  matrixReference: matrix.yaml\n  applicableRealizationInstances: [IR-ONE]\n`,
    "02-Implementation-Representations/ir-one/Publication-Test-Case-Manifestations/PTC-001/realization-test-case-manifestation.yaml": `identifier: RTCM-PTC-001-IR-ONE\nversion: 1.0.0\nstatus: authoritative\ncanonicalOrigin:\n  ptcIdentifier: PTC-001\ncomplementedRealization:\n  identifier: IR-ONE\n  layer: IR\napplicabilityBasis:\n  status: applicable\n  pairingKey: PTC-001|IR-ONE\n  conformanceAssertion: false\ninputDerivation:\n  canonicalInputReference: canonicalInputObject\n  concreteRepresentation:\n    mediaType: application/json\n    inlinePermitted: true\n  bindings:\n    - canonicalField: x\n      localBinding: argument x\n      transformation: identity\n  derivationConstraints: [canonical values unchanged]\ninvocation:\n  mode: library\n  entryPoint: calculate\n  argumentOrder: [x]\n  externalEnvironmentRequirements: [external runtime]\n  doesNotEmbedRuntime: true\nobservationDerivation:\n  rawObservationLocation: return-value\n  extractionExpression: result\n  semanticOutcome: result\n  normalizations: []\n  rawObservationMustBePreserved: true\ncomparison:\n  canonicalExpectedOutcomeReference: canonicalExpectedOutcome\n  comparisonType: exact\n  toleranceReference: 0\n  representationSpecificHandling: []\n  mustPermitFailResult: true\nevidenceLinkageRequirements: [ptcIdentifier, rtcmIdentifier, rawObservation]\nlimitations: [Declarative only.]\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationTestCases.length, 1);
  assert.equal(result.realizationTestCaseManifestations.length, 1);
  assert.equal(result.publicationTestCaseApplicability.length, 1);
  assert.equal(result.exerciseReadiness[0].status, "complete");
  assert.deepEqual(result.exerciseDiscoveryIndex.ptcIdentifiers, ["PTC-001"]);
  assert.deepEqual(result.exerciseDiscoveryIndex.ptcToRealizationIdentifiers["PTC-001"], ["IR-ONE"]);
  assert.deepEqual(result.exerciseDiscoveryIndex.realizationToPtcIdentifiers["IR-ONE"], ["PTC-001"]);
  assert.equal(result.exerciseDiscoveryIndex.pairingToRtcmIdentifier["PTC-001|IR-ONE"], "RTCM-PTC-001-IR-ONE");
  assert.equal(result.publicationTestCases[0].canonicalInput.value.x, 2);
  assert.equal(result.publicationTestCases[0].canonicalExpectedOutcome.value, 4);
  assert.equal(result.realizationTestCaseManifestations[0].invocation.doesNotEmbedRuntime, true);
  assert.equal(result.resolvedExercises.length, 1);
  assert.equal(result.resolvedExercises[0].ptc.identifier, "PTC-001");
  assert.equal(result.resolvedExercises[0].realization.identifier, "IR-ONE");
  assert.equal(result.resolvedExercises[0].rtcm.identifier, "RTCM-PTC-001-IR-ONE");
  assert.equal(result.resolvedExercises[0].executionBoundary, "external-to-publication");
  assert.equal(result.publicationValidation.status, "valid");
  assert.equal(result.publicationValidation.issueCount, 0);
  assert.equal(result.publicationValidation.checkedApplicabilityPairingCount, 1);
  assert.equal(result.capabilityProfile.kind, "ptc");
  assert.equal(result.capabilityProfile.exerciseAuthority, "publication-test-cases");
});

test("authoritative PTC architecture outranks coexisting standalone inputs without discarding them", async () => {
  const acquired = await acquire({
    "metadata/publication.yaml": `publication:\n  identifier: UKO-MIXED-AUTHORITY\ninputObjects:\n  - identifier: LEGACY-INPUT\n    mediaType: application/json\n    value: { x: 2 }\nimplementationRepresentations:\n  - identifier: IR-ONE\n`,
    "cks.docx": "canonical capability specification",
    "ptc.yaml": `identifier: PTC-ONE\nversion: 1.0.0\ntitle: Coexistence exercise\nstatus: authoritative\npublicationIdentifier: UKO-MIXED-AUTHORITY\npublishedCapabilitySpecification: cks.docx\npurpose: Exercise the published capability.\napplicability:\n  applicableRealizationCount: 1\n  notApplicableRealizationCount: 0\n  nonApplicabilityIsPermitted: true\ncanonicalInputObject:\n  canonicalPredictorOrder: [x]\n  objectType: predictor set\n  validity: valid\n  properties:\n    x: 2\ncanonicalExpectedOutcome:\n  outcomeKind: successful computation\n  semanticResult:\n    value: 4\n  expectedValueAuthority: CKS\ncomparisonSemantics:\n  comparisonType: exact\n  normativeValuePath: semanticResult.value\n  absoluteTolerance: 0\n  roundingPermittedBeforeComparison: false\napplicabilityDetermination:\n  matrixReference: matrix.yaml\n  applicableRealizationInstances: [IR-ONE]\n`,
    "rtcm.yaml": `identifier: RTCM-ONE\nversion: 1.0.0\nstatus: authoritative\ncanonicalOrigin:\n  ptcIdentifier: PTC-ONE\ncomplementedRealization:\n  identifier: IR-ONE\n  layer: IR\napplicabilityBasis:\n  status: applicable\n  pairingKey: PTC-ONE|IR-ONE\n  conformanceAssertion: false\ninputDerivation:\n  canonicalInputReference: canonicalInputObject\n  concreteRepresentation:\n    mediaType: application/json\n    inlinePermitted: true\n  bindings:\n    - canonicalField: x\n      localBinding: argument x\n      transformation: identity\ninvocation:\n  mode: library\n  entryPoint: calculate\n  argumentOrder: [x]\n  externalEnvironmentRequirements: [external runtime]\n  doesNotEmbedRuntime: true\nobservationDerivation:\n  rawObservationLocation: return-value\n  extractionExpression: result\n  semanticOutcome: result\n  normalizations: []\n  rawObservationMustBePreserved: true\ncomparison:\n  canonicalExpectedOutcomeReference: canonicalExpectedOutcome\n  comparisonType: exact\n  toleranceReference: 0\n  representationSpecificHandling: []\n  mustPermitFailResult: true\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationValidation.status, "valid");
  assert.equal(result.capabilityProfile.kind, "ptc");
  assert.equal(result.capabilityProfile.standaloneInputCapability, "subordinate");
  assert.equal(result.inputObjects.length, 1);
});

test("incomplete explicit PTC signals produce an explained ambiguous mixed profile", async () => {
  const acquired = await acquire({
    "metadata.yaml": `inputObjects:\n  - identifier: LEGACY-INPUT\n    mediaType: application/json\n    value: { x: 2 }\n`,
    "incomplete-ptc.yaml": `identifier: PTC-INCOMPLETE\ncanonicalInputObject:\n  value: { x: 2 }\ncanonicalExpectedOutcome:\n  value: 4\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationTestCases.length, 0);
  assert.equal(result.inputObjects.length, 1);
  assert.equal(result.capabilityProfile.kind, "ambiguous-mixed");
  assert.equal(result.capabilityProfile.exerciseAuthority, "unresolved");
  assert.equal(result.capabilityProfile.standaloneInputCapability, "preserved");
});

test("does not infer PTCs or RTCMs from suggestive paths without complete declarations", async () => {
  const acquired = await acquire({
    "Publication-Test-Cases/PTC-FAKE/readme.yaml": `identifier: PTC-FAKE\ntitle: Not a complete declaration\n`,
    "some/Publication-Test-Case-Manifestations/RTCM-FAKE.yaml": `identifier: RTCM-FAKE\nstatus: authoritative\n`
  });
  const result = await interpreter.interpret(loadRecord(acquired.resources), acquired);
  assert.equal(result.publicationTestCases.length, 0);
  assert.equal(result.realizationTestCaseManifestations.length, 0);
  assert.deepEqual(result.exerciseDiscoveryIndex.ptcIdentifiers, []);
  assert.equal(result.publicationValidation.status, "not-applicable");
});
