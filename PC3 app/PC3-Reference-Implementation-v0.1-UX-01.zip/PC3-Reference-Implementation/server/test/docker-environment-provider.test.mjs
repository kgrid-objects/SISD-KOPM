import assert from "node:assert/strict";
import test from "node:test";
import { PinnedDockerEnvironmentProvider, PC3_DOTNET8_DOCKER_IMAGE, PC3_PYTHON_DOCKER_IMAGE } from "../dist/environment/docker-environment-provider.js";

const attempt = { id:"attempt-1",sessionId:"session-1",activeContextId:"context-1",publicationLoadId:"load-1",iorId:"ior-1",pathwayId:"path-1",endpointIdentifier:"SR-1",endpointType:"service-realization",exerciseDisposition:"canonical",input:{mediaType:"application/json",value:"{}",source:"publication-canonical"},requestedAt:"2026-07-19T12:00:00.000Z",status:"prepared",executionDisposition:"not-started",explanation:"test" };
const plan = { adapterResolution:{canonicalRuntime:"Python",adapterId:"adapter-1",adapterVersion:"1",capabilityId:"python-cli"}, executable:"python3", adapterArtifactReference:"services/python/adapter.py", arguments:["--value","1"] };

function fixture({ adapterOutcome="completed", cleanupExitCode=0, responseValue="result\n" }={}) {
  const commands=[]; let request;
  const runner={run:async(executable,args)=>{commands.push([executable,...args]); if(args[0]==="version") return {exitCode:0,signal:null,stdout:"29.0\n",stderr:"",timedOut:false}; if(args[0]==="image") return {exitCode:0,signal:null,stdout:"sha256:observed-image\n",stderr:"",timedOut:false}; return {exitCode:cleanupExitCode,signal:null,stdout:"",stderr:cleanupExitCode?"cleanup denied":"",timedOut:false};}};
  const adapter={descriptor:{id:"adapter-1",name:"Adapter",version:"1",kind:"local-process",transport:"stdio",supports:["exercise-attempt"],executionBoundary:"external-process",capabilities:[],explanation:"test"},execute:async(_attempt,input)=>{request=input; return {adapter:adapter.descriptor,environmentDescription:{environmentType:"local-process",executionBoundary:"external-process",externalEnvironmentIdentifier:"docker",operatingSystem:{platform:"host",release:"host",architecture:"host"},runtime:{executable:"docker"},workingDirectory:"/tmp"},externalInteractionId:"docker:test",receivedFrom:"adapter-1",environmentIdentity:"docker",outcome:adapterOutcome,responseMediaType:"text/plain",responseValue,runtimeReportedAt:"2026-07-19T12:00:00.000Z",process:{executable:"docker",arguments:input.arguments,exitCode:adapterOutcome==="completed"?0:7,signal:null,timedOut:false,stderr:adapterOutcome==="completed"?"":"failed"}};}};
  return {provider:new PinnedDockerEnvironmentProvider(runner),adapter,commands,get request(){return request;}};
}

test("EX-03C requires an immutable mapped image and performs readiness without pulling", async()=>{
  const mutable=new PinnedDockerEnvironmentProvider({run:async()=>({exitCode:0,signal:null,stdout:"ok",stderr:"",timedOut:false})},"docker",new Map([["python","python:3.12-slim"]]));
  assert.equal((await mutable.assess("Python")).code,"docker_image_not_immutable");
  const {provider,commands}=fixture(); const support=await provider.assess("Python");
  assert.equal(support.ready,true); assert.equal(support.imageReference,PC3_PYTHON_DOCKER_IMAGE);
  const dotnetSupport=await provider.assess(".NET 8");assert.equal(dotnetSupport.ready,true);assert.equal(dotnetSupport.imageReference,PC3_DOTNET8_DOCKER_IMAGE);
  assert.deepEqual(commands.map((item)=>item.slice(1,3)),[["version","--format"],["image","inspect"],["version","--format"],["image","inspect"]]);
  assert.equal(commands.some((item)=>item.includes("pull")),false);
});

test("EX-03C reports unavailable Docker and absent pinned images without changing Docker state",async()=>{
  const stopped=new PinnedDockerEnvironmentProvider({run:async()=>({exitCode:1,signal:null,stdout:"",stderr:"daemon unavailable",timedOut:false})});
  assert.equal((await stopped.assess("Python")).code,"docker_daemon_unavailable");
  const commands=[]; const missing=new PinnedDockerEnvironmentProvider({run:async(_executable,args)=>{commands.push(args); return args[0]==="version"?{exitCode:0,signal:null,stdout:"29\n",stderr:"",timedOut:false}:{exitCode:1,signal:null,stdout:"",stderr:"not found",timedOut:false};}});
  const support=await missing.assess("Python"); assert.equal(support.code,"docker_image_unavailable"); assert.match(support.reason,/docker pull/); assert.equal(commands.some((args)=>args.includes("pull")),false);
});

test("EX-03C constructs a constrained disposable container and records immutable environment identity",async()=>{
  const fx=fixture(); const result=await fx.provider.execute({attempt,adapter:fx.adapter,plan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/services/python/adapter.py"});
  const args=fx.request.arguments;
  for(const required of ["--network","none","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges","--cpus","1.0","--memory","256m","--memory-swap","--pids-limit","128","--user","65532:65532","--tmpfs","/tmp:rw,noexec,nosuid,size=64m","--mount","--workdir","/workspace",PC3_PYTHON_DOCKER_IMAGE,"python3","/workspace/services/python/adapter.py","--value","1"]) assert.ok(args.includes(required),required);
  assert.match(args[args.indexOf("--mount")+1],/dst=\/workspace,readonly$/);
  assert.equal(result.environmentDescription.environmentType,"docker-container");
  assert.equal(result.environmentDescription.container.imageId,"sha256:observed-image");
  assert.equal(result.environmentDescription.container.cleanupDisposition,"removed");
  assert.deepEqual(fx.commands.at(-1).slice(1,3),["rm","--force"]);
});

test("SEC-01 refuses an unmapped runtime before invoking an execution adapter",async()=>{
  const fx=fixture(); let called=false;
  const guardedAdapter={...fx.adapter,execute:async()=>{called=true;throw new Error("must not execute");}};
  await assert.rejects(
    ()=>fx.provider.execute({attempt,adapter:guardedAdapter,plan:{...plan,adapterResolution:{...plan.adapterResolution,canonicalRuntime:"Unregistered Runtime"}},publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/adapter"}),
    error=>error.code==="docker_image_mapping_not_found"
  );
  assert.equal(called,false);
});

test("EX-03C cleans up after an exceptional container result and makes cleanup failure explicit",async()=>{
  const failed=fixture({adapterOutcome:"failed"}); const result=await failed.provider.execute({attempt,adapter:failed.adapter,plan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/adapter.py"});
  assert.equal(result.outcome,"failed"); assert.equal(failed.commands.at(-1)[1],"rm");
  const unclean=fixture({cleanupExitCode:1});
  await assert.rejects(()=>unclean.provider.execute({attempt,adapter:unclean.adapter,plan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/adapter.py"}),error=>error.code==="docker_cleanup_failed");
});

test("SEC-01 forces container cleanup when adapter execution throws",async()=>{
  const fx=fixture();
  const throwing={...fx.adapter,execute:async()=>{throw new Error("capture bound exceeded");}};
  await assert.rejects(
    ()=>fx.provider.execute({attempt,adapter:throwing,plan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/adapter.py"}),
    /capture bound exceeded/
  );
  assert.deepEqual(fx.commands.at(-1).slice(1,3),["rm","--force"]);
});

test("EX-03-NP1 mounts separate bridge infrastructure and preserves the transferred return envelope",async()=>{
  const envelope='{"diagnosticStderr":"warn","diagnosticStdout":"note","schema":"pc3.python-library-return.v1","status":"returned","value":0.1234}';
  const fx=fixture({responseValue:envelope});
  const libraryPlan={...plan,invocationMode:"library",adapterArtifactReference:undefined,arguments:[],libraryInvocation:{bridgeId:"pc3.python-library-return.v1",sourceRootReference:"python/src",entryPoint:"uko_ohts.compute",entryPointKind:"language_function",executionContractResourcePath:"python/execution_contract.yaml",namedBindings:[{canonicalField:"age_years",rtcmLocalBinding:"age",parameter:"age_years",value:55}]}};
  const result=await fx.provider.execute({attempt,adapter:fx.adapter,plan:libraryPlan,publicationWorkspace:"/tmp/pc3-publication",infrastructureWorkspace:"/tmp/pc3-infrastructure"});
  const args=fx.request.arguments;
  assert.ok(args.some(value=>/src=\/tmp\/pc3-infrastructure,dst=\/pc3-infrastructure,readonly/.test(value)));
  assert.ok(args.includes("/pc3-infrastructure/python-library-bridge.py"));assert.ok(args.includes("uko_ohts.compute"));
  assert.equal(result.responseValue,"0.1234");assert.equal(result.libraryReturn.transferredEnvelope,envelope);assert.equal(result.libraryReturn.diagnosticStdout,"note");assert.match(result.libraryReturn.transferredEnvelopeSha256,/^[a-f0-9]{64}$/);
});

test("EX-03D-C3 launches .NET with SDK diagnostics suppressed and preserves adapter stdout byte-for-byte",async()=>{
  const cleanAdapterStdout='{"status":"success","result":{"risk":0.1234}}\n';
  const fx=fixture({responseValue:cleanAdapterStdout});
  const dotnetPlan={...plan,adapterResolution:{...plan.adapterResolution,canonicalRuntime:".NET 8",capabilityId:"dotnet8-cli-stdout.v1"},executable:"dotnet",adapterArtifactReference:"services/csharp/adapter/Program.cs",arguments:["--age-years","55"],dotnetCliInvocation:{bridgeId:"pc3.dotnet-cli-source.v1",projectFileReference:"services/csharp/adapter/Uko.csproj",adapterEntryPointReference:"services/csharp/adapter/Program.cs",implementationSourceRootReference:"implementation/csharp",implementationProjectReference:"implementation/csharp/UkoOhts.csproj",serviceDeclarationReference:"services/csharp/service.yaml",targetFramework:"net8.0"}};
  const result=await fx.provider.execute({attempt,adapter:fx.adapter,plan:dotnetPlan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/services/csharp/adapter/Program.cs",infrastructureWorkspace:"/tmp/pc3-infrastructure"});
  const args=fx.request.arguments;
  assert.ok(args.includes(PC3_DOTNET8_DOCKER_IMAGE));
  assert.ok(args.includes("dotnet"));
  assert.ok(args.includes("/pc3-infrastructure/pc3-dotnet-cli-bridge.csproj"));
  const mounts=args.flatMap((value,index)=>value==="--mount"?[args[index+1]]:[]);
  assert.ok(mounts.some(value=>/dst=\/workspace,readonly$/.test(value)));
  assert.ok(mounts.some(value=>/dst=\/pc3-infrastructure$/.test(value)));
  assert.equal(mounts.some(value=>/dst=\/pc3-infrastructure,readonly$/.test(value)),false);
  assert.equal(args.includes("--artifacts-path"),false);
  for(const environmentSetting of [
    "DOTNET_NOLOGO=true",
    "DOTNET_CLI_TELEMETRY_OPTOUT=true",
    "DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=true",
    "DOTNET_SKIP_WORKLOAD_INTEGRITY_CHECK=true"
  ]) assert.ok(args.includes(environmentSetting),environmentSetting);
  assert.ok(args.includes("UKO_SERVICE_YAML=/workspace/services/csharp/service.yaml"));
  assert.ok(args.includes("--age-years"));
  assert.ok(args.includes("55"));
  assert.equal(fx.request.timeoutMilliseconds,60_000);
  assert.equal(result.environmentDescription.container.limits.memory,"512m");
  assert.equal(result.environmentDescription.container.limits.tmpfs,"128m");
  assert.equal(result.responseValue,cleanAdapterStdout);
});

test("EX-03E runs a declared HTTP arrangement on container loopback and preserves the response body",async()=>{
  const requestBody='{"inputs":{"age":55}}';
  const responseBody='{"result":{"risk":0.1234}}';
  const adapterEnvelope='{"response":{"status":200,"body":{"result":{"risk":0.1234}}},"evidence":{"implementation_representation_id":"IR-1"}}';
  const envelope=JSON.stringify({schema:"pc3.python-http-loopback.v1",status:"returned",method:"POST",route:"/risk",requestBody,statusCode:200,responseHeaders:{"content-type":"application/json"},responseBody,adapterEnvelope,adapterEnvelopeSha256:"a".repeat(64),adapterStderr:"",adapterEvidence:{implementation_representation_id:"IR-1"}});
  const fx=fixture({responseValue:envelope});
  const httpPlan={...plan,invocationMode:"http",adapterResolution:{...plan.adapterResolution,canonicalRuntime:"Python",capabilityId:"python-http-response-body.v1"},adapterArtifactReference:"services/python-rest/adapter.py",arguments:[],observationLocation:"response-body",httpInvocation:{bridgeId:"pc3.python-http-loopback.v1",serviceDeclarationReference:"services/python-rest/service.yaml",bindingDeclarationReference:"services/python-rest/binding.yaml",implementationRepresentationIdentifier:"IR-1",implementationSourceRootReference:"implementation/python/src",implementationEntryPoint:"uko.compute",method:"POST",route:"/risk",requestMediaType:"application/json",responseMediaType:"application/json",responseValuePath:"result",requestBody,requestBindings:[{canonicalField:"age_years",localBinding:"age",value:55}]}};
  const result=await fx.provider.execute({attempt,adapter:fx.adapter,plan:httpPlan,publicationWorkspace:"/tmp/pc3-publication",adapterContainerPath:"/workspace/services/python-rest/adapter.py",infrastructureWorkspace:"/tmp/pc3-infrastructure"});
  const args=fx.request.arguments;
  assert.ok(args.includes("/pc3-infrastructure/python-http-loopback-bridge.py"));
  assert.ok(args.includes("/workspace/services/python-rest/adapter.py"));
  assert.ok(args.includes("/workspace/implementation/python/src"));
  assert.ok(args.includes("POST"));assert.ok(args.includes("/risk"));assert.ok(args.includes(requestBody));
  assert.ok(args.some(value=>/src=\/tmp\/pc3-infrastructure,dst=\/pc3-infrastructure,readonly/.test(value)));
  assert.ok(args.includes("--network"));assert.ok(args.includes("none"));
  assert.equal(result.responseValue,responseBody);
  assert.equal(result.responseMediaType,"application/json");
  assert.equal(result.httpExchange.statusCode,200);
  assert.equal(result.httpExchange.responseBody,responseBody);
  assert.equal(result.httpExchange.adapterEnvelope,adapterEnvelope);
  assert.match(result.httpExchange.transferredEnvelopeSha256,/^[a-f0-9]{64}$/);
});
