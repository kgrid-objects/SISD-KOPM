import assert from "node:assert/strict";
import test from "node:test";
import { PublicationCapabilityProfileSelector } from "../dist/publication/publication-capability-profile-selector.js";

const selector = new PublicationCapabilityProfileSelector();
const provenance = Object.freeze({ resourcePath: "metadata.yaml", resourceSha256: "a".repeat(64), location: "$", basis: "explicit-declaration" });
const validation = (status) => Object.freeze({ status, validationScope: "publication-declarations", checkedPtcCount: 0, checkedRtcmCount: 0, checkedRealizationCount: 0, checkedApplicabilityPairingCount: 0, issueCount: status === "invalid" ? 1 : 0, errorCount: status === "invalid" ? 1 : 0, warningCount: 0, checks: Object.freeze([]), issues: Object.freeze([]), statement: "fixture" });

test("selects PTC authority and makes coexisting standalone inputs subordinate", () => {
  const result = selector.select({ ptcCount: 2, standaloneInputObjectCount: 3, hasExplicitPtcDeclarationSignals: true, validation: validation("valid"), ptcProvenance: [provenance], inputProvenance: [provenance] });
  assert.equal(result.kind, "ptc");
  assert.equal(result.exerciseAuthority, "publication-test-cases");
  assert.equal(result.standaloneInputCapability, "subordinate");
  assert.equal(result.limitations.length, 0);
});

test("selects legacy input behavior only when no explicit PTC architecture exists", () => {
  const result = selector.select({ ptcCount: 0, standaloneInputObjectCount: 1, hasExplicitPtcDeclarationSignals: false, validation: validation("not-applicable"), ptcProvenance: [], inputProvenance: [provenance] });
  assert.equal(result.kind, "legacy-input");
  assert.equal(result.exerciseAuthority, "standalone-input-objects");
  assert.equal(result.standaloneInputCapability, "primary");
});

test("preserves mixed sources and refuses to guess when explicit PTC authority is incomplete", () => {
  const result = selector.select({ ptcCount: 0, standaloneInputObjectCount: 1, hasExplicitPtcDeclarationSignals: true, validation: validation("not-applicable"), ptcProvenance: [], inputProvenance: [provenance] });
  assert.equal(result.kind, "ambiguous-mixed");
  assert.equal(result.exerciseAuthority, "unresolved");
  assert.equal(result.standaloneInputCapability, "preserved");
  assert.match(result.rationale, /does not guess/);
});

test("selects ambiguous mixed behavior for an invalid discovered PTC architecture", () => {
  const result = selector.select({ ptcCount: 1, standaloneInputObjectCount: 1, hasExplicitPtcDeclarationSignals: true, validation: validation("invalid"), ptcProvenance: [provenance], inputProvenance: [provenance] });
  assert.equal(result.kind, "ambiguous-mixed");
  assert.equal(result.ptcCapability, "incomplete-or-invalid");
});

test("selects none without inventing capabilities", () => {
  const result = selector.select({ ptcCount: 0, standaloneInputObjectCount: 0, hasExplicitPtcDeclarationSignals: false, validation: validation("not-applicable"), ptcProvenance: [], inputProvenance: [] });
  assert.equal(result.kind, "none");
  assert.equal(result.exerciseAuthority, "none");
});
