import assert from "node:assert/strict";
import test from "node:test";
import { unzipSync, zipSync } from "fflate";
import { isoInstant } from "../dist/domain/index.js";
import { createServer } from "../dist/app/create-server.js";
import { PublicationReferenceExecutionPlanner } from "../dist/adapter/publication-reference-execution.js";
import { InMemoryZipPublicationSourceAdapter } from "../dist/infrastructure/publication/in-memory-zip-publication-source-adapter.js";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { readFile, stat } from "node:fs/promises";

const config = { host: "127.0.0.1", port: 3000, logLevel: "silent", maximumUploadBytes: 100_000_000 };
function dependencies(dockerEnvironmentProvider = testDockerEnvironmentProvider) {
  let counter = 0;
  return { config, clock: { now: () => isoInstant("2026-07-19T18:00:00.000Z") }, identifiers: { next: () => `ex02-${++counter}` }, dockerEnvironmentProvider };
}

const testDockerEnvironmentProvider = {
  assess: async () => ({ ready:true, code:"docker_environment_ready", reason:"Test Docker environment ready.", imageReference:"python@test-digest", imageId:"sha256:test-image" }),
  execute: async ({ attempt, adapter, plan, publicationWorkspace, infrastructureWorkspace }) => {
    const library=plan.libraryInvocation;
    const http=plan.httpInvocation;
    const negative=plan.negativeConditionPlan;
    const testStatus=negative?.declaredStatus??200;
    const testHttpBody=negative?JSON.stringify({error:{code:negative.expectedErrorCode,message:"Declared rejection.",details:negative.localSubject?{parameter:negative.localSubject}:{}}}):'{"metadata":{"service_realization_id":"python-rest"},"result":0.1234}';
    const testAdapterEnvelope=JSON.stringify({response:{status:testStatus,body:JSON.parse(testHttpBody)},evidence:{implementation_representation_id:http?.implementationRepresentationIdentifier,http_method:http?.method,route:http?.route}});
    const testHttpEnvelope=http?JSON.stringify({schema:http.bridgeId,status:"returned",method:http.method,route:http.route,requestBody:http.requestBody,statusCode:testStatus,responseHeaders:{"content-type":"application/json"},responseBody:testHttpBody,adapterEnvelope:testAdapterEnvelope,adapterEnvelopeSha256:createHash("sha256").update(testAdapterEnvelope).digest("hex"),adapterStderr:"",adapterEvidence:{implementation_representation_id:http.implementationRepresentationIdentifier,http_method:http.method,route:http.route}}):undefined;
    const argumentsList=library?[resolve(infrastructureWorkspace,"python-library-bridge.py"),"--source-root",resolve(publicationWorkspace,library.sourceRootReference),"--entry-point",library.entryPoint,"--bindings-json",JSON.stringify(Object.fromEntries(library.namedBindings.map(binding=>[binding.parameter,binding.value])))]:http?["-c",`import sys;sys.stdout.write(${JSON.stringify(testHttpEnvelope)})`]:[resolve(publicationWorkspace,plan.adapterArtifactReference),...plan.arguments];
    const result = await adapter.execute(attempt, { executable:plan.executable, arguments:argumentsList, workingDirectory:publicationWorkspace, timeoutMilliseconds:30_000, environmentIdentity:"docker-container:test", standardInput:"none" });
    let transfer;
    if(library&&result.outcome==="completed"){const envelope=JSON.parse(result.responseValue);const valueJson=JSON.stringify(envelope.value);transfer={bridgeId:library.bridgeId,transferredEnvelope:result.responseValue,transferredEnvelopeSha256:createHash("sha256").update(result.responseValue).digest("hex"),value:envelope.value,valueJson,diagnosticStdout:envelope.diagnosticStdout,diagnosticStderr:envelope.diagnosticStderr};}
    let httpTransfer;
    if(http&&result.outcome==="completed"){const envelope=JSON.parse(result.responseValue);httpTransfer={bridgeId:http.bridgeId,transferredEnvelope:result.responseValue,transferredEnvelopeSha256:createHash("sha256").update(result.responseValue).digest("hex"),method:http.method,route:http.route,requestBody:http.requestBody,statusCode:envelope.statusCode,responseHeaders:envelope.responseHeaders,responseBody:envelope.responseBody,adapterEnvelope:envelope.adapterEnvelope,adapterEnvelopeSha256:envelope.adapterEnvelopeSha256,adapterStderr:envelope.adapterStderr,adapterEvidence:envelope.adapterEvidence};}
    return Object.freeze({ ...result,...(transfer?{responseValue:transfer.valueJson,responseMediaType:"application/json",libraryReturn:transfer}:{}),...(httpTransfer?{responseValue:httpTransfer.responseBody,responseMediaType:"application/json",httpExchange:httpTransfer}:{}), environmentIdentity:"docker-container:test@sha256:test-image", environmentDescription:Object.freeze({ environmentType:"docker-container", executionBoundary:"external-container", externalEnvironmentIdentifier:"pc3-test-container", operatingSystem:Object.freeze({platform:"linux-container",release:"image-defined",architecture:"test"}), runtime:Object.freeze({executable:plan.executable}), workingDirectory:"/workspace", container:Object.freeze({providerId:"pc3.docker.environment.v1",imageReference:"python@test-digest",imageId:"sha256:test-image",containerName:"pc3-test-container",networkMode:"none",rootFilesystem:"read-only",publicationMount:Object.freeze({hostPath:publicationWorkspace,containerPath:"/workspace",mode:"read-only"}),limits:Object.freeze({cpus:"1.0",memory:"256m",pids:"128",tmpfs:"64m",timeoutMilliseconds:30_000}),cleanupDisposition:"removed"}) }) });
  }
};

function negativeResponseProvider(body,statusCode=400) {
  return {
    ...testDockerEnvironmentProvider,
    execute: async(request)=>{
      const result=await testDockerEnvironmentProvider.execute(request);
      if(!request.plan.negativeConditionPlan||!result.httpExchange)return result;
      const responseBody=JSON.stringify(body);
      return Object.freeze({...result,responseValue:responseBody,httpExchange:Object.freeze({...result.httpExchange,statusCode,responseBody})});
    }
  };
}

let capturedDotnetRequest;
const dotnetTestDockerEnvironmentProvider = {
  assess: async (runtime) => ({ ready:runtime===".NET 8", code:runtime===".NET 8"?"docker_environment_ready":"docker_image_mapping_not_found", reason:runtime===".NET 8"?"Test .NET Docker environment ready.":"No test image.", imageReference:"mcr.microsoft.com/dotnet/sdk:8.0.422-bookworm-slim@test-digest", imageId:"sha256:dotnet-test-image" }),
  execute: async (request) => {
    capturedDotnetRequest=request;
    const responseValue='{"status":"success","result":{"risk":0.1234}}\n';
    return Object.freeze({
      adapter:request.adapter.descriptor,
      environmentIdentity:"docker-container:dotnet-test@sha256:dotnet-test-image",
      externalInteractionId:"docker:dotnet-test",
      receivedFrom:request.adapter.descriptor.id,
      outcome:"completed",
      responseMediaType:"application/json",
      responseValue,
      runtimeReportedAt:"2026-07-19T18:00:00.000Z",
      process:Object.freeze({executable:"docker",arguments:Object.freeze(["dotnet","run","--",...request.plan.arguments]),exitCode:0,signal:null,timedOut:false,stderr:""}),
      environmentDescription:Object.freeze({environmentType:"docker-container",executionBoundary:"external-container",externalEnvironmentIdentifier:"pc3-dotnet-test",operatingSystem:Object.freeze({platform:"linux-container",release:"image-defined",architecture:"test"}),runtime:Object.freeze({executable:"dotnet",version:"8.0"}),workingDirectory:"/workspace",container:Object.freeze({providerId:"pc3.docker.environment.v1",imageReference:"mcr.microsoft.com/dotnet/sdk:8.0.422-bookworm-slim@test-digest",imageId:"sha256:dotnet-test-image",containerName:"pc3-dotnet-test",networkMode:"none",rootFilesystem:"read-only",publicationMount:Object.freeze({hostPath:request.publicationWorkspace,containerPath:"/workspace",mode:"read-only"}),limits:Object.freeze({cpus:"1.0",memory:"512m",pids:"128",tmpfs:"128m",timeoutMilliseconds:60_000}),cleanupDisposition:"removed"})})
    });
  }
};

const fields = ["age_years", "mean_untreated_iop_mm_hg", "mean_cct_um", "mean_vcdr_by_contour", "mean_humphrey_equivalent_psd_db"];

function archive({
  exceptional = false,
  risk = 0.1234,
  invalidJson = false,
  normalization = [],
  surroundingWhitespace = false,
  ptcIdentifier = "UKO-001-PTC-001",
  realizationIdentifier = "UKO-001-SR-PYTHON-COMMAND-LINE",
  declarationRealizationIdentifier,
  runtimeRequirement = "Python",
  declaredRuntime,
  invocationMode = "cli"
} = {}) {
  const script = exceptional
    ? "import sys\nsys.stderr.write('declared adapter exception')\nsys.exit(7)\n"
    : invalidJson
      ? "print('not-json')\n"
    : `import argparse, json
p=argparse.ArgumentParser()
p.add_argument('--age-years', required=True)
p.add_argument('--mean-iop-mmhg', required=True)
p.add_argument('--mean-cct-microns', required=True)
p.add_argument('--mean-vcdr', required=True)
p.add_argument('--mean-psd-db', required=True)
a=p.parse_args()
value=json.dumps({'status':'success','result':{'risk':${risk}}}, separators=(',',':'))
print(('  '+value+'  ') if ${surroundingWhitespace ? "True" : "False"} else value)
`;
  return zipSync({
    "UKO/": new Uint8Array(),
    "UKO/metadata/publication.yaml": bytes(`publication:\n  identifier: UKO-001\n  version: 1.1\nimplementationRepresentations:\n  - identifier: UKO-001-RCI-PYTHON-IR-001\nserviceRealizations:\n  - identifier: ${realizationIdentifier}\nrelationships:\n  - type: served-as\n    source: UKO-001-RCI-PYTHON-IR-001\n    target: ${realizationIdentifier}\n`),
    "UKO/cks.docx": bytes("canonical capability specification"),
    "UKO/ptc.yaml": bytes(`identifier: ${ptcIdentifier}
version: 1.0.0
status: authoritative
purpose: Exercise the accepted Python command-line realization.
publicationIdentifier: UKO-001
publishedCapabilitySpecification: cks.docx
canonicalInputObject:
  canonicalPredictorOrder: [${fields.join(", ")}]
  properties:
    age_years: 55
    mean_untreated_iop_mm_hg: 24
    mean_cct_um: 540
    mean_vcdr_by_contour: 0.4
    mean_humphrey_equivalent_psd_db: 2.2
canonicalExpectedOutcome:
  outcomeKind: successful computation
  semanticResult:
    value: 0.1234
comparisonSemantics:
  comparisonType: numeric absolute tolerance
  absoluteTolerance: 1.0e-12
  normativeValuePath: result.risk
applicabilityDetermination:
  applicableRealizationInstances: [${realizationIdentifier}]
  notApplicableRealizationInstances: [UKO-001-RCI-PYTHON-IR-001]
`),
    "UKO/rtcm.yaml": bytes(`identifier: ${ptcIdentifier}-RTCM-${realizationIdentifier}
version: 1.0.0
status: authoritative
canonicalOrigin:
  ptcIdentifier: ${ptcIdentifier}
complementedRealization:
  identifier: ${realizationIdentifier}
  layer: SR
applicabilityBasis:
  status: applicable
  pairingKey: ${ptcIdentifier}|${realizationIdentifier}
  conformanceAssertion: false
inputDerivation:
  canonicalInputReference: canonicalInputObject
  concreteRepresentation:
    mediaType: application/json
    inlinePermitted: true
  bindings:
${fields.map((field, index) => `    - canonicalField: ${field}\n      localBinding: argument position ${index + 1}`).join("\n")}
invocation:
  mode: ${invocationMode}
  entryPoint: command-line entry point
  operation: process invocation
  argumentOrder: [${fields.join(", ")}]
  externalEnvironmentRequirements: [${runtimeRequirement}]
  doesNotEmbedRuntime: true
observationDerivation:
  rawObservationLocation: stdout
  extractionExpression: result.risk
  semanticOutcome: risk-probability
  normalizations: [${normalization.map((item) => JSON.stringify(item)).join(", ")}]
  rawObservationMustBePreserved: true
comparison:
  canonicalExpectedOutcomeReference: canonicalExpectedOutcome
  comparisonType: numeric absolute tolerance
  toleranceReference: 1.0e-12
  mustPermitFailResult: true
`),
    "UKO/services/python-command-line/service.yaml": bytes(`service_realization_id: ${declarationRealizationIdentifier ?? realizationIdentifier}
${declaredRuntime ? `language_or_ecosystem: ${declaredRuntime}\n` : ""}preferred_output_format: json
adapter:
  entry_point: adapter/reference.py
adapter_binding:
  adapter_entry_point:
    path: adapter/reference.py
  input_translation:
    age-years: age_years
    mean-iop-mmhg: mean_iop_mmhg
    mean-cct-microns: mean_cct_microns
    mean-vcdr: mean_vcdr
    mean-psd-db: mean_psd_db
    strict: strict
`),
    "UKO/services/python-command-line/adapter/reference.py": bytes(script)
  });
}

function bytes(value) { return new TextEncoder().encode(value); }

function dotnetArchive() {
  const realizationIdentifier = "UKO-001-SR-CSHARP-NATIVE-COMMAND-LINE";
  const files = unzipSync(archive({ realizationIdentifier, runtimeRequirement: "A compatible external runtime environment for the complemented realization, managed outside the publication.", declaredRuntime: "C# / .NET / Native AOT target" }));
  delete files["UKO/services/python-command-line/service.yaml"];
  delete files["UKO/services/python-command-line/adapter/reference.py"];
  files["UKO/services/csharp-command-line/service.yaml"] = bytes(`service_realization_id: ${realizationIdentifier}
language_or_ecosystem: C# / .NET / Native AOT target
preferred_output_format: json
adapter:
  entry_point: adapter/UkoOhts.Cli/Program.cs
  project_file: adapter/UkoOhts.Cli/UkoOhts.Cli.csproj
adapter_binding:
  runtime_resolution: relative_to_uko_root
  binding_type: dotnet_project_reference_static_method
  implementation_representation_path: implementation/csharp
  entry_point:
    namespace: UkoOhts
    class: Model
    method: Compute
  adapter_entry_point:
    path: adapter/UkoOhts.Cli/Program.cs
  input_translation:
    age-years: ageYears
    mean-iop-mmhg: meanIopMmhg
    mean-cct-microns: meanCctMicrons
    mean-vcdr: meanVcdr
    mean-psd-db: meanPsdDb
    strict: strict
`);
  files["UKO/services/csharp-command-line/adapter/UkoOhts.Cli/Program.cs"] = bytes('Console.WriteLine("{\\"status\\":\\"success\\",\\"result\\":{\\"risk\\":0.1234}}");\n');
  files["UKO/services/csharp-command-line/adapter/UkoOhts.Cli/UkoOhts.Cli.csproj"] = bytes('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>\n');
  files["UKO/implementation/csharp/Model.cs"] = bytes('namespace UkoOhts; public static class Model { public static double Compute() => 0.1234; }\n');
  files["UKO/implementation/csharp/UkoOhts.csproj"] = bytes('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>\n');
  return zipSync(files);
}

function libraryArchive({brokenImport=false}={}) {
  const realization="UKO-001-RCI-PYTHON-IR-001";
  return zipSync({
    "UKO/metadata/publication.yaml":bytes(`publication:\n  identifier: UKO-001\n  version: 1.1\nimplementationRepresentations:\n  - identifier: ${realization}\n`),
    "UKO/cks.docx":bytes("canonical capability specification"),
    "UKO/ptc.yaml":bytes(`identifier: UKO-001-PTC-001\nversion: 1.0.0\nstatus: authoritative\npurpose: Exercise Python IR.\npublicationIdentifier: UKO-001\npublishedCapabilitySpecification: cks.docx\ncanonicalInputObject:\n  canonicalPredictorOrder: [${fields.join(", ")}]\n  properties:\n    age_years: 55\n    mean_untreated_iop_mm_hg: 24\n    mean_cct_um: 540\n    mean_vcdr_by_contour: 0.4\n    mean_humphrey_equivalent_psd_db: 2.2\ncanonicalExpectedOutcome:\n  outcomeKind: successful computation\n  semanticResult:\n    value: 0.1234\ncomparisonSemantics:\n  comparisonType: numeric absolute tolerance\n  absoluteTolerance: 1.0e-12\napplicabilityDetermination:\n  applicableRealizationInstances: [${realization}]\n  notApplicableRealizationInstances: []\n`),
    "UKO/python/rtcm.yaml":bytes(`identifier: UKO-001-PTC-001-RTCM-PYTHON-IR\nversion: 1.0.0\nstatus: authoritative\ncanonicalOrigin:\n  ptcIdentifier: UKO-001-PTC-001\ncomplementedRealization:\n  identifier: ${realization}\n  layer: IR\napplicabilityBasis:\n  status: applicable\n  pairingKey: UKO-001-PTC-001|${realization}\n  conformanceAssertion: false\ninputDerivation:\n  canonicalInputReference: canonicalInputObject\n  concreteRepresentation:\n    mediaType: application/json\n    inlinePermitted: true\n  bindings:\n${fields.map((field,index)=>`    - canonicalField: ${field}\n      localBinding: ${["age","mean_iop_mmhg","mean_cct_microns","mean_vcdr","mean_psd_db"][index]}\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity`).join("\n")}\ninvocation:\n  mode: library\n  entryPoint: published calculation entry point\n  operation: calculate risk\n  argumentOrder: []\n  externalEnvironmentRequirements: [compatible Python runtime]\n  doesNotEmbedRuntime: true\nobservationDerivation:\n  rawObservationLocation: return-value\n  extractionExpression: returned probability\n  semanticOutcome: risk-probability\n  normalizations: []\n  rawObservationMustBePreserved: true\ncomparison:\n  canonicalExpectedOutcomeReference: canonicalExpectedOutcome\n  comparisonType: numeric absolute tolerance\n  toleranceReference: 1.0e-12\n  mustPermitFailResult: true\n`),
    "UKO/python/representation.yaml":bytes(`representation_id: ${realization}\ntype: source\nlanguage: Python\nlocation: src/\ncanonical_entry_point: ${brokenImport?"missing.compute":"uko_ohts.compute"}\nexecution_contract: execution_contract.yaml\n`),
    "UKO/python/execution_contract.yaml":bytes(`representation_id: ${realization}\nentry_point:\n  name: ${brokenImport?"missing.compute":"uko_ohts.compute"}\n  kind: language_function\ninput_signature:\n${["age_years","mean_iop_mmhg","mean_cct_microns","mean_vcdr","mean_psd_db"].map(name=>`  - name: ${name}\n    type: decimal`).join("\n")}\noutput_signature:\n  name: risk\n  type: decimal\n`),
    "UKO/python/src/uko_ohts/__init__.py":bytes("def compute(age_years, mean_iop_mmhg, mean_cct_microns, mean_vcdr, mean_psd_db):\n    print('diagnostic only')\n    return 0.1234\n")
  });
}

function httpArchive() {
  const realization="UKO-001-SR-PYTHON-REST";
  const implementation="UKO-001-RCI-PYTHON-IR-001";
  return zipSync({
    "UKO/metadata/publication.yaml":bytes(`publication:\n  identifier: UKO-001\n  version: 1.1\nimplementationRepresentations:\n  - identifier: ${implementation}\nserviceRealizations:\n  - identifier: ${realization}\nrelationships:\n  - type: served-as\n    source: ${implementation}\n    target: ${realization}\n`),
    "UKO/cks.docx":bytes("canonical capability specification"),
    "UKO/ptc.yaml":bytes(`identifier: UKO-001-PTC-001\nversion: 1.0.0\nstatus: authoritative\npurpose: Exercise the published Python REST realization.\npublicationIdentifier: UKO-001\npublishedCapabilitySpecification: cks.docx\ncanonicalInputObject:\n  canonicalPredictorOrder: [${fields.join(", ")}]\n  properties:\n    age_years: 55\n    mean_untreated_iop_mm_hg: 24\n    mean_cct_um: 540\n    mean_vcdr_by_contour: 0.4\n    mean_humphrey_equivalent_psd_db: 2.2\ncanonicalExpectedOutcome:\n  outcomeKind: successful computation\n  semanticResult:\n    value: 0.1234\ncomparisonSemantics:\n  comparisonType: numeric absolute tolerance\n  absoluteTolerance: 1.0e-12\n  normativeValuePath: result\napplicabilityDetermination:\n  applicableRealizationInstances: [${realization}]\n  notApplicableRealizationInstances: [${implementation}]\n`),
    "UKO/services/python-rest/rtcm.yaml":bytes(`identifier: UKO-001-PTC-001-RTCM-${realization}\nversion: 1.0.0\nstatus: authoritative\ncanonicalOrigin:\n  ptcIdentifier: UKO-001-PTC-001\ncomplementedRealization:\n  identifier: ${realization}\n  layer: SR\napplicabilityBasis:\n  status: applicable\n  pairingKey: UKO-001-PTC-001|${realization}\n  conformanceAssertion: false\ninputDerivation:\n  canonicalInputReference: canonicalInputObject\n  concreteRepresentation:\n    mediaType: application/json\n    inlinePermitted: true\n  bindings:\n    - canonicalField: age_years\n      localBinding: age\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity\n    - canonicalField: mean_untreated_iop_mm_hg\n      localBinding: mean_iop_mmhg\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity\n    - canonicalField: mean_cct_um\n      localBinding: mean_cct_microns\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity\n    - canonicalField: mean_vcdr_by_contour\n      localBinding: mean_vcdr\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity\n    - canonicalField: mean_humphrey_equivalent_psd_db\n      localBinding: mean_psd_db\n      bindingKind: named\n      unitMapping: identity\n      transformation: identity\ninvocation:\n  mode: http\n  entryPoint: published REST endpoint\n  operation: HTTP request\n  argumentOrder: []\n  externalEnvironmentRequirements: [compatible Python runtime]\n  doesNotEmbedRuntime: true\nobservationDerivation:\n  rawObservationLocation: response-field\n  extractionExpression: declared risk or error field in response body\n  semanticOutcome: risk-probability\n  normalizations: []\n  rawObservationMustBePreserved: true\ncomparison:\n  canonicalExpectedOutcomeReference: canonicalExpectedOutcome\n  comparisonType: numeric absolute tolerance\n  toleranceReference: 1.0e-12\n  mustPermitFailResult: true\n`),
    "UKO/services/python-rest/instance-metadata.yaml":bytes(`describes:\n  identifier: ${realization}\n  parentLayerIdentifier: UKO-LAYER-SR\n  architecturalType: REST API\n  repositoryPath: services/python-rest\n  instanceArchitecture:\n    applicableInformation:\n      complementaryMetadataArtifacts:\n        - services/python-rest/service.yaml\n        - services/python-rest/binding.yaml\n`),
    "UKO/services/python-rest/service.yaml":bytes(`service_realization_id: python-rest\nservice_mode: REST\nbinding: binding.yaml\nadapter: adapter/reference.py\nimplementation_representation:\n  id: ${implementation}\n  canonical_entry_point: uko_ohts.compute\n`),
    "UKO/services/python-rest/binding.yaml":bytes(`binding_id: python-rest-binding\nservice_mode: REST\nservice_realization_id: python-rest\nimplementation_representation:\n  id: ${implementation}\n  runtime: python\n  language: Python\n  canonical_entry_point: uko_ohts.compute\nhttp_interface:\n  method: POST\n  route: /risk\n  consumes: application/json\n  produces: application/json\nrequest_mapping:\n  source: json_body\n  parameter_container: body.inputs\n  parameters:\n    - { name: age, from: body.inputs.age, required: true, datatype: number }\n    - { name: mean_iop_mmhg, from: body.inputs.mean_iop_mmhg, required: true, datatype: number }\n    - { name: mean_cct_microns, from: body.inputs.mean_cct_microns, required: true, datatype: number }\n    - { name: mean_vcdr, from: body.inputs.mean_vcdr, required: true, datatype: number }\n    - { name: mean_psd_db, from: body.inputs.mean_psd_db, required: true, datatype: number }\nresponse_mapping:\n  status_success: 200\n  body:\n    result:\n      from: implementation.result\nerror_mapping:\n  standard_error_object: true\n  errors:\n    - { condition: invalid_request_shape, status: 400, code: REST_INVALID_REQUEST_SHAPE }\n    - { condition: missing_required_parameter, status: 400, code: REST_MISSING_PARAMETER }\n    - { condition: invalid_parameter_type, status: 400, code: REST_INVALID_PARAMETER }\n`),
    "UKO/implementation/python/representation.yaml":bytes(`representation_id: ${implementation}\ntype: source\nlanguage: Python\nlocation: src/\ncanonical_entry_point: uko_ohts.compute\n`),
    "UKO/implementation/python/src/uko_ohts/__init__.py":bytes("def compute(age, mean_iop_mmhg, mean_cct_microns, mean_vcdr, mean_psd_db):\n    return 0.1234\n"),
    "UKO/services/python-rest/adapter/reference.py":bytes(`import json, sys\nfrom uko_ohts import compute\nrequest=json.load(sys.stdin)\ninputs=request["inputs"]\nrisk=compute(**inputs)\nresult={"response":{"status":200,"body":{"result":risk,"metadata":{"service_realization_id":"python-rest"}}},"evidence":{"implementation_representation_id":"${implementation}","http_method":"POST","route":"/risk"}}\njson.dump(result,sys.stdout,sort_keys=True,separators=(",",":"))\n`)
  });
}

function negativeHttpArchive(kind,{ptc004RtcmSubject="age_years"}={}) {
  const files=unzipSync(httpArchive());
  const realization="UKO-001-SR-PYTHON-REST";
  const ptcIdentifier=`UKO-001-PTC-${kind}`;
  const conditions={
    "004":`canonicalInputCondition:\n  conditionType: missing required canonical predictor\n  omittedCanonicalPredictor: mean_humphrey_equivalent_psd_db\n  suppliedCanonicalPredictors:\n    age_years: 55\n    mean_untreated_iop_mm_hg: 24\n    mean_cct_um: 540\n    mean_vcdr_by_contour: 0.4\n`,
    "005":`canonicalInputCondition:\n  conditionType: nonnumeric required canonical predictor\n  invalidCanonicalPredictor: age_years\n  invalidSemanticContent: nonnumeric\n  illustrativeLexicalValue: not-a-number\n  otherSuppliedCanonicalPredictors:\n    mean_untreated_iop_mm_hg: 24\n    mean_cct_um: 550\n    mean_vcdr_by_contour: 0.5\n    mean_humphrey_equivalent_psd_db: 1.2\n`,
    "006":`canonicalInputCondition:\n  conditionType: structurally unusable canonical input aggregate\n  illustrativeInvalidAggregate: [not, an, identified-predictor-object]\n  distinctionFromPTC004: malformed aggregate is not a known missing predictor\n`
  };
  const expected={"004":["missing-required-input","mean_humphrey_equivalent_psd_db"],"005":["invalid-input-value","age_years"],"006":["invalid-input-structure","canonical predictor aggregate"]}[kind];
  files["UKO/ptc.yaml"]=bytes(`identifier: ${ptcIdentifier}\nversion: 1.0.0\nstatus: authoritative\npurpose: Negative HTTP exercise.\npublicationIdentifier: UKO-001\npublishedCapabilitySpecification: cks.docx\n${conditions[kind]}canonicalExpectedOutcome:\n  outcomeKind: semantic rejection\n  errorSemantics:\n    category: ${expected[0]}\n    subject: ${expected[1]}\n    computationMustNotProduceRiskResult: true\n    messageTextIsNormative: false\n    transportStatusIsNormative: false\ncomparisonSemantics:\n  comparisonType: semantic error comparison\n  requiredSemanticAssertions:\n    - no valid risk result\n    - declared rejection category and subject\napplicabilityDetermination:\n  applicableRealizationInstances: [${realization}]\n  notApplicableRealizationInstances: [UKO-001-RCI-PYTHON-IR-001]\n`);
  const existing=new TextDecoder().decode(files["UKO/services/python-rest/rtcm.yaml"]);
  const semantic=kind==="004"?"one required canonical predictor is absent":kind==="005"?"one required predictor has a nonnumeric value":"the aggregate input cannot establish required predictor associations";
  const concrete=kind==="004"?`omit ${ptc004RtcmSubject} binding`:kind==="005"?"supply a nonnumeric age_years value":"supply an aggregate with invalid association structure";
  files["UKO/services/python-rest/rtcm.yaml"]=bytes(existing
    .replaceAll("UKO-001-PTC-001",ptcIdentifier)
    .replace("inputDerivation:\n",`inputDerivation:\n  negativeConditionDerivation:\n    semanticCondition: ${semantic}\n    concreteDerivation: ${concrete}\n    mustNotConflateWith: ${kind==="006"?"missing required predictor alone":"malformed aggregate structure"}\n`)
    .replace("semanticOutcome: risk-probability","semanticOutcome: semantic-rejection")
    .replace("comparisonType: numeric absolute tolerance","comparisonType: semantic error comparison"));
  return zipSync(files);
}

async function prepareReference(server, publicationArchive, { ptcIdentifier = "UKO-001-PTC-001", realizationIdentifier = "UKO-001-SR-PYTHON-COMMAND-LINE" } = {}) {
  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const activation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=uko.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(publicationArchive) });
  assert.equal(activation.statusCode, 200, activation.body);
  const contextId = activation.json().activeContext.contextId;
  const matrix = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` })).json();
  const pathway = matrix.pathways.find((item) => item.endpointIdentifier === realizationIdentifier);
  assert.ok(pathway);
  const selected = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathway.id)}/select?expectedActiveContextId=${contextId}` });
  assert.equal(selected.statusCode, 200, selected.body);
  const prepared = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`, headers: { "content-type": "application/json" }, payload: { ptcIdentifier, exerciseDisposition: "canonical" } });
  assert.equal(prepared.statusCode, 201, `${prepared.body}\n${JSON.stringify({ profile: activation.json().interpretation.capabilityProfile, issues: activation.json().interpretation.publicationValidation.issues }, null, 2)}`);
  const exercise = activation.json().interpretation.resolvedExercises.find((item) => item.ptc.identifier === ptcIdentifier && item.realization.identifier === realizationIdentifier);
  assert.ok(exercise);
  const invocationSupport = activation.json().invocationSupport.find((item) => item.ptcIdentifier === ptcIdentifier && item.realizationIdentifier === realizationIdentifier && item.rtcmIdentifier === exercise.rtcm.identifier);
  assert.ok(invocationSupport);
  return { session, contextId, attempt: prepared.json(), exercise, invocationSupport };
}

test("EX-02 constructs and executes the exact publication-declared reference CLI invocation", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive());
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const result = response.json();
  assert.equal(result.interaction.response.outcome, "completed");
  assert.equal(result.interaction.response.value, '{"status":"success","result":{"risk":0.1234}}\n');
  assert.equal(result.interaction.response.preservationDisposition, "raw-unmodified");
  assert.equal(result.observation.publicationExerciseScope.ptcIdentifier, "UKO-001-PTC-001");
  assert.equal(result.observation.publicationExerciseScope.rtcmIdentifier, "UKO-001-PTC-001-RTCM-UKO-001-SR-PYTHON-COMMAND-LINE");
  assert.equal(result.observation.rawObservation.value, result.interaction.response.value);
  assert.equal(result.observation.rawObservation.preservationDisposition, "immutable-raw-preserved");
  assert.equal(result.observation.rawObservation.sourceClassification, "directly-observed");
  assert.equal(result.observation.extractionProvenance.disposition, "rtcm-declaration-captured-not-applied");
  assert.deepEqual(result.observation.normalizationRecords, []);
  assert.deepEqual(result.referenceExecution.invocation.arguments, ["--age-years","55","--mean-iop-mmhg","24","--mean-cct-microns","540","--mean-vcdr","0.4","--mean-psd-db","2.2"]);
  assert.equal(result.referenceExecution.declarationIdentityField, "service_realization_id");
  assert.equal(result.referenceExecution.invocation.mode, "cli");
  assert.equal(result.referenceExecution.invocation.runtimeRequirement, "Python");
  assert.equal(result.referenceExecution.invocation.runtimeResolutionBasis, "registered-adapter-capability-match");
  assert.deepEqual(result.referenceExecution.invocation.adapterResolution, { adapterId: "pc3.local-process.stdio.v1", adapterVersion: "1.0.0", capabilityId: "python-cli-stdout.v1", canonicalRuntime: "Python" });
  assert.equal(result.referenceExecution.comparisonDeclaration.disposition, "declared-not-yet-evaluated");
  assert.equal(result.referenceExecution.comparisonDeclaration.absoluteTolerance, 1e-12);
  assert.equal(result.comparison.status, "pass");
  assert.equal(result.comparison.extractedRepresentation.value, 0.1234);
  assert.equal(result.comparison.expectedRepresentation.value, 0.1234);
  assert.equal(result.comparison.comparisonRepresentation.absoluteDifference, 0);
  assert.equal(result.comparison.claimDisposition, "comparison-result-not-conformance");
  assert.equal(result.comparison.rawRepresentation.rawObservationId, result.observation.rawObservation.id);
  assert.equal(result.environment.container.publicationMount.hostPath.assurance, "unavailable");
  assert.equal("value" in result.environment.container.publicationMount.hostPath, false);
  assert.equal(result.process.arguments[0].endsWith("/UKO/services/python-command-line/adapter/reference.py"), true);
});

test("EX-03-NP1 invokes an explicit Python IR function and observes only its return value", async(t)=>{
  const server=createServer(dependencies()); t.after(()=>server.close());
  const prepared=await prepareReference(server,libraryArchive(),{realizationIdentifier:"UKO-001-RCI-PYTHON-IR-001"});
  assert.equal(prepared.invocationSupport.executable,true,JSON.stringify(prepared.invocationSupport));
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  const result=response.json();
  assert.equal(result.referenceExecution.invocation.mode,"library");
  assert.equal(result.referenceExecution.declarationIdentityField,"representation_id");
  assert.equal(result.referenceExecution.invocation.libraryInvocation.entryPoint,"uko_ohts.compute");
  assert.deepEqual(result.referenceExecution.invocation.libraryInvocation.namedBindings.map(binding=>binding.parameter),["age_years","mean_iop_mmhg","mean_cct_microns","mean_vcdr","mean_psd_db"]);
  assert.equal(result.observation.rawObservation.location,"return-value");
  assert.equal(result.observation.rawObservation.value,"0.1234");
  assert.equal(result.comparison.status,"pass");
  assert.equal(result.comparison.extractedRepresentation.sourcePath,"$return");
  assert.equal(result.interaction.referenceExecution.returnTransfer.diagnosticStdout,"diagnostic only\n");
  assert.notEqual(result.interaction.referenceExecution.returnTransfer.transferredEnvelope,"0.1234");
});

test("EX-03-NP1 preserves a failed library interaction without retaining an invented Observation",async(t)=>{
  const server=createServer(dependencies()); t.after(()=>server.close());
  const prepared=await prepareReference(server,libraryArchive({brokenImport:true}),{realizationIdentifier:"UKO-001-RCI-PYTHON-IR-001"});
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,409,response.body); assert.equal(response.json().error.code,"library_invocation_failed");
  const observations=(await server.inject({method:"GET",url:`/api/sessions/${prepared.session.id}/runtime-observations`})).json().observations;
  const interactions=(await server.inject({method:"GET",url:`/api/sessions/${prepared.session.id}/execution-interactions`})).json().interactions;
  assert.equal(observations.length,0); assert.equal(interactions.length,1); assert.equal(interactions[0].response.outcome,"failed");
});

test("EX-03A derives the same immutable CLI plan for publication-defined identities rather than a named UKO-001 path", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const identities = { ptcIdentifier: "PUBLICATION-X-PTC-ALPHA", realizationIdentifier: "PUBLICATION-X-SR-CANONICAL-CLI" };
  const { session, contextId, attempt } = await prepareReference(server, archive(identities), identities);
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const plan = response.json().referenceExecution;
  assert.equal(plan.pathIdentifier, `${identities.ptcIdentifier}×${identities.realizationIdentifier}`);
  assert.equal(plan.ptcIdentifier, identities.ptcIdentifier);
  assert.equal(plan.realizationIdentifier, identities.realizationIdentifier);
  assert.equal(plan.rtcmIdentifier, `${identities.ptcIdentifier}-RTCM-${identities.realizationIdentifier}`);
  assert.equal(plan.invocation.executable, "python3");
  assert.equal(response.json().comparison.status, "pass");
});

test("EX-03A enables the accepted corpus pattern by resolving Python from the explicit realization declaration", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const publicationArchive = archive({
    runtimeRequirement: "A compatible external runtime environment for the complemented realization, managed outside the publication.",
    declaredRuntime: "Python"
  });
  const { session, contextId, attempt, invocationSupport } = await prepareReference(server, publicationArchive);
  assert.equal(invocationSupport.executable, true);
  assert.equal(invocationSupport.code, "executable");
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  assert.deepEqual(response.json().referenceExecution.runtimeDeclaration, {
    value: "Python",
    field: "language_or_ecosystem",
    resourcePath: "UKO/services/python-command-line/service.yaml"
  });
  assert.equal(response.json().referenceExecution.invocation.executable, "python3");
});

test("EX-03D resolves, materializes, and captures one declaration-driven .NET 8 CLI exercise", async (t) => {
  capturedDotnetRequest=undefined;
  const server=createServer(dependencies(dotnetTestDockerEnvironmentProvider));
  t.after(()=>server.close());
  const publicationArchive=dotnetArchive();
  const prepared=await prepareReference(server,publicationArchive,{realizationIdentifier:"UKO-001-SR-CSHARP-NATIVE-COMMAND-LINE"});
  assert.equal(prepared.invocationSupport.executable,true,JSON.stringify(prepared.invocationSupport));
  const acquired=await new InMemoryZipPublicationSourceAdapter(publicationArchive,"dotnet-fixture.zip").acquire({kind:"uploaded-archive",locator:"dotnet-fixture.zip"});
  const invocationPlan=await new PublicationReferenceExecutionPlanner().plan(prepared.attempt,prepared.exercise,acquired);
  assert.equal(invocationPlan.dotnetCliInvocation.bridgeId,"pc3.dotnet-cli-source.v1");
  assert.equal(invocationPlan.dotnetCliInvocation.targetFramework,"net8.0");
  const materialized=await new PublicationReferenceExecutionPlanner().materialize(invocationPlan,acquired);
  t.after(()=>materialized.cleanup());
  const bridge=await readFile(resolve(materialized.infrastructureDirectory,"pc3-dotnet-cli-bridge.csproj"),"utf8");
  assert.match(bridge,/PublicationAdapterEntryPoint\.cs/);
  assert.doesNotMatch(bridge,/ProjectReference/);
  assert.match(bridge,/implementation\/csharp\/\*\.cs/);
  assert.doesNotMatch(bridge,/\/workspace\/[^<"]*\/obj/);
  assert.equal((await stat(materialized.infrastructureDirectory)).mode & 0o777,0o777);
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  const result=response.json();
  assert.equal(result.referenceExecution.invocation.adapterResolution.capabilityId,"dotnet8-cli-stdout.v1");
  assert.equal(result.referenceExecution.invocation.adapterResolution.canonicalRuntime,".NET 8");
  assert.equal(result.referenceExecution.invocation.dotnetCliInvocation.projectFileReference,"UKO/services/csharp-command-line/adapter/UkoOhts.Cli/UkoOhts.Cli.csproj");
  assert.equal(result.observation.rawObservation.value,'{"status":"success","result":{"risk":0.1234}}\n');
  assert.equal(result.comparison.status,"pass");
  assert.ok(capturedDotnetRequest.infrastructureWorkspace);
});

test("EX-03E performs one declaration-driven HTTP exchange and observes the unmodified response body", async (t) => {
  const server=createServer(dependencies());
  t.after(()=>server.close());
  const publicationArchive=httpArchive();
  const prepared=await prepareReference(server,publicationArchive,{realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(prepared.invocationSupport.executable,true,JSON.stringify(prepared.invocationSupport));
  const acquired=await new InMemoryZipPublicationSourceAdapter(publicationArchive,"http-fixture.zip").acquire({kind:"uploaded-archive",locator:"http-fixture.zip"});
  const invocationPlan=await new PublicationReferenceExecutionPlanner().plan(prepared.attempt,prepared.exercise,acquired);
  const materialized=await new PublicationReferenceExecutionPlanner().materialize(invocationPlan,acquired);
  t.after(()=>materialized.cleanup());
  const bridge=await readFile(resolve(materialized.infrastructureDirectory,"python-http-loopback-bridge.py"),"utf8");
  assert.match(bridge,/HTTPServer\(\("127\.0\.0\.1", 0\), Handler\)/);
  assert.match(bridge,/http\.client\.HTTPConnection\("127\.0\.0\.1"/);
  assert.match(bridge,/subprocess\.run\(\[sys\.executable, args\.adapter\]/);
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  const result=response.json();
  assert.equal(result.referenceExecution.invocation.mode,"http");
  assert.equal(result.referenceExecution.invocation.adapterResolution.capabilityId,"python-http-response-body.v1");
  assert.equal(result.referenceExecution.observation.location,"response-body");
  assert.equal(result.referenceExecution.declarationIdentityField,"describes.identifier");
  assert.equal(result.referenceExecution.invocation.httpInvocation.method,"POST");
  assert.equal(result.referenceExecution.invocation.httpInvocation.route,"/risk");
  assert.deepEqual(JSON.parse(result.referenceExecution.invocation.httpInvocation.requestBody),{inputs:{age:55,mean_iop_mmhg:24,mean_cct_microns:540,mean_vcdr:0.4,mean_psd_db:2.2}});
  assert.equal(result.interaction.response.value,'{"metadata":{"service_realization_id":"python-rest"},"result":0.1234}');
  assert.equal(result.observation.rawObservation.value,result.interaction.response.value);
  assert.equal(result.referenceExecution.httpTransfer.statusCode,200);
  assert.equal(result.referenceExecution.httpTransfer.responseHeaders["content-type"],"application/json");
  assert.equal(result.referenceExecution.httpTransfer.responseBody,result.observation.rawObservation.value);
  assert.equal(result.referenceExecution.httpTransfer.adapterEvidence.implementation_representation_id,"UKO-001-RCI-PYTHON-IR-001");
  assert.match(result.referenceExecution.httpTransfer.transferredEnvelopeSha256,/^[a-f0-9]{64}$/);
  assert.equal(result.referenceExecution.invocation.httpInvocation.responseValuePath,"result");
  assert.equal(result.referenceExecution.semanticExtractionStrategy,"json-declared-path");
  assert.equal(result.referenceExecution.semanticObservationPath,"result");
  assert.equal(result.comparison.extractedRepresentation.sourcePath,"result");
  assert.equal(result.comparison.extractedRepresentation.value,0.1234);
  assert.equal(result.comparison.status,"pass");
});

test("EX-03F derives and compares the canonical invalid-value Python REST exercise",async(t)=>{
  const server=createServer(dependencies()); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("005"),{ptcIdentifier:"UKO-001-PTC-005",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(prepared.invocationSupport.executable,true,JSON.stringify(prepared.invocationSupport));
  assert.equal(prepared.attempt.input.source,"publication-derived-negative");
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  const result=response.json();
  assert.equal(result.interaction.response.outcome,"completed");
  assert.equal(result.referenceExecution.httpTransfer.statusCode,400);
  assert.deepEqual(JSON.parse(result.referenceExecution.invocation.httpInvocation.requestBody),{inputs:{age:"not-a-number",mean_iop_mmhg:24,mean_cct_microns:550,mean_vcdr:0.5,mean_psd_db:1.2}});
  assert.match(result.referenceExecution.invocation.httpInvocation.requestBodySha256,/^[a-f0-9]{64}$/);
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.operation,"supply-invalid-lexical-value");
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.semanticSubject,"age_years");
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.localSubject,"age");
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.expectedErrorCode,"REST_INVALID_PARAMETER");
  assert.equal(result.observation.rawObservation.value,result.interaction.response.value);
  assert.equal(result.comparison.status,"pass");
  assert.equal(result.comparison.extractedRepresentation.strategy,"semantic-rejection");
  assert.equal(result.comparison.comparisonRepresentation.semanticAssertions.every(item=>item.satisfied),true);
});

test("EX-03F derives invalid aggregate shape without conflating it with a missing predictor",async(t)=>{
  const server=createServer(dependencies()); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("006"),{ptcIdentifier:"UKO-001-PTC-006",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(prepared.invocationSupport.executable,true,JSON.stringify(prepared.invocationSupport));
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  const result=response.json();
  assert.deepEqual(JSON.parse(result.referenceExecution.invocation.httpInvocation.requestBody),{inputs:["not","an","identified-predictor-object"]});
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.operation,"supply-invalid-aggregate-shape");
  assert.equal(result.referenceExecution.invocation.negativeConditionPlan.expectedErrorCode,"REST_INVALID_REQUEST_SHAPE");
  assert.equal(result.referenceExecution.httpTransfer.statusCode,400);
  assert.equal(result.comparison.status,"pass");
  assert.equal(result.comparison.comparisonRepresentation.semanticAssertions.find(item=>item.assertion==="must-not-conflate").satisfied,true);
});

test("EX-03F keeps a contradictory missing-input PTC and RTCM disabled without repair",async(t)=>{
  const server=createServer(dependencies()); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("004"),{ptcIdentifier:"UKO-001-PTC-004",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(prepared.invocationSupport.executable,false);
  assert.equal(prepared.invocationSupport.code,"negative_derivation_subject_mismatch");
  assert.match(prepared.invocationSupport.reason,/mean_humphrey_equivalent_psd_db/);
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,409,response.body);
  assert.equal(response.json().error.code,"negative_derivation_subject_mismatch");
});

test("EX-03F records fail for a structured but wrong rejection",async(t)=>{
  const server=createServer(dependencies(negativeResponseProvider({error:{code:"REST_MISSING_PARAMETER",details:{parameter:"age"}}}))); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("005"),{ptcIdentifier:"UKO-001-PTC-005",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  assert.equal(response.json().comparison.status,"fail");
  assert.equal(response.json().comparison.comparisonRepresentation.semanticAssertions.find(item=>item.assertion==="declared-error-code").satisfied,false);
});

test("EX-03F records comparison-error when no structured rejection can be extracted",async(t)=>{
  const server=createServer(dependencies(negativeResponseProvider({metadata:{rejected:true}}))); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("006"),{ptcIdentifier:"UKO-001-PTC-006",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  assert.equal(response.json().comparison.status,"comparison-error");
  assert.equal(response.json().comparison.error.code,"semantic_rejection_error_absent");
  assert.equal(response.json().observation.rawObservation.value,'{"metadata":{"rejected":true}}');
});

test("EX-03F records fail when a negative PTC produces a finite risk result",async(t)=>{
  const server=createServer(dependencies(negativeResponseProvider({result:0.25},200))); t.after(()=>server.close());
  const prepared=await prepareReference(server,negativeHttpArchive("005"),{ptcIdentifier:"UKO-001-PTC-005",realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  const response=await server.inject({method:"POST",url:`/api/sessions/${prepared.session.id}/exercise-attempts/${prepared.attempt.id}/execute-reference?expectedActiveContextId=${prepared.contextId}`});
  assert.equal(response.statusCode,201,response.body);
  assert.equal(response.json().comparison.status,"fail");
  assert.equal(response.json().comparison.comparisonRepresentation.semanticAssertions.find(item=>item.assertion==="no-valid-risk-result").satisfied,false);
});

test("EX-03E keeps unsupported methods and runtimes disabled without HTTP fallback",async(t)=>{
  const server=createServer(dependencies());
  t.after(()=>server.close());
  const getFiles=unzipSync(httpArchive());
  getFiles["UKO/services/python-rest/binding.yaml"]=bytes(new TextDecoder().decode(getFiles["UKO/services/python-rest/binding.yaml"]).replace("method: POST","method: GET"));
  const unsupportedMethod=await prepareReference(server,zipSync(getFiles),{realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(unsupportedMethod.invocationSupport.executable,false);
  assert.equal(unsupportedMethod.invocationSupport.code,"http_interface_not_supported");
  const methodResponse=await server.inject({method:"POST",url:`/api/sessions/${unsupportedMethod.session.id}/exercise-attempts/${unsupportedMethod.attempt.id}/execute-reference?expectedActiveContextId=${unsupportedMethod.contextId}`});
  assert.equal(methodResponse.statusCode,409);
  assert.equal(methodResponse.json().error.code,"http_interface_not_supported");

  const unmappedFiles=unzipSync(httpArchive());
  unmappedFiles["UKO/services/python-rest/binding.yaml"]=bytes(new TextDecoder().decode(unmappedFiles["UKO/services/python-rest/binding.yaml"]).replace("  body:\n    result:\n      from: implementation.result\n",""));
  const unmappedResponse=await prepareReference(server,zipSync(unmappedFiles),{realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(unmappedResponse.invocationSupport.executable,false);
  assert.equal(unmappedResponse.invocationSupport.code,"http_response_mapping_not_supported");

  const javaFiles=unzipSync(httpArchive());
  javaFiles["UKO/implementation/python/representation.yaml"]=bytes(new TextDecoder().decode(javaFiles["UKO/implementation/python/representation.yaml"]).replace("language: Python","language: Java"));
  const unsupportedRuntime=await prepareReference(server,zipSync(javaFiles),{realizationIdentifier:"UKO-001-SR-PYTHON-REST"});
  assert.equal(unsupportedRuntime.invocationSupport.executable,false);
  assert.equal(unsupportedRuntime.invocationSupport.code,"adapter_capability_not_found");
});

test("EX-03B keeps unsupported RTCM modes and runtimes explicit without adapter fallback", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const rest = await prepareReference(server, archive({ invocationMode: "rest" }));
  assert.equal(rest.invocationSupport.executable, false);
  assert.equal(rest.invocationSupport.code, "rtcm_invocation_mode_not_supported");
  const restResponse = await server.inject({ method: "POST", url: `/api/sessions/${rest.session.id}/exercise-attempts/${rest.attempt.id}/execute-reference?expectedActiveContextId=${rest.contextId}` });
  assert.equal(restResponse.statusCode, 409);
  assert.equal(restResponse.json().error.code, "rtcm_invocation_mode_not_supported");

  const rustArchive = archive({ runtimeRequirement: "Rust" });
  const rust = await prepareReference(server, rustArchive);
  assert.equal(rust.invocationSupport.executable, false);
  assert.equal(rust.invocationSupport.code, "adapter_capability_not_found");
  const acquired = await new InMemoryZipPublicationSourceAdapter(rustArchive, "fixture.zip").acquire({ kind: "uploaded-archive", locator: "fixture.zip" });
  const genericPlan = await new PublicationReferenceExecutionPlanner().plan(rust.attempt, rust.exercise, acquired);
  assert.deepEqual(genericPlan.runtimeRequirements, ["Rust"]);
  assert.equal("executable" in genericPlan, false);
  const rustResponse = await server.inject({ method: "POST", url: `/api/sessions/${rust.session.id}/exercise-attempts/${rust.attempt.id}/execute-reference?expectedActiveContextId=${rust.contextId}` });
  assert.equal(rustResponse.statusCode, 409);
  assert.equal(rustResponse.json().error.code, "adapter_capability_not_found");
});

test("EX-03A keeps a resolved exercise disabled when its explicit realization declaration cannot be found", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const unresolved = await prepareReference(server, archive({ declarationRealizationIdentifier: "ANOTHER-SR" }));
  assert.equal(unresolved.invocationSupport.executable, false);
  assert.equal(unresolved.invocationSupport.code, "rtcm_realization_declaration_not_unique");
  assert.match(unresolved.invocationSupport.reason, /found 0/);
});

test("UII-03 repeated canonical exercises preserve distinct immutable history", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt: firstAttempt } = await prepareReference(server, archive());
  const firstExecution = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${firstAttempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(firstExecution.statusCode, 201, firstExecution.body);

  const secondPrepared = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`, headers: { "content-type": "application/json" }, payload: { ptcIdentifier: "UKO-001-PTC-001", exerciseDisposition: "canonical" } });
  assert.equal(secondPrepared.statusCode, 201, secondPrepared.body);
  const secondAttempt = secondPrepared.json();
  const secondExecution = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${secondAttempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(secondExecution.statusCode, 201, secondExecution.body);

  const attempts = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/exercise-attempts` })).json().attempts;
  const interactions = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/execution-interactions` })).json().interactions;
  const observations = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/runtime-observations` })).json().observations;
  assert.equal(attempts.length, 2);
  assert.equal(interactions.length, 2);
  assert.equal(observations.length, 2);
  assert.notEqual(firstAttempt.id, secondAttempt.id);
  assert.notEqual(firstExecution.json().interaction.id, secondExecution.json().interaction.id);
  assert.notEqual(firstExecution.json().observation.id, secondExecution.json().observation.id);
  assert.ok(secondExecution.json().observation.sessionSequence > firstExecution.json().observation.sessionSequence);
});

test("UII-04 correction formally attests and saves all current Observations in one artifact", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt: firstAttempt } = await prepareReference(server, archive());
  const first = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${firstAttempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(first.statusCode, 201, first.body);
  const prepared = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`, headers: { "content-type": "application/json" }, payload: { ptcIdentifier: "UKO-001-PTC-001", exerciseDisposition: "canonical" } });
  const second = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${prepared.json().id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(second.statusCode, 201, second.body);

  const saved = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/execution-evidence/attest-current?expectedActiveContextId=${contextId}` });
  assert.equal(saved.statusCode, 200, saved.body);
  assert.match(saved.headers["content-disposition"], /pc3-observation-collection-attestation/);
  const record = saved.json();
  assert.equal(record.recordType, "pc3-observation-collection-attestation");
  assert.equal(record.observationCount, 2);
  assert.deepEqual(record.evidence.map((item) => item.runtimeObservation.id), [first.json().observation.id, second.json().observation.id]);
  assert.equal(record.integrity.coveredContent, "ordered-current-observation-evidence-and-pc3-identity");
  assert.match(record.integrity.digest, /^[a-f0-9]{64}$/);
  assert.match(record.statement, /all Runtime Observations currently present/);

  const evidence = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/execution-evidence` })).json().evidence;
  assert.equal(evidence.length, 2);
});

test("ATT-01 attests and optionally saves the complete PTC exercise chain", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive());
  const executed = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(executed.statusCode, 201, executed.body);
  const result = executed.json();
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/runtime-observations/${result.observation.id}/attest?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const evidence = response.json();
  assert.equal(evidence.evidenceScope, "complete-ptc-exercise-chain");
  assert.deepEqual(evidence.ptcExerciseChain, {
    publicationLoadId: attempt.publicationLoadId,
    publicationIdentifier: "UKO-001",
    ptcIdentifier: "UKO-001-PTC-001",
    rtcmIdentifier: "UKO-001-PTC-001-RTCM-UKO-001-SR-PYTHON-COMMAND-LINE",
    realizationIdentifier: "UKO-001-SR-PYTHON-COMMAND-LINE",
    attemptId: attempt.id,
    interactionId: result.interaction.id,
    observationId: result.observation.id,
    comparisonId: result.comparison.id
  });
  assert.equal(evidence.inputDisposition.exerciseDisposition, "canonical");
  assert.equal(evidence.inputDisposition.source, "publication-canonical");
  assert.match(evidence.inputDisposition.snapshot.sha256, /^[a-f0-9]{64}$/);
  assert.equal(evidence.runtimeObservation.rawObservation.value, result.observation.rawObservation.value);
  assert.deepEqual(evidence.expectedOutcomeComparison, result.comparison);
  assert.equal(evidence.expectedOutcomeComparison.status, "pass");
  assert.equal(evidence.provenance.executionEnvironmentDescription.executionBoundary, "external-container");
  assert.equal(evidence.provenance.executionEnvironmentDescription.container.imageId.value, "sha256:test-image");
  assert.equal(evidence.provenance.executionEnvironmentDescription.container.cleanupDisposition, "removed");
  assert.equal(evidence.attestation.implementationVersion, "0.1.0");
  assert.equal(evidence.attestation.developmentPass, "UX-01");
  assert.deepEqual(evidence.pc3Identity, { implementation: "PC3 Architectural Reference Implementation", version: "0.1.0", developmentPass: "UX-01" });
  assert.equal(evidence.integrity.coveredContent, "attested-exercise-record-and-pc3-identity");
  assert.match(evidence.integrity.digest, /^[a-f0-9]{64}$/);
  assert.match(evidence.attestation.statement, /does not attest publication or realization conformance/i);
  const saved = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/execution-evidence/${evidence.id}/save` });
  assert.equal(saved.statusCode, 200, saved.body);
  assert.equal(saved.json().recordSchemaVersion, "2.0");
  assert.equal(saved.json().evidence.expectedOutcomeComparison.id, result.comparison.id);
});

test("ATT-01 faithfully preserves a failed comparison without overstating the attestation", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ risk: 0.2 }));
  const executed = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  const result = executed.json();
  assert.equal(result.comparison.status, "fail");
  const attested = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/runtime-observations/${result.observation.id}/attest?expectedActiveContextId=${contextId}` });
  assert.equal(attested.statusCode, 201, attested.body);
  assert.equal(attested.json().expectedOutcomeComparison.status, "fail");
  assert.equal(attested.json().expectedOutcomeComparison.comparisonRepresentation.satisfied, false);
  assert.equal(attested.json().expectedOutcomeComparison.claimDisposition, "comparison-result-not-conformance");
  assert.match(attested.json().attestation.statement, /does not attest.*correctness/i);
});

test("EX-02 records an exceptional adapter outcome and raw stderr without substitution or repair", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ exceptional: true }));
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const result = response.json();
  assert.equal(result.interaction.response.outcome, "failed");
  assert.equal(result.interaction.response.value, "");
  assert.equal(result.interaction.externalProcess.exitCode, 7);
  assert.equal(result.interaction.externalProcess.stderr, "declared adapter exception");
  assert.equal(result.comparison.status, "indeterminate");
  assert.equal(result.comparison.error.code, "external_outcome_not_completed");
  const listed = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/execution-interactions` })).json();
  assert.equal(listed.interactions[0].externalProcess.stderr, "declared adapter exception");
  assert.equal(listed.interactions[0].referenceExecution.observation.preservationDisposition, "raw-unmodified");
});

test("OBS-02 returns fail with the exact discrepancy while preserving raw and comparison representations", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ risk: 0.2 }));
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const result = response.json();
  assert.equal(result.comparison.status, "fail");
  assert.equal(result.comparison.comparisonRepresentation.satisfied, false);
  assert.ok(Math.abs(result.comparison.comparisonRepresentation.absoluteDifference - 0.0766) < 1e-15);
  assert.equal(result.comparison.rawRepresentation.value, result.observation.rawObservation.value);
  assert.match(result.comparison.statement, /not a conformance claim/i);
});

test("OBS-02 returns comparison-error for malformed semantic output without changing the observation", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ invalidJson: true }));
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 201, response.body);
  const result = response.json();
  assert.equal(result.comparison.status, "comparison-error");
  assert.equal(result.comparison.error.code, "raw_observation_not_json");
  assert.equal(result.observation.rawObservation.value, "not-json\n");
  assert.equal(result.comparison.rawRepresentation.value, "not-json\n");
});

test("OBS-02 applies only a permitted normalization to a separate representation", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ normalization: ["trim surrounding whitespace"], surroundingWhitespace: true }));
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  const result = response.json();
  assert.equal(response.statusCode, 201, response.body);
  assert.equal(result.comparison.status, "pass");
  assert.equal(result.observation.rawObservation.value.startsWith("  "), true);
  assert.equal(result.comparison.normalizedRepresentation.disposition, "applied-separately");
  assert.equal(result.comparison.normalizedRepresentation.value.startsWith("{"), true);
  assert.deepEqual(result.comparison.normalizedRepresentation.appliedNormalizations, ["trim surrounding whitespace"]);
});

test("OBS-02 rejects an unsupported normalization and exposes the stored result through its list API", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId, attempt } = await prepareReference(server, archive({ normalization: ["round to four decimals"] }));
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute-reference?expectedActiveContextId=${contextId}` });
  const result = response.json();
  assert.equal(result.comparison.status, "comparison-error");
  assert.equal(result.comparison.error.code, "normalization_not_supported");
  assert.equal(result.comparison.normalizedRepresentation.disposition, "not-produced");
  const listed = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/observation-comparisons?observationId=${encodeURIComponent(result.observation.id)}` });
  assert.equal(listed.statusCode, 200);
  assert.equal(listed.json().comparisons.length, 1);
  assert.equal(listed.json().comparisons[0].id, result.comparison.id);
});

test("EX-03A refuses exploratory attempts instead of inventing an invocation", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const { session, contextId } = await prepareReference(server, archive());
  const exploratory = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`, headers: { "content-type": "application/json" }, payload: { ptcIdentifier: "UKO-001-PTC-001", exerciseDisposition: "exploratory", mediaType: "application/json", value: "{}" } });
  assert.equal(exploratory.statusCode, 201);
  const response = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${exploratory.json().id}/execute-reference?expectedActiveContextId=${contextId}` });
  assert.equal(response.statusCode, 409);
  assert.equal(response.json().error.code, "canonical_rtcm_attempt_required");
});
