import test from "node:test";
import assert from "node:assert/strict";
import { ExecutionEvidenceManager } from "../dist/evidence/execution-evidence-manager.js";

function dependencies() { let n=0; return { clock:{now:()=>"2026-07-17T13:00:00.000Z"}, identifiers:{next:()=>`evidence-${++n}`} }; }
const attempt=Object.freeze({id:"attempt-1",sessionId:"session-1",activeContextId:"context-1",publicationLoadId:"load-1",iorId:"ior-1",pathwayId:"path-1",endpointIdentifier:"IR-1",endpointType:"implementation-representation",input:Object.freeze({mediaType:"application/json",value:'{"x":1}'}),requestedAt:"2026-07-17T11:00:00.000Z",status:"prepared",executionDisposition:"not-started",explanation:"none"});
const interaction=Object.freeze({id:"interaction-1",sessionId:"session-1",activeContextId:"context-1",attemptId:"attempt-1",publicationLoadId:"load-1",iorId:"ior-1",pathwayId:"path-1",endpointIdentifier:"IR-1",externalInteractionId:"external-1",request:Object.freeze({mediaType:"application/json",value:'{"x":1}',requestedAt:"2026-07-17T11:00:00.000Z"}),response:Object.freeze({receivedFrom:"adapter:test",outcome:"completed",mediaType:"application/json",value:'{"result":42}',receivedAt:"2026-07-17T12:00:00.000Z"}),status:"response-received",executionResponsibility:"external-environment",coordinationDisposition:"response-intake-only",verificationDisposition:"received-not-independently-verified",explanation:"none"});
const observation=Object.freeze({id:"observation-1",sessionId:"session-1",activeContextId:"context-1",attemptId:"attempt-1",pathwayId:"path-1",endpointIdentifier:"IR-1",executionInteractionId:"interaction-1",externalInteractionId:"external-1",receivedFrom:"adapter:test",outcome:"completed",response:Object.freeze({mediaType:"application/json",value:'{"result":42}'}),capturedAt:"2026-07-17T12:00:00.000Z",status:"ephemeral",captureDisposition:"automatically-derived-from-interaction",verificationDisposition:"received-not-independently-verified",persistenceDisposition:"not-saved",explanation:"none"});
const publication={activeContextId:"context-1",publicationLoadId:"load-1",publicationIdentifier:"UKO-1",sourceName:"uko.zip",iorId:"ior-1"};
const pathway={id:"path-1",endpointIdentifier:"IR-1",endpointType:"implementation-representation",relationshipTypes:[],steps:[{identifier:"IR-1",realizationType:"implementation-representation"}]};
const identity={implementation:"PC3 Architectural Reference Implementation",version:"0.0.0-dev11c",developmentPass:"DEV-11C"};

test("attests an immutable self-contained evidence artifact with provenance and integrity",()=>{
  const manager=new ExecutionEvidenceManager(dependencies());
  const result=manager.attest({observation,interaction,attempt,expectedActiveContextId:"context-1",publication,pathway,identity});
  assert.equal(result.status,"attested");
  assert.equal(result.evidence.status,"attested-ephemeral");
  assert.equal(result.evidence.attestation.scope,"faithful-record-attestation");
  assert.equal(result.evidence.attestation.cryptographicSignatureDisposition,"not-implemented");
  assert.equal(result.evidence.runtimeObservation.id,"observation-1");
  assert.equal(result.evidence.provenance.executionInteraction.id,"interaction-1");
  assert.equal(result.evidence.provenance.exerciseAttempt.id,"attempt-1");
  assert.match(result.evidence.integrity.digest,/^[a-f0-9]{64}$/);
  assert.match(result.evidence.attestation.statement,/does not attest/);
  assert.equal(Object.isFrozen(result.evidence),true);
  assert.equal(Object.isFrozen(result.evidence.provenance),true);
});

test("attestation is idempotent per observation and rejects context mismatch",()=>{
  const manager=new ExecutionEvidenceManager(dependencies());
  assert.equal(manager.attest({observation,interaction,attempt,expectedActiveContextId:"wrong",publication,pathway,identity}).status,"context-mismatch");
  const first=manager.attest({observation,interaction,attempt,expectedActiveContextId:"context-1",publication,pathway,identity});
  const second=manager.attest({observation,interaction,attempt,expectedActiveContextId:"context-1",publication,pathway,identity});
  assert.equal(first.status,"attested"); assert.equal(second.status,"already-attested"); assert.equal(second.evidence.id,first.evidence.id);
});

test("optional save identifies PC3 and discard affects only ephemeral evidence",()=>{
  const manager=new ExecutionEvidenceManager(dependencies());
  const result=manager.attest({observation,interaction,attempt,expectedActiveContextId:"context-1",publication,pathway,identity});
  assert.equal(result.status,"attested");
  const saved=manager.saveRecord(result.evidence);
  assert.equal(saved.recordType,"pc3-execution-evidence"); assert.equal(saved.source.version,"0.0.0-dev11c"); assert.match(saved.statement,/Saving was optional/);
  assert.equal(manager.discard("session-1","context-1",result.evidence.id),"discarded");
  assert.equal(manager.list("session-1","context-1").length,0);
});

test("formal collection save covers every requested current observation in order",()=>{
  const manager=new ExecutionEvidenceManager(dependencies());
  const result=manager.attest({observation,interaction,attempt,expectedActiveContextId:"context-1",publication,pathway,identity});
  assert.equal(result.status,"attested");
  assert.equal(manager.saveCollectionRecord("session-1","context-1",["missing"]),undefined);
  const saved=manager.saveCollectionRecord("session-1","context-1",[observation.id]);
  assert.equal(saved.recordType,"pc3-observation-collection-attestation");
  assert.equal(saved.observationCount,1);
  assert.equal(saved.evidence[0].runtimeObservation.id,observation.id);
  assert.equal(saved.integrity.coveredContent,"ordered-current-observation-evidence-and-pc3-identity");
  assert.match(saved.integrity.digest,/^[a-f0-9]{64}$/);
  assert.match(saved.statement,/all Runtime Observations currently present/);
});

test("ATT-01 requires and integrity-covers a matching comparison for PTC-scoped evidence",()=>{
  const manager=new ExecutionEvidenceManager(dependencies());
  const binding=Object.freeze({ptcIdentifier:"PTC-1",rtcmIdentifier:"RTCM-1",realizationIdentifier:"SR-1",resolutionDisposition:"unique-authoritative-rtcm"});
  const ptcAttempt=Object.freeze({...attempt,endpointIdentifier:"SR-1",input:Object.freeze({mediaType:"application/json",value:'{"x":1}',source:"publication-canonical"}),exerciseDisposition:"canonical",publicationExerciseBinding:binding});
  const ptcInteraction=Object.freeze({...interaction,endpointIdentifier:"SR-1",publicationExerciseBinding:binding});
  const ptcObservation=Object.freeze({...observation,endpointIdentifier:"SR-1",publicationExerciseScope:binding,rawObservation:Object.freeze({id:"raw-1",mediaType:"application/json",value:'{"result":{"risk":1}}',sha256:"abc",location:"stdout",preservationDisposition:"immutable-raw-preserved",sourceClassification:"directly-observed"})});
  const comparison=Object.freeze({id:"comparison-1",sessionId:"session-1",activeContextId:"context-1",observationId:"observation-1",executionInteractionId:"interaction-1",evaluatedAt:"2026-07-17T12:00:00.000Z",publicationExerciseScope:Object.freeze({ptcIdentifier:"PTC-1",rtcmIdentifier:"RTCM-1",realizationIdentifier:"SR-1"}),status:"fail",rawRepresentation:Object.freeze({rawObservationId:"raw-1",mediaType:"application/json",value:'{"result":{"risk":1}}',sha256:"abc",preservationDisposition:"immutable-raw-preserved"}),normalizedRepresentation:Object.freeze({disposition:"not-required",mediaType:"application/json",value:'{"result":{"risk":1}}',appliedNormalizations:Object.freeze([])}),extractedRepresentation:Object.freeze({disposition:"extracted",strategy:"json-result-risk",sourcePath:"result.risk",value:1}),expectedRepresentation:Object.freeze({outcomeKind:"value",value:2}),comparisonRepresentation:Object.freeze({comparisonType:"exact",absoluteTolerance:0,absoluteDifference:1,roundingApplied:false,satisfied:false}),claimDisposition:"comparison-result-not-conformance",statement:"A failed comparison is not conformance."});
  assert.equal(manager.attest({observation:ptcObservation,interaction:ptcInteraction,attempt:ptcAttempt,expectedActiveContextId:"context-1",publication,pathway,identity}).status,"incomplete-ptc-chain");
  const result=manager.attest({observation:ptcObservation,interaction:ptcInteraction,attempt:ptcAttempt,comparison,expectedActiveContextId:"context-1",publication,pathway,identity});
  assert.equal(result.status,"attested");
  assert.equal(result.evidence.evidenceScope,"complete-ptc-exercise-chain");
  assert.equal(result.evidence.expectedOutcomeComparison.status,"fail");
  assert.equal(result.evidence.ptcExerciseChain.comparisonId,"comparison-1");
  assert.equal(result.evidence.inputDisposition.source,"publication-canonical");
  assert.deepEqual(result.evidence.pc3Identity,identity);
  assert.equal(result.evidence.integrity.coveredContent,"attested-exercise-record-and-pc3-identity");
  const changedIdentityManager=new ExecutionEvidenceManager(dependencies());
  const changed=changedIdentityManager.attest({observation:ptcObservation,interaction:ptcInteraction,attempt:ptcAttempt,comparison,expectedActiveContextId:"context-1",publication,pathway,identity:{...identity,version:"different-version"}});
  assert.equal(changed.status,"attested");
  assert.notEqual(changed.evidence.integrity.digest,result.evidence.integrity.digest);
  assert.equal(Object.isFrozen(result.evidence.expectedOutcomeComparison),true);
});
