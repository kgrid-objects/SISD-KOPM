import assert from "node:assert/strict";
import test from "node:test";
import { isoInstant, publicationInterpretationId, publicationLoadId } from "../dist/domain/index.js";
import { InternalOperationalRepresentationManager } from "../dist/publication/internal-operational-representation.js";

const provenance = { resourcePath: "metadata.yaml", resourceSha256: "a".repeat(64), location: "$.realizations[0]", basis: "explicit-declaration" };
const manager = new InternalOperationalRepresentationManager({
  clock: { now: () => isoInstant("2026-07-16T18:10:00.000Z") },
  identifiers: { next: () => "ior-001" }
});

function interpretation(overrides = {}) {
  return {
    id: publicationInterpretationId("interpretation-001"),
    publicationLoadId: publicationLoadId("load-001"),
    interpretedAt: isoInstant("2026-07-16T18:00:00.000Z"),
    publicationIdentity: { value: { declaredIdentifier: "UKO-001" }, provenance },
    realizations: [
      { identifier: "IR-PY", realizationType: "implementation-representation", provenance },
      { identifier: "SR-REST", realizationType: "service-realization", provenance: { ...provenance, location: "$.realizations[1]" } }
    ],
    relationships: [
      { relationshipType: "built-up-from", sourceIdentifier: "SR-REST", targetIdentifier: "IR-PY", provenance }
    ],
    limitations: [],
    interpretedResourcePaths: ["metadata.yaml"],
    ...overrides
  };
}

test("constructs a traceable IOR from PC3 Interpretation", () => {
  const result = manager.construct(interpretation());
  assert.equal(result.id, "ior-001");
  assert.equal(result.publicationIdentifier, "UKO-001");
  assert.equal(result.realizationNodes.length, 2);
  assert.equal(result.relationshipEdges[0].sourceResolved, true);
  assert.equal(result.relationshipEdges[0].traceability.resourcePath, "metadata.yaml");
});

test("preserves unresolved relationships as visible construction limitations", () => {
  const result = manager.construct(interpretation({
    relationships: [{ relationshipType: "built-up-from", sourceIdentifier: "SR-REST", targetIdentifier: "IR-MISSING", provenance }]
  }));
  assert.equal(result.relationshipEdges[0].targetResolved, false);
  assert.equal(result.constructionLimitations[0].code, "unresolved_relationship_endpoint");
});

test("does not silently merge duplicate realization identifiers", () => {
  const result = manager.construct(interpretation({
    realizations: [
      { identifier: "R-1", realizationType: "implementation-representation", provenance },
      { identifier: "R-1", realizationType: "service-realization", provenance }
    ]
  }));
  assert.equal(result.realizationNodes.length, 1);
  assert.equal(result.constructionLimitations[0].code, "duplicate_realization_identifier");
});
