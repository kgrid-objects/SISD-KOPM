import assert from "node:assert/strict";
import test from "node:test";
import { zipSync } from "fflate";
import { isoInstant } from "../dist/domain/index.js";
import { createServer } from "../dist/app/create-server.js";

const config = { host: "127.0.0.1", port: 3000, logLevel: "silent", maximumUploadBytes: 1_073_741_824 };
function dependencies() {
  let counter = 0;
  return {
    config,
    clock: { now: () => isoInstant("2026-07-16T18:00:00.000Z") },
    identifiers: { next: () => `id-${++counter}` }
  };
}

function ptcExerciseArchive() {
  return zipSync({
    "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO-EX-01\n  version: 1.1\n"),
    "cks.docx": new TextEncoder().encode("canonical capability specification"),
    "ir.yaml": new TextEncoder().encode("describes:\n  identifier: IR-ONE\n  parentLayerIdentifier: UKO-LAYER-IR\n"),
    "ir-two.yaml": new TextEncoder().encode("describes:\n  identifier: IR-TWO\n  parentLayerIdentifier: UKO-LAYER-IR\n"),
    "ptc.yaml": new TextEncoder().encode(`identifier: PTC-001
version: 1.0.0
title: Canonical exercise
status: authoritative
publicationIdentifier: UKO-EX-01
publishedCapabilitySpecification: cks.docx
purpose: Exercise the published capability.
applicability:
  applicableRealizationCount: 1
  notApplicableRealizationCount: 1
  nonApplicabilityIsPermitted: true
canonicalInputObject:
  canonicalPredictorOrder: [x]
  objectType: predictor set
  validity: valid
  properties:
    x: 2
canonicalExpectedOutcome:
  outcomeKind: successful computation
  semanticResult:
    value: 4
  expectedValueAuthority: CKS
comparisonSemantics:
  comparisonType: exact
  normativeValuePath: semanticResult.value
  absoluteTolerance: 0
  roundingPermittedBeforeComparison: false
applicabilityDetermination:
  matrixReference: matrix.yaml
  applicableRealizationInstances: [IR-ONE]
  notApplicableRealizationInstances: [IR-TWO]
`),
    "rtcm.yaml": new TextEncoder().encode(`identifier: RTCM-PTC-001-IR-ONE
version: 1.0.0
status: authoritative
canonicalOrigin:
  ptcIdentifier: PTC-001
complementedRealization:
  identifier: IR-ONE
  layer: IR
applicabilityBasis:
  status: applicable
  pairingKey: PTC-001|IR-ONE
  conformanceAssertion: false
inputDerivation:
  canonicalInputReference: canonicalInputObject
  concreteRepresentation:
    mediaType: application/json
    inlinePermitted: true
  bindings:
    - canonicalField: x
      localBinding: argument x
      transformation: identity
  derivationConstraints: [canonical values unchanged]
invocation:
  mode: library
  entryPoint: calculate
  argumentOrder: [x]
  externalEnvironmentRequirements: [external runtime]
  doesNotEmbedRuntime: true
observationDerivation:
  rawObservationLocation: return-value
  extractionExpression: result
  semanticOutcome: result
  normalizations: []
  rawObservationMustBePreserved: true
comparison:
  canonicalExpectedOutcomeReference: canonicalExpectedOutcome
  comparisonType: exact
  toleranceReference: 0
  representationSpecificHandling: []
  mustPermitFailResult: true
evidenceLinkageRequirements: [ptcIdentifier, rtcmIdentifier, rawObservation]
limitations: [Declarative only.]
`)
  });
}

test("health endpoint reports the exact UX-01 reference release", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const response = await server.inject({ method: "GET", url: "/api/health" });
  assert.equal(response.statusCode, 200);
  assert.deepEqual(response.json(), {
    status: "ok",
    service: "pc3-server",
    implementationVersion: "0.1.0",
    developmentPass: "UX-01"
  });
});

test("application endpoint discloses governing baselines", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const response = await server.inject({ method: "GET", url: "/api/application" });
  assert.equal(response.statusCode, 200);
  assert.equal(response.json().specificationBaseline, "PC3 v1.0 Pass 11.7 + PC3-SPEC-ADD-PTC-01");
  assert.equal(response.json().blueprintBaseline, "PC3 Architecture Blueprint v1.0 + PC3-BP-ADD-PTC-01");
});

test("browser upload loads and interprets explicit declarations without activating a publication", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const archive = zipSync({
    "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO-001\n  version: 1.0\nimplementationRepresentations:\n  - identifier: IR-PY\n")
  });
  const response = await server.inject({
    method: "POST",
    url: "/api/publications/interpret?filename=UKO-001.zip",
    headers: { "content-type": "application/zip" },
    payload: Buffer.from(archive)
  });
  assert.equal(response.statusCode, 200);
  const payload = response.json();
  assert.equal(payload.load.sourceName, "UKO-001.zip");
  assert.equal(payload.interpretation.publicationIdentity.declaredIdentifier, "UKO-001");
  assert.equal(payload.interpretation.realizations[0].identifier, "IR-PY");
  assert.equal(payload.interpretation.realizations[0].provenance.basis, "explicit-declaration");
  assert.equal(payload.interpretation.publicationValidation.status, "not-applicable");
  assert.equal(payload.ior.realizationNodeCount, 1);
  assert.equal(payload.ior.publicationIdentifier, "UKO-001");
  assert.equal("activeContext" in payload, false);
});

test("invalid browser uploads return bounded loading failures", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const response = await server.inject({
    method: "POST",
    url: "/api/publications/interpret?filename=broken.zip",
    headers: { "content-type": "application/zip" },
    payload: Buffer.from("not a zip")
  });
  assert.equal(response.statusCode, 400);
  assert.equal(response.json().error.code, "invalid_archive");
});

test("unknown API routes return a bounded error contract", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const response = await server.inject({ method: "GET", url: "/api/unknown" });
  assert.equal(response.statusCode, 404);
  const payload = response.json();
  assert.equal(payload.error.code, "route_not_found");
  assert.equal(typeof payload.error.requestId, "string");
});


test("oversized browser uploads return a specific 413 response", async (t) => {
  const server = createServer({ ...dependencies(), config: { ...config, maximumUploadBytes: 8 } });
  t.after(() => server.close());
  const response = await server.inject({
    method: "POST",
    url: "/api/publications/interpret?filename=large.zip",
    headers: { "content-type": "application/zip" },
    payload: Buffer.alloc(9)
  });
  assert.equal(response.statusCode, 413);
  assert.equal(response.json().error.code, "publication_upload_too_large");
});

test("session activation establishes and replaces exactly one active publication", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const sessionResponse = await server.inject({ method: "POST", url: "/api/sessions" });
  assert.equal(sessionResponse.statusCode, 201);
  const session = sessionResponse.json();
  const archiveOne = zipSync({
    "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO-ONE\nimplementationRepresentations:\n  - identifier: IR-ONE\n")
  });
  const first = await server.inject({
    method: "POST",
    url: `/api/sessions/${session.id}/publications/activate?filename=one.zip`,
    headers: { "content-type": "application/zip" },
    payload: Buffer.from(archiveOne)
  });
  assert.equal(first.statusCode, 200);
  assert.equal(first.json().activeContext.publicationIdentifier, "UKO-ONE");
  const firstContextId = first.json().activeContext.contextId;

  const archiveTwo = zipSync({
    "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO-TWO\nimplementationRepresentations:\n  - identifier: IR-TWO\n")
  });
  const second = await server.inject({
    method: "POST",
    url: `/api/sessions/${session.id}/publications/activate?filename=two.zip&expectedActiveContextId=${encodeURIComponent(firstContextId)}`,
    headers: { "content-type": "application/zip" },
    payload: Buffer.from(archiveTwo)
  });
  assert.equal(second.statusCode, 200);
  assert.equal(second.json().replacedContextId, firstContextId);
  assert.equal(second.json().activeContext.publicationIdentifier, "UKO-TWO");

  const current = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/active-context` });
  assert.equal(current.statusCode, 200);
  assert.equal(current.json().publicationIdentifier, "UKO-TWO");
});

test("stale activation is rejected without replacing the active publication", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const archive = zipSync({ "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO-ONE\n") });
  const first = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=one.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive) });
  assert.equal(first.statusCode, 200);
  const stale = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=two.zip&expectedActiveContextId=stale`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive) });
  assert.equal(stale.statusCode, 409);
  assert.equal(stale.json().error.code, "stale_active_context");
  const current = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/active-context` });
  assert.equal(current.json().contextId, first.json().activeContext.contextId);
});

test("UX-01 release regression keeps publications and selections isolated by session", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const firstSession = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const secondSession = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const archive = (publicationIdentifier, realizationIdentifier) => zipSync({
    "metadata/publication.yaml": new TextEncoder().encode(`publication:\n  identifier: ${publicationIdentifier}\nimplementationRepresentations:\n  - identifier: ${realizationIdentifier}\n`)
  });
  const firstActivation = await server.inject({ method: "POST", url: `/api/sessions/${firstSession.id}/publications/activate?filename=first.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive("UKO-FIRST", "IR-FIRST")) });
  const secondActivation = await server.inject({ method: "POST", url: `/api/sessions/${secondSession.id}/publications/activate?filename=second.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive("UKO-SECOND", "IR-SECOND")) });
  assert.equal(firstActivation.statusCode, 200);
  assert.equal(secondActivation.statusCode, 200);
  const firstMatrix = (await server.inject({ method: "GET", url: `/api/sessions/${firstSession.id}/realization-matrix` })).json();
  const secondMatrix = (await server.inject({ method: "GET", url: `/api/sessions/${secondSession.id}/realization-matrix` })).json();
  assert.deepEqual(firstMatrix.pathways.map((item) => item.endpointIdentifier), ["IR-FIRST"]);
  assert.deepEqual(secondMatrix.pathways.map((item) => item.endpointIdentifier), ["IR-SECOND"]);
  const selected = await server.inject({ method: "POST", url: `/api/sessions/${firstSession.id}/realization-matrix/${encodeURIComponent(firstMatrix.pathways[0].id)}/select?expectedActiveContextId=${encodeURIComponent(firstActivation.json().activeContext.contextId)}` });
  assert.equal(selected.statusCode, 200);
  const untouchedSecond = await server.inject({ method: "GET", url: `/api/sessions/${secondSession.id}/active-context` });
  assert.equal(untouchedSecond.json().publicationIdentifier, "UKO-SECOND");
  assert.equal(untouchedSecond.json().selectedPathwayId, undefined);
});


test("matrix exposes all realizations, remains unsupported, and selection changes only context", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const archive = zipSync({
    "metadata/publication.yaml": new TextEncoder().encode(`publication:\n  identifier: UKO-MATRIX\nimplementationRepresentations:\n  - identifier: IR-ONE\nserviceRealizations:\n  - identifier: SR-ONE\ndeploymentPackages:\n  - identifier: DP-ONE\nrelationships:\n  - type: realized-as\n    source: IR-ONE\n    target: SR-ONE\n  - type: packaged-as\n    source: SR-ONE\n    target: DP-ONE\n`)
  });
  const activation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=matrix.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive) });
  assert.equal(activation.statusCode, 200);
  const contextId = activation.json().activeContext.contextId;
  const matrix = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` });
  assert.equal(matrix.statusCode, 200);
  assert.equal(matrix.json().realizationCount, 3);
  assert.equal(matrix.json().realizationPathwayCount, 3);
  assert.deepEqual([matrix.json().irEndpointPathwayCount, matrix.json().srEndpointPathwayCount, matrix.json().dpEndpointPathwayCount], [1,1,1]);
  const deploymentPathway = matrix.json().pathways.find((pathway) => pathway.endpointIdentifier === "DP-ONE");
  assert.deepEqual(deploymentPathway.steps.map((step) => step.identifier), ["IR-ONE", "SR-ONE", "DP-ONE"]);
  const pathwayId = deploymentPathway.id;
  const selection = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathwayId)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}` });
  assert.equal(selection.statusCode, 200);
  const refreshed = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` });
  assert.equal(refreshed.json().selectedPathwayId, pathwayId);
  assert.equal(refreshed.json().pathways.find((pathway) => pathway.id === pathwayId).selected, true);
  assert.equal("exerciseAttemptId" in selection.json(), false);
});

test("matrix selection rejects unknown pathways and stale active contexts", async (t) => {
  const server = createServer(dependencies());
  t.after(() => server.close());
  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const archive = zipSync({ "metadata/publication.yaml": new TextEncoder().encode("publication:\n  identifier: UKO\nimplementationRepresentations:\n  - identifier: IR\n") });
  const activation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=a.zip`, headers: { "content-type": "application/zip" }, payload: Buffer.from(archive) });
  const contextId = activation.json().activeContext.contextId;
  const missing = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/missing/select?expectedActiveContextId=${contextId}` });
  assert.equal(missing.statusCode, 404);
  assert.equal(missing.json().error.code, "pathway_not_found");
  const matrix = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` })).json();
  const stale = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=stale` });
  assert.equal(stale.statusCode, 409);
  assert.equal(stale.json().error.code, "stale_active_context");
});


test("matrix rejects selection of pathway-integrity issues", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: FRAGMENT\nimplementationRepresentations:\n  - identifier: IR\ndeploymentPackages:\n  - identifier: ORPHAN\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=f.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  const fragment=matrix.pathways.find((p)=>p.kind==="pathway-integrity-issue");
  const selection=await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(fragment.id)}/select?expectedActiveContextId=${activation.json().activeContext.contextId}`});
  assert.equal(selection.statusCode,409); assert.equal(selection.json().error.code,"pathway_not_selectable");
});


test("DEV-7 prepares and lists immutable Exercise Attempts without execution", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: UKO-ATTEMPT\nimplementationRepresentations:\n  - identifier: IR-ONE\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=a.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  const pathwayId=matrix.pathways[0].id;
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathwayId)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const prepared=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{mediaType:"application/json",value:'{"risk":0.2}'}});
  assert.equal(prepared.statusCode,201);
  assert.equal(prepared.json().endpointIdentifier,"IR-ONE");
  assert.equal(prepared.json().status,"prepared");
  assert.equal(prepared.json().executionDisposition,"not-started");
  assert.equal("runtimeObservation" in prepared.json(),false);
  const listed=await server.inject({method:"GET",url:`/api/sessions/${session.id}/exercise-attempts`});
  assert.equal(listed.statusCode,200);
  assert.equal(listed.json().attempts.length,1);
  assert.equal(listed.json().attempts[0].input.value,'{"risk":0.2}');
});

test("EX-01 prepares canonical and exploratory attempts with immutable PTC RTCM realization bindings", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=ex-01.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(ptcExerciseArchive())});
  assert.equal(activation.statusCode,200);
  assert.equal(activation.json().interpretation.capabilityProfile.kind,"ptc");
  assert.equal(activation.json().exerciseOpportunityCoverage.status,"available");
  assert.deepEqual(activation.json().exerciseOpportunityCoverage.rows.map(({level,possible,applicable,rtcmResolved,exerciseEnabled,blocked,notApplicable,unclassified})=>({level,possible,applicable,rtcmResolved,exerciseEnabled,blocked,notApplicable,unclassified})),[
    {level:"implementation-representation",possible:2,applicable:1,rtcmResolved:1,exerciseEnabled:0,blocked:1,notApplicable:1,unclassified:0},
    {level:"service-realization",possible:0,applicable:0,rtcmResolved:0,exerciseEnabled:0,blocked:0,notApplicable:0,unclassified:0},
    {level:"deployment-package",possible:0,applicable:0,rtcmResolved:0,exerciseEnabled:0,blocked:0,notApplicable:0,unclassified:0},
    {level:"total",possible:2,applicable:1,rtcmResolved:1,exerciseEnabled:0,blocked:1,notApplicable:1,unclassified:0}
  ]);
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  const pathway=matrix.pathways.find((candidate)=>candidate.endpointIdentifier==="IR-ONE");
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathway.id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});

  const canonical=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{ptcIdentifier:"PTC-001",exerciseDisposition:"canonical",mediaType:"text/plain",value:"must-not-replace-publication-input"}});
  assert.equal(canonical.statusCode,201);
  assert.equal(canonical.json().exerciseDisposition,"canonical");
  assert.deepEqual(canonical.json().input,{mediaType:"application/json",value:'{"x":2}',source:"publication-canonical"});
  assert.deepEqual(canonical.json().publicationExerciseBinding,{ptcIdentifier:"PTC-001",rtcmIdentifier:"RTCM-PTC-001-IR-ONE",realizationIdentifier:"IR-ONE",resolutionDisposition:"unique-authoritative-rtcm"});

  const exploratory=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{ptcIdentifier:"PTC-001",exerciseDisposition:"exploratory",mediaType:"application/json",value:'{"x":9}'}});
  assert.equal(exploratory.statusCode,201);
  assert.equal(exploratory.json().input.value,'{"x":9}');
  assert.equal(exploratory.json().input.source,"user-exploratory");
  assert.equal(exploratory.json().publicationExerciseBinding.rtcmIdentifier,"RTCM-PTC-001-IR-ONE");
  const observations=await server.inject({method:"GET",url:`/api/sessions/${session.id}/runtime-observations`});
  assert.equal(observations.json().observations.length,0);
});

test("EX-01 refuses PTC attempts without an explicit uniquely resolved pairing", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const activation=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=ex-01.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(ptcExerciseArchive())})).json();
  const contextId=activation.activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const missing=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{exerciseDisposition:"canonical"}});
  assert.equal(missing.statusCode,400); assert.equal(missing.json().error.code,"ptc_identifier_required");
  const unknown=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{ptcIdentifier:"PTC-MISSING",exerciseDisposition:"canonical"}});
  assert.equal(unknown.statusCode,409); assert.equal(unknown.json().error.code,"ptc_not_found");
  const nonApplicablePathway=matrix.pathways.find((candidate)=>candidate.endpointIdentifier==="IR-TWO");
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(nonApplicablePathway.id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const nonApplicable=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{ptcIdentifier:"PTC-001",exerciseDisposition:"canonical"}});
  assert.equal(nonApplicable.statusCode,409); assert.equal(nonApplicable.json().error.code,"ptc_realization_not_applicable");
  const listed=await server.inject({method:"GET",url:`/api/sessions/${session.id}/exercise-attempts`});
  assert.equal(listed.json().attempts.length,0);
});

test("EX-01 blocks attempt creation when publication PTC authority is incomplete or invalid", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const invalidArchive=zipSync({
    "metadata.yaml":new TextEncoder().encode("publication:\n  identifier: UKO-INVALID-PTC\nimplementationRepresentations:\n  - identifier: IR-ONE\n"),
    "incomplete-ptc.yaml":new TextEncoder().encode("identifier: PTC-INCOMPLETE\ncanonicalInputObject:\n  properties: { x: 2 }\ncanonicalExpectedOutcome:\n  value: 4\n")
  });
  const activation=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=invalid.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(invalidArchive)})).json();
  assert.equal(activation.interpretation.capabilityProfile.kind,"ambiguous-mixed");
  const contextId=activation.activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const blocked=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{ptcIdentifier:"PTC-INCOMPLETE",exerciseDisposition:"canonical"}});
  assert.equal(blocked.statusCode,409); assert.equal(blocked.json().error.code,"publication_exercise_authority_unresolved");
  const listed=await server.inject({method:"GET",url:`/api/sessions/${session.id}/exercise-attempts`});
  assert.equal(listed.json().attempts.length,0);
});

test("Exercise Attempt preparation requires an active selected realization pathway and current context", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const noPublication=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=x`,headers:{"content-type":"application/json"},payload:{mediaType:"application/json",value:"{}"}});
  assert.equal(noPublication.statusCode,409); assert.equal(noPublication.json().error.code,"no_active_publication");
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: UKO\nimplementationRepresentations:\n  - identifier: IR\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=a.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const noSelection=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{mediaType:"application/json",value:"{}"}});
  assert.equal(noSelection.statusCode,409); assert.equal(noSelection.json().error.code,"no_selected_pathway");
});

test("DEV-9 automatically captures, lists, saves, and discards ephemeral Runtime Observations", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode(`publication:
  identifier: UKO-OBS
implementationRepresentations:
  - identifier: IR-OBS
`)});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=o.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${contextId}`});
  const attempt=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{mediaType:"application/json",value:"{}"}})).json();
  const captured=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execution-responses?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{externalInteractionId:"interaction-1",receivedFrom:"adapter:test",outcome:"completed",responseMediaType:"application/json",responseValue:'{"result":42}',environmentIdentity:"external-test-runtime"}});
  assert.equal(captured.statusCode,201);
  assert.equal(captured.json().observation.captureDisposition,"automatically-derived-from-interaction");
  assert.equal(captured.json().observation.status,"ephemeral");
  assert.equal(captured.json().observation.sessionSequence,1);
  assert.equal(captured.json().observation.response.value,'{"result":42}');
  assert.equal(captured.json().observation.rawObservation.value,'{"result":42}');
  assert.equal(captured.json().observation.rawObservation.sourceClassification,"externally-reported");
  assert.equal(captured.json().observation.extractionProvenance.disposition,"not-available-to-interaction");
  const listed=await server.inject({method:"GET",url:`/api/sessions/${session.id}/runtime-observations`});
  assert.equal(listed.json().observations.length,1);
  const saved=await server.inject({method:"GET",url:`/api/sessions/${session.id}/runtime-observations/${captured.json().observation.id}/save`});
  assert.equal(saved.statusCode,200);
  assert.equal(saved.json().source.product,"PC3");
  assert.equal(saved.json().recordSchemaVersion,"1.3");
  assert.equal(saved.json().observation.rawObservation.value,'{"result":42}');
  assert.equal(saved.json().source.developmentPass,"UX-01");
  assert.match(saved.headers["content-disposition"],/attachment/);
  const discarded=await server.inject({method:"DELETE",url:`/api/sessions/${session.id}/runtime-observations/${captured.json().observation.id}?expectedActiveContextId=${contextId}`});
  assert.equal(discarded.statusCode,200);
  assert.equal((await server.inject({method:"GET",url:`/api/sessions/${session.id}/runtime-observations`})).json().observations.length,0);
});

test("DEV-9 removes manual observation authorship and validates execution-response intake", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const manual=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/missing/runtime-observations`});
  assert.equal(manual.statusCode,410);
  assert.equal(manual.json().error.code,"manual_runtime_observation_removed");
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode(`publication:
  identifier: UKO
implementationRepresentations:
  - identifier: IR
`)});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=o.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const missing=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/missing/execution-responses?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{externalInteractionId:"x",receivedFrom:"adapter",outcome:"completed",responseMediaType:"application/json",responseValue:"{}"}});
  assert.equal(missing.statusCode,404);
  const stale=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/missing/execution-responses?expectedActiveContextId=stale`,headers:{"content-type":"application/json"},payload:{externalInteractionId:"x",receivedFrom:"adapter",outcome:"completed",responseMediaType:"application/json",responseValue:"{}"}});
  assert.equal(stale.statusCode,409);
});

test("DEV-10 attests Runtime Observation plus provenance as optional Execution Evidence", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: UKO-EVIDENCE\nimplementationRepresentations:\n  - identifier: IR-EVIDENCE\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=evidence.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${contextId}`});
  const attempt=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{mediaType:"application/json",value:'{"x":1}'}})).json();
  const capture=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execution-responses?expectedActiveContextId=${contextId}`,headers:{"content-type":"application/json"},payload:{externalInteractionId:"external-evidence-1",receivedFrom:"adapter:test",outcome:"completed",responseMediaType:"application/json",responseValue:'{"result":42}'}})).json();
  const attested=await server.inject({method:"POST",url:`/api/sessions/${session.id}/runtime-observations/${capture.observation.id}/attest?expectedActiveContextId=${contextId}`});
  assert.equal(attested.statusCode,201);
  assert.equal(attested.json().attestation.attester,"PC3");
  assert.equal(attested.json().attestation.implementationVersion,"0.1.0");
  assert.equal(attested.json().runtimeObservation.id,capture.observation.id);
  assert.equal(attested.json().provenance.executionInteraction.id,capture.interaction.id);
  assert.equal(attested.json().provenance.exerciseAttempt.id,attempt.id);
  assert.equal(attested.json().provenance.publication.publicationIdentifier,"UKO-EVIDENCE");
  assert.match(attested.json().integrity.digest,/^[a-f0-9]{64}$/);
  const repeated=await server.inject({method:"POST",url:`/api/sessions/${session.id}/runtime-observations/${capture.observation.id}/attest?expectedActiveContextId=${contextId}`});
  assert.equal(repeated.statusCode,200); assert.equal(repeated.json().id,attested.json().id);
  const listed=await server.inject({method:"GET",url:`/api/sessions/${session.id}/execution-evidence`});
  assert.equal(listed.json().evidence.length,1);
  const saved=await server.inject({method:"GET",url:`/api/sessions/${session.id}/execution-evidence/${attested.json().id}/save`});
  assert.equal(saved.statusCode,200); assert.equal(saved.json().recordType,"pc3-execution-evidence"); assert.match(saved.json().statement,/Saving was optional/);
  const discarded=await server.inject({method:"DELETE",url:`/api/sessions/${session.id}/execution-evidence/${attested.json().id}?expectedActiveContextId=${contextId}`});
  assert.equal(discarded.statusCode,200);
  const observations=await server.inject({method:"GET",url:`/api/sessions/${session.id}/runtime-observations`});
  assert.equal(observations.json().observations.length,1);
});

test("DEV-11 executes an Exercise Attempt through the registered external local-process adapter", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: UKO-EXEC\nimplementationRepresentations:\n  - identifier: IR-ECHO\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=exec.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const attempt=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{mediaType:"text/plain",value:"hello from PC3"}})).json();
  const executed=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execute?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{adapterId:"pc3.local-process.stdio.v1",executable:process.execPath,arguments:["-e","process.stdin.pipe(process.stdout)"]}});
  assert.equal(executed.statusCode,201);
  assert.equal(executed.json().process.exitCode,0);
  assert.equal(executed.json().interaction.response.value,"hello from PC3");
  assert.equal(executed.json().observation.response.value,"hello from PC3");
  assert.equal(executed.json().realizationIdentityAssurance.level,"reported");
  assert.equal(executed.json().environment.environmentType,"local-process");
  assert.equal(executed.json().environment.identityAssurance.level,"observed-and-reported");
  assert.equal(executed.json().environment.operatingSystem.platform.assurance,"observed");
  assert.equal(executed.json().environment.runtime.executable.assurance,"reported");
  assert.equal(executed.json().interaction.response.executionEnvironmentDescriptionId,executed.json().environment.id);
  assert.equal(executed.json().observation.executionEnvironmentDescriptionId,executed.json().environment.id);
  const environments=await server.inject({method:"GET",url:`/api/sessions/${session.id}/execution-environments`});
  assert.equal(environments.statusCode,200);
  assert.equal(environments.json().environments.length,1);
  assert.equal(environments.json().environments[0].descriptionDisposition,"pc3-described-not-provisioned");
});

test("DEV-11 exposes registered adapter capability metadata", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const response=await server.inject({method:"GET",url:"/api/execution-adapters"});
  assert.equal(response.statusCode,200);
  assert.equal(response.json().adapters[0].id,"pc3.local-process.stdio.v1");
  assert.equal(response.json().adapters[0].executionBoundary,"external-process");
  assert.deepEqual(response.json().adapters[0].capabilities[0],{
    id:"python-cli-stdout.v1",
    invocationModes:["cli"],
    realizationTypes:["implementation-representation","service-realization","deployment-package"],
    observation:{location:"stdout",rawMustBePreserved:true},
    runtimeBindings:[{canonicalRuntime:"Python",aliases:["python","python 3","python3"],executable:"python3"}]
  });
  assert.deepEqual(response.json().adapters[0].capabilities[2],{
    id:"dotnet8-cli-stdout.v1",
    invocationModes:["cli"],
    realizationTypes:["service-realization"],
    observation:{location:"stdout",rawMustBePreserved:true},
    runtimeBindings:[{canonicalRuntime:".NET 8",aliases:[".NET 8","dotnet 8","C# / .NET / Native AOT target"],executable:"dotnet"}]
  });
});


test("DEV-12 creates a reported-only environment description for generic external response intake", async (t) => {
  const server=createServer(dependencies()); t.after(()=>server.close());
  const session=(await server.inject({method:"POST",url:"/api/sessions"})).json();
  const archive=zipSync({"metadata/publication.yaml":new TextEncoder().encode("publication:\n  identifier: UKO-ENV\nimplementationRepresentations:\n  - identifier: IR-ENV\n")});
  const activation=await server.inject({method:"POST",url:`/api/sessions/${session.id}/publications/activate?filename=env.zip`,headers:{"content-type":"application/zip"},payload:Buffer.from(archive)});
  const contextId=activation.json().activeContext.contextId;
  const matrix=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/realization-matrix`})).json();
  await server.inject({method:"POST",url:`/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(matrix.pathways[0].id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}`});
  const attempt=(await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{mediaType:"text/plain",value:"input"}})).json();
  const response=await server.inject({method:"POST",url:`/api/sessions/${session.id}/exercise-attempts/${attempt.id}/execution-responses?expectedActiveContextId=${encodeURIComponent(contextId)}`,headers:{"content-type":"application/json"},payload:{externalInteractionId:"external-env-1",receivedFrom:"adapter:test",outcome:"completed",responseMediaType:"text/plain",responseValue:"output",environmentIdentity:"reported-env"}});
  assert.equal(response.statusCode,201);
  const listed=(await server.inject({method:"GET",url:`/api/sessions/${session.id}/execution-environments`})).json();
  assert.equal(listed.environments[0].identityAssurance.level,"reported-only");
  assert.equal(listed.environments[0].externalEnvironmentIdentifier.assurance,"reported");
  assert.equal(listed.environments[0].operatingSystem.platform.assurance,"unavailable");
  assert.equal(response.json().interaction.response.executionEnvironmentDescriptionId,listed.environments[0].id);
});
