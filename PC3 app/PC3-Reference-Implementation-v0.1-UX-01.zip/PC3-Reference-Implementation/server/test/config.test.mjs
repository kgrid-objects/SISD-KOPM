import assert from "node:assert/strict";
import test from "node:test";
import { loadServerConfig } from "../dist/app/config.js";

test("server configuration uses safe local defaults", () => {
  assert.deepEqual(loadServerConfig({}), {
    host: "127.0.0.1",
    port: 3000,
    logLevel: "info",
    maximumUploadBytes: 268435456,
    maximumPublicationResources: 10000,
    maximumPublicationExpandedBytes: 536870912,
    maximumPublicationResourceBytes: 201326592
  });
});

test("server configuration rejects an invalid port", () => {
  assert.throws(() => loadServerConfig({ PC3_PORT: "70000" }), /PC3_PORT/);
});

test("server configuration rejects an invalid log level", () => {
  assert.throws(() => loadServerConfig({ PC3_LOG_LEVEL: "verbose" }), /PC3_LOG_LEVEL/);
});

test("SEC-01 validates every publication intake bound", () => {
  assert.throws(() => loadServerConfig({ PC3_MAX_UPLOAD_BYTES: "0" }), /PC3_MAX_UPLOAD_BYTES/);
  assert.throws(() => loadServerConfig({ PC3_MAX_PUBLICATION_RESOURCES: "many" }), /PC3_MAX_PUBLICATION_RESOURCES/);
  assert.throws(() => loadServerConfig({ PC3_MAX_PUBLICATION_EXPANDED_BYTES: "-1" }), /PC3_MAX_PUBLICATION_EXPANDED_BYTES/);
  assert.throws(() => loadServerConfig({ PC3_MAX_PUBLICATION_RESOURCE_BYTES: "1.5" }), /PC3_MAX_PUBLICATION_RESOURCE_BYTES/);
});
