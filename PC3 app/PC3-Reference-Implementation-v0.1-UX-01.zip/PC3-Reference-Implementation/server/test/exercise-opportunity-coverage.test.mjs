import assert from "node:assert/strict";
import test from "node:test";
import { projectExerciseOpportunityCoverage } from "../dist/publication/exercise-opportunity-coverage.js";

const provenance={resourcePath:"publication.yaml",resourceSha256:"a".repeat(64),location:"$",basis:"explicit-declaration"};
const realization=(identifier,realizationType)=>({identifier,realizationType,provenance});
const ptc=(identifier)=>({identifier,canonicalInput:{value:{},canonicalFieldOrder:[]},canonicalExpectedOutcome:{outcomeKind:"value",value:1},comparisonSemantics:{comparisonType:"exact"},applicability:{nonApplicabilityPermitted:true},provenance});
const applicability=(ptcIdentifier,realizationIdentifier,status)=>({ptcIdentifier,realizationIdentifier,status,provenance});
const resolved=(ptcValue,realizationValue,rtcmIdentifier)=>({ptc:ptcValue,realization:realizationValue,rtcm:{identifier:rtcmIdentifier},canonicalInput:ptcValue.canonicalInput,canonicalExpectedOutcome:ptcValue.canonicalExpectedOutcome,comparisonSemantics:ptcValue.comparisonSemantics,readiness:"publication-exercise-ready",executionBoundary:"external-to-publication",statement:"test"});

test("UII-06 partitions exact PTC-realization opportunities by unique realization level",()=>{
  const p1=ptc("P1"),p2=ptc("P2");
  const ir=realization("IR1","implementation-representation"),sr1=realization("SR1","service-realization"),sr2=realization("SR2","service-realization"),dp=realization("DP1","deployment-package");
  const interpretation={
    publicationTestCases:[p1,p2],
    realizations:[ir,ir,sr1,sr2,dp],
    publicationTestCaseApplicability:[
      applicability("P1","IR1","applicable"),applicability("P1","IR1","applicable"),applicability("P2","IR1","not-applicable"),
      applicability("P1","SR1","applicable"),applicability("P2","SR1","applicable"),applicability("P1","SR2","not-applicable"),applicability("P2","SR2","undetermined"),
      applicability("P1","DP1","applicable")
    ],
    resolvedExercises:[resolved(p1,ir,"R1"),resolved(p1,ir,"R1"),resolved(p1,sr1,"R2"),resolved(p2,sr1,"R3"),resolved(p1,dp,"R4")]
  };
  const support=[
    {ptcIdentifier:"P1",realizationIdentifier:"IR1",rtcmIdentifier:"R1",executable:true},
    {ptcIdentifier:"P1",realizationIdentifier:"SR1",rtcmIdentifier:"R2",executable:false},
    {ptcIdentifier:"P2",realizationIdentifier:"SR1",rtcmIdentifier:"R3",executable:true}
  ];
  const result=projectExerciseOpportunityCoverage(interpretation,support);
  assert.equal(result.status,"available");
  assert.deepEqual(result.rows.map(({level,possible,applicable,rtcmResolved,exerciseEnabled,blocked,notApplicable,unclassified,coveragePercent})=>({level,possible,applicable,rtcmResolved,exerciseEnabled,blocked,notApplicable,unclassified,coveragePercent})),[
    {level:"implementation-representation",possible:2,applicable:1,rtcmResolved:1,exerciseEnabled:1,blocked:0,notApplicable:1,unclassified:0,coveragePercent:100},
    {level:"service-realization",possible:4,applicable:2,rtcmResolved:2,exerciseEnabled:1,blocked:1,notApplicable:1,unclassified:1,coveragePercent:50},
    {level:"deployment-package",possible:2,applicable:1,rtcmResolved:1,exerciseEnabled:0,blocked:1,notApplicable:0,unclassified:1,coveragePercent:0},
    {level:"total",possible:8,applicable:4,rtcmResolved:4,exerciseEnabled:2,blocked:2,notApplicable:2,unclassified:2,coveragePercent:50}
  ]);
});

test("UII-06 treats conflicting applicability as unclassified and exposes hierarchy errors",()=>{
  const p1=ptc("P1"),ir=realization("IR1","implementation-representation");
  const conflict=projectExerciseOpportunityCoverage({publicationTestCases:[p1],realizations:[ir],publicationTestCaseApplicability:[applicability("P1","IR1","applicable"),applicability("P1","IR1","not-applicable")],resolvedExercises:[resolved(p1,ir,"R1")]},[]);
  assert.equal(conflict.rows[0].unclassified,1);assert.equal(conflict.rows[0].applicable,0);assert.equal(conflict.status,"projection-error");assert.match(conflict.errors[0],/not deterministically applicable/);
});

test("UII-06 rejects ambiguous realization levels and duplicate support tuples",()=>{
  const p1=ptc("P1");
  const ir=realization("R1","implementation-representation");
  const sr=realization("R1","service-realization");
  const result=projectExerciseOpportunityCoverage({
    publicationTestCases:[p1],
    realizations:[ir,sr],
    publicationTestCaseApplicability:[applicability("P1","R1","applicable")],
    resolvedExercises:[resolved(p1,ir,"RTCM1")]
  },[
    {ptcIdentifier:"P1",realizationIdentifier:"R1",rtcmIdentifier:"RTCM1",executable:true},
    {ptcIdentifier:"P1",realizationIdentifier:"R1",rtcmIdentifier:"RTCM1",executable:true}
  ]);
  assert.equal(result.status,"projection-error");
  assert.ok(result.errors.some((message)=>/multiple levels/.test(message)));
  assert.ok(result.errors.some((message)=>/not unique/.test(message)));
  assert.equal(result.rows.at(-1).exerciseEnabled,0);
});

test("UII-06 keeps a zero-valued PTC-less matrix and em-dash-ready null coverage",()=>{
  const result=projectExerciseOpportunityCoverage({publicationTestCases:[],realizations:[realization("IR1","implementation-representation")],publicationTestCaseApplicability:[],resolvedExercises:[]},[]);
  assert.equal(result.status,"available");assert.equal(result.rows.length,4);
  for(const item of result.rows){assert.equal(item.possible,0);assert.equal(item.applicable,0);assert.equal(item.coveragePercent,null);}
  assert.match(result.statement,/no Publication Test Cases/);
});
