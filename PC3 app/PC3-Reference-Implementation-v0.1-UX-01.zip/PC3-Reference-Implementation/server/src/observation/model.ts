import type { IsoInstant } from "../domain/time.js";
import type { ActiveOperationalContextId, ExecutionInteractionId, ExerciseAttemptId, RuntimeObservationId, SessionId } from "../domain/identifiers.js";

export type RuntimeOutcome = "completed" | "failed" | "indeterminate";
export type ObservationPropertyClassification = "directly-observed" | "externally-reported" | "pc3-derived";

/** Automatically derived, session-ephemeral record of an explicit Execution Interaction. */
export interface RuntimeObservation {
  readonly id: RuntimeObservationId;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly sessionSequence: number;
  readonly attemptId: ExerciseAttemptId;
  readonly pathwayId: string;
  readonly endpointIdentifier: string;
  readonly publicationExerciseScope?: {
    readonly ptcIdentifier: string;
    readonly rtcmIdentifier: string;
    readonly realizationIdentifier: string;
    readonly resolutionDisposition: "unique-authoritative-rtcm";
  };
  readonly executionInteractionId: ExecutionInteractionId;
  readonly externalInteractionId: string;
  readonly receivedFrom: string;
  readonly environmentIdentity?: string;
  readonly executionEnvironmentDescriptionId?: string;
  readonly outcome: RuntimeOutcome;
  readonly response: { readonly mediaType: string; readonly value: string };
  readonly rawObservation: {
    readonly id: string;
    readonly mediaType: string;
    readonly value: string;
    readonly sha256: string;
    readonly location: string;
    readonly preservationDisposition: "immutable-raw-preserved";
    readonly sourceClassification: "directly-observed" | "externally-reported";
  };
  readonly extractionProvenance: {
    readonly disposition: "rtcm-declaration-captured-not-applied" | "not-available-to-interaction";
    readonly rtcmIdentifier?: string;
    readonly rawObservationLocation?: string;
    readonly extractionExpression?: string;
    readonly semanticOutcome?: string;
    readonly declarationProvenance?: { readonly resourcePath: string; readonly resourceSha256: string; readonly location: string; readonly basis: "explicit-declaration" | "provisional-structure-inference" };
    readonly statement: string;
  };
  readonly normalizationRecords: readonly {
    readonly declaration: string;
    readonly disposition: "declared-not-applied";
    readonly inputRawObservationId: string;
    readonly statement: string;
  }[];
  readonly propertyClassifications: readonly {
    readonly classification: ObservationPropertyClassification;
    readonly properties: readonly string[];
    readonly basis: string;
  }[];
  readonly runtimeReportedAt?: IsoInstant;
  readonly capturedAt: IsoInstant;
  readonly status: "ephemeral";
  readonly captureDisposition: "automatically-derived-from-interaction";
  readonly verificationDisposition: "received-not-independently-verified";
  readonly persistenceDisposition: "not-saved";
  readonly explanation: string;
}

export interface SavedRuntimeObservationRecord {
  readonly recordType: "pc3-saved-runtime-observation";
  readonly recordSchemaVersion: "1.3";
  readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly savedAt: IsoInstant;
  readonly observation: RuntimeObservation;
  readonly statement: string;
}
