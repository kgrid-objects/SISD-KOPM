# Observation boundary

OBS-01 extends every Runtime Observation with a separately identified immutable raw observation. PTC-bound observations copy their PTC, RTCM, and realization scope from the immutable Exercise Interaction. Reference executions retain the RTCM raw-location, extraction, semantic-outcome, normalization, and declaration-provenance information available to the interaction.

Raw content is hashed and remains independently inspectable. Normalization declarations are recorded as `declared-not-applied`; no normalized representation replaces the raw observation. Properties are classified as directly observed, externally reported, or PC3-derived. Extraction, comparison, scientific validity, and conformance remain outside OBS-01.

DEV-8B supersedes DEV-8 manual observation recording.

A Runtime Observation is created automatically when PC3 receives a response through the external execution-response intake boundary. The received response, its interaction identity, source, outcome, optional environment identity, and associated Exercise Attempt are preserved immutably.

Runtime Observations are session-memory records with status `ephemeral`, capture disposition `automatically-derived-from-interaction`, verification disposition `received-not-independently-verified`, and persistence disposition `not-saved`.

The user may save a PC3-authored JSON record or discard the ephemeral observation. Saving is optional, leaves the ephemeral object unchanged, identifies PC3 and its exact version, stays external to the UKO, and is not Execution Evidence.

PC3 does not launch, control, or become the external runtime. Receiving a response does not independently prove execution correctness.
