import { runtimeObservationId, type ActiveOperationalContextId, type ExerciseAttemptId, type RuntimeObservationId, type SessionId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import type { ExecutionInteraction } from "../interaction/model.js";
import type { RuntimeObservation, SavedRuntimeObservationRecord } from "./model.js";
import { createHash } from "node:crypto";

export class RuntimeObservationManager {
  private readonly bySession = new Map<SessionId, RuntimeObservation[]>();
  private readonly nextSequenceBySession = new Map<SessionId, number>();
  constructor(private readonly dependencies: { readonly clock: Clock; readonly identifiers: IdentifierGenerator }) {}

  derive(interaction: ExecutionInteraction): RuntimeObservation {
    const existing = (this.bySession.get(interaction.sessionId) ?? []).find((item) => item.executionInteractionId === interaction.id);
    if (existing) return existing;
    const sessionSequence = this.nextSequenceBySession.get(interaction.sessionId) ?? 1;
    const rawObservationId = `raw-observation:${interaction.id}`;
    const rawSourceClassification = interaction.externalProcess ? "directly-observed" as const : "externally-reported" as const;
    const extractionProvenance = interaction.referenceExecution ? Object.freeze({
      disposition: "rtcm-declaration-captured-not-applied" as const,
      rtcmIdentifier: interaction.referenceExecution.rtcmIdentifier,
      rawObservationLocation: interaction.referenceExecution.observation.location,
      ...(interaction.referenceExecution.extractionExpression ? { extractionExpression: interaction.referenceExecution.extractionExpression } : {}),
      ...(interaction.referenceExecution.semanticOutcome ? { semanticOutcome: interaction.referenceExecution.semanticOutcome } : {}),
      declarationProvenance: interaction.referenceExecution.rtcmDeclarationProvenance,
      statement: "OBS-01 retains the RTCM extraction declaration as provenance only. Semantic extraction and comparison have not been performed."
    }) : Object.freeze({
      disposition: "not-available-to-interaction" as const,
      ...(interaction.publicationExerciseBinding ? { rtcmIdentifier: interaction.publicationExerciseBinding.rtcmIdentifier } : {}),
      statement: "The interaction did not carry an RTCM observation-extraction declaration. PC3 did not infer one."
    });
    const normalizationRecords = Object.freeze((interaction.referenceExecution?.normalizationDeclarations ?? []).map((declaration) => Object.freeze({
      declaration,
      disposition: "declared-not-applied" as const,
      inputRawObservationId: rawObservationId,
      statement: "OBS-01 records this declared normalization without applying it or replacing the immutable raw observation."
    })));
    const observation: RuntimeObservation = Object.freeze({
      id: runtimeObservationId(this.dependencies.identifiers.next()),
      sessionId: interaction.sessionId,
      activeContextId: interaction.activeContextId,
      sessionSequence,
      attemptId: interaction.attemptId,
      pathwayId: interaction.pathwayId,
      endpointIdentifier: interaction.endpointIdentifier,
      ...(interaction.publicationExerciseBinding ? { publicationExerciseScope: Object.freeze({ ...interaction.publicationExerciseBinding }) } : {}),
      executionInteractionId: interaction.id,
      externalInteractionId: interaction.externalInteractionId,
      receivedFrom: interaction.response.receivedFrom,
      ...(interaction.response.environmentIdentity ? { environmentIdentity: interaction.response.environmentIdentity } : {}),
      ...(interaction.response.executionEnvironmentDescriptionId ? { executionEnvironmentDescriptionId: interaction.response.executionEnvironmentDescriptionId } : {}),
      outcome: interaction.response.outcome,
      response: Object.freeze({ mediaType: interaction.response.mediaType, value: interaction.response.value }),
      rawObservation: Object.freeze({
        id: rawObservationId,
        mediaType: interaction.response.mediaType,
        value: interaction.response.value,
        sha256: createHash("sha256").update(interaction.response.value, "utf8").digest("hex"),
        location: interaction.referenceExecution?.observation.location ?? "external-response-value",
        preservationDisposition: "immutable-raw-preserved" as const,
        sourceClassification: rawSourceClassification
      }),
      extractionProvenance,
      normalizationRecords,
      propertyClassifications: Object.freeze([
        Object.freeze({ classification: rawSourceClassification, properties: Object.freeze(["rawObservation.value", "rawObservation.mediaType"]), basis: interaction.externalProcess ? "PC3 captured stdout bytes and process disposition directly from the external child process." : "An external caller supplied the response value and media type through the execution-response intake boundary." }),
        Object.freeze({ classification: "externally-reported" as const, properties: Object.freeze(["outcome", "runtimeReportedAt", "receivedFrom", "environmentIdentity"]), basis: "These properties originate with the external execution environment or adapter and are not independently verified by PC3." }),
        Object.freeze({ classification: "pc3-derived" as const, properties: Object.freeze(["id", "sessionSequence", "publicationExerciseScope", "rawObservation.id", "rawObservation.sha256", "capturedAt"]), basis: "PC3 derived identifiers, sequencing, scope association, integrity identity, and capture linkage from immutable PC3-held records." })
      ]),
      ...(interaction.response.runtimeReportedAt ? { runtimeReportedAt: interaction.response.runtimeReportedAt } : {}),
      capturedAt: interaction.response.receivedAt,
      status: "ephemeral",
      captureDisposition: "automatically-derived-from-interaction",
      verificationDisposition: "received-not-independently-verified",
      persistenceDisposition: "not-saved",
      explanation: "OBS-01 automatically derives this ephemeral, PTC-scoped Runtime Observation from an explicit Execution Interaction. Its independently inspectable raw observation remains immutable; extraction and normalization declarations are provenance only and no comparison has been performed."
    });
    const list = this.bySession.get(observation.sessionId) ?? [];
    this.bySession.set(observation.sessionId, [...list, observation]);
    this.nextSequenceBySession.set(observation.sessionId, sessionSequence + 1);
    return observation;
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId, attemptId?: ExerciseAttemptId): readonly RuntimeObservation[] {
    return (this.bySession.get(sessionId) ?? []).filter((item) => item.activeContextId === activeContextId && (!attemptId || item.attemptId === attemptId));
  }

  find(sessionId: SessionId, observationId: RuntimeObservationId): RuntimeObservation | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.id === observationId);
  }

  discard(sessionId: SessionId, activeContextId: ActiveOperationalContextId, observationId: RuntimeObservationId): "discarded" | "not-found" | "context-mismatch" {
    const list = this.bySession.get(sessionId) ?? [];
    const observation = list.find((item) => item.id === observationId);
    if (!observation) return "not-found";
    if (observation.activeContextId !== activeContextId) return "context-mismatch";
    this.bySession.set(sessionId, list.filter((item) => item.id !== observationId));
    return "discarded";
  }

  saveRecord(observation: RuntimeObservation, identity: { readonly implementation: string; readonly version: string; readonly developmentPass: string }): SavedRuntimeObservationRecord {
    return Object.freeze({
      recordType: "pc3-saved-runtime-observation",
      recordSchemaVersion: "1.3",
      source: Object.freeze({ product: "PC3", ...identity }),
      savedAt: this.dependencies.clock.now(),
      observation,
      statement: "This user-saved record was produced by PC3 from an ephemeral Runtime Observation derived from an explicit Execution Interaction. Saving was optional. The record remains external to the published computational capability and is not Execution Evidence."
    });
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); this.nextSequenceBySession.delete(sessionId); }
}
