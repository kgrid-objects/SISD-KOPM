import type { ActiveOperationalContextId, ExecutionInteractionId, RuntimeObservationId, SessionId } from "../domain/identifiers.js";
import type { IsoInstant } from "../domain/time.js";

export type ExpectedOutcomeComparisonStatus = "pass" | "fail" | "indeterminate" | "comparison-error";

/** Immutable result of deterministic comparison. It is not a Runtime Observation or conformance claim. */
export interface ExpectedOutcomeComparison {
  readonly id: string;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly observationId: RuntimeObservationId;
  readonly executionInteractionId: ExecutionInteractionId;
  readonly evaluatedAt: IsoInstant;
  readonly publicationExerciseScope: { readonly ptcIdentifier: string; readonly rtcmIdentifier: string; readonly realizationIdentifier: string };
  readonly status: ExpectedOutcomeComparisonStatus;
  readonly rawRepresentation: { readonly rawObservationId: string; readonly mediaType: string; readonly value: string; readonly sha256: string; readonly preservationDisposition: "immutable-raw-preserved" };
  readonly normalizedRepresentation: {
    readonly disposition: "not-required" | "applied-separately" | "not-produced";
    readonly mediaType: string;
    readonly value?: string;
    readonly appliedNormalizations: readonly string[];
  };
  readonly extractedRepresentation: {
    readonly disposition: "extracted" | "not-extracted";
    readonly strategy: "json-result-risk" | "direct-json-return-value" | "json-declared-path" | "semantic-rejection";
    readonly declaredExpression?: string;
    readonly sourcePath: string;
    readonly value?: unknown;
  };
  readonly expectedRepresentation: {
    readonly outcomeKind: string;
    readonly value: unknown;
    readonly normativeValuePath?: string;
    readonly authorityReference?: string;
    readonly requiredRepresentation?: string;
    readonly requiredUnit?: string;
  };
  readonly comparisonRepresentation: {
    readonly comparisonType?: string;
    readonly absoluteTolerance?: number;
    readonly relativeTolerance?: number;
    readonly absoluteDifference?: number;
    readonly roundingApplied: false;
    readonly satisfied?: boolean;
    readonly semanticAssertions?: readonly {
      readonly assertion: "no-valid-risk-result" | "declared-error-code" | "declared-error-subject" | "must-not-conflate";
      readonly satisfied: boolean;
      readonly observed: string;
    }[];
  };
  readonly error?: { readonly code: string; readonly message: string };
  readonly claimDisposition: "comparison-result-not-conformance";
  readonly statement: string;
}
