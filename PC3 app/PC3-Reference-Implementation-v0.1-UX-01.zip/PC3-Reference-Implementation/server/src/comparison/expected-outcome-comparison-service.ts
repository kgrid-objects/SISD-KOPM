import type { ActiveOperationalContextId, RuntimeObservationId, SessionId } from "../domain/identifiers.js";
import type { ExecutionInteraction } from "../interaction/model.js";
import type { RuntimeObservation } from "../observation/model.js";
import type { ExpectedOutcomeComparison } from "./model.js";

const permittedNormalizations = new Set(["trim surrounding whitespace", "trim trailing newline"]);

export class ExpectedOutcomeComparisonService {
  private readonly bySession = new Map<SessionId, ExpectedOutcomeComparison[]>();

  evaluate(observation: RuntimeObservation, interaction: ExecutionInteraction): ExpectedOutcomeComparison | undefined {
    if (!observation.publicationExerciseScope || !interaction.referenceExecution) return undefined;
    const existing = (this.bySession.get(observation.sessionId) ?? []).find((item) => item.observationId === observation.id);
    if (existing) return existing;
    const reference = interaction.referenceExecution;
    const sourcePath = reference.semanticExtractionStrategy === "direct-json-return-value" ? "$return" : reference.semanticExtractionStrategy === "json-declared-path" ? reference.semanticObservationPath ?? "<undeclared>" : reference.semanticExtractionStrategy === "semantic-rejection" ? "error" : "result.risk";
    const base = {
      id: `expected-outcome-comparison:${observation.id}`,
      sessionId: observation.sessionId,
      activeContextId: observation.activeContextId,
      observationId: observation.id,
      executionInteractionId: interaction.id,
      evaluatedAt: observation.capturedAt,
      publicationExerciseScope: Object.freeze({ ptcIdentifier: observation.publicationExerciseScope.ptcIdentifier, rtcmIdentifier: observation.publicationExerciseScope.rtcmIdentifier, realizationIdentifier: observation.publicationExerciseScope.realizationIdentifier }),
      rawRepresentation: Object.freeze({ rawObservationId: observation.rawObservation.id, mediaType: observation.rawObservation.mediaType, value: observation.rawObservation.value, sha256: observation.rawObservation.sha256, preservationDisposition: "immutable-raw-preserved" as const }),
      expectedRepresentation: Object.freeze({
        outcomeKind: reference.expectedOutcomeKind,
        value: reference.expectedOutcomeValue,
        ...(reference.normativeExpectedValuePath ? { normativeValuePath: reference.normativeExpectedValuePath } : {}),
        ...(reference.expectedOutcomeAuthorityReference ? { authorityReference: reference.expectedOutcomeAuthorityReference } : {}),
        ...(reference.requiredRepresentation ? { requiredRepresentation: reference.requiredRepresentation } : {}),
        ...(reference.requiredUnit ? { requiredUnit: reference.requiredUnit } : {})
      }),
      claimDisposition: "comparison-result-not-conformance" as const
    };
    const notExtracted = (normalizedRepresentation: ExpectedOutcomeComparison["normalizedRepresentation"], code: string, message: string, status: "indeterminate" | "comparison-error"): ExpectedOutcomeComparison => Object.freeze({
      ...base,
      status,
      normalizedRepresentation,
      extractedRepresentation: Object.freeze({ disposition: "not-extracted" as const, strategy: reference.semanticExtractionStrategy, ...(reference.extractionExpression ? { declaredExpression: reference.extractionExpression } : {}), sourcePath }),
      comparisonRepresentation: comparisonDeclaration(reference),
      error: Object.freeze({ code, message }),
      statement: status === "indeterminate" ? "The external execution did not produce a completed observation suitable for comparison. No conformance conclusion follows." : "PC3 could not deterministically apply the declared extraction and comparison contract. The raw observation remains unchanged and no conformance conclusion follows."
    });

    if (observation.outcome !== "completed") {
      return this.store(notExtracted(Object.freeze({ disposition: "not-produced", mediaType: observation.rawObservation.mediaType, appliedNormalizations: Object.freeze([]) }), "external_outcome_not_completed", `External outcome was ${observation.outcome}.`, "indeterminate"));
    }

    const declarations = reference.normalizationDeclarations;
    const unsupported = declarations.find((item) => !permittedNormalizations.has(item.trim().toLowerCase()));
    if (unsupported) {
      return this.store(notExtracted(Object.freeze({ disposition: "not-produced", mediaType: observation.rawObservation.mediaType, appliedNormalizations: Object.freeze([]) }), "normalization_not_supported", `Declared normalization is not supported by OBS-02: ${unsupported}.`, "comparison-error"));
    }
    let normalized = observation.rawObservation.value;
    for (const declaration of declarations) {
      const normalizedDeclaration = declaration.trim().toLowerCase();
      if (normalizedDeclaration === "trim surrounding whitespace") normalized = normalized.trim();
      if (normalizedDeclaration === "trim trailing newline") normalized = normalized.replace(/[\r\n]+$/u, "");
    }
    const normalizedRepresentation: ExpectedOutcomeComparison["normalizedRepresentation"] = Object.freeze({
      disposition: declarations.length ? "applied-separately" as const : "not-required" as const,
      mediaType: observation.rawObservation.mediaType,
      value: normalized,
      appliedNormalizations: Object.freeze([...declarations])
    });

    let parsed: unknown;
    try { parsed = JSON.parse(normalized); }
    catch { return this.store(notExtracted(normalizedRepresentation, "raw_observation_not_json", "The completed raw observation is not valid JSON.", "comparison-error")); }
    if (reference.semanticExtractionStrategy === "semantic-rejection") {
      const plan = reference.invocation.negativeConditionPlan;
      if (!plan) return this.store(notExtracted(normalizedRepresentation, "negative_comparison_contract_incomplete", "The immutable reference execution does not retain its negative-condition comparison plan.", "comparison-error"));
      const root = isObject(parsed) ? parsed : undefined;
      if (!root) return this.store(notExtracted(normalizedRepresentation, "semantic_rejection_not_object", "The completed rejection Observation is not a JSON object.", "comparison-error"));
      const risk = readJsonPath(root, reference.semanticObservationPath ?? "result");
      const noValidRisk = typeof risk !== "number" || !Number.isFinite(risk);
      const errorObject = isObject(root.error) ? root.error : undefined;
      if (!errorObject && noValidRisk) return this.store(notExtracted(normalizedRepresentation, "semantic_rejection_error_absent", "The response contains neither a valid risk result nor the declared structured error object.", "comparison-error"));
      const observedCode = typeof errorObject?.code === "string" ? errorObject.code : "<absent>";
      const details = isObject(errorObject?.details) ? errorObject.details : undefined;
      const observedSubject = typeof details?.parameter === "string" ? details.parameter : undefined;
      const codeSatisfied = observedCode === plan.expectedErrorCode;
      const subjectRequired = plan.operation !== "supply-invalid-aggregate-shape";
      const subjectSatisfied = !subjectRequired || observedSubject === plan.localSubject;
      const distinctionSatisfied = plan.operation === "supply-invalid-aggregate-shape" ? observedCode === plan.expectedErrorCode : observedCode !== "REST_INVALID_REQUEST_SHAPE";
      const assertions = Object.freeze([
        Object.freeze({ assertion: "no-valid-risk-result" as const, satisfied: noValidRisk, observed: noValidRisk ? "No finite numeric risk result was present." : `Finite risk result ${String(risk)} was present.` }),
        Object.freeze({ assertion: "declared-error-code" as const, satisfied: codeSatisfied, observed: observedCode }),
        Object.freeze({ assertion: "declared-error-subject" as const, satisfied: subjectSatisfied, observed: subjectRequired ? observedSubject ?? "<absent>" : "Aggregate subject established by the declared request-shape error mapping." }),
        Object.freeze({ assertion: "must-not-conflate" as const, satisfied: distinctionSatisfied, observed: plan.mustNotConflateWith ? `${observedCode}; excluded: ${plan.mustNotConflateWith}` : observedCode })
      ]);
      const satisfied = assertions.every((item) => item.satisfied);
      return this.store(Object.freeze({
        ...base,
        status: satisfied ? "pass" as const : "fail" as const,
        normalizedRepresentation,
        extractedRepresentation: Object.freeze({ disposition: "extracted" as const, strategy: "semantic-rejection" as const, ...(reference.extractionExpression ? { declaredExpression: reference.extractionExpression } : {}), sourcePath, value: immutableJson(errorObject ?? root) }),
        comparisonRepresentation: Object.freeze({ ...comparisonDeclaration(reference), semanticAssertions: assertions, satisfied }),
        statement: satisfied ? "The structured rejection satisfies the declared semantic Expected Outcome. This is a comparison result, not a conformance claim." : "The structured rejection does not satisfy every declared semantic assertion. The discrepancy is preserved; this is not a conformance claim."
      }));
    }
    const risk = sourcePath === "$return" ? parsed : readJsonPath(parsed, sourcePath);
    if (typeof risk !== "number" || !Number.isFinite(risk)) return this.store(notExtracted(normalizedRepresentation, "semantic_observation_not_numeric", `The declared ${sourcePath} semantic observation is absent or not a finite number.`, "comparison-error"));
    if (typeof reference.expectedOutcomeValue !== "number" || !Number.isFinite(reference.expectedOutcomeValue)) return this.store(notExtracted(normalizedRepresentation, "expected_outcome_not_numeric", "The canonical Expected Outcome is not a finite number.", "comparison-error"));
    const type = reference.comparisonDeclaration?.comparisonType?.trim().toLowerCase();
    if (type !== "numeric absolute tolerance" && type !== "exact") return this.store(notExtracted(normalizedRepresentation, "comparison_type_not_supported", `Comparison type is not supported by OBS-02: ${reference.comparisonDeclaration?.comparisonType ?? "undeclared"}.`, "comparison-error"));
    const tolerance = type === "exact" ? 0 : reference.comparisonDeclaration?.absoluteTolerance;
    if (typeof tolerance !== "number" || !Number.isFinite(tolerance) || tolerance < 0) return this.store(notExtracted(normalizedRepresentation, "absolute_tolerance_invalid", "Numeric absolute-tolerance comparison requires a finite non-negative tolerance.", "comparison-error"));
    const difference = Math.abs(risk - reference.expectedOutcomeValue);
    const satisfied = difference <= tolerance;
    return this.store(Object.freeze({
      ...base,
      status: satisfied ? "pass" as const : "fail" as const,
      normalizedRepresentation,
      extractedRepresentation: Object.freeze({ disposition: "extracted" as const, strategy: reference.semanticExtractionStrategy, ...(reference.extractionExpression ? { declaredExpression: reference.extractionExpression } : {}), sourcePath, value: risk }),
      comparisonRepresentation: Object.freeze({ ...comparisonDeclaration(reference), absoluteTolerance: tolerance, absoluteDifference: difference, roundingApplied: false as const, satisfied }),
      statement: satisfied ? "The extracted semantic observation satisfies the declared canonical comparison rule. This is a comparison result, not a conformance claim." : "The extracted semantic observation does not satisfy the declared canonical comparison rule. The discrepancy is preserved; this is not a conformance claim."
    }));
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId, observationId?: RuntimeObservationId): readonly ExpectedOutcomeComparison[] {
    return (this.bySession.get(sessionId) ?? []).filter((item) => item.activeContextId === activeContextId && (!observationId || item.observationId === observationId));
  }

  findByObservation(sessionId: SessionId, observationId: RuntimeObservationId): ExpectedOutcomeComparison | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.observationId === observationId);
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); }

  discardByObservation(sessionId: SessionId, observationId: RuntimeObservationId): void {
    this.bySession.set(sessionId, (this.bySession.get(sessionId) ?? []).filter((item) => item.observationId !== observationId));
  }

  private store(result: ExpectedOutcomeComparison): ExpectedOutcomeComparison {
    const list = this.bySession.get(result.sessionId) ?? [];
    this.bySession.set(result.sessionId, [...list, result]);
    return result;
  }
}

function comparisonDeclaration(reference: NonNullable<ExecutionInteraction["referenceExecution"]>): ExpectedOutcomeComparison["comparisonRepresentation"] {
  return Object.freeze({
    ...(reference.comparisonDeclaration?.comparisonType ? { comparisonType: reference.comparisonDeclaration.comparisonType } : {}),
    ...(reference.comparisonDeclaration?.absoluteTolerance !== undefined ? { absoluteTolerance: reference.comparisonDeclaration.absoluteTolerance } : {}),
    ...(reference.comparisonDeclaration?.relativeTolerance !== undefined ? { relativeTolerance: reference.comparisonDeclaration.relativeTolerance } : {}),
    roundingApplied: false as const
  });
}

function isObject(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value); }

function readJsonPath(value: unknown, path: string): unknown {
  if (!path || path === "<undeclared>") return undefined;
  return path.split(".").reduce<unknown>((current, segment) => isObject(current) ? current[segment] : undefined, value);
}

function immutableJson(value: unknown): unknown {
  return value === undefined ? null : JSON.parse(JSON.stringify(value));
}
