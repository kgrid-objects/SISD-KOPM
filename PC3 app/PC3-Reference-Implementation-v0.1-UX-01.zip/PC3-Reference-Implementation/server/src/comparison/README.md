# Expected Outcome comparison boundary

OBS-02 implements deterministic comparison as a service separate from Runtime Observation capture. It currently supports the accepted `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` profile: extract finite numeric `result.risk` from completed JSON output and apply exact or numeric absolute-tolerance comparison against the canonical Expected Outcome.

Raw, normalized, extracted, expected, and comparison representations are retained separately. Permitted normalization is allow-listed and creates a separate string representation; unknown normalization produces `comparison-error`. External failed or indeterminate outcomes produce `indeterminate`. Invalid JSON, missing/non-numeric semantic values, invalid expected values or tolerance, and unsupported comparison types produce `comparison-error`.

`pass` and `fail` mean only that the extracted value did or did not satisfy the declared numeric rule. They are not conformance, scientific-validity, execution-correctness, or realization-equivalence claims. The Runtime Observation remains unchanged.
