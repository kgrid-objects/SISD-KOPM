import { resolve } from "node:path";
import { PublicationLoader } from "../publication/publication-loader.js";
import { LocalFilesystemPublicationSourceAdapter } from "../infrastructure/publication/local-filesystem-publication-source-adapter.js";
import { randomIdentifierGenerator, systemClock } from "../infrastructure/system/system-services.js";

const locator = process.argv[2];
if (!locator) {
  console.error("Usage: npm run load:publication -- <directory-or-zip>");
  process.exitCode = 2;
} else {
  const absolute = resolve(locator);
  const kind = absolute.toLowerCase().endsWith(".zip") ? "uploaded-archive" : "local-directory";
  const loader = new PublicationLoader({ adapters: [new LocalFilesystemPublicationSourceAdapter()], clock: systemClock, identifiers: randomIdentifierGenerator });
  const outcome = await loader.load({ kind, locator: absolute });
  console.log(JSON.stringify(outcome, null, 2));
  if (outcome.status === "failed") process.exitCode = 1;
}
