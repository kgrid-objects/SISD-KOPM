import type { IsoInstant } from "../domain/time.js";
import type { ActiveOperationalContextId, ExecutionEnvironmentDescriptionId, ExerciseAttemptId, SessionId } from "../domain/identifiers.js";

export type EnvironmentPropertyAssurance = "observed" | "reported" | "unavailable";

export interface DescribedEnvironmentProperty {
  readonly value?: string;
  readonly assurance: EnvironmentPropertyAssurance;
  readonly basis: string;
}

/** Immutable PC3 description of an external execution environment; never the environment itself. */
export interface ExecutionEnvironmentDescription {
  readonly id: ExecutionEnvironmentDescriptionId;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly attemptId: ExerciseAttemptId;
  readonly pathwayId: string;
  readonly adapter: { readonly id: string; readonly name: string; readonly version: string };
  readonly environmentType: "local-process" | "docker-container" | "externally-reported";
  readonly executionBoundary: "external-process" | "external-container" | "external-environment";
  readonly externalEnvironmentIdentifier: DescribedEnvironmentProperty;
  readonly operatingSystem: {
    readonly platform: DescribedEnvironmentProperty;
    readonly release: DescribedEnvironmentProperty;
    readonly architecture: DescribedEnvironmentProperty;
  };
  readonly runtime: {
    readonly executable: DescribedEnvironmentProperty;
    readonly version: DescribedEnvironmentProperty;
  };
  readonly workingDirectory: DescribedEnvironmentProperty;
  readonly container?: {
    readonly providerId: string;
    readonly imageReference: DescribedEnvironmentProperty;
    readonly imageId: DescribedEnvironmentProperty;
    readonly containerName: DescribedEnvironmentProperty;
    readonly networkMode: "none";
    readonly rootFilesystem: "read-only";
    readonly publicationMount: { readonly hostPath: DescribedEnvironmentProperty; readonly containerPath: "/workspace"; readonly mode: "read-only" };
    readonly limits: { readonly cpus: string; readonly memory: string; readonly pids: string; readonly tmpfs: string; readonly timeoutMilliseconds: number };
    readonly cleanupDisposition: "removed" | "cleanup-failed";
  };
  readonly describedAt: IsoInstant;
  readonly descriptionDisposition: "pc3-described-not-provisioned" | "pc3-provisioned-disposable-container";
  readonly identityAssurance: {
    readonly level: "observed-and-reported" | "reported-only";
    readonly statement: string;
  };
  readonly explanation: string;
}
