# Execution environment description

DEV-12 makes the external Execution Environment explicit without bringing it inside PC3.

An `ExecutionEnvironmentDescription` is an immutable PC3 record associated with one Exercise Attempt. It distinguishes properties PC3 directly observes from properties reported through an adapter or external response. The description is not an environment, does not provision or manage one, and does not authenticate the realization or prove reproducibility.

The local-process adapter describes the host operating-system context observed by PC3 and the executable/identifier supplied in a generic execution request. External response intake can create a reported-only description when richer observation is unavailable.

EX-03C adds a bounded Docker environment provider for canonical reference execution. It selects only digest-pinned images from an explicit PC3 runtime map, performs read-only daemon and image readiness checks, creates a uniquely named container with no network, a read-only root, a read-only publication mount, resource limits, and a timeout, then attempts forced cleanup in every outcome. The resulting environment description retains the provider, image reference and observed image ID, container identity, isolation policy, limits, mount, and cleanup disposition.
