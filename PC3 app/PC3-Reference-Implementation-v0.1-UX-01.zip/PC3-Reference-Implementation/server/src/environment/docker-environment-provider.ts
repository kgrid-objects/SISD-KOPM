import { createHash, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import type { AdapterExecutionResult, ExecutionAdapter, ReferenceExecutionPlan } from "../adapter/model.js";
import type { ExerciseAttempt } from "../operation/model.js";

export const PC3_PYTHON_DOCKER_IMAGE = "python:3.12-slim@sha256:57cd7c3a7a273101a6485ba99423ee568157882804b1124b4dd04266317710de";
export const PC3_DOTNET8_DOCKER_IMAGE = "mcr.microsoft.com/dotnet/sdk:8.0.422-bookworm-slim@sha256:d80fdd84f7e18eea12f8e45c52914f1353395009c95c41197178ea19944e6d48";

export interface DockerCommandResult {
  readonly exitCode: number | null;
  readonly signal: string | null;
  readonly stdout: string;
  readonly stderr: string;
  readonly timedOut: boolean;
}

export interface DockerCommandRunner {
  run(executable: string, argumentsList: readonly string[], timeoutMilliseconds: number): Promise<DockerCommandResult>;
}

export interface DockerEnvironmentSupport {
  readonly ready: boolean;
  readonly code: string;
  readonly reason: string;
  readonly imageReference?: string;
  readonly imageId?: string;
}

export interface DockerEnvironmentExecutionRequest {
  readonly attempt: ExerciseAttempt;
  readonly adapter: ExecutionAdapter;
  readonly plan: ReferenceExecutionPlan;
  readonly publicationWorkspace: string;
  readonly adapterContainerPath?: string;
  readonly infrastructureWorkspace?: string;
}

export interface DockerEnvironmentProvider {
  assess(canonicalRuntime: string): Promise<DockerEnvironmentSupport>;
  execute(request: DockerEnvironmentExecutionRequest): Promise<AdapterExecutionResult>;
}

export class DockerEnvironmentProviderError extends Error {
  constructor(readonly code: string, message: string) { super(message); this.name = "DockerEnvironmentProviderError"; }
}

const CPU_LIMIT = "1.0";
const MEMORY_LIMIT = "256m";
const PIDS_LIMIT = "128";
const TMPFS_LIMIT = "64m";

export class PinnedDockerEnvironmentProvider implements DockerEnvironmentProvider {
  constructor(
    private readonly runner: DockerCommandRunner = new SpawnDockerCommandRunner(),
    private readonly dockerExecutable = "docker",
    private readonly images: ReadonlyMap<string, string> = new Map([["python", PC3_PYTHON_DOCKER_IMAGE], [".net 8", PC3_DOTNET8_DOCKER_IMAGE]])
  ) {}

  async assess(canonicalRuntime: string): Promise<DockerEnvironmentSupport> {
    const imageReference = this.images.get(canonicalRuntime.trim().toLowerCase());
    if (!imageReference) return Object.freeze({ ready: false, code: "docker_image_mapping_not_found", reason: `No Docker image is explicitly mapped for canonical runtime ${canonicalRuntime}.` });
    if (!/@sha256:[a-f0-9]{64}$/i.test(imageReference)) return Object.freeze({ ready: false, code: "docker_image_not_immutable", reason: `The Docker image mapping for ${canonicalRuntime} is not digest-pinned.` });
    const daemon = await this.runner.run(this.dockerExecutable, ["version", "--format", "{{.Server.Version}}"], 5_000);
    if (daemon.exitCode !== 0 || !daemon.stdout.trim()) return Object.freeze({ ready: false, code: "docker_daemon_unavailable", reason: "Docker is not running or its daemon is not reachable by PC3." });
    const inspected = await this.runner.run(this.dockerExecutable, ["image", "inspect", "--format", "{{.Id}}", imageReference], 5_000);
    if (inspected.exitCode !== 0 || !inspected.stdout.trim()) return Object.freeze({ ready: false, code: "docker_image_unavailable", reason: `The required immutable image is not present locally. Pull it before loading the publication: docker pull ${imageReference}`, imageReference });
    return Object.freeze({ ready: true, code: "docker_environment_ready", reason: "Docker environment ready.", imageReference, imageId: inspected.stdout.trim() });
  }

  async execute(request: DockerEnvironmentExecutionRequest): Promise<AdapterExecutionResult> {
    const support = await this.assess(request.plan.adapterResolution.canonicalRuntime);
    if (!support.ready || !support.imageReference || !support.imageId) throw new DockerEnvironmentProviderError(support.code, support.reason);
    const containerName = `pc3-${randomUUID()}`;
    const mount = `type=bind,src=${request.publicationWorkspace},dst=/workspace,readonly`;
    const library = request.plan.libraryInvocation;
    const dotnetCli = request.plan.dotnetCliInvocation;
    const http = request.plan.httpInvocation;
    if ((library || dotnetCli || http) && !request.infrastructureWorkspace) throw new DockerEnvironmentProviderError(library ? "library_bridge_unavailable" : http ? "http_bridge_unavailable" : "dotnet_cli_bridge_unavailable", "The required PC3 execution bridge was not materialized separately from the publication.");
    if (!library && !dotnetCli && !http && !request.adapterContainerPath) throw new DockerEnvironmentProviderError("reference_adapter_path_missing", "The CLI adapter container path is missing.");
    const invocationArguments = library
      ? ["/pc3-infrastructure/python-library-bridge.py", "--source-root", `/workspace/${library.sourceRootReference}`, "--entry-point", library.entryPoint, "--bindings-json", JSON.stringify(Object.fromEntries(library.namedBindings.map((binding) => [binding.parameter, binding.value])))]
      : dotnetCli
        ? ["run", "--project", "/pc3-infrastructure/pc3-dotnet-cli-bridge.csproj", "--no-launch-profile", "--verbosity", "quiet", "--property:UseAppHost=false", "--", ...request.plan.arguments]
        : http
          ? ["/pc3-infrastructure/python-http-loopback-bridge.py", "--adapter", `/workspace/${request.plan.adapterArtifactReference}`, "--source-root", `/workspace/${http.implementationSourceRootReference}`, "--method", http.method, "--route", http.route, "--request-json", http.requestBody]
          : [request.adapterContainerPath!, ...request.plan.arguments];
    const timeoutMilliseconds = dotnetCli ? 60_000 : 30_000;
    const memoryLimit = dotnetCli ? "512m" : MEMORY_LIMIT;
    const tmpfsLimit = dotnetCli ? "128m" : TMPFS_LIMIT;
    const dockerArguments = [
      "run", "--name", containerName, "--network", "none", "--read-only", "--cap-drop", "ALL",
      "--security-opt", "no-new-privileges", "--cpus", CPU_LIMIT, "--memory", memoryLimit,
      "--memory-swap", memoryLimit, "--pids-limit", PIDS_LIMIT, "--user", "65532:65532", "--tmpfs", `/tmp:rw,noexec,nosuid,size=${tmpfsLimit}`,
      "--mount", mount,
      ...(library || dotnetCli || http ? ["--mount", `type=bind,src=${request.infrastructureWorkspace},dst=/pc3-infrastructure${library || http ? ",readonly" : ""}`] : []),
      "--workdir", "/workspace",
      ...(dotnetCli ? [
        "--env", "DOTNET_CLI_HOME=/tmp/dotnet-home",
        "--env", "NUGET_PACKAGES=/tmp/nuget-packages",
        "--env", "DOTNET_NOLOGO=true",
        "--env", "DOTNET_CLI_TELEMETRY_OPTOUT=true",
        "--env", "DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=true",
        "--env", "DOTNET_SKIP_WORKLOAD_INTEGRITY_CHECK=true",
        "--env", `UKO_SERVICE_YAML=/workspace/${dotnetCli.serviceDeclarationReference}`
      ] : ["--env", "PYTHONDONTWRITEBYTECODE=1"]),
      support.imageReference, request.plan.executable, ...invocationArguments
    ];
    let result: AdapterExecutionResult | undefined;
    let cleanup: DockerCommandResult | undefined;
    try {
      result = await request.adapter.execute(request.attempt, {
        executable: this.dockerExecutable,
        arguments: dockerArguments,
        timeoutMilliseconds,
        environmentIdentity: `docker-container:${containerName}`,
        standardInput: "none"
      });
    } finally {
      cleanup = await this.runner.run(this.dockerExecutable, ["rm", "--force", containerName], 10_000);
    }
    if (!result) throw new DockerEnvironmentProviderError("docker_execution_failed", "The Docker execution did not produce an adapter result.");
    const cleanupDisposition = cleanup.exitCode === 0 || /No such container/i.test(cleanup.stderr) ? "removed" as const : "cleanup-failed" as const;
    if (cleanupDisposition === "cleanup-failed") throw new DockerEnvironmentProviderError("docker_cleanup_failed", `PC3 could not remove container ${containerName}: ${cleanup.stderr.trim() || "unknown Docker error"}`);
    let libraryReturn: AdapterExecutionResult["libraryReturn"];
    let httpExchange: AdapterExecutionResult["httpExchange"];
    let responseValue = result.responseValue;
    let outcome = result.outcome;
    if (library) {
      try {
        const envelope = JSON.parse(result.responseValue) as Record<string, unknown>;
        if (envelope.schema !== library.bridgeId || envelope.status !== "returned" || !("value" in envelope)) {
          outcome = "failed";
        } else {
          const valueJson = JSON.stringify(envelope.value);
          if (valueJson === undefined) throw new Error("The returned value is not JSON transportable.");
          responseValue = valueJson;
          libraryReturn = Object.freeze({
            bridgeId: library.bridgeId,
            transferredEnvelope: result.responseValue,
            transferredEnvelopeSha256: createHash("sha256").update(result.responseValue).digest("hex"),
            value: immutable(envelope.value), valueJson,
            diagnosticStdout: typeof envelope.diagnosticStdout === "string" ? envelope.diagnosticStdout : "",
            diagnosticStderr: typeof envelope.diagnosticStderr === "string" ? envelope.diagnosticStderr : ""
          });
        }
      } catch { outcome = "failed"; }
    }
    if (http) {
      try {
        const envelope = JSON.parse(result.responseValue) as Record<string, unknown>;
        const headers = envelope.responseHeaders;
        if (envelope.schema !== http.bridgeId || envelope.status !== "returned" || envelope.method !== http.method || envelope.route !== http.route || envelope.requestBody !== http.requestBody || !Number.isInteger(envelope.statusCode) || typeof envelope.responseBody !== "string" || typeof envelope.adapterEnvelope !== "string" || typeof envelope.adapterEnvelopeSha256 !== "string" || typeof envelope.adapterStderr !== "string" || !headers || typeof headers !== "object" || Array.isArray(headers)) {
          outcome = "failed";
        } else {
          const responseHeaders = immutable(headers as Record<string, string>);
          responseValue = envelope.responseBody;
          httpExchange = Object.freeze({
            bridgeId: http.bridgeId,
            transferredEnvelope: result.responseValue,
            transferredEnvelopeSha256: createHash("sha256").update(result.responseValue).digest("hex"),
            method: http.method,
            route: http.route,
            requestBody: http.requestBody,
            statusCode: envelope.statusCode as number,
            responseHeaders,
            responseBody: envelope.responseBody,
            adapterEnvelope: envelope.adapterEnvelope,
            adapterEnvelopeSha256: envelope.adapterEnvelopeSha256,
            adapterStderr: envelope.adapterStderr,
            adapterEvidence: immutable(envelope.adapterEvidence)
          });
        }
      } catch { outcome = "failed"; }
    }
    return Object.freeze({
      ...result,
      outcome,
      responseMediaType: library || http ? "application/json" : result.responseMediaType,
      responseValue,
      ...(libraryReturn ? { libraryReturn } : {}),
      ...(httpExchange ? { httpExchange } : {}),
      environmentIdentity: `docker-container:${containerName}@${support.imageId}`,
      environmentDescription: Object.freeze({
        environmentType: "docker-container" as const,
        executionBoundary: "external-container" as const,
        externalEnvironmentIdentifier: containerName,
        operatingSystem: Object.freeze({ platform: "linux-container", release: "image-defined", architecture: "docker-selected" }),
        runtime: Object.freeze({ executable: request.plan.executable }),
        workingDirectory: "/workspace",
        container: Object.freeze({
          providerId: "pc3.docker.environment.v1",
          imageReference: support.imageReference,
          imageId: support.imageId,
          containerName,
          networkMode: "none" as const,
          rootFilesystem: "read-only" as const,
          publicationMount: Object.freeze({ hostPath: request.publicationWorkspace, containerPath: "/workspace", mode: "read-only" as const }),
          limits: Object.freeze({ cpus: CPU_LIMIT, memory: memoryLimit, pids: PIDS_LIMIT, tmpfs: tmpfsLimit, timeoutMilliseconds }),
          cleanupDisposition
        })
      })
    });
  }
}

function immutable<T>(value: T): T {
  const clone = structuredClone(value);
  const freeze = (item: unknown): void => { if (!item || typeof item !== "object" || Object.isFrozen(item)) return; for (const child of Object.values(item)) freeze(child); Object.freeze(item); };
  freeze(clone); return clone;
}

export class SpawnDockerCommandRunner implements DockerCommandRunner {
  async run(executable: string, argumentsList: readonly string[], timeoutMilliseconds: number): Promise<DockerCommandResult> {
    return await new Promise((resolve) => {
      const child = spawn(executable, [...argumentsList], { stdio: ["ignore", "pipe", "pipe"], shell: false, windowsHide: true });
      const stdout: Buffer[] = []; const stderr: Buffer[] = []; let timedOut = false; let settled = false;
      const timer = setTimeout(() => { timedOut = true; child.kill("SIGKILL"); }, timeoutMilliseconds);
      child.stdout.on("data", (chunk: Buffer) => stdout.push(chunk)); child.stderr.on("data", (chunk: Buffer) => stderr.push(chunk));
      child.on("error", (error) => { if (settled) return; settled = true; clearTimeout(timer); resolve(Object.freeze({ exitCode: null, signal: null, stdout: "", stderr: error.message, timedOut })); });
      child.on("close", (exitCode, signal) => { if (settled) return; settled = true; clearTimeout(timer); resolve(Object.freeze({ exitCode, signal, stdout: Buffer.concat(stdout).toString("utf8"), stderr: Buffer.concat(stderr).toString("utf8"), timedOut })); });
    });
  }
}
