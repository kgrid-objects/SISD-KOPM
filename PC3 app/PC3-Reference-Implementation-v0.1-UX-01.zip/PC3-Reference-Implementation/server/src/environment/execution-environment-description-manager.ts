import { executionEnvironmentDescriptionId, type ActiveOperationalContextId, type SessionId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import type { ExerciseAttempt } from "../operation/model.js";
import type { ExecutionEnvironmentDescription } from "./model.js";

export class ExecutionEnvironmentDescriptionManager {
  private readonly bySession = new Map<SessionId, ExecutionEnvironmentDescription[]>();
  constructor(private readonly dependencies: { readonly clock: Clock; readonly identifiers: IdentifierGenerator }) {}

  record(input: Omit<ExecutionEnvironmentDescription, "id" | "sessionId" | "activeContextId" | "attemptId" | "pathwayId" | "describedAt"> & { readonly attempt: ExerciseAttempt }): ExecutionEnvironmentDescription {
    const description: ExecutionEnvironmentDescription = deepFreeze({
      ...input,
      id: executionEnvironmentDescriptionId(this.dependencies.identifiers.next()),
      sessionId: input.attempt.sessionId,
      activeContextId: input.attempt.activeContextId,
      attemptId: input.attempt.id,
      pathwayId: input.attempt.pathwayId,
      describedAt: this.dependencies.clock.now()
    });
    const list = this.bySession.get(description.sessionId) ?? [];
    this.bySession.set(description.sessionId, [...list, description]);
    return description;
  }

  find(sessionId: SessionId, id: string): ExecutionEnvironmentDescription | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.id === id);
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId): readonly ExecutionEnvironmentDescription[] {
    return (this.bySession.get(sessionId) ?? []).filter((item) => item.activeContextId === activeContextId);
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); }
}

function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const nested of Object.values(value as Record<string, unknown>)) deepFreeze(nested);
  }
  return value;
}
