export type IsoInstant = string & { readonly __brand: "IsoInstant" };

export function isoInstant(value: string): IsoInstant {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new Error("Instant must be a valid ISO-8601 date-time.");
  return new Date(parsed).toISOString() as IsoInstant;
}

export interface Clock {
  now(): IsoInstant;
}

export interface IdentifierGenerator {
  next(): string;
}
