/** Framework-neutral, scope-distinct identifiers owned by PC3. */
export type BrandedId<Value extends string, Brand extends string> = Value & {
  readonly __brand: Brand;
};

function createIdFactory<Brand extends string>(prefix: string) {
  return (value: string): BrandedId<string, Brand> => {
    const normalized = value.trim();
    if (!normalized) throw new Error(`${prefix} identifier must not be empty.`);
    return normalized as BrandedId<string, Brand>;
  };
}

export type SessionId = BrandedId<string, "SessionId">;
export type PublicationLoadId = BrandedId<string, "PublicationLoadId">;
export type PublicationInterpretationId = BrandedId<string, "PublicationInterpretationId">;
export type IorId = BrandedId<string, "IorId">;
export type ActiveOperationalContextId = BrandedId<string, "ActiveOperationalContextId">;
export type RealizationPathwayId = BrandedId<string, "RealizationPathwayId">;
export type EnvironmentAssociationId = BrandedId<string, "EnvironmentAssociationId">;
export type ExecutionEnvironmentDescriptionId = BrandedId<string, "ExecutionEnvironmentDescriptionId">;
export type ExerciseAttemptId = BrandedId<string, "ExerciseAttemptId">;
export type ExecutionInteractionId = BrandedId<string, "ExecutionInteractionId">;
export type RuntimeObservationId = BrandedId<string, "RuntimeObservationId">;
export type ExecutionEvidenceId = BrandedId<string, "ExecutionEvidenceId">;

export const sessionId = createIdFactory<"SessionId">("Session");
export const publicationLoadId = createIdFactory<"PublicationLoadId">("Publication load");
export const publicationInterpretationId = createIdFactory<"PublicationInterpretationId">("Publication interpretation");
export const iorId = createIdFactory<"IorId">("IOR");
export const activeOperationalContextId = createIdFactory<"ActiveOperationalContextId">("Active operational context");
export const realizationPathwayId = createIdFactory<"RealizationPathwayId">("Realization pathway");
export const environmentAssociationId = createIdFactory<"EnvironmentAssociationId">("Environment association");
export const executionEnvironmentDescriptionId = createIdFactory<"ExecutionEnvironmentDescriptionId">("Execution environment description");
export const exerciseAttemptId = createIdFactory<"ExerciseAttemptId">("Exercise attempt");
export const executionInteractionId = createIdFactory<"ExecutionInteractionId">("Execution interaction");
export const runtimeObservationId = createIdFactory<"RuntimeObservationId">("Runtime observation");
export const executionEvidenceId = createIdFactory<"ExecutionEvidenceId">("Execution evidence");
