import Fastify, { type FastifyInstance } from "fastify";
import {
  PC3_IMPLEMENTATION,
  type ActiveOperationalContextResponse,
  type ApiErrorResponse,
  type ApplicationInfoResponse,
  type HealthResponse,
  type PublicationActivationResponse,
  type ExecutableRealizationMatrixResponse,
  type PathwaySelectionResponse,
  type PublicationInterpretationResponse,
  type SessionResponse,
  type ExerciseAttemptResponse,
  type ExerciseAttemptListResponse,
  type PrepareExerciseAttemptInput,
  type RuntimeObservationResponse,
  type RuntimeObservationListResponse,
  type ExecutionInteractionCaptureResponse,
  type ExecutionInteractionListResponse,
  type ExternalExecutionResponseInput,
  type SavedRuntimeObservationRecord,
  type ExecutionEvidenceResponse,
  type ExecutionEvidenceListResponse,
  type SavedExecutionEvidenceRecord,
  type SavedObservationCollectionAttestationRecord,
  type ExecutionAdapterListResponse,
  type ExecuteExerciseAttemptInput,
  type ExecuteExerciseAttemptResponse,
  type ExecuteReferenceExerciseAttemptResponse,
  type ExpectedOutcomeComparisonListResponse,
  type ExecutionEnvironmentDescriptionListResponse
} from "@pc3/shared";
import { activeOperationalContextId, sessionId } from "../domain/identifiers.js";
import { ExerciseAttemptManager } from "../operation/exercise-attempt-manager.js";
import { RuntimeObservationManager } from "../observation/runtime-observation-manager.js";
import { ExecutionInteractionManager } from "../interaction/execution-interaction-manager.js";
import { ExecutionEvidenceManager } from "../evidence/execution-evidence-manager.js";
import { exerciseAttemptId, runtimeObservationId, executionEvidenceId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import { InMemoryZipPublicationSourceAdapter } from "../infrastructure/publication/in-memory-zip-publication-source-adapter.js";
import { ActiveOperationalContextManager, type ActivePublicationSnapshot } from "../operation/active-operational-context-manager.js";
import { ExecutableRealizationMatrixProjector, NoInvocationAdapterSupportResolver } from "../operation/executable-realization-matrix.js";
import { PublicationInterpreter } from "../publication/publication-interpreter.js";
import { InternalOperationalRepresentationManager } from "../publication/internal-operational-representation.js";
import { PublicationLoader } from "../publication/publication-loader.js";
import type { ServerConfig } from "./config.js";
import { AdapterCapabilityResolutionError, ExecutionAdapterRegistry } from "../adapter/execution-adapter-registry.js";
import { LocalProcessExecutionAdapter } from "../adapter/local-process-execution-adapter.js";
import { ExecutionEnvironmentDescriptionManager } from "../environment/execution-environment-description-manager.js";
import { PublicationReferenceExecutionPlanner, ReferenceExecutionPlanningError } from "../adapter/publication-reference-execution.js";
import type { AcquiredPublication } from "../publication/source-adapter.js";
import type { AdapterExecutionResult, ReferenceExecutionPlan } from "../adapter/model.js";
import type { ExerciseAttempt } from "../operation/model.js";
import { ExpectedOutcomeComparisonService } from "../comparison/expected-outcome-comparison-service.js";
import { projectExerciseOpportunityCoverage } from "../publication/exercise-opportunity-coverage.js";
import { DockerEnvironmentProviderError, PinnedDockerEnvironmentProvider, type DockerEnvironmentProvider } from "../environment/docker-environment-provider.js";

export interface CreateServerOptions {
  readonly config: ServerConfig;
  readonly clock: Clock;
  readonly identifiers: IdentifierGenerator;
  readonly dockerEnvironmentProvider?: DockerEnvironmentProvider;
}

export function createServer(options: CreateServerOptions): FastifyInstance {
  const server = Fastify({
    logger: { level: options.config.logLevel },
    genReqId: () => crypto.randomUUID(),
    bodyLimit: options.config.maximumUploadBytes
  });
  const contexts = new ActiveOperationalContextManager({ clock: options.clock, identifiers: options.identifiers });
  const matrixProjector = new ExecutableRealizationMatrixProjector(new NoInvocationAdapterSupportResolver());
  const attempts = new ExerciseAttemptManager({ clock: options.clock, identifiers: options.identifiers });
  const interactions = new ExecutionInteractionManager({ clock: options.clock, identifiers: options.identifiers });
  const observations = new RuntimeObservationManager({ clock: options.clock, identifiers: options.identifiers });
  const evidence = new ExecutionEvidenceManager({ clock: options.clock, identifiers: options.identifiers });
  const environments = new ExecutionEnvironmentDescriptionManager({ clock: options.clock, identifiers: options.identifiers });
  const adapters = new ExecutionAdapterRegistry([new LocalProcessExecutionAdapter()]);
  const dockerEnvironments = options.dockerEnvironmentProvider ?? new PinnedDockerEnvironmentProvider();
  const referenceExecutions = new PublicationReferenceExecutionPlanner(adapters, dockerEnvironments);
  const comparisons = new ExpectedOutcomeComparisonService();
  const acquiredPublications = new Map<string, AcquiredPublication>();

  const captureAdapterResult = (attempt: ExerciseAttempt, active: ActivePublicationSnapshot, result: AdapterExecutionResult, referenceExecution?: ReferenceExecutionPlan) => {
    const environment = environments.record({
      attempt,
      adapter: { id: result.adapter.id, name: result.adapter.name, version: result.adapter.version },
      environmentType: result.environmentDescription.environmentType,
      executionBoundary: result.environmentDescription.executionBoundary,
      externalEnvironmentIdentifier: { value: result.environmentDescription.externalEnvironmentIdentifier, assurance: "reported", basis: "Supplied to or constructed by the execution adapter." },
      operatingSystem: {
        platform: { value: result.environmentDescription.operatingSystem.platform, assurance: result.environmentDescription.container ? "reported" : "observed", basis: result.environmentDescription.container ? "Defined by the selected immutable container image and Docker provider." : "Observed by PC3 from the host operating system used to launch the external process." },
        release: { value: result.environmentDescription.operatingSystem.release, assurance: result.environmentDescription.container ? "reported" : "observed", basis: result.environmentDescription.container ? "Defined by the selected immutable container image; not independently queried inside the container." : "Observed by PC3 from the host operating system used to launch the external process." },
        architecture: { value: result.environmentDescription.operatingSystem.architecture, assurance: result.environmentDescription.container ? "reported" : "observed", basis: result.environmentDescription.container ? "Selected by Docker for the immutable multi-platform image." : "Observed by PC3 from the host operating system used to launch the external process." }
      },
      runtime: {
        executable: { value: result.environmentDescription.runtime.executable, assurance: "reported", basis: "Executable path or command supplied in the execution request." },
        version: result.environmentDescription.runtime.version
          ? { value: result.environmentDescription.runtime.version, assurance: "observed", basis: "Observed by PC3 because the requested runtime is the Node.js runtime hosting this reference implementation." }
          : { assurance: "unavailable", basis: "The adapter did not independently query the launched runtime version." }
      },
      workingDirectory: { value: result.environmentDescription.workingDirectory, assurance: "observed", basis: "Effective working directory resolved by PC3 for process launch." },
      ...(result.environmentDescription.container ? { container: {
        providerId: result.environmentDescription.container.providerId,
        imageReference: { value: result.environmentDescription.container.imageReference, assurance: "reported" as const, basis: "Digest-pinned image selected by the PC3 Docker environment provider." },
        imageId: { value: result.environmentDescription.container.imageId, assurance: "observed" as const, basis: "Observed with Docker image inspect immediately before container creation." },
        containerName: { value: result.environmentDescription.container.containerName, assurance: "observed" as const, basis: "Unique container name generated by PC3 for this Exercise Attempt." },
        networkMode: result.environmentDescription.container.networkMode,
        rootFilesystem: result.environmentDescription.container.rootFilesystem,
        publicationMount: { hostPath: { assurance: "unavailable" as const, basis: "PC3 does not disclose its temporary host filesystem path through operational records." }, containerPath: result.environmentDescription.container.publicationMount.containerPath, mode: result.environmentDescription.container.publicationMount.mode },
        limits: result.environmentDescription.container.limits,
        cleanupDisposition: result.environmentDescription.container.cleanupDisposition
      } } : {}),
      descriptionDisposition: result.environmentDescription.container ? "pc3-provisioned-disposable-container" : "pc3-described-not-provisioned",
      identityAssurance: { level: "observed-and-reported", statement: "PC3 combines directly observed host/process-launch properties with adapter-reported identity. This description is not authentication, reproducibility proof, or realization verification." },
      explanation: result.environmentDescription.container ? "PC3 provisioned one disposable, constrained Docker container for this Exercise Attempt and recorded its immutable image identity and cleanup disposition." : "PC3 describes the external execution setting used for this Exercise Attempt. PC3 does not provision, own, or manage the environment."
    });
    const received = interactions.receive({ attempt, expectedActiveContextId: active.contextId, response: {
      externalInteractionId: result.externalInteractionId, receivedFrom: result.receivedFrom, outcome: result.outcome,
      responseMediaType: referenceExecution?.responseMediaType ?? result.responseMediaType, responseValue: result.responseValue, runtimeReportedAt: result.runtimeReportedAt as never,
      environmentIdentity: result.environmentIdentity, executionEnvironmentDescriptionId: environment.id,
      ...(referenceExecution ? { externalProcess: result.process, referenceExecution } : {})
      ,...(result.libraryReturn ? { libraryReturn: result.libraryReturn } : {})
      ,...(result.httpExchange ? { httpExchange: result.httpExchange } : {})
    }});
    if (received.status !== "received") throw new Error("The adapter response could not be captured as an Execution Interaction.");
    const observation = observations.derive(received.interaction);
    const comparison = comparisons.evaluate(observation, received.interaction);
    return { environment, interaction: received.interaction, observation, ...(comparison ? { comparison } : {}) };
  };

  server.addContentTypeParser("application/zip", { parseAs: "buffer" }, (_request, body, done) => done(null, body));
  server.addContentTypeParser("application/octet-stream", { parseAs: "buffer" }, (_request, body, done) => done(null, body));

  server.get<{ Reply: HealthResponse }>("/api/health", async () => ({
    status: "ok", service: "pc3-server", implementationVersion: PC3_IMPLEMENTATION.implementationVersion,
    developmentPass: PC3_IMPLEMENTATION.developmentPass
  }));
  server.get<{ Reply: ApplicationInfoResponse }>("/api/application", async () => ({ ...PC3_IMPLEMENTATION }));
  server.get<{ Reply: ExecutionAdapterListResponse }>("/api/execution-adapters", async () => ({ adapters: adapters.list().map((adapter) => adapter.descriptor) }));
  server.get<{ Params: { sessionId: string }; Reply: ExecutionEnvironmentDescriptionListResponse | ApiErrorResponse }>("/api/sessions/:sessionId/execution-environments", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    return { sessionId: id, activeContextId: active.contextId, environments: environments.list(id, active.contextId) };
  });

  server.post<{ Reply: SessionResponse }>("/api/sessions", async (_request, reply) => {
    const created = contexts.createSession();
    return reply.code(201).send({ id: created.id, createdAt: created.createdAt });
  });

  server.get<{ Params: { sessionId: string }; Reply: ActiveOperationalContextResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/active-context", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      return reply.code(200).send(active ? activeContextView(active) : { sessionId: id });
    }
  );

  server.delete<{ Params: { sessionId: string }; Reply: { closed: true } | ApiErrorResponse }>(
    "/api/sessions/:sessionId", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const priorLoadId = contexts.getActive(id)?.publicationLoad.id;
      const closed = contexts.closeSession(id);
      if (!closed) return reply.code(404).send(apiError("session_not_found_or_closed", "The PC3 session does not exist or is already closed.", request.id));
      attempts.clearSession(id);
      interactions.clearSession(id);
      observations.clearSession(id);
      evidence.clearSession(id);
      environments.clearSession(id);
      comparisons.clearSession(id);
      if (priorLoadId) acquiredPublications.delete(priorLoadId);
      return reply.code(200).send({ closed: true });
    }
  );

  server.post<{
    Params: { sessionId: string };
    Querystring: { filename?: string; expectedActiveContextId?: string };
    Body: Buffer;
    Reply: PublicationActivationResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/publications/activate", async (request, reply) => {
    const candidate = await interpretUpload(request.body, request.query.filename, options);
    if (candidate.error) return reply.code(candidate.error.status).send(apiError(candidate.error.code, candidate.error.message, request.id));
    const session = sessionId(request.params.sessionId);
    const priorLoadId = contexts.getActive(session)?.publicationLoad.id;
    const activation = contexts.activate({
      sessionId: session,
      ...(request.query.expectedActiveContextId ? { expectedActiveContextId: activeOperationalContextId(request.query.expectedActiveContextId) } : {}),
      sourceName: candidate.filename,
      publicationLoad: candidate.loaded.record,
      interpretation: candidate.interpretation,
      ior: candidate.ior
    });
    if (activation.status === "session-not-found") return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
    if (activation.status === "session-closed") return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
    if (activation.status === "stale-context") return reply.code(409).send(apiError("stale_active_context", "The active publication changed before this activation completed. Reload the current context and try again.", request.id));
    acquiredPublications.set(candidate.loaded.record.id, candidate.loaded.acquired);
    if (priorLoadId && priorLoadId !== candidate.loaded.record.id) acquiredPublications.delete(priorLoadId);
    const invocationSupport = await referenceExecutions.assessAll(candidate.interpretation.resolvedExercises, candidate.loaded.acquired);
    const exerciseOpportunityCoverage = projectExerciseOpportunityCoverage(candidate.interpretation, invocationSupport);
    return reply.code(200).send({
      ...interpretationResponse(candidate.filename, candidate.loaded.record, candidate.interpretation, candidate.ior),
      activeContext: activeContextView(activation.active),
      invocationSupport,
      exerciseOpportunityCoverage,
      ...(activation.replacedContextId ? { replacedContextId: activation.replacedContextId } : {})
    });
  });


  server.get<{ Params: { sessionId: string }; Reply: ExecutableRealizationMatrixResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/realization-matrix", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      const matrix = matrixProjector.project(active.ior);
      return reply.code(200).send(matrixView(active, matrix));
    }
  );

  server.post<{ Params: { sessionId: string; pathwayId: string }; Querystring: { expectedActiveContextId?: string }; Reply: PathwaySelectionResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/realization-matrix/:pathwayId/select", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const active = contexts.getActive(id);
      if (!active) {
        const session = contexts.getSession(id);
        if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
        if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
        return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      }
      const matrix = matrixProjector.project(active.ior);
      const pathway = matrix.pathways.find((item) => item.id === request.params.pathwayId);
      if (!pathway) return reply.code(404).send(apiError("pathway_not_found", "The realization pathway is not present in the active publication matrix.", request.id));
      if (!pathway.selectable) return reply.code(409).send(apiError("pathway_not_selectable", "A realization endpoint with an unresolved predecessor chain is visible as a pathway-integrity issue and is not selectable.", request.id));
      const result = contexts.selectPathway({
        sessionId: id,
        expectedActiveContextId: activeOperationalContextId(request.query.expectedActiveContextId ?? active.contextId),
        pathwayId: pathway.id
      });
      if (result.status === "stale-context") return reply.code(409).send(apiError("stale_active_context", "The active publication changed before selection completed.", request.id));
      if (result.status !== "selected") return reply.code(409).send(apiError(result.status, "The pathway could not be selected.", request.id));
      return reply.code(200).send({ sessionId: result.active.sessionId, contextId: result.active.contextId, selectedPathwayId: pathway.id });
    }
  );

  server.post<{
    Params: { sessionId: string };
    Querystring: { expectedActiveContextId?: string };
    Body: PrepareExerciseAttemptInput;
    Reply: ExerciseAttemptResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/exercise-attempts", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const session = contexts.getSession(id);
    if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
    if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId) return reply.code(400).send(apiError("expected_context_required", "Exercise Attempt preparation requires the expected active-context identity.", request.id));
    if (active.contextId !== request.query.expectedActiveContextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before the Exercise Attempt was prepared.", request.id));
    if (!active.selectedPathwayId) return reply.code(409).send(apiError("no_selected_pathway", "Select a realization pathway before preparing an Exercise Attempt.", request.id));
    const matrix = matrixProjector.project(active.ior);
    const pathway = matrix.pathways.find((item) => item.id === active.selectedPathwayId);
    if (!pathway) return reply.code(409).send(apiError("selected_pathway_unavailable", "The selected realization pathway is no longer present in the active Matrix.", request.id));
    const profile = active.interpretation.capabilityProfile;
    const requestedDisposition = request.body?.exerciseDisposition ?? (profile.kind === "ptc" ? "canonical" : "exploratory");
    if (requestedDisposition !== "canonical" && requestedDisposition !== "exploratory") return reply.code(400).send(apiError("invalid_exercise_disposition", "Exercise disposition must be canonical or exploratory.", request.id));
    if (profile.kind === "ambiguous-mixed") return reply.code(409).send(apiError("publication_exercise_authority_unresolved", "The publication's PTC exercise authority is incomplete or invalid. PC3 will not create an Exercise Attempt by guessing an authority.", request.id));

    let publicationExerciseBinding: import("../operation/model.js").ExerciseAttemptBinding | undefined;
    let mediaType = request.body?.mediaType ?? "application/json";
    let value = request.body?.value ?? "";
    let canonicalInputSource: "publication-canonical" | "publication-derived-negative" = "publication-canonical";
    if (profile.kind === "ptc") {
      const ptcIdentifier = request.body?.ptcIdentifier?.trim();
      if (!ptcIdentifier) return reply.code(400).send(apiError("ptc_identifier_required", "A PTC-profile publication requires an explicitly selected Publication Test Case before an Exercise Attempt can be prepared.", request.id));
      const ptc = active.interpretation.publicationTestCases.find((candidate) => candidate.identifier === ptcIdentifier);
      if (!ptc) return reply.code(409).send(apiError("ptc_not_found", "The selected Publication Test Case is not declared by the active publication.", request.id));
      const applicability = active.interpretation.publicationTestCaseApplicability.find((candidate) => candidate.ptcIdentifier === ptcIdentifier && candidate.realizationIdentifier === pathway.endpointIdentifier);
      if (applicability?.status === "not-applicable") return reply.code(409).send(apiError("ptc_realization_not_applicable", "The selected Publication Test Case is explicitly not applicable to this realization.", request.id));
      const authoritativeRtcMs = active.interpretation.realizationTestCaseManifestations.filter((candidate) => candidate.ptcIdentifier === ptcIdentifier && candidate.realizationIdentifier === pathway.endpointIdentifier && candidate.applicability.status === "applicable" && candidate.status === "authoritative");
      if (authoritativeRtcMs.length > 1) return reply.code(409).send(apiError("ptc_realization_rtcm_ambiguous", "More than one authoritative RTCM applies to the selected PTC and realization. PC3 will not choose one.", request.id));
      const resolvedExercise = active.interpretation.resolvedExercises.find((candidate) => candidate.ptc.identifier === ptcIdentifier && candidate.realization.identifier === pathway.endpointIdentifier);
      if (!resolvedExercise) return reply.code(409).send(apiError("ptc_realization_unresolved", "No unique authoritative applicable RTCM resolves the selected PTC and realization. No Exercise Attempt was created.", request.id));
      publicationExerciseBinding = {
        ptcIdentifier: resolvedExercise.ptc.identifier,
        rtcmIdentifier: resolvedExercise.rtcm.identifier,
        realizationIdentifier: resolvedExercise.realization.identifier,
        resolutionDisposition: "unique-authoritative-rtcm"
      };
      if (requestedDisposition === "canonical") {
        mediaType = resolvedExercise.rtcm.inputDerivation.concreteMediaType ?? resolvedExercise.canonicalInput.mediaType ?? "application/json";
        value = serializeCanonicalExerciseInput(resolvedExercise.canonicalInput.value);
        canonicalInputSource = resolvedExercise.ptc.canonicalNegativeInputCondition ? "publication-derived-negative" : "publication-canonical";
      }
    } else if (request.body?.ptcIdentifier || requestedDisposition === "canonical") {
      return reply.code(409).send(apiError("ptc_capability_unavailable", "The active publication does not declare an authoritative PTC capability. A canonical PTC-bound attempt cannot be created.", request.id));
    }
    const result = attempts.prepare({
      active, expectedActiveContextId: activeOperationalContextId(request.query.expectedActiveContextId), pathway,
      mediaType, value, exerciseDisposition: requestedDisposition,
      canonicalInputSource,
      ptcBindingRequired: profile.kind === "ptc",
      ...(publicationExerciseBinding ? { publicationExerciseBinding } : {})
    });
    if (result.status === "stale-context") return reply.code(409).send(apiError("stale_active_context", "The active publication changed before the Exercise Attempt was prepared.", request.id));
    if (result.status === "no-selected-pathway") return reply.code(409).send(apiError("no_selected_pathway", "Select a realization pathway before preparing an Exercise Attempt.", request.id));
    if (result.status === "selected-pathway-mismatch") return reply.code(409).send(apiError("selected_pathway_mismatch", "The selected pathway changed before the Exercise Attempt was prepared.", request.id));
    if (result.status === "pathway-not-selectable") return reply.code(409).send(apiError("pathway_not_selectable", "The selected Matrix entry is not a selectable realization pathway.", request.id));
    if (result.status === "exercise-resolution-required") return reply.code(409).send(apiError("exercise_resolution_required", "A unique authoritative applicable PTC/realization/RTCM resolution is required before this Exercise Attempt can be prepared.", request.id));
    if (result.status === "exercise-binding-mismatch") return reply.code(409).send(apiError("exercise_binding_mismatch", "The resolved exercise realization does not match the selected realization pathway.", request.id));
    if (result.status === "invalid-input") return reply.code(400).send(apiError("invalid_exercise_input", result.explanation, request.id));
    return reply.code(201).send(exerciseAttemptView(result.attempt));
  });

  server.get<{ Params: { sessionId: string }; Reply: ExerciseAttemptListResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/exercise-attempts", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      return reply.code(200).send({ sessionId: id, activeContextId: active.contextId, attempts: attempts.list(id, active.contextId).map(exerciseAttemptView) });
    }
  );

  // DEV-4 compatibility endpoint: interpretation without activation.
  server.post<{ Querystring: { filename?: string }; Body: Buffer; Reply: PublicationInterpretationResponse | ApiErrorResponse }>(
    "/api/publications/interpret", async (request, reply) => {
      const candidate = await interpretUpload(request.body, request.query.filename, options);
      if (candidate.error) return reply.code(candidate.error.status).send(apiError(candidate.error.code, candidate.error.message, request.id));
      return reply.code(200).send(interpretationResponse(candidate.filename, candidate.loaded.record, candidate.interpretation, candidate.ior));
    }
  );


  server.post<{
    Params: { sessionId: string; observationId: string };
    Querystring: { expectedActiveContextId?: string };
    Reply: ExecutionEvidenceResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/runtime-observations/:observationId/attest", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const session = contexts.getSession(id);
    if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
    if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId) return reply.code(400).send(apiError("expected_context_required", "Execution Evidence attestation requires the expected active-context identity.", request.id));
    if (request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before attestation.", request.id));
    const observation = observations.find(id, runtimeObservationId(request.params.observationId));
    if (!observation) return reply.code(404).send(apiError("runtime_observation_not_found", "The Runtime Observation does not exist in this session or has been discarded.", request.id));
    if (observation.activeContextId !== active.contextId) return reply.code(409).send(apiError("observation_context_mismatch", "The Runtime Observation belongs to a different publication context.", request.id));
    const interaction = interactions.find(id, observation.executionInteractionId);
    const attempt = attempts.find(id, observation.attemptId);
    const comparison = comparisons.findByObservation(id, observation.id);
    const environment = observation.executionEnvironmentDescriptionId ? environments.find(id, observation.executionEnvironmentDescriptionId) : undefined;
    if (!interaction || !attempt) return reply.code(409).send(apiError("observation_provenance_incomplete", "PC3 cannot attest this observation because its required interaction or attempt provenance is unavailable.", request.id));
    const matrix = matrixProjector.project(active.ior);
    const pathway = matrix.pathways.find((item) => item.id === observation.pathwayId && item.kind === "realization-pathway");
    if (!pathway) return reply.code(409).send(apiError("pathway_provenance_unavailable", "PC3 cannot attest this observation because its realization pathway is unavailable in the active publication context.", request.id));
    const result = evidence.attest({
      observation, interaction, attempt,
      ...(environment ? { environment } : {}),
      ...(comparison ? { comparison } : {}),
      expectedActiveContextId: active.contextId,
      publication: {
        activeContextId: active.contextId,
        publicationLoadId: active.publicationLoad.id,
        ...(active.ior.publicationIdentifier ? { publicationIdentifier: active.ior.publicationIdentifier } : {}),
        sourceName: active.sourceName,
        iorId: active.ior.id
      },
      pathway: {
        id: pathway.id,
        endpointIdentifier: pathway.endpointIdentifier,
        endpointType: pathway.endpointType,
        relationshipTypes: pathway.relationshipTypes,
        steps: pathway.steps.map((step) => ({
          identifier: step.identifier,
          realizationType: step.realizationType,
          ...(step.artifactReference ? { artifactReference: step.artifactReference } : {}),
          ...(step.invocationMechanism ? { invocationMechanism: step.invocationMechanism } : {})
        }))
      },
      identity: { implementation: PC3_IMPLEMENTATION.implementationName, version: PC3_IMPLEMENTATION.implementationVersion, developmentPass: PC3_IMPLEMENTATION.developmentPass }
    });
    if (result.status === "context-mismatch") return reply.code(409).send(apiError("evidence_context_mismatch", "The evidence inputs do not belong to the active publication context.", request.id));
    if (result.status === "incomplete-ptc-chain") return reply.code(409).send(apiError("ptc_evidence_chain_incomplete", "PC3 cannot attest a PTC-scoped observation until its PTC, RTCM, realization, attempt, interaction, observation, and comparison identities form one complete chain.", request.id));
    return reply.code(result.status === "attested" ? 201 : 200).send(result.evidence);
  });

  server.post<{
    Params: { sessionId: string };
    Querystring: { expectedActiveContextId?: string };
    Reply: SavedObservationCollectionAttestationRecord | ApiErrorResponse;
  }>("/api/sessions/:sessionId/execution-evidence/attest-current", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const session = contexts.getSession(id);
    if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
    if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId || request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before collection attestation.", request.id));
    const currentObservations = [...observations.list(id, active.contextId)].sort((left, right) => left.sessionSequence - right.sessionSequence);
    if (!currentObservations.length) return reply.code(409).send(apiError("observation_collection_empty", "At least one current Runtime Observation is required for collection attestation.", request.id));
    const matrix = matrixProjector.project(active.ior);

    for (const observation of currentObservations) {
      const interaction = interactions.find(id, observation.executionInteractionId);
      const attempt = attempts.find(id, observation.attemptId);
      const comparison = comparisons.findByObservation(id, observation.id);
      const environment = observation.executionEnvironmentDescriptionId ? environments.find(id, observation.executionEnvironmentDescriptionId) : undefined;
      if (!interaction || !attempt) return reply.code(409).send(apiError("observation_collection_provenance_incomplete", `Observation ${observation.sessionSequence} cannot be attested because its Interaction or Attempt provenance is unavailable.`, request.id));
      const pathway = matrix.pathways.find((item) => item.id === observation.pathwayId && item.kind === "realization-pathway");
      if (!pathway) return reply.code(409).send(apiError("observation_collection_pathway_unavailable", `Observation ${observation.sessionSequence} cannot be attested because its realization pathway is unavailable.`, request.id));
      const result = evidence.attest({
        observation, interaction, attempt,
        ...(environment ? { environment } : {}),
        ...(comparison ? { comparison } : {}),
        expectedActiveContextId: active.contextId,
        publication: { activeContextId: active.contextId, publicationLoadId: active.publicationLoad.id, ...(active.ior.publicationIdentifier ? { publicationIdentifier: active.ior.publicationIdentifier } : {}), sourceName: active.sourceName, iorId: active.ior.id },
        pathway: { id: pathway.id, endpointIdentifier: pathway.endpointIdentifier, endpointType: pathway.endpointType, relationshipTypes: pathway.relationshipTypes, steps: pathway.steps.map((step) => ({ identifier: step.identifier, realizationType: step.realizationType, ...(step.artifactReference ? { artifactReference: step.artifactReference } : {}), ...(step.invocationMechanism ? { invocationMechanism: step.invocationMechanism } : {}) })) },
        identity: { implementation: PC3_IMPLEMENTATION.implementationName, version: PC3_IMPLEMENTATION.implementationVersion, developmentPass: PC3_IMPLEMENTATION.developmentPass }
      });
      if (result.status === "context-mismatch") return reply.code(409).send(apiError("evidence_collection_context_mismatch", `Observation ${observation.sessionSequence} does not belong to the active publication context.`, request.id));
      if (result.status === "incomplete-ptc-chain") return reply.code(409).send(apiError("evidence_collection_incomplete", `Observation ${observation.sessionSequence} cannot be attested until its complete PTC exercise chain and comparison are available.`, request.id));
    }

    const record = evidence.saveCollectionRecord(id, active.contextId, currentObservations.map((item) => item.id));
    if (!record) return reply.code(409).send(apiError("evidence_collection_incomplete", "PC3 could not compose one attestation covering every current Observation.", request.id));
    return reply.header("content-disposition", `attachment; filename="pc3-observation-collection-attestation-${active.contextId}.json"`).code(200).send(record);
  });

  server.get<{ Params: { sessionId: string }; Reply: ExecutionEvidenceListResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/execution-evidence", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      return reply.code(200).send({ sessionId: id, activeContextId: active.contextId, evidence: evidence.list(id, active.contextId) });
    }
  );

  server.get<{ Params: { sessionId: string; evidenceId: string }; Reply: SavedExecutionEvidenceRecord | ApiErrorResponse }>(
    "/api/sessions/:sessionId/execution-evidence/:evidenceId/save", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      const item = evidence.find(id, executionEvidenceId(request.params.evidenceId));
      if (!item) return reply.code(404).send(apiError("execution_evidence_not_found", "The Execution Evidence does not exist in this session.", request.id));
      if (item.activeContextId !== active.contextId) return reply.code(409).send(apiError("evidence_context_mismatch", "The Execution Evidence belongs to a different publication context.", request.id));
      const record = evidence.saveRecord(item);
      return reply.header("content-disposition", `attachment; filename="pc3-execution-evidence-${item.id}.json"`).code(200).send(record);
    }
  );

  server.delete<{ Params: { sessionId: string; evidenceId: string }; Querystring: { expectedActiveContextId?: string }; Reply: { discarded: true } | ApiErrorResponse }>(
    "/api/sessions/:sessionId/execution-evidence/:evidenceId", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      if (!request.query.expectedActiveContextId || request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before evidence discard.", request.id));
      const result = evidence.discard(id, active.contextId, executionEvidenceId(request.params.evidenceId));
      if (result === "not-found") return reply.code(404).send(apiError("execution_evidence_not_found", "The Execution Evidence does not exist in this session.", request.id));
      if (result === "context-mismatch") return reply.code(409).send(apiError("evidence_context_mismatch", "The Execution Evidence belongs to a different publication context.", request.id));
      return reply.code(200).send({ discarded: true });
    }
  );

  server.setNotFoundHandler(async (request, reply) => {
    await reply.code(404).send(apiError("route_not_found", "The requested PC3 API route does not exist.", request.id));
  });
  server.setErrorHandler(async (error, request, reply) => {
    const serverError = error as { readonly statusCode?: number; readonly code?: string };
    if (serverError.statusCode === 413 || serverError.code === "FST_ERR_CTP_BODY_TOO_LARGE") {
      request.log.warn({ err: error }, "Publication upload exceeded configured limit");
      await reply.code(413).send(apiError("publication_upload_too_large", `The selected publication exceeds the configured upload limit of ${options.config.maximumUploadBytes} bytes.`, request.id));
      return;
    }
    request.log.error({ err: error }, "Unhandled PC3 server error");
    await reply.code(500).send(apiError("internal_server_error", "The PC3 server could not complete the request.", request.id));
  });


  server.post<{
    Params: { sessionId: string; attemptId: string };
    Querystring: { expectedActiveContextId?: string };
    Body: ExecuteExerciseAttemptInput;
    Reply: ExecuteExerciseAttemptResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/exercise-attempts/:attemptId/execute", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId || request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before adapter execution.", request.id));
    const attempt = attempts.find(id, request.params.attemptId);
    if (!attempt) return reply.code(404).send(apiError("exercise_attempt_not_found", "The Exercise Attempt does not exist in this session.", request.id));
    if (attempt.activeContextId !== active.contextId) return reply.code(409).send(apiError("attempt_context_mismatch", "The Exercise Attempt belongs to a different publication context.", request.id));
    const adapter = adapters.find(request.body?.adapterId ?? "");
    if (!adapter) return reply.code(400).send(apiError("execution_adapter_not_found", "The requested execution adapter is not registered.", request.id));
    try {
      const result = await adapter.execute(attempt, {
        executable: request.body?.executable ?? "",
        ...(request.body?.arguments ? { arguments: request.body.arguments } : {}),
        ...(request.body?.workingDirectory ? { workingDirectory: request.body.workingDirectory } : {}),
        ...(request.body?.timeoutMilliseconds !== undefined ? { timeoutMilliseconds: request.body.timeoutMilliseconds } : {}),
        ...(request.body?.environmentIdentity ? { environmentIdentity: request.body.environmentIdentity } : {})
      });
      const captured = captureAdapterResult(attempt, active, result);
      return reply.code(201).send({
        adapter: result.adapter, process: result.process, ...captured,
        realizationIdentityAssurance: { level: "reported", statement: "DEV-11 records that this adapter was instructed to exercise the selected pathway endpoint. It does not yet verify that the launched executable is the realization published in the UKO." }
      });
    } catch (error) {
      return reply.code(400).send(apiError("external_execution_failed", error instanceof Error ? error.message : "The external adapter could not complete the interaction.", request.id));
    }
  });

  server.post<{
    Params: { sessionId: string; attemptId: string };
    Querystring: { expectedActiveContextId?: string };
    Reply: ExecuteReferenceExerciseAttemptResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/exercise-attempts/:attemptId/execute-reference", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId || request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before reference execution.", request.id));
    const attempt = attempts.find(id, request.params.attemptId);
    if (!attempt) return reply.code(404).send(apiError("exercise_attempt_not_found", "The Exercise Attempt does not exist in this session.", request.id));
    if (attempt.activeContextId !== active.contextId) return reply.code(409).send(apiError("attempt_context_mismatch", "The Exercise Attempt belongs to a different publication context.", request.id));
    const binding = attempt.publicationExerciseBinding;
    const exercise = binding ? active.interpretation.resolvedExercises.find((candidate) =>
      candidate.ptc.identifier === binding.ptcIdentifier && candidate.rtcm.identifier === binding.rtcmIdentifier && candidate.realization.identifier === binding.realizationIdentifier
    ) : undefined;
    if (!exercise) return reply.code(409).send(apiError("reference_exercise_resolution_unavailable", "The immutable attempt does not resolve to its publication PTC, RTCM, and realization.", request.id));
    const publication = acquiredPublications.get(active.publicationLoad.id);
    if (!publication) return reply.code(409).send(apiError("reference_publication_resources_unavailable", "The active publication's read-only resources are unavailable for reference execution.", request.id));
    let materialized: Awaited<ReturnType<PublicationReferenceExecutionPlanner["materialize"]>> | undefined;
    try {
      const invocationPlan = await referenceExecutions.plan(attempt, exercise, publication);
      const { adapter, plan } = adapters.resolve(invocationPlan);
      materialized = await referenceExecutions.materialize(invocationPlan, publication);
      const result = await dockerEnvironments.execute({
        attempt,
        adapter,
        plan,
        publicationWorkspace: materialized.workingDirectory,
        ...(plan.adapterArtifactReference ? { adapterContainerPath: `/workspace/${plan.adapterArtifactReference}` } : {}),
        ...(materialized.infrastructureDirectory ? { infrastructureWorkspace: materialized.infrastructureDirectory } : {})
      });
      const captured = captureAdapterResult(attempt, active, result, plan);
      if (plan.invocationMode === "library" && !result.libraryReturn) {
        observations.discard(id, active.contextId, captured.observation.id);
        comparisons.discardByObservation(id, captured.observation.id);
        return reply.code(409).send(apiError("library_invocation_failed", `The declared library import or function call failed. ${result.process.stderr}`.trim(), request.id));
      }
      if (plan.invocationMode === "http" && !result.httpExchange) {
        observations.discard(id, active.contextId, captured.observation.id);
        comparisons.discardByObservation(id, captured.observation.id);
        return reply.code(409).send(apiError("http_invocation_failed", `The declared HTTP arrangement did not return a attributable HTTP response. ${result.process.stderr}`.trim(), request.id));
      }
      if (!captured.interaction.referenceExecution) throw new Error("The reference execution record was not retained.");
      if (!captured.comparison) throw new Error("The expected-outcome comparison result was not retained.");
      return reply.code(201).send({
        adapter: result.adapter,
        process: result.process,
        ...captured,
        comparison: captured.comparison,
        referenceExecution: captured.interaction.referenceExecution,
        realizationIdentityAssurance: { level: "reported", statement: "PC3 matched the exact RTCM plan to one adapter capability and invoked the publication-declared CLI adapter, language-function entry point, or HTTP arrangement inside a digest-pinned disposable Docker environment. This is declaration-backed selection and immutable environment identity, not cryptographic realization authentication." }
      });
    } catch (error) {
      const code = error instanceof ReferenceExecutionPlanningError || error instanceof AdapterCapabilityResolutionError || error instanceof DockerEnvironmentProviderError ? error.code : "reference_execution_failed";
      const message = error instanceof Error ? error.message : "The reference execution could not be completed.";
      return reply.code(error instanceof ReferenceExecutionPlanningError || error instanceof AdapterCapabilityResolutionError || error instanceof DockerEnvironmentProviderError ? 409 : 400).send(apiError(code, message, request.id));
    } finally {
      if (materialized) await materialized.cleanup();
    }
  });

  server.post<{
    Params: { sessionId: string; attemptId: string };
    Querystring: { expectedActiveContextId?: string };
    Body: ExternalExecutionResponseInput;
    Reply: ExecutionInteractionCaptureResponse | ApiErrorResponse;
  }>("/api/sessions/:sessionId/exercise-attempts/:attemptId/execution-responses", async (request, reply) => {
    const id = sessionId(request.params.sessionId);
    const session = contexts.getSession(id);
    if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
    if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
    const active = contexts.getActive(id);
    if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
    if (!request.query.expectedActiveContextId) return reply.code(400).send(apiError("expected_context_required", "Execution-response intake requires the expected active-context identity.", request.id));
    if (request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before the external execution response was received.", request.id));
    const attempt = attempts.find(id, request.params.attemptId);
    if (!attempt) return reply.code(404).send(apiError("exercise_attempt_not_found", "The Exercise Attempt does not exist in this session.", request.id));
    if (attempt.activeContextId !== active.contextId) return reply.code(409).send(apiError("attempt_context_mismatch", "The Exercise Attempt belongs to a different publication context.", request.id));
    const outcome = request.body?.outcome;
    if (outcome !== "completed" && outcome !== "failed" && outcome !== "indeterminate") return reply.code(400).send(apiError("invalid_runtime_outcome", "External execution response outcome is not supported by DEV-9.", request.id));
    const environment = environments.record({
      attempt,
      adapter: { id: request.body?.receivedFrom?.trim() || "external-response", name: "External response source", version: "unreported" },
      environmentType: "externally-reported",
      executionBoundary: "external-environment",
      externalEnvironmentIdentifier: request.body?.environmentIdentity?.trim()
        ? { value: request.body.environmentIdentity.trim(), assurance: "reported", basis: "Reported in the external execution response." }
        : { assurance: "unavailable", basis: "No external environment identifier was supplied." },
      operatingSystem: {
        platform: { assurance: "unavailable", basis: "External response intake did not report an operating-system platform." },
        release: { assurance: "unavailable", basis: "External response intake did not report an operating-system release." },
        architecture: { assurance: "unavailable", basis: "External response intake did not report an architecture." }
      },
      runtime: {
        executable: { assurance: "unavailable", basis: "External response intake did not report an executable." },
        version: { assurance: "unavailable", basis: "External response intake did not report a runtime version." }
      },
      workingDirectory: { assurance: "unavailable", basis: "External response intake did not report a working directory." },
      descriptionDisposition: "pc3-described-not-provisioned",
      identityAssurance: { level: "reported-only", statement: "PC3 recorded only properties reported by the external response source. No environment properties were independently observed or authenticated." },
      explanation: "This minimal description preserves the external environment context available to PC3 without implying provisioning, verification, or completeness."
    });
    const result = interactions.receive({
      attempt,
      expectedActiveContextId: activeOperationalContextId(request.query.expectedActiveContextId),
      response: {
        externalInteractionId: request.body?.externalInteractionId ?? "", receivedFrom: request.body?.receivedFrom ?? "", outcome,
        responseMediaType: request.body?.responseMediaType ?? "", responseValue: request.body?.responseValue ?? "",
        ...(request.body?.runtimeReportedAt ? { runtimeReportedAt: request.body.runtimeReportedAt as never } : {}),
        ...(request.body?.environmentIdentity ? { environmentIdentity: request.body.environmentIdentity } : {}),
        executionEnvironmentDescriptionId: environment.id
      }
    });
    if (result.status === "invalid-response") return reply.code(400).send(apiError("invalid_execution_response", result.explanation, request.id));
    if (result.status === "stale-context") return reply.code(409).send(apiError("stale_active_context", "The active publication changed before execution interaction intake.", request.id));
    if (result.status === "duplicate-external-interaction") return reply.code(409).send(apiError("duplicate_execution_interaction", "This external execution interaction has already been received.", request.id));
    const observation = observations.derive(result.interaction);
    return reply.code(201).send({ interaction: result.interaction, observation });
  });

  server.get<{ Params: { sessionId: string }; Querystring: { attemptId?: string }; Reply: ExecutionInteractionListResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/execution-interactions", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      return reply.code(200).send({ sessionId: id, activeContextId: active.contextId, interactions: interactions.list(id, active.contextId, request.query.attemptId ? exerciseAttemptId(request.query.attemptId) : undefined) });
    }
  );

  server.get<{ Params: { sessionId: string }; Querystring: { observationId?: string }; Reply: ExpectedOutcomeComparisonListResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/observation-comparisons", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      return reply.code(200).send({
        sessionId: id,
        activeContextId: active.contextId,
        comparisons: comparisons.list(id, active.contextId, request.query.observationId ? runtimeObservationId(request.query.observationId) : undefined)
      });
    }
  );

  // Manual observation authorship remains removed. Runtime Observations derive only from explicit Execution Interactions. is intentionally removed. Runtime Observations arise only from execution-response intake.
  server.post("/api/sessions/:sessionId/exercise-attempts/:attemptId/runtime-observations", async (request, reply) =>
    reply.code(410).send(apiError("manual_runtime_observation_removed", "DEV-9 automatically derives Runtime Observations from explicit Execution Interactions from external execution responses; users do not manually author them.", request.id))
  );

  server.get<{ Params: { sessionId: string }; Querystring: { attemptId?: string }; Reply: RuntimeObservationListResponse | ApiErrorResponse }>(
    "/api/sessions/:sessionId/runtime-observations", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const session = contexts.getSession(id);
      if (!session) return reply.code(404).send(apiError("session_not_found", "The PC3 session does not exist.", request.id));
      if (session.closedAt) return reply.code(409).send(apiError("session_closed", "The PC3 session is closed.", request.id));
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      const items = observations.list(id, active.contextId, request.query.attemptId ? exerciseAttemptId(request.query.attemptId) : undefined);
      return reply.code(200).send({ sessionId: id, activeContextId: active.contextId, observations: items });
    }
  );

  server.get<{ Params: { sessionId: string; observationId: string }; Reply: SavedRuntimeObservationRecord | ApiErrorResponse }>(
    "/api/sessions/:sessionId/runtime-observations/:observationId/save", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      const observation = observations.find(id, runtimeObservationId(request.params.observationId));
      if (!observation) return reply.code(404).send(apiError("runtime_observation_not_found", "The ephemeral Runtime Observation does not exist.", request.id));
      if (observation.activeContextId !== active.contextId) return reply.code(409).send(apiError("observation_context_mismatch", "The Runtime Observation belongs to a different publication context.", request.id));
      const record = observations.saveRecord(observation, { implementation: PC3_IMPLEMENTATION.implementationName, version: PC3_IMPLEMENTATION.implementationVersion, developmentPass: PC3_IMPLEMENTATION.developmentPass });
      return reply.header("content-disposition", `attachment; filename="pc3-runtime-observation-${observation.id}.json"`).code(200).send(record);
    }
  );

  server.delete<{ Params: { sessionId: string; observationId: string }; Querystring: { expectedActiveContextId?: string }; Reply: { discarded: true } | ApiErrorResponse }>(
    "/api/sessions/:sessionId/runtime-observations/:observationId", async (request, reply) => {
      const id = sessionId(request.params.sessionId);
      const active = contexts.getActive(id);
      if (!active) return reply.code(409).send(apiError("no_active_publication", "The session does not have an active publication.", request.id));
      if (!request.query.expectedActiveContextId || request.query.expectedActiveContextId !== active.contextId) return reply.code(409).send(apiError("stale_active_context", "The active publication changed before the ephemeral observation was discarded.", request.id));
      const result = observations.discard(id, active.contextId, runtimeObservationId(request.params.observationId));
      if (result === "not-found") return reply.code(404).send(apiError("runtime_observation_not_found", "The ephemeral Runtime Observation does not exist.", request.id));
      if (result === "context-mismatch") return reply.code(409).send(apiError("observation_context_mismatch", "The Runtime Observation belongs to a different publication context.", request.id));
      return reply.code(200).send({ discarded: true });
    }
  );

  return server;
}

async function interpretUpload(body: Buffer, filenameValue: string | undefined, options: CreateServerOptions) {
  const filename = filenameValue?.trim() || "uploaded-publication.zip";
  if (!Buffer.isBuffer(body) || body.byteLength === 0) return { error: { status: 400 as const, code: "empty_publication_upload", message: "Select a non-empty ZIP publication archive." } };
  const adapter = new InMemoryZipPublicationSourceAdapter(body, filename, {
    maximumArchiveBytes: options.config.maximumUploadBytes,
    maximumResourceCount: options.config.maximumPublicationResources,
    maximumTotalBytes: options.config.maximumPublicationExpandedBytes,
    maximumResourceBytes: options.config.maximumPublicationResourceBytes
  });
  const loader = new PublicationLoader({ adapters: [adapter], clock: options.clock, identifiers: options.identifiers });
  const loaded = await loader.loadForInterpretation({ kind: "uploaded-archive", locator: filename });
  if ("failure" in loaded) return { error: { status: 400 as const, code: loaded.failure.code, message: loaded.failure.message } };
  const interpretation = await new PublicationInterpreter({ clock: options.clock, identifiers: options.identifiers }).interpret(loaded.loaded.record, loaded.loaded.acquired);
  const ior = new InternalOperationalRepresentationManager({ clock: options.clock, identifiers: options.identifiers }).construct(interpretation);
  return { filename, loaded: loaded.loaded, interpretation, ior };
}

function interpretationResponse(filename: string, load: any, interpretation: any, ior: any): PublicationInterpretationResponse {
  const identity = interpretation.publicationIdentity;
  return {
    load: { id: load.id, loadedAt: load.loadedAt, sourceName: filename, resourceCount: load.resourceCount },
    interpretation: {
      id: interpretation.id, interpretedAt: interpretation.interpretedAt,
      ...(identity ? { publicationIdentity: { declaredIdentifier: identity.value.declaredIdentifier, ...(identity.value.declaredVersion ? { declaredVersion: identity.value.declaredVersion } : {}), ...(identity.value.title ? { title: identity.value.title } : {}), provenance: identity.provenance } } : {}),
      inputObjects: interpretation.inputObjects,
      publicationTestCases: interpretation.publicationTestCases,
      realizationTestCaseManifestations: interpretation.realizationTestCaseManifestations,
      publicationTestCaseApplicability: interpretation.publicationTestCaseApplicability,
      exerciseReadiness: interpretation.exerciseReadiness,
      exerciseDiscoveryIndex: interpretation.exerciseDiscoveryIndex,
      publicationValidation: interpretation.publicationValidation,
      capabilityProfile: interpretation.capabilityProfile,
      resolvedExercises: interpretation.resolvedExercises,
      realizations: interpretation.realizations, relationships: interpretation.relationships,
      limitations: interpretation.limitations, interpretedResourcePaths: interpretation.interpretedResourcePaths
    },
    ior: {
      id: ior.id, createdAt: ior.createdAt,
      ...(ior.publicationIdentifier ? { publicationIdentifier: ior.publicationIdentifier } : {}),
      realizationNodeCount: ior.realizationNodes.length, relationshipEdgeCount: ior.relationshipEdges.length,
      unresolvedRelationshipCount: ior.relationshipEdges.filter((edge: any) => !edge.sourceResolved || !edge.targetResolved).length,
      constructionLimitations: ior.constructionLimitations
    }
  };
}

function activeContextView(active: ActivePublicationSnapshot): ActiveOperationalContextResponse {
  return {
    sessionId: active.sessionId, contextId: active.contextId, activatedAt: active.activatedAt,
    sourceName: active.sourceName, publicationLoadId: active.publicationLoad.id,
    ...(active.ior.publicationIdentifier ? { publicationIdentifier: active.ior.publicationIdentifier } : {}),
    iorId: active.ior.id, realizationNodeCount: active.ior.realizationNodes.length,
    relationshipEdgeCount: active.ior.relationshipEdges.length,
    interpretationLimitationCount: active.interpretation.limitations.length,
    iorConstructionLimitationCount: active.ior.constructionLimitations.length,
    ...(active.selectedPathwayId ? { selectedPathwayId: active.selectedPathwayId } : {})
  };
}

function apiError(code: string, message: string, requestId: string): ApiErrorResponse {
  return { error: { code, message, requestId } };
}


function exerciseAttemptView(attempt: import("../operation/model.js").ExerciseAttempt): ExerciseAttemptResponse {
  return {
    id: attempt.id, sessionId: attempt.sessionId, activeContextId: attempt.activeContextId, publicationLoadId: attempt.publicationLoadId,
    iorId: attempt.iorId, pathwayId: attempt.pathwayId, endpointIdentifier: attempt.endpointIdentifier, endpointType: attempt.endpointType,
    input: attempt.input, exerciseDisposition: attempt.exerciseDisposition,
    ...(attempt.publicationExerciseBinding ? { publicationExerciseBinding: attempt.publicationExerciseBinding } : {}),
    requestedAt: attempt.requestedAt, status: attempt.status, executionDisposition: attempt.executionDisposition, explanation: attempt.explanation
  };
}

function serializeCanonicalExerciseInput(value: unknown): string {
  if (typeof value === "string") return value;
  const serialized = JSON.stringify(value);
  if (serialized === undefined) throw new Error("A resolved canonical input must have a serializable value.");
  return serialized;
}

function matrixView(active: ActivePublicationSnapshot, matrix: import("../operation/executable-realization-matrix.js").ExecutableRealizationMatrixProjection): ExecutableRealizationMatrixResponse {
  return {
    sessionId: active.sessionId,
    contextId: active.contextId,
    iorId: active.ior.id,
    ...(active.selectedPathwayId ? { selectedPathwayId: active.selectedPathwayId } : {}),
    realizationCount: matrix.realizationCount,
    pathwayCount: matrix.pathwayCount,
    realizationPathwayCount: matrix.realizationPathwayCount,
    pathwayIntegrityIssueCount: matrix.pathwayIntegrityIssueCount,
    unresolvedServiceRealizationCount: matrix.unresolvedServiceRealizationCount,
    unresolvedDeploymentPackageCount: matrix.unresolvedDeploymentPackageCount,
    invalidTransitionCount: matrix.invalidTransitionCount,
    irEndpointPathwayCount: matrix.irEndpointPathwayCount,
    srEndpointPathwayCount: matrix.srEndpointPathwayCount,
    dpEndpointPathwayCount: matrix.dpEndpointPathwayCount,
    representedImplementationRepresentationCount: matrix.representedImplementationRepresentationCount,
    totalImplementationRepresentationCount: matrix.totalImplementationRepresentationCount,
    unsupportedRealizationCount: matrix.unsupportedRealizationCount,
    projectionLimitations: matrix.projectionLimitations,
    pathways: matrix.pathways.map((pathway) => ({
      id: pathway.id,
      selected: active.selectedPathwayId === pathway.id,
      kind: pathway.kind,
      endpointType: pathway.endpointType,
      endpointIdentifier: pathway.endpointIdentifier,
      selectable: pathway.selectable,
      exerciseSupport: pathway.exerciseSupport,
      unsupportedExplanations: pathway.unsupportedExplanations,
      relationshipTypes: pathway.relationshipTypes,
      steps: pathway.steps,
      ...(pathway.integrityIssue ? { integrityIssue: pathway.integrityIssue } : {})
    }))
  };
}
