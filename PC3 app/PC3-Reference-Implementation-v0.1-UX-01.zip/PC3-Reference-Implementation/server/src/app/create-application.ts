import type { FastifyInstance } from "fastify";
import { randomIdentifierGenerator, systemClock } from "../infrastructure/system/system-services.js";
import { createServer } from "./create-server.js";
import type { ServerConfig } from "./config.js";

export interface Pc3Application {
  readonly server: FastifyInstance;
  start(): Promise<void>;
  stop(): Promise<void>;
}

export function createApplication(config: ServerConfig): Pc3Application {
  const server = createServer({ config, clock: systemClock, identifiers: randomIdentifierGenerator });

  return {
    server,
    async start(): Promise<void> {
      await server.listen({ host: config.host, port: config.port });
    },
    async stop(): Promise<void> {
      await server.close();
    }
  };
}
