export interface ServerConfig {
  readonly host: string;
  readonly port: number;
  readonly logLevel: "fatal" | "error" | "warn" | "info" | "debug" | "trace" | "silent";
  readonly maximumUploadBytes: number;
  readonly maximumPublicationResources: number;
  readonly maximumPublicationExpandedBytes: number;
  readonly maximumPublicationResourceBytes: number;
}

const validLogLevels = new Set<ServerConfig["logLevel"]>([
  "fatal",
  "error",
  "warn",
  "info",
  "debug",
  "trace",
  "silent"
]);

export function loadServerConfig(environment: NodeJS.ProcessEnv = process.env): ServerConfig {
  const host = environment.PC3_HOST?.trim() || "127.0.0.1";
  const rawPort = environment.PC3_PORT?.trim() || "3000";
  const port = Number(rawPort);
  const rawLogLevel = environment.PC3_LOG_LEVEL?.trim() || "info";
  const rawMaximumUploadBytes = environment.PC3_MAX_UPLOAD_BYTES?.trim() || "268435456";
  const maximumUploadBytes = Number(rawMaximumUploadBytes);
  const rawMaximumPublicationResources = environment.PC3_MAX_PUBLICATION_RESOURCES?.trim() || "10000";
  const maximumPublicationResources = Number(rawMaximumPublicationResources);
  const rawMaximumPublicationExpandedBytes = environment.PC3_MAX_PUBLICATION_EXPANDED_BYTES?.trim() || "536870912";
  const maximumPublicationExpandedBytes = Number(rawMaximumPublicationExpandedBytes);
  const rawMaximumPublicationResourceBytes = environment.PC3_MAX_PUBLICATION_RESOURCE_BYTES?.trim() || "201326592";
  const maximumPublicationResourceBytes = Number(rawMaximumPublicationResourceBytes);

  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`PC3_PORT must be an integer from 1 through 65535; received "${rawPort}".`);
  }

  if (!Number.isSafeInteger(maximumUploadBytes) || maximumUploadBytes < 1) {
    throw new Error(`PC3_MAX_UPLOAD_BYTES must be a positive safe integer; received "${rawMaximumUploadBytes}".`);
  }
  if (!Number.isSafeInteger(maximumPublicationResources) || maximumPublicationResources < 1) {
    throw new Error(`PC3_MAX_PUBLICATION_RESOURCES must be a positive safe integer; received "${rawMaximumPublicationResources}".`);
  }
  if (!Number.isSafeInteger(maximumPublicationExpandedBytes) || maximumPublicationExpandedBytes < 1) {
    throw new Error(`PC3_MAX_PUBLICATION_EXPANDED_BYTES must be a positive safe integer; received "${rawMaximumPublicationExpandedBytes}".`);
  }
  if (!Number.isSafeInteger(maximumPublicationResourceBytes) || maximumPublicationResourceBytes < 1) {
    throw new Error(`PC3_MAX_PUBLICATION_RESOURCE_BYTES must be a positive safe integer; received "${rawMaximumPublicationResourceBytes}".`);
  }

  if (!validLogLevels.has(rawLogLevel as ServerConfig["logLevel"])) {
    throw new Error(`PC3_LOG_LEVEL is invalid; received "${rawLogLevel}".`);
  }

  return {
    host, port, logLevel: rawLogLevel as ServerConfig["logLevel"], maximumUploadBytes,
    maximumPublicationResources, maximumPublicationExpandedBytes, maximumPublicationResourceBytes
  };
}
