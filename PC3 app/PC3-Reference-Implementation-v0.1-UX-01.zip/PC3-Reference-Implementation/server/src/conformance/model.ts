export interface ConformanceDeclaration {
  readonly implementationName: string;
  readonly implementationVersion: string;
  readonly specificationBaseline: string;
  readonly claimScope: string;
  readonly limitations: readonly string[];
}
