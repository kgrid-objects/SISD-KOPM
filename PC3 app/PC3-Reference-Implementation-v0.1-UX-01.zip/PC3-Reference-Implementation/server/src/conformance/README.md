# Conformance module

Reserved for the exact implementation/version conformance declaration in a later pass. DEV-1 exposes implementation identity only and makes no full conformance claim.
