# Operation module

Owns the Active Operational Context, realization-Matrix projection and selection, and Exercise Attempt preparation.

EX-01 extends the immutable attempt snapshot with canonical or exploratory disposition and, when PTC authority governs the publication, a required PTC/RTCM/realization binding copied from one uniquely Resolved Exercise. Canonical input comes from that resolved publication object. Exploratory input remains user supplied. Missing, invalid, ambiguous, or non-applicable resolution prevents storage.

Preparation still does not coordinate or perform execution. The existing adapter layer remains the separate external-execution boundary.
