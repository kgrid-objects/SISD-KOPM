import type { IsoInstant } from "../domain/time.js";
import type {
  ActiveOperationalContextId,
  EnvironmentAssociationId,
  ExerciseAttemptId,
  IorId,
  PublicationLoadId,
  RealizationPathwayId,
  SessionId
} from "../domain/identifiers.js";

/** PC3 Interpretation remains subordinate to Publication Truth. */
export interface InternalOperationalRepresentationReference {
  readonly id: IorId;
  readonly publicationLoadId: PublicationLoadId;
  readonly createdAt: IsoInstant;
}

export interface RealizationPathwayReference {
  readonly id: RealizationPathwayId;
  readonly iorId: IorId;
  readonly publicationDeclaredIdentifier: string;
}

export interface ActiveOperationalContext {
  readonly id: ActiveOperationalContextId;
  readonly sessionId: SessionId;
  readonly publicationLoadId: PublicationLoadId;
  readonly iorId: IorId;
  readonly activatedAt: IsoInstant;
  readonly selectedPathwayId?: RealizationPathwayId;
  readonly activeEnvironmentAssociationId?: EnvironmentAssociationId;
}

export interface ExerciseAttemptInputSnapshot {
  readonly mediaType: string;
  readonly value: string;
  readonly source: "publication-canonical" | "publication-derived-negative" | "user-exploratory";
}

/** Publication-bound identity selected before an attempt can be prepared. */
export interface ExerciseAttemptBinding {
  readonly ptcIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly realizationIdentifier: string;
  readonly resolutionDisposition: "unique-authoritative-rtcm";
}

/** Immutable request-context snapshot prepared for a user-requested exercise. DEV-7 does not execute it. */
export interface ExerciseAttempt {
  readonly id: ExerciseAttemptId;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly publicationLoadId: PublicationLoadId;
  readonly iorId: IorId;
  readonly pathwayId: RealizationPathwayId;
  readonly endpointIdentifier: string;
  readonly endpointType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly environmentAssociationId?: EnvironmentAssociationId;
  readonly input: ExerciseAttemptInputSnapshot;
  readonly exerciseDisposition: "canonical" | "exploratory";
  readonly publicationExerciseBinding?: ExerciseAttemptBinding;
  readonly requestedAt: IsoInstant;
  readonly status: "prepared";
  readonly executionDisposition: "not-started";
  readonly explanation: string;
}
