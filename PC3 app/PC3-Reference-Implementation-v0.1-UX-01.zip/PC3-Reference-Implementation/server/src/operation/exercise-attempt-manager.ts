import { exerciseAttemptId, type ActiveOperationalContextId, type RealizationPathwayId, type SessionId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import type { ExerciseAttempt, ExerciseAttemptBinding } from "./model.js";
import type { ActivePublicationSnapshot } from "./active-operational-context-manager.js";
import type { ExecutableRealizationPathwayRow } from "./executable-realization-matrix.js";

export type PrepareExerciseAttemptResult =
  | { readonly status: "prepared"; readonly attempt: ExerciseAttempt }
  | { readonly status: "stale-context" }
  | { readonly status: "no-selected-pathway" }
  | { readonly status: "selected-pathway-mismatch" }
  | { readonly status: "pathway-not-selectable" }
  | { readonly status: "exercise-resolution-required" }
  | { readonly status: "exercise-binding-mismatch" }
  | { readonly status: "invalid-input"; readonly explanation: string };

export class ExerciseAttemptManager {
  private readonly bySession = new Map<SessionId, ExerciseAttempt[]>();
  constructor(private readonly dependencies: { readonly clock: Clock; readonly identifiers: IdentifierGenerator }) {}

  prepare(input: {
    readonly active: ActivePublicationSnapshot;
    readonly expectedActiveContextId: ActiveOperationalContextId;
    readonly pathway: ExecutableRealizationPathwayRow;
    readonly mediaType: string;
    readonly value: string;
    readonly exerciseDisposition?: "canonical" | "exploratory";
    readonly canonicalInputSource?: "publication-canonical" | "publication-derived-negative";
    readonly ptcBindingRequired?: boolean;
    readonly publicationExerciseBinding?: ExerciseAttemptBinding;
  }): PrepareExerciseAttemptResult {
    if (input.active.contextId !== input.expectedActiveContextId) return { status: "stale-context" };
    if (!input.active.selectedPathwayId) return { status: "no-selected-pathway" };
    if (input.active.selectedPathwayId !== input.pathway.id) return { status: "selected-pathway-mismatch" };
    if (!input.pathway.selectable || input.pathway.kind !== "realization-pathway") return { status: "pathway-not-selectable" };
    if (input.ptcBindingRequired && !input.publicationExerciseBinding) return { status: "exercise-resolution-required" };
    if (input.publicationExerciseBinding?.realizationIdentifier !== undefined && input.publicationExerciseBinding.realizationIdentifier !== input.pathway.endpointIdentifier) return { status: "exercise-binding-mismatch" };
    const exerciseDisposition = input.exerciseDisposition ?? "exploratory";
    if (exerciseDisposition === "canonical" && !input.publicationExerciseBinding) return { status: "exercise-resolution-required" };
    const mediaType = input.mediaType.trim();
    if (!mediaType) return { status: "invalid-input", explanation: "Input media type must not be empty." };
    if (input.value.length > 1_000_000) return { status: "invalid-input", explanation: "Exercise input exceeds the DEV-7 one-megabyte preparation limit." };
    const attempt: ExerciseAttempt = Object.freeze({
      id: exerciseAttemptId(this.dependencies.identifiers.next()),
      sessionId: input.active.sessionId,
      activeContextId: input.active.contextId,
      publicationLoadId: input.active.publicationLoad.id,
      iorId: input.active.ior.id,
      pathwayId: input.pathway.id as RealizationPathwayId,
      endpointIdentifier: input.pathway.endpointIdentifier,
      endpointType: input.pathway.endpointType,
      input: Object.freeze({ mediaType, value: input.value, source: exerciseDisposition === "canonical" ? input.canonicalInputSource ?? "publication-canonical" : "user-exploratory" }),
      exerciseDisposition,
      ...(input.publicationExerciseBinding ? { publicationExerciseBinding: Object.freeze({ ...input.publicationExerciseBinding }) } : {}),
      requestedAt: this.dependencies.clock.now(),
      status: "prepared",
      executionDisposition: "not-started",
      explanation: input.publicationExerciseBinding
        ? `EX-01 prepared an immutable ${exerciseDisposition} attempt bound to ${input.publicationExerciseBinding.ptcIdentifier}, ${input.publicationExerciseBinding.rtcmIdentifier}, and ${input.publicationExerciseBinding.realizationIdentifier}. No execution environment was associated and no computation was initiated.`
        : "EX-01 preserves the legacy exploratory request and immutable context snapshot only; PC3 has not associated an execution environment or initiated computation."
    });
    const list = this.bySession.get(attempt.sessionId) ?? [];
    this.bySession.set(attempt.sessionId, [...list, attempt]);
    return { status: "prepared", attempt };
  }

  find(sessionId: SessionId, attemptId: string): ExerciseAttempt | undefined {
    return (this.bySession.get(sessionId) ?? []).find((attempt) => attempt.id === attemptId);
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId): readonly ExerciseAttempt[] {
    return (this.bySession.get(sessionId) ?? []).filter((attempt) => attempt.activeContextId === activeContextId);
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); }
}
