import { realizationPathwayId, type RealizationPathwayId } from "../domain/identifiers.js";
import type { InternalOperationalRepresentation, IorRealizationNode } from "../publication/internal-operational-representation.js";

export type RealizationSupportStatus =
  | { readonly status: "supported"; readonly supportDescriptor: string }
  | { readonly status: "unsupported"; readonly explanation: string };
export interface RealizationSupportResolver { resolve(node: IorRealizationNode): RealizationSupportStatus; }
export interface MatrixPathwayStep {
  readonly identifier: string;
  readonly realizationType: IorRealizationNode["realizationType"];
  readonly artifactReference?: string;
  readonly invocationMechanism?: string;
  readonly support: RealizationSupportStatus;
}
export type OperationalEndpointType = "implementation-representation" | "service-realization" | "deployment-package";
export type MatrixEntryKind = "realization-pathway" | "pathway-integrity-issue";
export type PathwayIntegrityIssueCode =
  | "service-realization-missing-ir-predecessor"
  | "deployment-package-missing-sr-predecessor"
  | "unresolved-relationship-endpoint"
  | "non-adjacent-or-reversed-transition";
export interface PathwayIntegrityIssue {
  readonly code: PathwayIntegrityIssueCode;
  readonly message: string;
}
export interface ExecutableRealizationPathwayRow {
  readonly id: RealizationPathwayId;
  readonly kind: MatrixEntryKind;
  readonly endpointType: OperationalEndpointType;
  readonly endpointIdentifier: string;
  readonly steps: readonly MatrixPathwayStep[];
  readonly relationshipTypes: readonly string[];
  readonly selectable: boolean;
  readonly exerciseSupport: "supported" | "unsupported";
  readonly unsupportedExplanations: readonly string[];
  readonly integrityIssue?: PathwayIntegrityIssue;
}
export interface ExecutableRealizationMatrixProjection {
  readonly iorId: string;
  readonly pathways: readonly ExecutableRealizationPathwayRow[];
  readonly realizationCount: number;
  readonly pathwayCount: number;
  readonly realizationPathwayCount: number;
  readonly pathwayIntegrityIssueCount: number;
  readonly unresolvedServiceRealizationCount: number;
  readonly unresolvedDeploymentPackageCount: number;
  readonly invalidTransitionCount: number;
  readonly irEndpointPathwayCount: number;
  readonly srEndpointPathwayCount: number;
  readonly dpEndpointPathwayCount: number;
  readonly representedImplementationRepresentationCount: number;
  readonly totalImplementationRepresentationCount: number;
  readonly unsupportedRealizationCount: number;
  readonly projectionLimitations: readonly string[];
}
export class NoInvocationAdapterSupportResolver implements RealizationSupportResolver {
  resolve(node: IorRealizationNode): RealizationSupportStatus {
    return { status: "unsupported", explanation: `PC3 DEV-6F has no invocation adapter registered for ${node.realizationType} ${node.identifier}.` };
  }
}
interface RawEntry {
  readonly kind: MatrixEntryKind;
  readonly nodes: readonly string[];
  readonly relationships: readonly string[];
  readonly integrityIssue?: PathwayIntegrityIssue;
}

function validAdjacentTransition(source: IorRealizationNode, target: IorRealizationNode): boolean {
  return (source.realizationType === "implementation-representation" && target.realizationType === "service-realization") ||
    (source.realizationType === "service-realization" && target.realizationType === "deployment-package");
}

export class ExecutableRealizationMatrixProjector {
  constructor(private readonly supportResolver: RealizationSupportResolver) {}
  project(ior: InternalOperationalRepresentation): ExecutableRealizationMatrixProjection {
    const nodesById = new Map(ior.realizationNodes.map((node) => [node.identifier, node]));
    const outgoing = new Map<string, { target: string; relationshipType: string }[]>();
    const rawEntries: RawEntry[] = [];
    const entryKeys = new Set<string>();
    const reachableFromIr = new Set<string>();
    const limitations: string[] = [];
    let invalidTransitionCount = 0;

    const addEntry = (entry: RawEntry): void => {
      const key = `${entry.kind}|${entry.nodes.join("->")}|${entry.integrityIssue?.code ?? ""}|${entry.integrityIssue?.message ?? ""}`;
      if (entryKeys.has(key)) return;
      entryKeys.add(key);
      rawEntries.push(entry);
    };

    for (const edge of ior.relationshipEdges) {
      if (!edge.sourceResolved || !edge.targetResolved) {
        const identifier = edge.targetResolved ? edge.sourceIdentifier : edge.targetIdentifier;
        const node = nodesById.get(identifier);
        if (node) {
          addEntry({
            kind: "pathway-integrity-issue",
            nodes: [identifier],
            relationships: [],
            integrityIssue: {
              code: "unresolved-relationship-endpoint",
              message: `A declared relationship for ${identifier} references an unresolved realization endpoint.`
            }
          });
        }
        continue;
      }
      const source = nodesById.get(edge.sourceIdentifier);
      const target = nodesById.get(edge.targetIdentifier);
      if (!source || !target) continue;
      if (!validAdjacentTransition(source, target)) {
        invalidTransitionCount += 1;
        addEntry({
          kind: "pathway-integrity-issue",
          nodes: [target.identifier],
          relationships: [],
          integrityIssue: {
            code: "non-adjacent-or-reversed-transition",
            message: `The declared transition ${source.identifier} → ${target.identifier} does not follow IR → SR → DP adjacency and was not used to construct a pathway.`
          }
        });
        continue;
      }
      const list = outgoing.get(source.identifier) ?? [];
      if (!list.some((item) => item.target === target.identifier)) {
        list.push({ target: target.identifier, relationshipType: edge.relationshipType });
      }
      outgoing.set(source.identifier, list);
    }
    for (const list of outgoing.values()) list.sort((a, b) => a.target.localeCompare(b.target));

    const traverse = (current: string, path: readonly string[], relationships: readonly string[]): void => {
      const node = nodesById.get(current);
      if (!node) return;
      const nextPath = [...path, current];
      reachableFromIr.add(current);
      addEntry({ kind: "realization-pathway", nodes: nextPath, relationships });
      for (const edge of outgoing.get(current) ?? []) {
        traverse(edge.target, nextPath, [...relationships, edge.relationshipType]);
      }
    };

    const implementationRepresentations = ior.realizationNodes
      .filter((node) => node.realizationType === "implementation-representation")
      .map((node) => node.identifier)
      .sort();
    for (const ir of implementationRepresentations) traverse(ir, [], []);

    let unresolvedServiceRealizationCount = 0;
    let unresolvedDeploymentPackageCount = 0;
    for (const node of ior.realizationNodes) {
      if (reachableFromIr.has(node.identifier) || node.realizationType === "implementation-representation") continue;
      if (node.realizationType === "service-realization") unresolvedServiceRealizationCount += 1;
      if (node.realizationType === "deployment-package") unresolvedDeploymentPackageCount += 1;
      const integrityIssue: PathwayIntegrityIssue = node.realizationType === "service-realization"
        ? {
            code: "service-realization-missing-ir-predecessor",
            message: `Service Realization ${node.identifier} cannot be reconstructed as a valid pathway endpoint because no declared route from an Implementation Representation was resolved.`
          }
        : {
            code: "deployment-package-missing-sr-predecessor",
            message: `Deployment Package ${node.identifier} cannot be reconstructed as a valid pathway endpoint because no declared route through a Service Realization and Implementation Representation was resolved.`
          };
      addEntry({ kind: "pathway-integrity-issue", nodes: [node.identifier], relationships: [], integrityIssue });
    }

    rawEntries.sort((a, b) => `${a.kind}|${a.nodes.join("->")}`.localeCompare(`${b.kind}|${b.nodes.join("->")}`));
    const pathways = rawEntries.map((entry, index): ExecutableRealizationPathwayRow => {
      const steps = entry.nodes.map((identifier): MatrixPathwayStep => {
        const node = nodesById.get(identifier);
        if (!node) throw new Error(`IOR pathway projection lost realization ${identifier}.`);
        return Object.freeze({
          identifier: node.identifier,
          realizationType: node.realizationType,
          ...(node.artifactReference ? { artifactReference: node.artifactReference } : {}),
          ...(node.invocationMechanism ? { invocationMechanism: node.invocationMechanism } : {}),
          support: this.supportResolver.resolve(node)
        });
      });
      const endpoint = steps.at(-1);
      if (!endpoint) throw new Error("Matrix entry has no operational endpoint.");
      const unsupportedExplanations = entry.kind === "realization-pathway" && endpoint.support.status === "unsupported"
        ? [endpoint.support.explanation]
        : [];
      return Object.freeze({
        id: realizationPathwayId(`${ior.id}:pathway:${index + 1}`),
        kind: entry.kind,
        endpointType: endpoint.realizationType,
        endpointIdentifier: endpoint.identifier,
        steps: Object.freeze(steps),
        relationshipTypes: Object.freeze([...entry.relationships]),
        selectable: entry.kind === "realization-pathway",
        exerciseSupport: unsupportedExplanations.length === 0 ? "supported" as const : "unsupported" as const,
        unsupportedExplanations: Object.freeze(unsupportedExplanations),
        ...(entry.integrityIssue ? { integrityIssue: Object.freeze(entry.integrityIssue) } : {})
      });
    });

    const operational = pathways.filter((pathway) => pathway.kind === "realization-pathway");
    const issues = pathways.filter((pathway) => pathway.kind === "pathway-integrity-issue");
    const unsupportedRealizationCount = ior.realizationNodes.filter((node) => this.supportResolver.resolve(node).status === "unsupported").length;
    const representedIrs = new Set(operational.flatMap((pathway) => pathway.steps
      .filter((step) => step.realizationType === "implementation-representation")
      .map((step) => step.identifier)));
    if (issues.length > 0) limitations.push("One or more realization endpoints could not be reconstructed under the required IR → SR → DP predecessor-chain invariant.");

    return Object.freeze({
      iorId: ior.id,
      pathways: Object.freeze(pathways),
      realizationCount: ior.realizationNodes.length,
      pathwayCount: pathways.length,
      realizationPathwayCount: operational.length,
      pathwayIntegrityIssueCount: issues.length,
      unresolvedServiceRealizationCount,
      unresolvedDeploymentPackageCount,
      invalidTransitionCount,
      irEndpointPathwayCount: operational.filter((pathway) => pathway.endpointType === "implementation-representation").length,
      srEndpointPathwayCount: operational.filter((pathway) => pathway.endpointType === "service-realization").length,
      dpEndpointPathwayCount: operational.filter((pathway) => pathway.endpointType === "deployment-package").length,
      representedImplementationRepresentationCount: representedIrs.size,
      totalImplementationRepresentationCount: implementationRepresentations.length,
      unsupportedRealizationCount,
      projectionLimitations: Object.freeze([...new Set(limitations)])
    });
  }
}
