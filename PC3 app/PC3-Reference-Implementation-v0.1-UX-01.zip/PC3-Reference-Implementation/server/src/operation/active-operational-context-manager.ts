import { activeOperationalContextId, sessionId, type ActiveOperationalContextId, type RealizationPathwayId, type SessionId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator, IsoInstant } from "../domain/time.js";
import type { InternalOperationalRepresentation } from "../publication/internal-operational-representation.js";
import type { PublicationInterpretation } from "../publication/interpretation-model.js";
import type { PublicationLoadRecord } from "../publication/model.js";

export interface SessionRecord {
  readonly id: SessionId;
  readonly createdAt: IsoInstant;
  readonly closedAt?: IsoInstant;
}

export interface ActivePublicationSnapshot {
  readonly contextId: ActiveOperationalContextId;
  readonly sessionId: SessionId;
  readonly activatedAt: IsoInstant;
  readonly sourceName: string;
  readonly publicationLoad: PublicationLoadRecord;
  readonly interpretation: PublicationInterpretation;
  readonly ior: InternalOperationalRepresentation;
  readonly selectedPathwayId?: RealizationPathwayId;
}

export type ActivationResult =
  | { readonly status: "activated"; readonly active: ActivePublicationSnapshot; readonly replacedContextId?: ActiveOperationalContextId }
  | { readonly status: "session-not-found" }
  | { readonly status: "session-closed" }
  | { readonly status: "stale-context"; readonly activeContextId?: ActiveOperationalContextId };


export type PathwaySelectionResult =
  | { readonly status: "selected"; readonly active: ActivePublicationSnapshot }
  | { readonly status: "session-not-found" }
  | { readonly status: "session-closed" }
  | { readonly status: "no-active-context" }
  | { readonly status: "stale-context"; readonly activeContextId: ActiveOperationalContextId };

export interface ActiveContextDependencies {
  readonly clock: Clock;
  readonly identifiers: IdentifierGenerator;
}

/** In-memory DEV-5 owner for session lifetime and exactly one active publication context per open session. */
export class ActiveOperationalContextManager {
  private readonly sessions = new Map<SessionId, SessionRecord>();
  private readonly activeBySession = new Map<SessionId, ActivePublicationSnapshot>();

  constructor(private readonly dependencies: ActiveContextDependencies) {}

  createSession(): SessionRecord {
    const record = Object.freeze({ id: sessionId(this.dependencies.identifiers.next()), createdAt: this.dependencies.clock.now() });
    this.sessions.set(record.id, record);
    return record;
  }

  getSession(id: SessionId): SessionRecord | undefined {
    return this.sessions.get(id);
  }

  getActive(id: SessionId): ActivePublicationSnapshot | undefined {
    return this.activeBySession.get(id);
  }

  activate(input: {
    readonly sessionId: SessionId;
    readonly expectedActiveContextId?: ActiveOperationalContextId;
    readonly sourceName: string;
    readonly publicationLoad: PublicationLoadRecord;
    readonly interpretation: PublicationInterpretation;
    readonly ior: InternalOperationalRepresentation;
  }): ActivationResult {
    const session = this.sessions.get(input.sessionId);
    if (!session) return { status: "session-not-found" };
    if (session.closedAt) return { status: "session-closed" };

    const prior = this.activeBySession.get(input.sessionId);
    if (input.expectedActiveContextId !== prior?.contextId) {
      return { status: "stale-context", ...(prior ? { activeContextId: prior.contextId } : {}) };
    }

    const active = Object.freeze({
      contextId: activeOperationalContextId(this.dependencies.identifiers.next()),
      sessionId: input.sessionId,
      activatedAt: this.dependencies.clock.now(),
      sourceName: input.sourceName,
      publicationLoad: input.publicationLoad,
      interpretation: input.interpretation,
      ior: input.ior
    });
    this.activeBySession.set(input.sessionId, active);
    return { status: "activated", active, ...(prior ? { replacedContextId: prior.contextId } : {}) };
  }

  selectPathway(input: { readonly sessionId: SessionId; readonly expectedActiveContextId: ActiveOperationalContextId; readonly pathwayId: RealizationPathwayId }): PathwaySelectionResult {
    const session = this.sessions.get(input.sessionId);
    if (!session) return { status: "session-not-found" };
    if (session.closedAt) return { status: "session-closed" };
    const active = this.activeBySession.get(input.sessionId);
    if (!active) return { status: "no-active-context" };
    if (active.contextId !== input.expectedActiveContextId) return { status: "stale-context", activeContextId: active.contextId };
    const updated = Object.freeze({ ...active, selectedPathwayId: input.pathwayId });
    this.activeBySession.set(input.sessionId, updated);
    return { status: "selected", active: updated };
  }

  closeSession(id: SessionId): boolean {
    const session = this.sessions.get(id);
    if (!session || session.closedAt) return false;
    this.sessions.set(id, Object.freeze({ ...session, closedAt: this.dependencies.clock.now() }));
    this.activeBySession.delete(id);
    return true;
  }
}
