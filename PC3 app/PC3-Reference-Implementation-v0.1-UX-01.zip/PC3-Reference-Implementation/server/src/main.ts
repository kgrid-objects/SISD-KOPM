import { createApplication } from "./app/create-application.js";
import { loadServerConfig } from "./app/config.js";

const config = loadServerConfig();
const application = createApplication(config);
let stopping = false;

async function stop(signal: NodeJS.Signals): Promise<void> {
  if (stopping) return;
  stopping = true;
  application.server.log.info({ signal }, "Stopping PC3 server");
  await application.stop();
}

process.once("SIGINT", () => void stop("SIGINT"));
process.once("SIGTERM", () => void stop("SIGTERM"));

try {
  await application.start();
} catch (error) {
  application.server.log.error({ err: error }, "PC3 server failed to start");
  process.exitCode = 1;
}
