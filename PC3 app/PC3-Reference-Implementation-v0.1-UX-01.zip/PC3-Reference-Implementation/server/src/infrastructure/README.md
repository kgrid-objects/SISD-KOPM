# Infrastructure module

Reserved for implementations of persistence, identifiers, clocks, cryptography, secrets, and external technical ports. Infrastructure must not become the source of PC3 architectural meaning.
