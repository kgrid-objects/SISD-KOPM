import { posix } from "node:path";
import { unzipSync, type UnzipFileInfo } from "fflate";
import { PublicationAcquisitionError } from "../../publication/publication-loader.js";

export const DEFAULT_MAX_ARCHIVE_BYTES = 268_435_456;
export const DEFAULT_MAX_RESOURCE_COUNT = 10_000;
export const DEFAULT_MAX_EXPANDED_BYTES = 536_870_912;
export const DEFAULT_MAX_RESOURCE_BYTES = 201_326_592;

export interface PublicationIntakeLimits {
  readonly maximumArchiveBytes?: number;
  readonly maximumResourceCount?: number;
  readonly maximumTotalBytes?: number;
  readonly maximumResourceBytes?: number;
}

export interface ResolvedPublicationIntakeLimits {
  readonly maximumArchiveBytes: number;
  readonly maximumResourceCount: number;
  readonly maximumTotalBytes: number;
  readonly maximumResourceBytes: number;
}

export function resolvePublicationIntakeLimits(limits: PublicationIntakeLimits = {}): ResolvedPublicationIntakeLimits {
  const resolved = Object.freeze({
    maximumArchiveBytes: limits.maximumArchiveBytes ?? DEFAULT_MAX_ARCHIVE_BYTES,
    maximumResourceCount: limits.maximumResourceCount ?? DEFAULT_MAX_RESOURCE_COUNT,
    maximumTotalBytes: limits.maximumTotalBytes ?? DEFAULT_MAX_EXPANDED_BYTES,
    maximumResourceBytes: limits.maximumResourceBytes ?? DEFAULT_MAX_RESOURCE_BYTES
  });
  for (const [name, value] of Object.entries(resolved)) {
    if (!Number.isSafeInteger(value) || value < 1) throw new Error(`${name} must be a positive safe integer.`);
  }
  return resolved;
}

export function safePublicationResourcePath(value: string): string {
  if (value.includes("\0")) throw new PublicationAcquisitionError("unsafe_resource_path", "Publication resource paths must not contain null characters.");
  const portable = value.replaceAll("\\", "/");
  if (/^[a-zA-Z]:\//.test(portable)) throw new PublicationAcquisitionError("unsafe_resource_path", `Unsafe publication resource path: ${value}`);
  const normalized = posix.normalize(portable).replace(/^\.\//, "");
  if (!normalized || normalized === "." || normalized.startsWith("../") || normalized.startsWith("/") || normalized.includes("/../")) {
    throw new PublicationAcquisitionError("unsafe_resource_path", `Unsafe publication resource path: ${value}`);
  }
  return normalized;
}

export function unzipPublicationArchive(
  bytes: Uint8Array,
  limitsInput: PublicationIntakeLimits,
  invalidArchiveMessage: string
): Record<string, Uint8Array> {
  const limits = resolvePublicationIntakeLimits(limitsInput);
  if (bytes.byteLength > limits.maximumArchiveBytes) {
    throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication archive compressed-byte limit exceeded.");
  }

  const seen = new Set<string>();
  let resourceCount = 0;
  let totalExpandedBytes = 0;
  const filter = (entry: UnzipFileInfo): boolean => {
    const path = safePublicationResourcePath(entry.name);
    const collisionKey = path.toLowerCase();
    if (seen.has(collisionKey)) throw new PublicationAcquisitionError("duplicate_resource_path", `Duplicate publication resource path: ${path}`);
    seen.add(collisionKey);
    resourceCount += 1;
    if (resourceCount > limits.maximumResourceCount) throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication resource-count limit exceeded.");
    if (!Number.isSafeInteger(entry.originalSize) || entry.originalSize < 0) throw new PublicationAcquisitionError("invalid_archive", invalidArchiveMessage);
    if (entry.originalSize > limits.maximumResourceBytes) throw new PublicationAcquisitionError("resource_limit_exceeded", `Publication resource-byte limit exceeded: ${path}`);
    totalExpandedBytes += entry.originalSize;
    if (!Number.isSafeInteger(totalExpandedBytes) || totalExpandedBytes > limits.maximumTotalBytes) {
      throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication expanded-byte limit exceeded.");
    }
    return true;
  };

  let entries: Record<string, Uint8Array>;
  try { entries = unzipSync(bytes, { filter }); }
  catch (error) {
    if (error instanceof PublicationAcquisitionError) throw error;
    throw new PublicationAcquisitionError("invalid_archive", invalidArchiveMessage);
  }

  let actualTotal = 0;
  for (const [entryPath, resourceBytes] of Object.entries(entries)) {
    const path = safePublicationResourcePath(entryPath);
    if (resourceBytes.byteLength > limits.maximumResourceBytes) throw new PublicationAcquisitionError("resource_limit_exceeded", `Publication resource-byte limit exceeded: ${path}`);
    actualTotal += resourceBytes.byteLength;
  }
  if (!Number.isSafeInteger(actualTotal) || actualTotal > limits.maximumTotalBytes) {
    throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication expanded-byte limit exceeded.");
  }
  return entries;
}
