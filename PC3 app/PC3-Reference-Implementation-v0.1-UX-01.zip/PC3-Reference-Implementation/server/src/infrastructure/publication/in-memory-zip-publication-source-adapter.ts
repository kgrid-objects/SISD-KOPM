import { createHash } from "node:crypto";
import type { PublicationSourceReference } from "../../publication/model.js";
import type { AcquiredPublication, AcquiredPublicationResource, PublicationSourceAdapter } from "../../publication/source-adapter.js";
import { safePublicationResourcePath, unzipPublicationArchive, type PublicationIntakeLimits } from "./publication-intake-safety.js";

function resource(path: string, bytes: Uint8Array): AcquiredPublicationResource {
  const stored = Uint8Array.from(bytes);
  return Object.freeze({
    path,
    byteLength: stored.byteLength,
    sha256: createHash("sha256").update(stored).digest("hex"),
    async readBytes(): Promise<Uint8Array> { return Uint8Array.from(stored); }
  });
}

export class InMemoryZipPublicationSourceAdapter implements PublicationSourceAdapter {
  constructor(
    private readonly bytes: Uint8Array,
    private readonly expectedLocator: string,
    private readonly limits: PublicationIntakeLimits = {}
  ) {}

  supports(source: PublicationSourceReference): boolean {
    return source.kind === "uploaded-archive" && source.locator === this.expectedLocator;
  }

  async acquire(source: PublicationSourceReference): Promise<AcquiredPublication> {
    const entries = unzipPublicationArchive(this.bytes, this.limits, "The uploaded publication archive is invalid or unsupported.");
    const resources = Object.entries(entries).sort(([a], [b]) => a.localeCompare(b)).map(([entryPath, bytes]) => {
      const path = safePublicationResourcePath(entryPath);
      return resource(path, bytes);
    });
    return Object.freeze({ source: Object.freeze({ ...source }), resources: Object.freeze(resources) });
  }
}
