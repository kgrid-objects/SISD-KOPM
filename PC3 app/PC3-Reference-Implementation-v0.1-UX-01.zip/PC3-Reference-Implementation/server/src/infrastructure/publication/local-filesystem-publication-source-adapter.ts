import { createHash } from "node:crypto";
import { lstat, readFile, readdir } from "node:fs/promises";
import { basename, relative, resolve, sep } from "node:path";
import { PublicationAcquisitionError } from "../../publication/publication-loader.js";
import type { PublicationSourceReference } from "../../publication/model.js";
import type { AcquiredPublication, AcquiredPublicationResource, PublicationSourceAdapter } from "../../publication/source-adapter.js";
import { resolvePublicationIntakeLimits, safePublicationResourcePath, unzipPublicationArchive, type PublicationIntakeLimits } from "./publication-intake-safety.js";

export interface LocalFilesystemAdapterOptions extends PublicationIntakeLimits {}

function digest(bytes: Uint8Array): string {
  return createHash("sha256").update(bytes).digest("hex");
}

function memoryResource(path: string, originalBytes: Uint8Array): AcquiredPublicationResource {
  const stored = Uint8Array.from(originalBytes);
  return Object.freeze({
    path,
    byteLength: stored.byteLength,
    sha256: digest(stored),
    async readBytes(): Promise<Uint8Array> { return Uint8Array.from(stored); }
  });
}

export class LocalFilesystemPublicationSourceAdapter implements PublicationSourceAdapter {
  private readonly limits;

  constructor(options: LocalFilesystemAdapterOptions = {}) {
    this.limits = resolvePublicationIntakeLimits(options);
  }

  supports(source: PublicationSourceReference): boolean {
    return source.kind === "local-directory" || source.kind === "uploaded-archive";
  }

  async acquire(source: PublicationSourceReference): Promise<AcquiredPublication> {
    const locator = resolve(source.locator);
    let info;
    try { info = await lstat(locator); }
    catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (code === "ENOENT") throw new PublicationAcquisitionError("source_not_found", `Publication source not found: ${source.locator}`);
      throw new PublicationAcquisitionError("source_not_readable", `Publication source could not be read: ${source.locator}`);
    }
    if (info.isSymbolicLink()) throw new PublicationAcquisitionError("unsafe_resource_path", "Symbolic-link publication roots are not accepted.");

    const resources = source.kind === "local-directory"
      ? await this.acquireDirectory(locator, info.isDirectory())
      : await this.acquireArchive(locator, info.isFile(), info.size);
    return Object.freeze({ source: Object.freeze({ ...source, locator }), resources: Object.freeze(resources) });
  }

  private async acquireDirectory(root: string, isDirectory: boolean): Promise<AcquiredPublicationResource[]> {
    if (!isDirectory) throw new PublicationAcquisitionError("source_not_readable", "The local-directory source is not a directory.");
    const resources: AcquiredPublicationResource[] = [];
    const seen = new Set<string>();
    let totalBytes = 0;
    const visit = async (directory: string): Promise<void> => {
      const entries = await readdir(directory, { withFileTypes: true });
      entries.sort((a, b) => a.name.localeCompare(b.name));
      for (const entry of entries) {
        const fullPath = resolve(directory, entry.name);
        if (!fullPath.startsWith(root + sep)) throw new PublicationAcquisitionError("unsafe_resource_path", `Resource escapes publication root: ${entry.name}`);
        if (entry.isSymbolicLink()) throw new PublicationAcquisitionError("unsafe_resource_path", `Symbolic links are not accepted: ${entry.name}`);
        if (entry.isDirectory()) await visit(fullPath);
        else if (entry.isFile()) {
          if (resources.length + 1 > this.limits.maximumResourceCount) throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication resource-count limit exceeded.");
          const path = safePublicationResourcePath(relative(root, fullPath));
          const collisionKey = path.toLowerCase();
          if (seen.has(collisionKey)) throw new PublicationAcquisitionError("duplicate_resource_path", `Duplicate publication resource path: ${path}`);
          seen.add(collisionKey);
          const info = await lstat(fullPath);
          if (info.size > this.limits.maximumResourceBytes) throw new PublicationAcquisitionError("resource_limit_exceeded", `Publication resource-byte limit exceeded: ${path}`);
          totalBytes += info.size;
          if (!Number.isSafeInteger(totalBytes) || totalBytes > this.limits.maximumTotalBytes) throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication total-byte limit exceeded.");
          const bytes = await readFile(fullPath);
          if (bytes.byteLength > this.limits.maximumResourceBytes || totalBytes - info.size + bytes.byteLength > this.limits.maximumTotalBytes) {
            throw new PublicationAcquisitionError("resource_limit_exceeded", `Publication resource changed while being acquired: ${path}`);
          }
          totalBytes += bytes.byteLength - info.size;
          resources.push(memoryResource(path, bytes));
        }
      }
    };
    await visit(root);
    return resources;
  }

  private async acquireArchive(archivePath: string, isFile: boolean, archiveBytes: number): Promise<AcquiredPublicationResource[]> {
    if (!isFile) throw new PublicationAcquisitionError("source_not_readable", "The uploaded-archive source is not a file.");
    if (archiveBytes > this.limits.maximumArchiveBytes) throw new PublicationAcquisitionError("resource_limit_exceeded", "Publication archive compressed-byte limit exceeded.");
    const entries = unzipPublicationArchive(await readFile(archivePath), this.limits, `Publication archive is invalid or unsupported: ${basename(archivePath)}`);
    return Object.entries(entries).sort(([a], [b]) => a.localeCompare(b)).map(([entryPath, bytes]) => {
      const path = safePublicationResourcePath(entryPath);
      return memoryResource(path, bytes);
    });
  }
}
