import { randomUUID } from "node:crypto";
import type { Clock, IdentifierGenerator } from "../../domain/time.js";
import { isoInstant } from "../../domain/time.js";

export const systemClock: Clock = { now: () => isoInstant(new Date().toISOString()) };
export const randomIdentifierGenerator: IdentifierGenerator = { next: () => randomUUID() };
