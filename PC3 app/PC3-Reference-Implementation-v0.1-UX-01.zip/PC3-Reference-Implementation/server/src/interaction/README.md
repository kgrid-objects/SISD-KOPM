# Execution Interaction boundary

DEV-9 makes the request/response exchange with an external execution environment explicit.

An `ExecutionInteraction` is an immutable PC3-owned record. It preserves the prepared Exercise Attempt request snapshot and the response received from an external adapter or system. It does not represent a runtime, environment association, process launch, or claim that PC3 performed execution.

Each accepted interaction automatically gives rise to one ephemeral Runtime Observation. Multiple interactions may be associated with one Exercise Attempt. External correlation identifiers are preserved separately from PC3-owned interaction identifiers.
