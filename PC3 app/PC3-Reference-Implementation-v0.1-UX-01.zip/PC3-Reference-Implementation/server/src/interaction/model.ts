import type { IsoInstant } from "../domain/time.js";
import type { ActiveOperationalContextId, ExecutionInteractionId, ExerciseAttemptId, IorId, PublicationLoadId, SessionId } from "../domain/identifiers.js";
import type { RuntimeOutcome } from "../observation/model.js";
import type { ReferenceExecutionPlan } from "../adapter/model.js";
import type { ExerciseAttemptBinding } from "../operation/model.js";

export interface RecordedExternalProcess {
  readonly executable: string;
  readonly arguments: readonly string[];
  readonly exitCode: number | null;
  readonly signal: string | null;
  readonly timedOut: boolean;
  readonly stderr: string;
}

export interface ExternalExecutionResponse {
  readonly externalInteractionId: string;
  readonly receivedFrom: string;
  readonly outcome: RuntimeOutcome;
  readonly responseMediaType: string;
  readonly responseValue: string;
  readonly runtimeReportedAt?: IsoInstant;
  readonly environmentIdentity?: string;
  readonly executionEnvironmentDescriptionId?: string;
  readonly externalProcess?: RecordedExternalProcess;
  readonly referenceExecution?: ReferenceExecutionPlan;
  readonly libraryReturn?: import("../adapter/model.js").AdapterExecutionResult["libraryReturn"];
  readonly httpExchange?: import("../adapter/model.js").AdapterExecutionResult["httpExchange"];
}

/** Immutable PC3 record of one request/response exchange involving an external execution environment. */
export interface ExecutionInteraction {
  readonly id: ExecutionInteractionId;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly attemptId: ExerciseAttemptId;
  readonly publicationLoadId: PublicationLoadId;
  readonly iorId: IorId;
  readonly pathwayId: string;
  readonly endpointIdentifier: string;
  readonly externalInteractionId: string;
  readonly publicationExerciseBinding?: ExerciseAttemptBinding;
  readonly request: {
    readonly mediaType: string;
    readonly value: string;
    readonly requestedAt: IsoInstant;
  };
  readonly response: {
    readonly receivedFrom: string;
    readonly environmentIdentity?: string;
    readonly executionEnvironmentDescriptionId?: string;
    readonly outcome: RuntimeOutcome;
    readonly mediaType: string;
    readonly value: string;
    readonly runtimeReportedAt?: IsoInstant;
    readonly receivedAt: IsoInstant;
    readonly preservationDisposition?: "raw-unmodified";
    readonly observationLocation?: "stdout" | "return-value" | "response-body";
  };
  readonly externalProcess?: RecordedExternalProcess;
  readonly referenceExecution?: {
    readonly pathIdentifier: ReferenceExecutionPlan["pathIdentifier"];
    readonly declarationResourcePath: string;
    readonly adapterArtifactReference?: string;
    readonly realizationIdentifier: ReferenceExecutionPlan["realizationIdentifier"];
    readonly ptcIdentifier: ReferenceExecutionPlan["ptcIdentifier"];
    readonly rtcmIdentifier: string;
    readonly declarationIdentityField: ReferenceExecutionPlan["declarationIdentityField"];
    readonly realizationType: ReferenceExecutionPlan["realizationType"];
    readonly runtimeDeclaration?: NonNullable<ReferenceExecutionPlan["runtimeDeclaration"]>;
    readonly invocation: {
      readonly mode: "cli" | "library" | "http";
      readonly executable: string;
      readonly runtimeRequirement: string;
      readonly runtimeResolutionBasis: ReferenceExecutionPlan["runtimeResolutionBasis"];
      readonly adapterResolution: ReferenceExecutionPlan["adapterResolution"];
      readonly arguments: readonly string[];
      readonly orderedBindings: ReferenceExecutionPlan["orderedBindings"];
      readonly libraryInvocation?: NonNullable<ReferenceExecutionPlan["libraryInvocation"]>;
      readonly dotnetCliInvocation?: NonNullable<ReferenceExecutionPlan["dotnetCliInvocation"]>;
      readonly httpInvocation?: NonNullable<ReferenceExecutionPlan["httpInvocation"]>;
      readonly negativeConditionPlan?: NonNullable<ReferenceExecutionPlan["negativeConditionPlan"]>;
    };
    readonly observation: { readonly location: "stdout" | "return-value" | "response-body"; readonly rawMustBePreserved: true; readonly preservationDisposition: "raw-unmodified" };
    readonly comparisonDeclaration?: { readonly comparisonType?: string; readonly absoluteTolerance?: number; readonly relativeTolerance?: number; readonly disposition: "declared-not-yet-evaluated" };
    readonly extractionExpression?: string;
    readonly semanticOutcome?: string;
    readonly normalizationDeclarations: readonly string[];
    readonly rtcmDeclarationProvenance: ReferenceExecutionPlan["rtcmDeclarationProvenance"];
    readonly expectedOutcomeValue: unknown;
    readonly expectedOutcomeKind: string;
    readonly normativeExpectedValuePath?: string;
    readonly expectedOutcomeAuthorityReference?: string;
    readonly requiredRepresentation?: string;
    readonly requiredUnit?: string;
    readonly roundingPermittedBeforeComparison?: boolean;
    readonly semanticExtractionStrategy: "json-result-risk" | "direct-json-return-value" | "json-declared-path" | "semantic-rejection";
    readonly semanticObservationPath?: string;
    readonly returnTransfer?: NonNullable<import("../adapter/model.js").AdapterExecutionResult["libraryReturn"]>;
    readonly httpTransfer?: NonNullable<import("../adapter/model.js").AdapterExecutionResult["httpExchange"]>;
  };
  readonly status: "response-received";
  readonly executionResponsibility: "external-environment";
  readonly coordinationDisposition: "response-intake-only";
  readonly verificationDisposition: "received-not-independently-verified";
  readonly explanation: string;
}
