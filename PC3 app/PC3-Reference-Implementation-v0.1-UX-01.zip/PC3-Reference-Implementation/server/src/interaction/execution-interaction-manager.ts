import { executionInteractionId, type ActiveOperationalContextId, type ExecutionInteractionId, type ExerciseAttemptId, type SessionId } from "../domain/identifiers.js";
import { isoInstant, type Clock, type IdentifierGenerator } from "../domain/time.js";
import type { ExerciseAttempt } from "../operation/model.js";
import type { ExecutionInteraction, ExternalExecutionResponse } from "./model.js";

export type ReceiveExecutionInteractionResult =
  | { readonly status: "received"; readonly interaction: ExecutionInteraction }
  | { readonly status: "stale-context" }
  | { readonly status: "invalid-response"; readonly explanation: string }
  | { readonly status: "duplicate-external-interaction" };

export class ExecutionInteractionManager {
  private readonly bySession = new Map<SessionId, ExecutionInteraction[]>();
  constructor(private readonly dependencies: { readonly clock: Clock; readonly identifiers: IdentifierGenerator }) {}

  receive(input: { readonly attempt: ExerciseAttempt; readonly expectedActiveContextId: ActiveOperationalContextId; readonly response: ExternalExecutionResponse }): ReceiveExecutionInteractionResult {
    if (input.attempt.activeContextId !== input.expectedActiveContextId) return { status: "stale-context" };
    const externalInteractionId = input.response.externalInteractionId.trim();
    const receivedFrom = input.response.receivedFrom.trim();
    const mediaType = input.response.responseMediaType.trim();
    if (!externalInteractionId) return { status: "invalid-response", explanation: "External execution interaction identity must not be empty." };
    if (!receivedFrom) return { status: "invalid-response", explanation: "External execution response source must not be empty." };
    if (!mediaType) return { status: "invalid-response", explanation: "External execution response media type must not be empty." };
    if (input.response.responseValue.length > 5_000_000) return { status: "invalid-response", explanation: "External execution response exceeds the DEV-9 in-memory intake limit." };
    if ((this.bySession.get(input.attempt.sessionId) ?? []).some((item) => item.externalInteractionId === externalInteractionId)) return { status: "duplicate-external-interaction" };
    let runtimeReportedAt;
    if (input.response.runtimeReportedAt) {
      const parsed = new Date(input.response.runtimeReportedAt);
      if (Number.isNaN(parsed.valueOf())) return { status: "invalid-response", explanation: "External runtime reported time must be a valid timestamp when supplied." };
      runtimeReportedAt = isoInstant(parsed.toISOString());
    }
    const receivedAt = this.dependencies.clock.now();
    const interaction: ExecutionInteraction = Object.freeze({
      id: executionInteractionId(this.dependencies.identifiers.next()),
      sessionId: input.attempt.sessionId,
      activeContextId: input.attempt.activeContextId,
      attemptId: input.attempt.id,
      publicationLoadId: input.attempt.publicationLoadId,
      iorId: input.attempt.iorId,
      pathwayId: input.attempt.pathwayId,
      endpointIdentifier: input.attempt.endpointIdentifier,
      externalInteractionId,
      ...(input.attempt.publicationExerciseBinding ? { publicationExerciseBinding: Object.freeze({ ...input.attempt.publicationExerciseBinding }) } : {}),
      request: Object.freeze({ mediaType: input.attempt.input.mediaType, value: input.attempt.input.value, requestedAt: input.attempt.requestedAt }),
      response: Object.freeze({
        receivedFrom,
        ...(input.response.environmentIdentity?.trim() ? { environmentIdentity: input.response.environmentIdentity.trim() } : {}),
        ...(input.response.executionEnvironmentDescriptionId?.trim() ? { executionEnvironmentDescriptionId: input.response.executionEnvironmentDescriptionId.trim() } : {}),
        outcome: input.response.outcome,
        mediaType,
        value: input.response.responseValue,
        ...(runtimeReportedAt ? { runtimeReportedAt } : {}),
        receivedAt,
        ...(input.response.referenceExecution ? { preservationDisposition: "raw-unmodified" as const, observationLocation: input.response.referenceExecution.observationLocation } : {})
      }),
      ...(input.response.externalProcess ? { externalProcess: Object.freeze({ ...input.response.externalProcess, arguments: Object.freeze([...input.response.externalProcess.arguments]) }) } : {}),
      ...(input.response.referenceExecution ? { referenceExecution: Object.freeze({
        pathIdentifier: input.response.referenceExecution.pathIdentifier,
        declarationResourcePath: input.response.referenceExecution.declarationResourcePath,
        declarationIdentityField: input.response.referenceExecution.declarationIdentityField,
        ...(input.response.referenceExecution.adapterArtifactReference ? { adapterArtifactReference: input.response.referenceExecution.adapterArtifactReference } : {}),
        realizationIdentifier: input.response.referenceExecution.realizationIdentifier,
        realizationType: input.response.referenceExecution.realizationType,
        ...(input.response.referenceExecution.runtimeDeclaration ? { runtimeDeclaration: Object.freeze({ ...input.response.referenceExecution.runtimeDeclaration }) } : {}),
        ptcIdentifier: input.response.referenceExecution.ptcIdentifier,
        rtcmIdentifier: input.response.referenceExecution.rtcmIdentifier,
        invocation: Object.freeze({
          mode: input.response.referenceExecution.invocationMode,
          executable: input.response.referenceExecution.executable,
          runtimeRequirement: input.response.referenceExecution.runtimeRequirement,
          runtimeResolutionBasis: input.response.referenceExecution.runtimeResolutionBasis,
          adapterResolution: Object.freeze({ ...input.response.referenceExecution.adapterResolution }),
          arguments: Object.freeze([...input.response.referenceExecution.arguments]),
          orderedBindings: input.response.referenceExecution.orderedBindings
          ,...(input.response.referenceExecution.libraryInvocation ? { libraryInvocation: input.response.referenceExecution.libraryInvocation } : {})
          ,...(input.response.referenceExecution.dotnetCliInvocation ? { dotnetCliInvocation: input.response.referenceExecution.dotnetCliInvocation } : {})
          ,...(input.response.referenceExecution.httpInvocation ? { httpInvocation: input.response.referenceExecution.httpInvocation } : {})
          ,...(input.response.referenceExecution.negativeConditionPlan ? { negativeConditionPlan: input.response.referenceExecution.negativeConditionPlan } : {})
        }),
        observation: Object.freeze({ location: input.response.referenceExecution.observationLocation, rawMustBePreserved: true as const, preservationDisposition: "raw-unmodified" as const }),
        ...(input.response.referenceExecution.extractionExpression ? { extractionExpression: input.response.referenceExecution.extractionExpression } : {}),
        ...(input.response.referenceExecution.semanticOutcome ? { semanticOutcome: input.response.referenceExecution.semanticOutcome } : {}),
        normalizationDeclarations: Object.freeze([...input.response.referenceExecution.normalizationDeclarations]),
        rtcmDeclarationProvenance: Object.freeze({ ...input.response.referenceExecution.rtcmDeclarationProvenance }),
        expectedOutcomeValue: input.response.referenceExecution.expectedOutcomeValue,
        expectedOutcomeKind: input.response.referenceExecution.expectedOutcomeKind,
        ...(input.response.referenceExecution.normativeExpectedValuePath ? { normativeExpectedValuePath: input.response.referenceExecution.normativeExpectedValuePath } : {}),
        ...(input.response.referenceExecution.expectedOutcomeAuthorityReference ? { expectedOutcomeAuthorityReference: input.response.referenceExecution.expectedOutcomeAuthorityReference } : {}),
        ...(input.response.referenceExecution.requiredRepresentation ? { requiredRepresentation: input.response.referenceExecution.requiredRepresentation } : {}),
        ...(input.response.referenceExecution.requiredUnit ? { requiredUnit: input.response.referenceExecution.requiredUnit } : {}),
        ...(input.response.referenceExecution.roundingPermittedBeforeComparison !== undefined ? { roundingPermittedBeforeComparison: input.response.referenceExecution.roundingPermittedBeforeComparison } : {}),
        semanticExtractionStrategy: input.response.referenceExecution.semanticExtractionStrategy,
        ...(input.response.referenceExecution.semanticObservationPath ? { semanticObservationPath: input.response.referenceExecution.semanticObservationPath } : {}),
        ...(input.response.libraryReturn ? { returnTransfer: input.response.libraryReturn } : {}),
        ...(input.response.httpExchange ? { httpTransfer: input.response.httpExchange } : {}),
        ...((input.response.referenceExecution.comparisonType || input.response.referenceExecution.absoluteTolerance !== undefined) ? { comparisonDeclaration: Object.freeze({
          ...(input.response.referenceExecution.comparisonType ? { comparisonType: input.response.referenceExecution.comparisonType } : {}),
          ...(input.response.referenceExecution.absoluteTolerance !== undefined ? { absoluteTolerance: input.response.referenceExecution.absoluteTolerance } : {}),
          ...(input.response.referenceExecution.relativeTolerance !== undefined ? { relativeTolerance: input.response.referenceExecution.relativeTolerance } : {}),
          disposition: "declared-not-yet-evaluated" as const
        }) } : {})
      }) } : {}),
      status: "response-received",
      executionResponsibility: "external-environment",
      coordinationDisposition: "response-intake-only",
      verificationDisposition: "received-not-independently-verified",
      explanation: "This immutable PC3 Execution Interaction records the request/response exchange associated with an external environment. PC3 received the response but did not perform or control the execution."
    });
    const list = this.bySession.get(interaction.sessionId) ?? [];
    this.bySession.set(interaction.sessionId, [...list, interaction]);
    return { status: "received", interaction };
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId, attemptId?: ExerciseAttemptId): readonly ExecutionInteraction[] {
    return (this.bySession.get(sessionId) ?? []).filter((item) => item.activeContextId === activeContextId && (!attemptId || item.attemptId === attemptId));
  }

  find(sessionId: SessionId, id: ExecutionInteractionId): ExecutionInteraction | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.id === id);
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); }
}
