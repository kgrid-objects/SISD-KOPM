import type { PublicationDeclarationProvenance, ExecutableRealizationType } from "./interpretation-model.js";

/** Canonical comparison semantics published by a Publication Test Case. */
export interface CanonicalComparisonSemantics {
  readonly comparisonType: string;
  readonly normativeValuePath?: string;
  readonly absoluteTolerance?: number;
  readonly relativeTolerance?: number;
  readonly requiredRepresentation?: string;
  readonly requiredUnit?: string;
  readonly roundingPermittedBeforeComparison?: boolean;
}

/** Canonical, representation-independent input owned by a Publication Test Case. */
export interface CanonicalInputObject {
  readonly mediaType?: string;
  readonly objectType?: string;
  readonly validity?: string;
  readonly value: unknown;
  readonly canonicalFieldOrder: readonly string[];
  readonly conventionReference?: string;
}

/** Canonical representation-independent negative condition owned by a PTC. */
export interface CanonicalNegativeInputCondition {
  readonly conditionType: string;
  readonly baseInputReference?: string;
  readonly omittedCanonicalPredictor?: string;
  readonly invalidCanonicalPredictor?: string;
  readonly invalidSemanticContent?: string;
  readonly illustrativeLexicalValue?: unknown;
  readonly otherSuppliedCanonicalPredictors?: Readonly<Record<string, unknown>>;
  readonly suppliedCanonicalPredictors?: Readonly<Record<string, unknown>>;
  readonly illustrativeInvalidAggregate?: unknown;
  readonly distinctionFromPtc004?: string;
  readonly provenance: PublicationDeclarationProvenance;
}

export interface CanonicalSemanticRejection {
  readonly category: string;
  readonly subject: string;
  readonly reason?: string;
  readonly computationMustNotProduceRiskResult: boolean;
  readonly messageTextIsNormative: boolean;
  readonly transportStatusIsNormative: boolean;
  readonly requiredSemanticAssertions: readonly string[];
}

/** Canonical outcome against which a realization observation may later be compared. */
export interface CanonicalExpectedOutcome {
  readonly outcomeKind: string;
  readonly value: unknown;
  readonly normativeValuePath?: string;
  readonly authorityReference?: string;
}

/** Publication-wide specification of a canonical computational exercise. */
export interface PublicationTestCase {
  readonly identifier: string;
  readonly version?: string;
  readonly title?: string;
  readonly purpose?: string;
  readonly classification?: string;
  readonly status?: string;
  readonly publicationIdentifier?: string;
  readonly publishedCapabilitySpecificationReference?: string;
  readonly canonicalInput: CanonicalInputObject;
  readonly canonicalNegativeInputCondition?: CanonicalNegativeInputCondition;
  readonly canonicalExpectedOutcome: CanonicalExpectedOutcome;
  readonly canonicalSemanticRejection?: CanonicalSemanticRejection;
  readonly comparisonSemantics: CanonicalComparisonSemantics;
  readonly applicability: {
    readonly applicableRealizationCount?: number;
    readonly notApplicableRealizationCount?: number;
    readonly nonApplicabilityPermitted: boolean;
  };
  readonly provenance: PublicationDeclarationProvenance;
}

export interface RealizationInputBinding {
  readonly canonicalField: string;
  readonly localBinding: string;
  readonly bindingKind?: string;
  readonly unitMapping?: string;
  readonly transformation?: string;
}

export interface RealizationInvocationDeclaration {
  readonly mode: string;
  readonly entryPoint?: string;
  readonly operation?: string;
  readonly argumentOrder: readonly string[];
  readonly requestArtifactReference?: string;
  readonly supportAdapterReference?: string;
  readonly externalEnvironmentRequirements: readonly string[];
  readonly doesNotEmbedRuntime: boolean;
  readonly constructionBasis?: string;
}

export interface ObservationDerivationDeclaration {
  readonly rawObservationLocation?: string;
  readonly extractionExpression?: string;
  readonly semanticOutcome?: string;
  readonly normalizations: readonly string[];
  readonly rawObservationMustBePreserved: boolean;
}

export type PairingApplicabilityStatus = "applicable" | "not-applicable" | "undetermined";

/** Realization-specific manifestation of one canonical Publication Test Case. */
export interface RealizationTestCaseManifestation {
  readonly identifier: string;
  readonly version?: string;
  readonly status?: string;
  readonly ptcIdentifier: string;
  readonly realizationIdentifier: string;
  readonly realizationType: ExecutableRealizationType;
  readonly applicability: {
    readonly status: PairingApplicabilityStatus;
    readonly pairingKey?: string;
    readonly conformanceAssertion: boolean;
  };
  readonly inputDerivation: {
    readonly canonicalInputReference?: string;
    readonly concreteMediaType?: string;
    readonly artifactReference?: string;
    readonly inlinePermitted?: boolean;
    readonly bindings: readonly RealizationInputBinding[];
    readonly constraints: readonly string[];
    readonly negativeConditionDerivation?: {
      readonly semanticCondition: string;
      readonly concreteDerivation: string;
      readonly mustNotConflateWith?: string;
    };
  };
  readonly invocation: RealizationInvocationDeclaration;
  readonly observationDerivation: ObservationDerivationDeclaration;
  readonly comparison: {
    readonly canonicalExpectedOutcomeReference?: string;
    readonly comparisonType?: string;
    readonly toleranceReference?: string | number;
    readonly representationSpecificHandling: readonly string[];
    readonly mustPermitFailResult: boolean;
  };
  readonly evidenceLinkageRequirements: readonly string[];
  readonly limitations: readonly string[];
  readonly provenance: PublicationDeclarationProvenance;
}


/** Explicit publication declaration that a canonical PTC does or does not apply to one realization. */
export interface PublicationTestCaseApplicability {
  readonly ptcIdentifier: string;
  readonly realizationIdentifier: string;
  readonly status: PairingApplicabilityStatus;
  readonly basisReference?: string;
  readonly provenance: PublicationDeclarationProvenance;
}

/** Derived coverage state; it is not Publication Truth and does not assert runtime success. */
export interface ExerciseReadiness {
  readonly realizationIdentifier: string;
  readonly applicablePtcCount: number;
  readonly authoritativeRtcmCount: number;
  readonly missingRtcmPtcIdentifiers: readonly string[];
  readonly status: "complete" | "partial" | "none" | "not-applicable";
  readonly statement: string;
}

/** PC3-owned immutable view created only after a unique PTC/realization/RTCM pairing is resolved. */
export interface ResolvedExercise {
  readonly ptc: PublicationTestCase;
  readonly realization: {
    readonly identifier: string;
    readonly realizationType: ExecutableRealizationType;
    readonly artifactReference?: string;
    readonly invocationMechanism?: string;
  };
  readonly rtcm: RealizationTestCaseManifestation;
  readonly canonicalInput: CanonicalInputObject;
  readonly canonicalExpectedOutcome: CanonicalExpectedOutcome;
  readonly comparisonSemantics: CanonicalComparisonSemantics;
  readonly readiness: "publication-exercise-ready";
  readonly executionBoundary: "external-to-publication";
  readonly statement: string;
}

export type ExerciseResolutionOutcome =
  | { readonly status: "resolved"; readonly exercise: ResolvedExercise }
  | { readonly status: "ptc-not-found"; readonly ptcIdentifier: string }
  | { readonly status: "realization-not-found"; readonly realizationIdentifier: string }
  | { readonly status: "not-applicable"; readonly ptcIdentifier: string; readonly realizationIdentifier: string }
  | { readonly status: "rtcm-not-found"; readonly ptcIdentifier: string; readonly realizationIdentifier: string }
  | { readonly status: "ambiguous-rtcm"; readonly ptcIdentifier: string; readonly realizationIdentifier: string; readonly rtcmIdentifiers: readonly string[] };
