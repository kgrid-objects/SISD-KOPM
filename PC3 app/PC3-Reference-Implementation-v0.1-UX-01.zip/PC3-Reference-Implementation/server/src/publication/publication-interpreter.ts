import { parse as parseYaml } from "yaml";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import { publicationInterpretationId } from "../domain/identifiers.js";
import type { PublicationLoadRecord } from "./model.js";
import type { AcquiredPublication, AcquiredPublicationResource } from "./source-adapter.js";
import { PublicationExerciseDiscovery } from "./publication-exercise-discovery.js";
import { PublicationExerciseModelManager } from "./publication-exercise-model-manager.js";
import { PublicationIntegrityValidator } from "./publication-integrity-validator.js";
import { PublicationCapabilityProfileSelector } from "./publication-capability-profile-selector.js";
import type {
  ExecutableRealizationType,
  InterpretationLimitation,
  InterpretedPublicationIdentity,
  InterpretedInputObjectDeclaration,
  InterpretedRealizationDeclaration,
  InterpretedRelationshipDeclaration,
  PublicationDeclarationProvenance,
  PublicationInterpretation
} from "./interpretation-model.js";

export interface PublicationInterpreterDependencies {
  readonly clock: Clock;
  readonly identifiers: IdentifierGenerator;
}

type JsonObject = Record<string, unknown>;

const supportedExtensions = [".json", ".yaml", ".yml"];
const identityContainers = ["publication", "publishedComputationalCapability", "knowledgeObject", "uko"];
const declarationFilenameMarkers = ["metadata", "manifest", "architecture", "declaration", "implementation", "binding", "service", "package", "execution-contract"];
const realizationCollections: ReadonlyArray<readonly [string, ExecutableRealizationType]> = [
  ["implementationRepresentations", "implementation-representation"],
  ["serviceRealizations", "service-realization"],
  ["deploymentPackages", "deployment-package"]
];

function isObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isPackagingResidue(path: string): boolean {
  return path.split("/").some((part) => part === "__MACOSX" || part.startsWith("._"));
}

function isDevelopmentResource(path: string): boolean {
  return path.replaceAll("\\", "/").split("/").some((part) => part.toLowerCase() === "_development");
}

function isSummaryInventoryOrEvidenceResource(path: string): boolean {
  const filename = path.split("/").at(-1)?.toLowerCase() ?? "";
  return ["summary", "inventory", "register", "report", "evidence", "validation-record", "pass-record", "decision-register", "artifact-manifest"]
    .some((marker) => filename.includes(marker));
}

function isLikelyDeclarationResource(path: string): boolean {
  const filename = path.split("/").at(-1)?.toLowerCase() ?? "";
  return declarationFilenameMarkers.some((marker) => filename.includes(marker));
}

function typeContains(value: unknown, token: string): boolean {
  const values = Array.isArray(value) ? value : [value];
  return values.some((item) => stringValue(item)?.toLowerCase().includes(token.toLowerCase()));
}

function stringValue(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function firstString(object: JsonObject, keys: readonly string[]): string | undefined {
  for (const key of keys) {
    const value = stringValue(object[key]);
    if (value) return value;
  }
  return undefined;
}

function provenance(resource: AcquiredPublicationResource, location: string): PublicationDeclarationProvenance {
  return Object.freeze({
    resourcePath: resource.path,
    resourceSha256: resource.sha256,
    location,
    basis: "explicit-declaration"
  });
}

function normalizeRealizationType(value: unknown): ExecutableRealizationType | undefined {
  const normalized = stringValue(value)?.toLowerCase().replaceAll("_", "-").replaceAll(" ", "-");
  if (!normalized) return undefined;
  if (["implementation-representation", "implementation", "ir"].includes(normalized)) return "implementation-representation";
  if (["service-realization", "service", "sr"].includes(normalized)) return "service-realization";
  if (["deployment-package", "deployment", "dp"].includes(normalized)) return "deployment-package";
  return undefined;
}

function realizationTypeFromLayerIdentifier(value: unknown): ExecutableRealizationType | undefined {
  const normalized = stringValue(value)?.toUpperCase();
  if (!normalized) return undefined;
  if (["UKO-LAYER-IR", "IR", "IMPLEMENTATION-REPRESENTATION"].includes(normalized)) return "implementation-representation";
  if (["UKO-LAYER-SR", "SR", "SERVICE-REALIZATION"].includes(normalized)) return "service-realization";
  if (["UKO-LAYER-DP", "DP", "DEPLOYMENT-PACKAGE"].includes(normalized)) return "deployment-package";
  return undefined;
}

function semanticRelationshipType(value: string): string {
  const normalized = value.toLowerCase().replaceAll("_", "-").replaceAll(/\s+/g, " ").trim();
  if (normalized.includes("served") || normalized.includes("makes invocable")) return "implementation-to-service";
  if (normalized.includes("packaged") || normalized.includes("packages")) return "service-to-deployment";
  return normalized;
}

function stableKey(value: InterpretedRealizationDeclaration | InterpretedRelationshipDeclaration): string {
  if ("realizationType" in value) return `${value.realizationType}:${value.identifier}`;
  return `${semanticRelationshipType(value.relationshipType)}:${value.sourceIdentifier}->${value.targetIdentifier}`;
}

export class PublicationInterpreter {
  constructor(private readonly dependencies: PublicationInterpreterDependencies) {}

  async interpret(load: PublicationLoadRecord, acquired: AcquiredPublication): Promise<PublicationInterpretation> {
    const identities: InterpretedPublicationIdentity[] = [];
    const realizations: InterpretedRealizationDeclaration[] = [];
    const inputObjects: InterpretedInputObjectDeclaration[] = [];
    const relationships: InterpretedRelationshipDeclaration[] = [];
    const limitations: InterpretationLimitation[] = [];
    const interpretedResourcePaths: string[] = [];
    const parsedDocuments: Array<{ readonly document: JsonObject; readonly resource: AcquiredPublicationResource }> = [];

    for (const resource of acquired.resources) {
      if (isPackagingResidue(resource.path)) continue;
      // Development work products remain acquired and inspectable Publication
      // Truth, but they are not authoritative operational declarations.
      if (isDevelopmentResource(resource.path)) continue;
      if (!supportedExtensions.some((extension) => resource.path.toLowerCase().endsWith(extension))) continue;
      let document: unknown;
      try {
        const text = new TextDecoder("utf-8", { fatal: true }).decode(await resource.readBytes());
        document = resource.path.toLowerCase().endsWith(".json") ? JSON.parse(text) : parseYaml(text);
      } catch {
        if (isLikelyDeclarationResource(resource.path)) {
          limitations.push({
            code: "malformed_declaration_document",
            message: "A likely JSON or YAML declaration resource could not be parsed.",
            resourcePath: resource.path
          });
        }
        continue;
      }
      if (!isObject(document)) continue;
      parsedDocuments.push({ document, resource });
      const before = identities.length + inputObjects.length + realizations.length + relationships.length;
      this.collectIdentity(document, resource, identities);
      await this.collectInputObjects(document, resource, acquired, inputObjects, limitations);
      this.collectRealizations(document, resource, realizations, limitations);
      this.collectRelationships(document, resource, relationships, limitations);
      this.collectUkoInstanceMetadata(document, resource, realizations, relationships, limitations);
      if (identities.length + inputObjects.length + realizations.length + relationships.length > before) interpretedResourcePaths.push(resource.path);
    }

    const uniqueInputObjects = this.deduplicateInputs(inputObjects, limitations);
    const uniqueRealizations = this.deduplicate(realizations, limitations);
    for (const parsed of parsedDocuments) {
      this.collectComplementaryRealizationRelationships(parsed.document, parsed.resource, uniqueRealizations, relationships, limitations);
    }
    const uniqueRelationships = this.deduplicate(relationships, limitations);
    const publicationIdentity = this.resolveIdentity(identities, limitations);
    const exerciseDiscovery = new PublicationExerciseDiscovery().discover(parsedDocuments, uniqueRealizations, limitations);
    const exerciseModel = {
      publicationTestCases: exerciseDiscovery.publicationTestCases,
      realizationTestCaseManifestations: exerciseDiscovery.realizationTestCaseManifestations,
      applicabilityDeclarations: exerciseDiscovery.applicabilityDeclarations
    };
    const exerciseManager = new PublicationExerciseModelManager();
    const exerciseReadiness = exerciseManager.summarizeReadiness(exerciseModel, uniqueRealizations);
    const publicationValidation = new PublicationIntegrityValidator().validate({
      ...(publicationIdentity ? { publicationIdentifier: publicationIdentity.value.declaredIdentifier } : {}),
      ...exerciseModel,
      rawPublicationTestCases: exerciseDiscovery.validationSource.publicationTestCases,
      rawRealizationTestCaseManifestations: exerciseDiscovery.validationSource.realizationTestCaseManifestations,
      declaredApplicabilityDeclarations: exerciseDiscovery.validationSource.applicabilityDeclarations,
      realizations: uniqueRealizations,
      discoveryIndex: exerciseDiscovery.index,
      publicationResourcePaths: acquired.resources.map((resource) => resource.path)
    });
    const hasExplicitPtcDeclarationSignals = parsedDocuments.some(({ document }) =>
      document.canonicalInputObject !== undefined ||
      document.canonicalInputCondition !== undefined ||
      document.canonicalExpectedOutcome !== undefined ||
      document.comparisonSemantics !== undefined ||
      document.canonicalOrigin !== undefined ||
      document.complementedRealization !== undefined
    );
    const capabilityProfile = new PublicationCapabilityProfileSelector().select({
      ptcCount: exerciseDiscovery.publicationTestCases.length,
      standaloneInputObjectCount: uniqueInputObjects.length,
      hasExplicitPtcDeclarationSignals,
      validation: publicationValidation,
      ptcProvenance: exerciseDiscovery.publicationTestCases.map((value) => value.provenance),
      inputProvenance: uniqueInputObjects.map((value) => value.provenance)
    });
    const resolvedExercises = capabilityProfile.kind === "ptc" ? exerciseDiscovery.applicabilityDeclarations
      .filter((pairing) => pairing.status === "applicable")
      .filter((pairing, index, values) => values.findIndex((candidate) => candidate.ptcIdentifier === pairing.ptcIdentifier && candidate.realizationIdentifier === pairing.realizationIdentifier) === index)
      .map((pairing) => exerciseManager.resolve(exerciseModel, uniqueRealizations, pairing.ptcIdentifier, pairing.realizationIdentifier))
      .filter((outcome) => outcome.status === "resolved")
      .map((outcome) => outcome.exercise) : [];
    exerciseDiscovery.interpretedResourcePaths.forEach((path) => interpretedResourcePaths.push(path));

    if (!publicationIdentity && uniqueInputObjects.length === 0 && uniqueRealizations.length === 0 && uniqueRelationships.length === 0) {
      limitations.push({
        code: "no_supported_declarations",
        message: "No supported explicit publication identity, realization, or relationship declarations were found. Repository structure was not promoted to architectural meaning."
      });
    }

    return Object.freeze({
      id: publicationInterpretationId(this.dependencies.identifiers.next()),
      publicationLoadId: load.id,
      interpretedAt: this.dependencies.clock.now(),
      ...(publicationIdentity ? { publicationIdentity } : {}),
      inputObjects: Object.freeze(uniqueInputObjects),
      publicationTestCases: exerciseDiscovery.publicationTestCases,
      realizationTestCaseManifestations: exerciseDiscovery.realizationTestCaseManifestations,
      publicationTestCaseApplicability: exerciseDiscovery.applicabilityDeclarations,
      exerciseReadiness,
      exerciseDiscoveryIndex: exerciseDiscovery.index,
      publicationValidation,
      capabilityProfile,
      resolvedExercises: Object.freeze(resolvedExercises),
      realizations: Object.freeze(uniqueRealizations),
      relationships: Object.freeze(uniqueRelationships),
      limitations: Object.freeze(limitations),
      interpretedResourcePaths: Object.freeze([...new Set(interpretedResourcePaths)].sort())
    });
  }


  private async collectInputObjects(
    document: JsonObject,
    resource: AcquiredPublicationResource,
    acquired: AcquiredPublication,
    results: InterpretedInputObjectDeclaration[],
    limitations: InterpretationLimitation[]
  ): Promise<void> {
    const candidates: Array<readonly [unknown, string]> = [];
    for (const key of ["inputObjects", "inputs"]) {
      const collection = document[key];
      if (Array.isArray(collection)) collection.forEach((value, index) => candidates.push([value, `$.${key}[${index}]`]));
    }
    if (document.inputObject !== undefined) candidates.push([document.inputObject, "$.inputObject"]);
    for (const containerKey of identityContainers) {
      const container = document[containerKey];
      if (!isObject(container)) continue;
      for (const key of ["inputObjects", "inputs"]) {
        const collection = container[key];
        if (Array.isArray(collection)) collection.forEach((value, index) => candidates.push([value, `$.${containerKey}.${key}[${index}]`]));
      }
    }
    if (isObject(document.describes)) {
      const describes = document.describes as JsonObject;
      const pathSuggestsInput = resource.path.toLowerCase().split("/").some((part) => part.includes("input"));
      if (typeContains(describes["@type"], "input") || typeContains(describes.type, "input") || pathSuggestsInput) {
        candidates.push([describes, "$.describes"]);
      }
    }

    for (const [candidateValue, location] of candidates) {
      if (!isObject(candidateValue)) continue;
      const identifier = firstString(candidateValue, ["identifier", "id", "inputIdentifier", "name"]);
      if (!identifier) continue;
      const title = firstString(candidateValue, ["title", "label", "name"]);
      const description = firstString(candidateValue, ["description", "summary"]);
      const artifactReference = firstString(candidateValue, ["artifactReference", "resourcePath", "path", "file", "inputFile"]);
      const schemaReference = firstString(candidateValue, ["schemaReference", "schema", "inputSchema"]);
      let mediaType = firstString(candidateValue, ["mediaType", "contentType", "mimeType"]);
      let value: string | undefined;
      let contentDisposition: InterpretedInputObjectDeclaration["contentDisposition"] = "metadata-only";
      if (candidateValue.value !== undefined) {
        value = typeof candidateValue.value === "string" ? candidateValue.value : JSON.stringify(candidateValue.value, null, 2);
        mediaType ??= typeof candidateValue.value === "string" ? "text/plain" : "application/json";
        contentDisposition = "explicit-inline";
      }
      if (!value && artifactReference) {
        const referenced = this.resolveInputResource(resource.path, artifactReference, acquired.resources);
        if (referenced) {
          try {
            value = new TextDecoder("utf-8", { fatal: true }).decode(await referenced.readBytes());
            mediaType ??= this.inferMediaType(referenced.path);
            contentDisposition = "referenced-resource";
          } catch {
            limitations.push({ code: "publication_relationship_inconsistency", message: `Input object ${identifier} references a resource that could not be decoded as text.`, resourcePath: resource.path, location });
          }
        } else {
          limitations.push({ code: "publication_relationship_inconsistency", message: `Input object ${identifier} references a resource that was not found: ${artifactReference}.`, resourcePath: resource.path, location });
        }
      }
      results.push(Object.freeze({
        identifier,
        ...(title ? { title } : {}),
        ...(description ? { description } : {}),
        mediaType: mediaType ?? "application/octet-stream",
        ...(value !== undefined ? { value } : {}),
        ...(artifactReference ? { artifactReference } : {}),
        ...(schemaReference ? { schemaReference } : {}),
        contentDisposition,
        provenance: provenance(resource, location)
      }));
    }
  }

  private resolveInputResource(declarationPath: string, reference: string, resources: readonly AcquiredPublicationResource[]): AcquiredPublicationResource | undefined {
    const normalize = (value: string): string => {
      const parts: string[] = [];
      for (const part of value.replaceAll("\\", "/").split("/")) {
        if (!part || part === ".") continue;
        if (part === "..") parts.pop();
        else parts.push(part);
      }
      return parts.join("/");
    };
    const normalized = normalize(reference);
    const directory = declarationPath.includes("/") ? declarationPath.slice(0, declarationPath.lastIndexOf("/") + 1) : "";
    const candidates = [normalized, normalize(`${directory}${reference}`)];
    return resources.find((resource) => candidates.includes(normalize(resource.path)));
  }

  private inferMediaType(path: string): string {
    const lower = path.toLowerCase();
    if (lower.endsWith(".json")) return "application/json";
    if (lower.endsWith(".yaml") || lower.endsWith(".yml")) return "application/yaml";
    if (lower.endsWith(".csv")) return "text/csv";
    if (lower.endsWith(".xml")) return "application/xml";
    if (lower.endsWith(".txt")) return "text/plain";
    return "application/octet-stream";
  }

  private collectIdentity(document: JsonObject, resource: AcquiredPublicationResource, results: InterpretedPublicationIdentity[]): void {
    const candidates: Array<readonly [JsonObject, string]> = [];
    const describesPublication = isObject(document.describes) && (
      typeContains((document.describes as JsonObject)["@type"], "publication") ||
      typeContains((document.describes as JsonObject).type, "publication")
    );
    if (describesPublication) candidates.push([document.describes as JsonObject, "$.describes"]);

    const isExerciseDeclaration = (
      (isObject(document.canonicalExpectedOutcome) && isObject(document.comparisonSemantics)) ||
      (isObject(document.canonicalOrigin) && isObject(document.complementedRealization))
    );
    if (!describesPublication && !isExerciseDeclaration && !isSummaryInventoryOrEvidenceResource(resource.path)) {
      for (const key of identityContainers) {
        if (isObject(document[key])) candidates.push([document[key] as JsonObject, `$.${key}`]);
      }
    }
    if (!isExerciseDeclaration && !isSummaryInventoryOrEvidenceResource(resource.path) && firstString(document, ["publicationIdentifier", "knowledgeObjectIdentifier"])) candidates.push([document, "$"]);

    for (const [candidate, location] of candidates) {
      const identifier = firstString(candidate, ["identifier", "id", "publicationIdentifier", "knowledgeObjectIdentifier"]);
      if (!identifier) continue;
      const declaredVersion = firstString(candidate, ["version", "publicationVersion"]);
      const title = firstString(candidate, ["title", "name"]);
      results.push(Object.freeze({
        value: Object.freeze({ declaredIdentifier: identifier, ...(declaredVersion ? { declaredVersion } : {}), ...(title ? { title } : {}) }),
        provenance: provenance(resource, location)
      }));
      return;
    }
  }

  private collectRealizations(document: JsonObject, resource: AcquiredPublicationResource, results: InterpretedRealizationDeclaration[], limitations: InterpretationLimitation[]): void {
    const generic = document.realizations;
    if (Array.isArray(generic)) {
      const declarationCollection = generic.some((value) => isObject(value) && (
        value.realizationType !== undefined ||
        value.kind !== undefined ||
        normalizeRealizationType(value.type) !== undefined
      ));
      if (declarationCollection) {
        generic.forEach((value, index) => this.addRealization(value, undefined, resource, `$.realizations[${index}]`, results, limitations));
      }
    }
    for (const [key, type] of realizationCollections) {
      const collection = document[key];
      if (Array.isArray(collection)) {
        collection.forEach((value, index) => this.addRealization(value, type, resource, `$.${key}[${index}]`, results, limitations));
      }
    }
    const singularType = normalizeRealizationType(document.realizationType);
    if (singularType) this.addRealization(document, singularType, resource, "$", results, limitations);
  }

  private addRealization(value: unknown, suppliedType: ExecutableRealizationType | undefined, resource: AcquiredPublicationResource, location: string, results: InterpretedRealizationDeclaration[], limitations: InterpretationLimitation[]): void {
    if (!isObject(value)) {
      limitations.push({ code: "incomplete_realization_declaration", message: "A realization declaration is not an object.", resourcePath: resource.path, location });
      return;
    }
    const identifier = firstString(value, ["identifier", "id", "realizationIdentifier"]);
    const realizationType = suppliedType ?? normalizeRealizationType(value.realizationType ?? value.kind ?? value.type);
    if (!identifier || !realizationType) {
      const rawType = stringValue(value.realizationType ?? value.kind ?? value.type);
      limitations.push({
        code: rawType && !realizationType ? "unsupported_realization_type" : "incomplete_realization_declaration",
        message: rawType && !realizationType ? `Unsupported realization type: ${rawType}` : "A realization declaration lacks an identifier or supported type.",
        resourcePath: resource.path,
        location
      });
      return;
    }
    const title = firstString(value, ["title", "name", "label"]);
    const artifactReference = firstString(value, ["artifactReference", "artifact", "path", "resource"]);
    const invocationMechanism = firstString(value, ["invocationMechanism", "invocation", "executionContract"]);
    results.push(Object.freeze({ identifier, ...(title ? { title } : {}), realizationType, ...(artifactReference ? { artifactReference } : {}), ...(invocationMechanism ? { invocationMechanism } : {}), provenance: provenance(resource, location) }));
  }

  private collectRelationships(document: JsonObject, resource: AcquiredPublicationResource, results: InterpretedRelationshipDeclaration[], limitations: InterpretationLimitation[]): void {
    const collection = document.relationships ?? document.realizationRelationships;
    if (!Array.isArray(collection)) return;
    collection.forEach((value, index) => {
      const location = `$.${document.relationships === collection ? "relationships" : "realizationRelationships"}[${index}]`;
      if (!isObject(value)) {
        limitations.push({ code: "incomplete_relationship_declaration", message: "A relationship declaration is not an object.", resourcePath: resource.path, location });
        return;
      }
      const relationshipType = firstString(value, ["relationshipType", "type", "predicate", "relation"]);
      const sourceIdentifier = firstString(value, ["sourceIdentifier", "source", "from", "subject"]);
      const targetIdentifier = firstString(value, ["targetIdentifier", "target", "to", "object"]);
      if (!relationshipType || !sourceIdentifier || !targetIdentifier) {
        limitations.push({ code: "incomplete_relationship_declaration", message: "A relationship declaration lacks a type, source, or target.", resourcePath: resource.path, location });
        return;
      }
      results.push(Object.freeze({ relationshipType, sourceIdentifier, targetIdentifier, provenance: provenance(resource, location) }));
    });
  }

  private collectUkoInstanceMetadata(
    document: JsonObject,
    resource: AcquiredPublicationResource,
    realizations: InterpretedRealizationDeclaration[],
    relationships: InterpretedRelationshipDeclaration[],
    limitations: InterpretationLimitation[]
  ): void {
    const describes = document.describes;
    if (!isObject(describes)) return;

    const identifier = firstString(describes, ["identifier", "id"]);
    const realizationType = realizationTypeFromLayerIdentifier(describes.parentLayerIdentifier);
    if (!realizationType) return; // Non-executable layers, including CKS, remain outside the Matrix.

    if (!identifier) {
      limitations.push({
        code: "incomplete_realization_declaration",
        message: "Authoritative UKO Instance Metadata identifies an executable realization layer but lacks an Instance identifier.",
        resourcePath: resource.path,
        location: "$.describes"
      });
      return;
    }

    const title = firstString(describes, ["title"]);
    const artifactReference = firstString(describes, ["repositoryPath"]);
    realizations.push(Object.freeze({
      identifier,
      ...(title ? { title } : {}),
      realizationType,
      ...(artifactReference ? { artifactReference } : {}),
      provenance: provenance(resource, "$.describes")
    }));

    const instanceArchitecture = describes.instanceArchitecture;
    if (!isObject(instanceArchitecture)) return;
    const adjacent = instanceArchitecture.adjacentLayerRelationships;
    if (!isObject(adjacent)) return;

    const collectAdjacent = (side: "precedingLayer" | "followingLayer"): void => {
      const declaration = adjacent[side];
      if (!isObject(declaration)) return;
      const referenced = declaration.explicitlyReferencedInstances;
      if (!Array.isArray(referenced)) return;
      referenced.forEach((entry, index) => {
        if (!isObject(entry)) {
          limitations.push({
            code: "incomplete_relationship_declaration",
            message: "An explicitly referenced adjacent-layer Instance is not an object.",
            resourcePath: resource.path,
            location: `$.describes.instanceArchitecture.adjacentLayerRelationships.${side}.explicitlyReferencedInstances[${index}]`
          });
          return;
        }
        const adjacentIdentifier = firstString(entry, ["identifier", "id"]);
        if (!adjacentIdentifier) {
          limitations.push({
            code: "incomplete_relationship_declaration",
            message: "An explicitly referenced adjacent-layer Instance lacks an identifier.",
            resourcePath: resource.path,
            location: `$.describes.instanceArchitecture.adjacentLayerRelationships.${side}.explicitlyReferencedInstances[${index}]`
          });
          return;
        }
        const declaredRelationship = firstString(entry, ["relationship"]) ?? firstString(declaration, ["relationship"]) ?? (side === "precedingLayer" ? "built-up-into" : "builds-up-into");
        const sourceIdentifier = side === "precedingLayer" ? adjacentIdentifier : identifier;
        const targetIdentifier = side === "precedingLayer" ? identifier : adjacentIdentifier;
        relationships.push(Object.freeze({
          relationshipType: declaredRelationship,
          sourceIdentifier,
          targetIdentifier,
          provenance: provenance(resource, `$.describes.instanceArchitecture.adjacentLayerRelationships.${side}.explicitlyReferencedInstances[${index}]`)
        }));
      });
    };

    collectAdjacent("precedingLayer");
    collectAdjacent("followingLayer");
  }

  private collectComplementaryRealizationRelationships(
    document: JsonObject,
    resource: AcquiredPublicationResource,
    realizations: readonly InterpretedRealizationDeclaration[],
    relationships: InterpretedRelationshipDeclaration[],
    limitations: InterpretationLimitation[]
  ): void {
    const owner = this.realizationOwningResource(resource.path, realizations);
    if (!owner) return;

    const addResolved = (
      reference: unknown,
      expectedType: ExecutableRealizationType,
      sourceIsReference: boolean,
      relationshipType: string,
      location: string
    ): void => {
      const referenced = this.resolveRealizationReference(reference, expectedType, realizations);
      if (!referenced) {
        limitations.push({
          code: "publication_relationship_inconsistency",
          message: `An explicit ${expectedType} relationship reference could not be resolved to any declared realization: ${this.describeRelationshipReference(reference)}.`,
          resourcePath: resource.path,
          location
        });
        return;
      }
      relationships.push(Object.freeze({
        relationshipType,
        sourceIdentifier: sourceIsReference ? referenced.identifier : owner.identifier,
        targetIdentifier: sourceIsReference ? owner.identifier : referenced.identifier,
        provenance: provenance(resource, location)
      }));
    };

    if (owner.realizationType === "deployment-package" && Array.isArray(document.targetsServiceRealizations)) {
      document.targetsServiceRealizations.forEach((reference, index) =>
        addResolved(reference, "service-realization", true, "is-packaged-by", `$.targetsServiceRealizations[${index}]`)
      );
    }

    if (owner.realizationType === "service-realization") {
      const collections: Array<readonly [unknown, string]> = [
        [document.bindsToImplementationRepresentations, "$.bindsToImplementationRepresentations"],
        [document.carriesImplementationRepresentations, "$.carriesImplementationRepresentations"]
      ];
      for (const [collection, baseLocation] of collections) {
        if (!Array.isArray(collection)) continue;
        collection.forEach((reference, index) =>
          addResolved(reference, "implementation-representation", true, "is-served-by", `${baseLocation}[${index}]`)
        );
      }
      if (document.implementation_representation !== undefined) {
        addResolved(document.implementation_representation, "implementation-representation", true, "is-served-by", "$.implementation_representation");
      }
    }
  }

  private describeRelationshipReference(reference: unknown): string {
    if (typeof reference === "string") return reference;
    if (isObject(reference)) {
      return firstString(reference, ["identifier", "id", "localIdentifier", "repositoryPath", "implementationRepresentationIdentifier", "serviceRealizationIdentifier"]) ?? "unidentified explicit reference";
    }
    return "unidentified explicit reference";
  }

  private realizationOwningResource(
    resourcePath: string,
    realizations: readonly InterpretedRealizationDeclaration[]
  ): InterpretedRealizationDeclaration | undefined {
    const normalizedResource = resourcePath.replaceAll("\\", "/");
    return realizations
      .filter((realization) => {
        const artifact = realization.artifactReference?.replaceAll("\\", "/");
        return artifact !== undefined && (normalizedResource === artifact || normalizedResource.startsWith(`${artifact}/`) || normalizedResource.includes(`/${artifact}/`) || normalizedResource.endsWith(`/${artifact}`));
      })
      .sort((a, b) => (b.artifactReference?.length ?? 0) - (a.artifactReference?.length ?? 0))[0];
  }

  private resolveRealizationReference(
    reference: unknown,
    expectedType: ExecutableRealizationType,
    realizations: readonly InterpretedRealizationDeclaration[]
  ): InterpretedRealizationDeclaration | undefined {
    const candidates: string[] = [];
    if (typeof reference === "string") candidates.push(reference);
    if (isObject(reference)) {
      for (const key of ["identifier", "id", "localIdentifier", "repositoryPath", "implementationRepresentationIdentifier", "serviceRealizationIdentifier"]) {
        const value = stringValue(reference[key]);
        if (value) candidates.push(value);
      }
    }
    const normalized = candidates.map((value) => value.replaceAll("\\", "/").replace(/\/$/, ""));
    return realizations.find((realization) => {
      if (realization.realizationType !== expectedType) return false;
      const artifact = realization.artifactReference?.replaceAll("\\", "/").replace(/\/$/, "");
      const artifactBase = artifact?.split("/").at(-1);
      return normalized.some((candidate) =>
        candidate === realization.identifier ||
        (artifact !== undefined && (candidate === artifact || candidate.endsWith(`/${artifact}`))) ||
        (artifactBase !== undefined && (candidate === artifactBase || candidate.endsWith(`/${artifactBase}`)))
      );
    });
  }

  private resolveIdentity(candidates: readonly InterpretedPublicationIdentity[], limitations: InterpretationLimitation[]): InterpretedPublicationIdentity | undefined {
    if (candidates.length === 0) return undefined;
    const authorityRank = (candidate: InterpretedPublicationIdentity): number =>
      candidate.provenance.location === "$.describes" ? 3 :
      candidate.provenance.location === "$.publication" || candidate.provenance.location === "$.knowledgeObject" || candidate.provenance.location === "$.uko" ? 2 : 1;
    const ranked = [...candidates].sort((a, b) => authorityRank(b) - authorityRank(a) || a.provenance.resourcePath.localeCompare(b.provenance.resourcePath));
    const selected = ranked[0]!;
    const selectedRank = authorityRank(selected);
    const conflicts = ranked.slice(1).filter((candidate) =>
      authorityRank(candidate) === selectedRank && (
        candidate.value.declaredIdentifier !== selected.value.declaredIdentifier ||
        candidate.value.declaredVersion !== selected.value.declaredVersion
      )
    );
    if (conflicts.length > 0) {
      limitations.push({ code: "conflicting_publication_identity", message: "Equally authoritative publication declarations contain conflicting identities. The first deterministic declaration is retained as PC3 Interpretation." });
    }
    return selected;
  }

  private deduplicateInputs(values: readonly InterpretedInputObjectDeclaration[], limitations: InterpretationLimitation[]): InterpretedInputObjectDeclaration[] {
    const seen = new Map<string, InterpretedInputObjectDeclaration>();
    for (const value of values) {
      if (seen.has(value.identifier)) {
        limitations.push({ code: "duplicate_declaration", message: `Duplicate explicit input declaration ignored: ${value.identifier}`, resourcePath: value.provenance.resourcePath, location: value.provenance.location });
        continue;
      }
      seen.set(value.identifier, value);
    }
    return [...seen.values()];
  }

  private deduplicate<T extends InterpretedRealizationDeclaration | InterpretedRelationshipDeclaration>(values: readonly T[], limitations: InterpretationLimitation[]): T[] {
    const seen = new Map<string, T>();
    const relationshipByEndpoints = new Map<string, InterpretedRelationshipDeclaration>();
    for (const value of values) {
      const key = stableKey(value);
      if (seen.has(key)) {
        // Repeated statements of the same relationship are corroborating
        // provenance, not an interpretation limitation.
        if ("realizationType" in value) {
          limitations.push({ code: "duplicate_declaration", message: `Duplicate explicit declaration ignored: ${key}`, resourcePath: value.provenance.resourcePath, location: value.provenance.location });
        }
        continue;
      }
      if (!("realizationType" in value)) {
        const endpointKey = `${value.sourceIdentifier}->${value.targetIdentifier}`;
        const prior = relationshipByEndpoints.get(endpointKey);
        if (prior && semanticRelationshipType(prior.relationshipType) !== semanticRelationshipType(value.relationshipType)) {
          limitations.push({
            code: "publication_relationship_inconsistency",
            message: `Conflicting relationship declarations for ${endpointKey}: ${prior.relationshipType} and ${value.relationshipType}.`,
            resourcePath: value.provenance.resourcePath,
            location: value.provenance.location
          });
        } else if (!prior) relationshipByEndpoints.set(endpointKey, value);
      }
      seen.set(key, value);
    }
    return [...seen.values()];
  }
}
