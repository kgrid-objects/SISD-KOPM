import type { IsoInstant } from "../domain/time.js";
import type { PublicationLoadId } from "../domain/identifiers.js";

/** Publication Truth is represented only as sourced, read-only information. */
export interface PublicationIdentity {
  readonly declaredIdentifier: string;
  readonly declaredVersion?: string;
}

export interface PublicationSourceReference {
  readonly kind: "local-directory" | "uploaded-archive" | "repository" | "publication-service";
  readonly locator: string;
}

export interface LoadedPublicationResource {
  readonly path: string;
  readonly byteLength: number;
  readonly sha256: string;
}

export interface PublicationLoadRecord {
  readonly id: PublicationLoadId;
  readonly source: PublicationSourceReference;
  readonly loadedAt: IsoInstant;
  readonly publicationIdentity?: PublicationIdentity;
  readonly resourceCount: number;
  readonly resources: readonly LoadedPublicationResource[];
}

export type PublicationLoadFailureCode =
  | "unsupported_source"
  | "source_not_found"
  | "source_not_readable"
  | "invalid_archive"
  | "unsafe_resource_path"
  | "duplicate_resource_path"
  | "resource_limit_exceeded"
  | "acquisition_failed";

export interface PublicationLoadFailure {
  readonly code: PublicationLoadFailureCode;
  readonly message: string;
  readonly source: PublicationSourceReference;
}

export type PublicationLoadOutcome =
  | { readonly status: "loaded"; readonly publication: PublicationLoadRecord }
  | { readonly status: "failed"; readonly failure: PublicationLoadFailure };
