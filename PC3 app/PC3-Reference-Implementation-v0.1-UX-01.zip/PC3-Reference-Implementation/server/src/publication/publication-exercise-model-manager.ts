import type { InterpretedRealizationDeclaration } from "./interpretation-model.js";
import type {
  ExerciseReadiness,
  ExerciseResolutionOutcome,
  PublicationTestCase,
  PublicationTestCaseApplicability,
  RealizationTestCaseManifestation,
  ResolvedExercise
} from "./publication-exercise-model.js";

export interface PublicationExerciseModel {
  readonly publicationTestCases: readonly PublicationTestCase[];
  readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestation[];
  readonly applicabilityDeclarations: readonly PublicationTestCaseApplicability[];
}

/**
 * Derives readiness and resolved exercises from publication declarations.
 * It performs no discovery, execution, conformance assessment, or publication modification.
 */
export class PublicationExerciseModelManager {
  summarizeReadiness(
    model: PublicationExerciseModel,
    realizations: readonly InterpretedRealizationDeclaration[]
  ): readonly ExerciseReadiness[] {
    return Object.freeze(realizations.map((realization) => {
      const applicablePtcIds = model.applicabilityDeclarations
        .filter((pairing) => pairing.realizationIdentifier === realization.identifier && pairing.status === "applicable")
        .map((pairing) => pairing.ptcIdentifier);
      const applicableSet = new Set(applicablePtcIds);
      const authoritativeRtcmPtcIds = new Set(
        model.realizationTestCaseManifestations
          .filter((rtcm) => rtcm.realizationIdentifier === realization.identifier && rtcm.applicability.status === "applicable" && rtcm.status === "authoritative" && applicableSet.has(rtcm.ptcIdentifier))
          .map((rtcm) => rtcm.ptcIdentifier)
      );
      const missing = [...applicableSet].filter((identifier) => !authoritativeRtcmPtcIds.has(identifier)).sort();
      const applicableCount = applicableSet.size;
      const authoritativeCount = authoritativeRtcmPtcIds.size;
      const status: ExerciseReadiness["status"] = applicableCount === 0
        ? "not-applicable"
        : authoritativeCount === 0
          ? "none"
          : missing.length === 0
            ? "complete"
            : "partial";
      return Object.freeze({
        realizationIdentifier: realization.identifier,
        applicablePtcCount: applicableCount,
        authoritativeRtcmCount: authoritativeCount,
        missingRtcmPtcIdentifiers: Object.freeze(missing),
        status,
        statement: readinessStatement(status, authoritativeCount, applicableCount)
      });
    }));
  }

  resolve(
    model: PublicationExerciseModel,
    realizations: readonly InterpretedRealizationDeclaration[],
    ptcIdentifier: string,
    realizationIdentifier: string
  ): ExerciseResolutionOutcome {
    const ptc = model.publicationTestCases.find((candidate) => candidate.identifier === ptcIdentifier);
    if (!ptc) return Object.freeze({ status: "ptc-not-found", ptcIdentifier });
    const realization = realizations.find((candidate) => candidate.identifier === realizationIdentifier);
    if (!realization) return Object.freeze({ status: "realization-not-found", realizationIdentifier });

    const declaredApplicability = model.applicabilityDeclarations.find(
      (candidate) => candidate.ptcIdentifier === ptcIdentifier && candidate.realizationIdentifier === realizationIdentifier
    );
    if (declaredApplicability?.status === "not-applicable") {
      return Object.freeze({ status: "not-applicable", ptcIdentifier, realizationIdentifier });
    }
    const matching = model.realizationTestCaseManifestations.filter(
      (candidate) => candidate.ptcIdentifier === ptcIdentifier && candidate.realizationIdentifier === realizationIdentifier
    );
    if (matching.some((candidate) => candidate.applicability.status === "not-applicable")) {
      return Object.freeze({ status: "not-applicable", ptcIdentifier, realizationIdentifier });
    }
    const applicable = matching.filter((candidate) => candidate.applicability.status === "applicable" && candidate.status === "authoritative");
    if (applicable.length === 0) return Object.freeze({ status: "rtcm-not-found", ptcIdentifier, realizationIdentifier });
    if (applicable.length > 1) {
      return Object.freeze({
        status: "ambiguous-rtcm",
        ptcIdentifier,
        realizationIdentifier,
        rtcmIdentifiers: Object.freeze(applicable.map((candidate) => candidate.identifier).sort())
      });
    }

    const rtcm = applicable[0]!;
    const exercise: ResolvedExercise = Object.freeze({
      ptc,
      realization: Object.freeze({
        identifier: realization.identifier,
        realizationType: realization.realizationType,
        ...(realization.artifactReference ? { artifactReference: realization.artifactReference } : {}),
        ...(realization.invocationMechanism ? { invocationMechanism: realization.invocationMechanism } : {})
      }),
      rtcm,
      canonicalInput: ptc.canonicalInput,
      canonicalExpectedOutcome: ptc.canonicalExpectedOutcome,
      comparisonSemantics: ptc.comparisonSemantics,
      readiness: "publication-exercise-ready",
      executionBoundary: "external-to-publication",
      statement: "PC3 resolved one authoritative RTCM for the selected Publication Test Case and realization. This readiness declaration does not assert runtime availability, execution success, or conformance."
    });
    return Object.freeze({ status: "resolved", exercise });
  }
}

function readinessStatement(status: ExerciseReadiness["status"], covered: number, applicable: number): string {
  switch (status) {
    case "complete": return `Publication exercise readiness is complete for ${covered} of ${applicable} applicable Publication Test Cases.`;
    case "partial": return `Publication exercise readiness is partial: ${covered} authoritative RTCMs cover ${applicable} applicable Publication Test Cases.`;
    case "none": return `No authoritative RTCM covers the ${applicable} applicable Publication Test Cases.`;
    case "not-applicable": return "No applicable Publication Test Case has been declared for this realization.";
  }
}
