import type { Clock, IdentifierGenerator } from "../domain/time.js";
import { publicationLoadId } from "../domain/identifiers.js";
import type { PublicationLoadFailureCode, PublicationLoadOutcome, PublicationSourceReference } from "./model.js";
import type { AcquiredPublication, PublicationSourceAdapter } from "./source-adapter.js";
import type { PublicationLoadRecord } from "./model.js";

export class PublicationAcquisitionError extends Error {
  constructor(
    readonly code: PublicationLoadFailureCode,
    message: string
  ) {
    super(message);
    this.name = "PublicationAcquisitionError";
  }
}

export interface PublicationLoaderDependencies {
  readonly adapters: readonly PublicationSourceAdapter[];
  readonly clock: Clock;
  readonly identifiers: IdentifierGenerator;
}

export interface LoadedPublicationForInterpretation {
  readonly record: PublicationLoadRecord;
  readonly acquired: AcquiredPublication;
}

export class PublicationLoader {
  constructor(private readonly dependencies: PublicationLoaderDependencies) {}

  async load(source: PublicationSourceReference): Promise<PublicationLoadOutcome> {
    const detailed = await this.loadForInterpretation(source);
    if ("failure" in detailed) return { status: "failed", failure: detailed.failure };
    return { status: "loaded", publication: detailed.loaded.record };
  }

  async loadForInterpretation(source: PublicationSourceReference): Promise<
    { readonly loaded: LoadedPublicationForInterpretation } |
    { readonly failure: Extract<PublicationLoadOutcome, { readonly status: "failed" }>["failure"] }
  > {
    const adapter = this.dependencies.adapters.find((candidate) => candidate.supports(source));
    if (!adapter) return { failure: this.failure("unsupported_source", "No read-only publication source adapter supports this source.", source).failure };

    try {
      const acquired = await adapter.acquire(source);
      const resources = acquired.resources.map(({ path, byteLength, sha256 }) => ({ path, byteLength, sha256 }));
      const record: PublicationLoadRecord = Object.freeze({
        id: publicationLoadId(this.dependencies.identifiers.next()),
        source: acquired.source,
        loadedAt: this.dependencies.clock.now(),
        resourceCount: resources.length,
        resources: Object.freeze(resources)
      });
      return { loaded: Object.freeze({ record, acquired }) };
    } catch (error) {
      const outcome = error instanceof PublicationAcquisitionError
        ? this.failure(error.code, error.message, source)
        : this.failure("acquisition_failed", error instanceof Error ? error.message : "Publication acquisition failed.", source);
      return { failure: outcome.failure };
    }
  }

  private failure(code: PublicationLoadFailureCode, message: string, source: PublicationSourceReference): Extract<PublicationLoadOutcome, { readonly status: "failed" }> {
    return { status: "failed", failure: { code, message, source } };
  }
}
