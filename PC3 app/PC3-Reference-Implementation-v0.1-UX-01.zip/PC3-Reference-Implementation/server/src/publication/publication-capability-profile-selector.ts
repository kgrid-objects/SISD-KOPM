import type { PublicationDeclarationProvenance } from "./interpretation-model.js";
import type { PublicationValidationReport } from "./publication-integrity-validator.js";

export type PublicationCapabilityProfileKind = "ptc" | "legacy-input" | "ambiguous-mixed" | "none";
export type ExerciseAuthority = "publication-test-cases" | "standalone-input-objects" | "unresolved" | "none";

export interface PublicationCapabilityProfile {
  readonly kind: PublicationCapabilityProfileKind;
  readonly exerciseAuthority: ExerciseAuthority;
  readonly ptcCapability: "authoritative" | "incomplete-or-invalid" | "absent";
  readonly standaloneInputCapability: "primary" | "subordinate" | "preserved" | "absent";
  readonly ptcCount: number;
  readonly standaloneInputObjectCount: number;
  readonly rationale: string;
  readonly limitations: readonly string[];
  readonly basis: readonly PublicationDeclarationProvenance[];
}

export interface PublicationCapabilityProfileSelectionInput {
  readonly ptcCount: number;
  readonly standaloneInputObjectCount: number;
  readonly hasExplicitPtcDeclarationSignals: boolean;
  readonly validation: PublicationValidationReport;
  readonly ptcProvenance: readonly PublicationDeclarationProvenance[];
  readonly inputProvenance: readonly PublicationDeclarationProvenance[];
}

function uniqueProvenance(values: readonly PublicationDeclarationProvenance[]): readonly PublicationDeclarationProvenance[] {
  const seen = new Set<string>();
  return Object.freeze(values.filter((value) => {
    const key = `${value.resourceSha256}:${value.location}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }));
}

/** Selects behavior only from explicit interpreted publication capabilities. */
export class PublicationCapabilityProfileSelector {
  select(input: PublicationCapabilityProfileSelectionInput): PublicationCapabilityProfile {
    const hasPtcs = input.ptcCount > 0;
    const hasInputs = input.standaloneInputObjectCount > 0;
    const invalidPtcArchitecture = hasPtcs && input.validation.status === "invalid";
    const incompletePtcArchitecture = input.hasExplicitPtcDeclarationSignals && !hasPtcs;

    if (invalidPtcArchitecture || incompletePtcArchitecture) {
      const reason = invalidPtcArchitecture
        ? "Explicit PTC declarations were discovered, but publication integrity validation did not establish a safe authoritative PTC exercise architecture."
        : "Explicit PTC declaration signals were discovered, but no complete authoritative Publication Test Case could be interpreted.";
      return Object.freeze({
        kind: "ambiguous-mixed",
        exerciseAuthority: "unresolved",
        ptcCapability: "incomplete-or-invalid",
        standaloneInputCapability: hasInputs ? "preserved" : "absent",
        ptcCount: input.ptcCount,
        standaloneInputObjectCount: input.standaloneInputObjectCount,
        rationale: `${reason} PC3 preserves every interpreted source and does not guess an exercise authority.`,
        limitations: Object.freeze(["Automatic PTC-bound exercise behavior is unavailable until publication authority is complete and internally consistent."]),
        basis: uniqueProvenance([...input.ptcProvenance, ...input.inputProvenance])
      });
    }

    if (hasPtcs) {
      return Object.freeze({
        kind: "ptc",
        exerciseAuthority: "publication-test-cases",
        ptcCapability: "authoritative",
        standaloneInputCapability: hasInputs ? "subordinate" : "absent",
        ptcCount: input.ptcCount,
        standaloneInputObjectCount: input.standaloneInputObjectCount,
        rationale: hasInputs
          ? "Authoritative PTC declarations govern exercise behavior; standalone Input Objects remain preserved as subordinate publication context."
          : "Authoritative PTC declarations govern exercise behavior.",
        limitations: Object.freeze([]),
        basis: uniqueProvenance([...input.ptcProvenance, ...input.inputProvenance])
      });
    }

    if (hasInputs) {
      return Object.freeze({
        kind: "legacy-input",
        exerciseAuthority: "standalone-input-objects",
        ptcCapability: "absent",
        standaloneInputCapability: "primary",
        ptcCount: 0,
        standaloneInputObjectCount: input.standaloneInputObjectCount,
        rationale: "No explicit PTC architecture was declared; supported standalone Input Objects retain legacy exercise behavior.",
        limitations: Object.freeze([]),
        basis: uniqueProvenance(input.inputProvenance)
      });
    }

    return Object.freeze({
      kind: "none",
      exerciseAuthority: "none",
      ptcCapability: "absent",
      standaloneInputCapability: "absent",
      ptcCount: 0,
      standaloneInputObjectCount: 0,
      rationale: "No supported explicit PTC architecture or standalone Input Object capability was declared.",
      limitations: Object.freeze([]),
      basis: Object.freeze([])
    });
  }
}
