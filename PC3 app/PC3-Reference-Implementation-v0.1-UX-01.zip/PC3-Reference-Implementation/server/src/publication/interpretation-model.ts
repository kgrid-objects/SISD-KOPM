import type { IsoInstant } from "../domain/time.js";
import type { PublicationInterpretationId, PublicationLoadId } from "../domain/identifiers.js";
import type { PublicationIdentity } from "./model.js";
import type { ExerciseReadiness, PublicationTestCase, PublicationTestCaseApplicability, RealizationTestCaseManifestation, ResolvedExercise } from "./publication-exercise-model.js";
import type { PublicationExerciseDiscoveryIndex } from "./publication-exercise-discovery.js";
import type { PublicationValidationReport } from "./publication-integrity-validator.js";
import type { PublicationCapabilityProfile } from "./publication-capability-profile-selector.js";

export type InterpretationBasis = "explicit-declaration" | "provisional-structure-inference";

export interface PublicationDeclarationProvenance {
  readonly resourcePath: string;
  readonly resourceSha256: string;
  readonly location: string;
  readonly basis: InterpretationBasis;
}

export interface InterpretedPublicationIdentity {
  readonly value: PublicationIdentity & { readonly title?: string };
  readonly provenance: PublicationDeclarationProvenance;
}

export type ExecutableRealizationType =
  | "implementation-representation"
  | "service-realization"
  | "deployment-package";

export interface InterpretedRealizationDeclaration {
  readonly identifier: string;
  readonly title?: string;
  readonly realizationType: ExecutableRealizationType;
  readonly artifactReference?: string;
  readonly invocationMechanism?: string;
  readonly provenance: PublicationDeclarationProvenance;
}

export interface InterpretedInputObjectDeclaration {
  readonly identifier: string;
  readonly title?: string;
  readonly description?: string;
  readonly mediaType: string;
  readonly value?: string;
  readonly artifactReference?: string;
  readonly schemaReference?: string;
  readonly contentDisposition: "explicit-inline" | "referenced-resource" | "metadata-only";
  readonly provenance: PublicationDeclarationProvenance;
}

export interface InterpretedRelationshipDeclaration {
  readonly relationshipType: string;
  readonly sourceIdentifier: string;
  readonly targetIdentifier: string;
  readonly provenance: PublicationDeclarationProvenance;
}

export type InterpretationLimitationCode =
  | "no_supported_declarations"
  | "malformed_declaration_document"
  | "conflicting_publication_identity"
  | "incomplete_realization_declaration"
  | "incomplete_relationship_declaration"
  | "unsupported_realization_type"
  | "duplicate_declaration"
  | "publication_relationship_inconsistency";

export interface InterpretationLimitation {
  readonly code: InterpretationLimitationCode;
  readonly message: string;
  readonly resourcePath?: string;
  readonly location?: string;
}

/** PC3 Interpretation is derived, provenance-bearing, and subordinate to Publication Truth. */
export interface PublicationInterpretation {
  readonly id: PublicationInterpretationId;
  readonly publicationLoadId: PublicationLoadId;
  readonly interpretedAt: IsoInstant;
  readonly publicationIdentity?: InterpretedPublicationIdentity;
  readonly realizations: readonly InterpretedRealizationDeclaration[];
  readonly inputObjects: readonly InterpretedInputObjectDeclaration[];
  readonly publicationTestCases: readonly PublicationTestCase[];
  readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestation[];
  readonly publicationTestCaseApplicability: readonly PublicationTestCaseApplicability[];
  readonly exerciseReadiness: readonly ExerciseReadiness[];
  readonly exerciseDiscoveryIndex: PublicationExerciseDiscoveryIndex;
  readonly publicationValidation: PublicationValidationReport;
  readonly capabilityProfile: PublicationCapabilityProfile;
  readonly resolvedExercises: readonly ResolvedExercise[];
  readonly relationships: readonly InterpretedRelationshipDeclaration[];
  readonly limitations: readonly InterpretationLimitation[];
  readonly interpretedResourcePaths: readonly string[];
}
