import type { AcquiredPublicationResource } from "./source-adapter.js";
import type { InterpretedRealizationDeclaration, InterpretationLimitation, PublicationDeclarationProvenance } from "./interpretation-model.js";
import type {
  CanonicalComparisonSemantics,
  CanonicalExpectedOutcome,
  CanonicalInputObject,
  CanonicalNegativeInputCondition,
  CanonicalSemanticRejection,
  PairingApplicabilityStatus,
  PublicationTestCase,
  PublicationTestCaseApplicability,
  RealizationInputBinding,
  RealizationTestCaseManifestation
} from "./publication-exercise-model.js";

export type ParsedPublicationDocument = {
  readonly document: Record<string, unknown>;
  readonly resource: AcquiredPublicationResource;
};

export interface PublicationExerciseDiscoveryIndex {
  readonly ptcIdentifiers: readonly string[];
  readonly rtcmIdentifiers: readonly string[];
  readonly ptcToRealizationIdentifiers: Readonly<Record<string, readonly string[]>>;
  readonly realizationToPtcIdentifiers: Readonly<Record<string, readonly string[]>>;
  readonly pairingToRtcmIdentifier: Readonly<Record<string, string>>;
}

export interface PublicationExerciseDiscoveryResult {
  readonly publicationTestCases: readonly PublicationTestCase[];
  readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestation[];
  readonly applicabilityDeclarations: readonly PublicationTestCaseApplicability[];
  readonly index: PublicationExerciseDiscoveryIndex;
  readonly interpretedResourcePaths: readonly string[];
  /** Uncollapsed declaration candidates retained solely for integrity validation. */
  readonly validationSource: {
    readonly publicationTestCases: readonly PublicationTestCase[];
    readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestation[];
    readonly applicabilityDeclarations: readonly PublicationTestCaseApplicability[];
  };
}

type JsonObject = Record<string, unknown>;

function isObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function asNumber(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}
function asBoolean(value: unknown): boolean | undefined {
  return typeof value === "boolean" ? value : undefined;
}
function stringArray(value: unknown): readonly string[] {
  return Object.freeze(Array.isArray(value) ? value.map(asString).filter((item): item is string => Boolean(item)) : []);
}
function objectArray(value: unknown): readonly JsonObject[] {
  return Array.isArray(value) ? value.filter(isObject) : [];
}
function provenance(resource: AcquiredPublicationResource, location = "$"): PublicationDeclarationProvenance {
  return Object.freeze({ resourcePath: resource.path, resourceSha256: resource.sha256, location, basis: "explicit-declaration" });
}
function layerType(value: unknown): InterpretedRealizationDeclaration["realizationType"] | undefined {
  switch (asString(value)?.toUpperCase()) {
    case "IR": case "UKO-LAYER-IR": return "implementation-representation";
    case "SR": case "UKO-LAYER-SR": return "service-realization";
    case "DP": case "UKO-LAYER-DP": return "deployment-package";
    default: return undefined;
  }
}
function applicabilityStatus(value: unknown): PairingApplicabilityStatus {
  const normalized = asString(value)?.toLowerCase().replaceAll("_", "-");
  if (normalized === "applicable") return "applicable";
  if (normalized === "not-applicable" || normalized === "non-applicable") return "not-applicable";
  return "undetermined";
}
function freezeRecord<T>(entries: Iterable<readonly [string, T]>): Readonly<Record<string, T>> {
  return Object.freeze(Object.fromEntries(entries));
}
function sortedUnique(values: Iterable<string>): readonly string[] {
  return Object.freeze([...new Set(values)].sort());
}

export class PublicationExerciseDiscovery {
  discover(
    documents: readonly ParsedPublicationDocument[],
    realizations: readonly InterpretedRealizationDeclaration[],
    limitations: InterpretationLimitation[]
  ): PublicationExerciseDiscoveryResult {
    const ptcs: PublicationTestCase[] = [];
    const rtcms: RealizationTestCaseManifestation[] = [];
    const declaredApplicability: PublicationTestCaseApplicability[] = [];
    const rtcmApplicability: PublicationTestCaseApplicability[] = [];
    const interpretedPaths = new Set<string>();

    for (const { document, resource } of documents) {
      const ptc = this.parsePtc(document, resource);
      if (ptc) {
        ptcs.push(ptc);
        interpretedPaths.add(resource.path);
        this.collectPtcApplicability(document, resource, ptc.identifier, declaredApplicability);
      }
      const rtcm = this.parseRtcm(document, resource, limitations);
      if (rtcm) {
        rtcms.push(rtcm);
        interpretedPaths.add(resource.path);
        rtcmApplicability.push(Object.freeze({
          ptcIdentifier: rtcm.ptcIdentifier,
          realizationIdentifier: rtcm.realizationIdentifier,
          status: rtcm.applicability.status,
          ...(rtcm.applicability.pairingKey ? { basisReference: rtcm.applicability.pairingKey } : {}),
          provenance: rtcm.provenance
        }));
      }
    }

    const uniquePtcs = this.uniqueByIdentifier(ptcs, "Publication Test Case", limitations);
    const uniqueRtcMs = this.uniqueByIdentifier(rtcms, "RTCM", limitations);
    const knownPtc = new Set(uniquePtcs.map((item) => item.identifier));
    const knownRealization = new Set(realizations.map((item) => item.identifier));

    for (const rtcm of uniqueRtcMs) {
      if (!knownPtc.has(rtcm.ptcIdentifier)) limitations.push({
        code: "publication_relationship_inconsistency",
        message: `RTCM ${rtcm.identifier} references undeclared Publication Test Case ${rtcm.ptcIdentifier}.`,
        resourcePath: rtcm.provenance.resourcePath,
        location: rtcm.provenance.location
      });
      if (!knownRealization.has(rtcm.realizationIdentifier)) limitations.push({
        code: "publication_relationship_inconsistency",
        message: `RTCM ${rtcm.identifier} references realization ${rtcm.realizationIdentifier}, which was not discovered as an executable realization.`,
        resourcePath: rtcm.provenance.resourcePath,
        location: rtcm.provenance.location
      });
    }

    const uniqueApplicability = this.uniqueApplicability([...declaredApplicability, ...rtcmApplicability], limitations);
    const index = this.buildIndex(uniquePtcs, uniqueRtcMs, uniqueApplicability);
    return Object.freeze({
      publicationTestCases: Object.freeze(uniquePtcs),
      realizationTestCaseManifestations: Object.freeze(uniqueRtcMs),
      applicabilityDeclarations: Object.freeze(uniqueApplicability),
      index,
      interpretedResourcePaths: Object.freeze([...interpretedPaths].sort()),
      validationSource: Object.freeze({
        publicationTestCases: Object.freeze([...ptcs]),
        realizationTestCaseManifestations: Object.freeze([...rtcms]),
        applicabilityDeclarations: Object.freeze([...declaredApplicability])
      })
    });
  }

  private parsePtc(document: JsonObject, resource: AcquiredPublicationResource): PublicationTestCase | undefined {
    const canonicalInputDeclaration = isObject(document.canonicalInputObject) ? document.canonicalInputObject : isObject(document.canonicalInputCondition) ? document.canonicalInputCondition : undefined;
    if (!canonicalInputDeclaration || !isObject(document.canonicalExpectedOutcome) || !isObject(document.comparisonSemantics)) return undefined;
    const identifier = asString(document.identifier);
    if (!identifier) return undefined;
    const input = canonicalInputDeclaration;
    const expected = document.canonicalExpectedOutcome;
    const comparison = document.comparisonSemantics;
    const applicability = isObject(document.applicability) ? document.applicability : {};
    const semanticResult = isObject(expected.semanticResult) ? expected.semanticResult : undefined;
    const errorSemantics = isObject(expected.errorSemantics) ? expected.errorSemantics : undefined;
    const isNegativeCondition = isObject(document.canonicalInputCondition);

    const canonicalInput = Object.freeze({
      ...(asString(input.mediaType) ? { mediaType: asString(input.mediaType) } : {}),
      ...(asString(input.objectType) ? { objectType: asString(input.objectType) } : {}),
      ...(asString(input.validity) ? { validity: asString(input.validity) } : {}),
      value: input.properties ?? input.suppliedCanonicalPredictors ?? input.otherSuppliedCanonicalPredictors ?? input.illustrativeInvalidAggregate ?? input.value ?? input,
      canonicalFieldOrder: stringArray(input.canonicalPredictorOrder ?? input.canonicalFieldOrder),
      ...(asString(input.canonicalInputConventionReference) ? { conventionReference: asString(input.canonicalInputConventionReference) } : {})
    }) as CanonicalInputObject;
    const canonicalExpectedOutcome = Object.freeze({
      outcomeKind: asString(expected.outcomeKind) ?? "declared-outcome",
      value: semanticResult?.value ?? expected.value ?? expected,
      ...(asString(comparison.normativeValuePath) ? { normativeValuePath: asString(comparison.normativeValuePath) } : {}),
      ...(asString(expected.expectedValueAuthority) ? { authorityReference: asString(expected.expectedValueAuthority) } : {})
    }) as CanonicalExpectedOutcome;
    const canonicalNegativeInputCondition = isNegativeCondition ? Object.freeze({
      conditionType: asString(input.conditionType) ?? "undeclared negative condition",
      ...(asString(input.baseInputReference) ? { baseInputReference: asString(input.baseInputReference) } : {}),
      ...(asString(input.omittedCanonicalPredictor) ? { omittedCanonicalPredictor: asString(input.omittedCanonicalPredictor) } : {}),
      ...(asString(input.invalidCanonicalPredictor) ? { invalidCanonicalPredictor: asString(input.invalidCanonicalPredictor) } : {}),
      ...(asString(input.invalidSemanticContent) ? { invalidSemanticContent: asString(input.invalidSemanticContent) } : {}),
      ...(input.illustrativeLexicalValue !== undefined ? { illustrativeLexicalValue: input.illustrativeLexicalValue } : {}),
      ...(isObject(input.otherSuppliedCanonicalPredictors) ? { otherSuppliedCanonicalPredictors: Object.freeze({ ...input.otherSuppliedCanonicalPredictors }) } : {}),
      ...(isObject(input.suppliedCanonicalPredictors) ? { suppliedCanonicalPredictors: Object.freeze({ ...input.suppliedCanonicalPredictors }) } : {}),
      ...(input.illustrativeInvalidAggregate !== undefined ? { illustrativeInvalidAggregate: structuredClone(input.illustrativeInvalidAggregate) } : {}),
      ...(asString(input.distinctionFromPTC004) ? { distinctionFromPtc004: asString(input.distinctionFromPTC004) } : {}),
      provenance: provenance(resource, "$.canonicalInputCondition")
    }) as CanonicalNegativeInputCondition : undefined;
    const canonicalSemanticRejection = errorSemantics && asString(errorSemantics.category) && asString(errorSemantics.subject) ? Object.freeze({
      category: asString(errorSemantics.category)!,
      subject: asString(errorSemantics.subject)!,
      ...(asString(errorSemantics.reason) ? { reason: asString(errorSemantics.reason) } : {}),
      computationMustNotProduceRiskResult: asBoolean(errorSemantics.computationMustNotProduceRiskResult) ?? false,
      messageTextIsNormative: asBoolean(errorSemantics.messageTextIsNormative) ?? false,
      transportStatusIsNormative: asBoolean(errorSemantics.transportStatusIsNormative) ?? false,
      requiredSemanticAssertions: stringArray(comparison.requiredSemanticAssertions)
    }) as CanonicalSemanticRejection : undefined;
    const comparisonSemantics = Object.freeze({
      comparisonType: asString(comparison.comparisonType) ?? "declared-comparison",
      ...(asString(comparison.normativeValuePath) ? { normativeValuePath: asString(comparison.normativeValuePath) } : {}),
      ...(asNumber(comparison.absoluteTolerance) !== undefined ? { absoluteTolerance: asNumber(comparison.absoluteTolerance) } : {}),
      ...(asNumber(comparison.relativeTolerance) !== undefined ? { relativeTolerance: asNumber(comparison.relativeTolerance) } : {}),
      ...(asString(comparison.requiredRepresentation) ? { requiredRepresentation: asString(comparison.requiredRepresentation) } : {}),
      ...(asString(comparison.requiredUnit) ? { requiredUnit: asString(comparison.requiredUnit) } : {}),
      ...(asBoolean(comparison.roundingPermittedBeforeComparison) !== undefined ? { roundingPermittedBeforeComparison: asBoolean(comparison.roundingPermittedBeforeComparison) } : {})
    }) as CanonicalComparisonSemantics;

    return Object.freeze({
      identifier,
      ...(asString(document.version) ? { version: asString(document.version) } : {}),
      ...(asString(document.title) ? { title: asString(document.title) } : {}),
      ...(asString(document.purpose) ? { purpose: asString(document.purpose) } : {}),
      ...(asString(document.classification) ? { classification: asString(document.classification) } : {}),
      ...(asString(document.status) ? { status: asString(document.status) } : {}),
      ...(asString(document.publicationIdentifier) ? { publicationIdentifier: asString(document.publicationIdentifier) } : {}),
      ...(asString(document.publishedCapabilitySpecification) ? { publishedCapabilitySpecificationReference: asString(document.publishedCapabilitySpecification) } : {}),
      canonicalInput,
      ...(canonicalNegativeInputCondition ? { canonicalNegativeInputCondition } : {}),
      canonicalExpectedOutcome,
      ...(canonicalSemanticRejection ? { canonicalSemanticRejection } : {}),
      comparisonSemantics,
      applicability: Object.freeze({
        ...(asNumber(applicability.applicableRealizationCount) !== undefined ? { applicableRealizationCount: asNumber(applicability.applicableRealizationCount) } : {}),
        ...(asNumber(applicability.notApplicableRealizationCount) !== undefined ? { notApplicableRealizationCount: asNumber(applicability.notApplicableRealizationCount) } : {}),
        nonApplicabilityPermitted: asBoolean(applicability.nonApplicabilityIsPermitted) ?? false
      }),
      provenance: provenance(resource)
    }) as PublicationTestCase;
  }

  private collectPtcApplicability(document: JsonObject, resource: AcquiredPublicationResource, ptcIdentifier: string, results: PublicationTestCaseApplicability[]): void {
    const determination = isObject(document.applicabilityDetermination) ? document.applicabilityDetermination : undefined;
    if (!determination) return;
    const basisReference = asString(determination.matrixReference);
    for (const realizationIdentifier of stringArray(determination.applicableRealizationInstances)) results.push(Object.freeze({
      ptcIdentifier, realizationIdentifier, status: "applicable", ...(basisReference ? { basisReference } : {}), provenance: provenance(resource, "$.applicabilityDetermination.applicableRealizationInstances")
    }));
    for (const realizationIdentifier of stringArray(determination.notApplicableRealizationInstances ?? determination.nonApplicableRealizationInstances)) results.push(Object.freeze({
      ptcIdentifier, realizationIdentifier, status: "not-applicable", ...(basisReference ? { basisReference } : {}), provenance: provenance(resource, "$.applicabilityDetermination.notApplicableRealizationInstances")
    }));
  }

  private parseRtcm(document: JsonObject, resource: AcquiredPublicationResource, limitations: InterpretationLimitation[]): RealizationTestCaseManifestation | undefined {
    if (!isObject(document.canonicalOrigin) || !isObject(document.complementedRealization) || !isObject(document.applicabilityBasis) || !isObject(document.inputDerivation) || !isObject(document.invocation) || !isObject(document.observationDerivation) || !isObject(document.comparison)) return undefined;
    const identifier = asString(document.identifier);
    const ptcIdentifier = asString(document.canonicalOrigin.ptcIdentifier);
    const realizationIdentifier = asString(document.complementedRealization.identifier);
    const realizationType = layerType(document.complementedRealization.layer);
    if (!identifier || !ptcIdentifier || !realizationIdentifier || !realizationType) {
      limitations.push({ code: "incomplete_relationship_declaration", message: "An RTCM declaration lacks its identifier, canonical PTC, complemented realization, or supported realization layer.", resourcePath: resource.path, location: "$" });
      return undefined;
    }
    const input = document.inputDerivation;
    const representation = isObject(input.concreteRepresentation) ? input.concreteRepresentation : {};
    const invocation = document.invocation;
    const observation = document.observationDerivation;
    const comparison = document.comparison;
    const negativeCondition = isObject(input.negativeConditionDerivation) ? input.negativeConditionDerivation : undefined;
    const bindings: RealizationInputBinding[] = objectArray(input.bindings).flatMap((binding) => {
      const canonicalField = asString(binding.canonicalField);
      const localBinding = asString(binding.localBinding);
      if (!canonicalField || !localBinding) return [];
      return [Object.freeze({
        canonicalField, localBinding,
        ...(asString(binding.bindingKind) ? { bindingKind: asString(binding.bindingKind) } : {}),
        ...(asString(binding.unitMapping) ? { unitMapping: asString(binding.unitMapping) } : {}),
        ...(asString(binding.transformation) ? { transformation: asString(binding.transformation) } : {})
      }) as RealizationInputBinding];
    });
    const appStatus = applicabilityStatus(document.applicabilityBasis.status);
    return Object.freeze({
      identifier,
      ...(asString(document.version) ? { version: asString(document.version) } : {}),
      ...(asString(document.status) ? { status: asString(document.status) } : {}),
      ptcIdentifier,
      realizationIdentifier,
      realizationType,
      applicability: Object.freeze({
        status: appStatus,
        ...(asString(document.applicabilityBasis.pairingKey) ? { pairingKey: asString(document.applicabilityBasis.pairingKey) } : {}),
        conformanceAssertion: asBoolean(document.applicabilityBasis.conformanceAssertion) ?? false
      }),
      inputDerivation: Object.freeze({
        ...(asString(input.canonicalInputReference) ? { canonicalInputReference: asString(input.canonicalInputReference) } : {}),
        ...(asString(representation.mediaType) ? { concreteMediaType: asString(representation.mediaType) } : {}),
        ...(asString(representation.artifactReference) ? { artifactReference: asString(representation.artifactReference) } : {}),
        ...(asBoolean(representation.inlinePermitted) !== undefined ? { inlinePermitted: asBoolean(representation.inlinePermitted) } : {}),
        bindings: Object.freeze(bindings),
        constraints: stringArray(input.derivationConstraints),
        ...(negativeCondition && asString(negativeCondition.semanticCondition) && asString(negativeCondition.concreteDerivation) ? { negativeConditionDerivation: Object.freeze({
          semanticCondition: asString(negativeCondition.semanticCondition)!,
          concreteDerivation: asString(negativeCondition.concreteDerivation)!,
          ...(asString(negativeCondition.mustNotConflateWith) ? { mustNotConflateWith: asString(negativeCondition.mustNotConflateWith) } : {})
        }) } : {})
      }),
      invocation: Object.freeze({
        mode: asString(invocation.mode) ?? "unspecified",
        ...(asString(invocation.entryPoint) ? { entryPoint: asString(invocation.entryPoint) } : {}),
        ...(asString(invocation.operation) ? { operation: asString(invocation.operation) } : {}),
        argumentOrder: stringArray(invocation.argumentOrder),
        ...(asString(invocation.requestArtifactReference) ? { requestArtifactReference: asString(invocation.requestArtifactReference) } : {}),
        ...(asString(invocation.supportAdapterReference) ? { supportAdapterReference: asString(invocation.supportAdapterReference) } : {}),
        externalEnvironmentRequirements: stringArray(invocation.externalEnvironmentRequirements),
        doesNotEmbedRuntime: asBoolean(invocation.doesNotEmbedRuntime) ?? true,
        ...(asString(invocation.constructionBasis) ? { constructionBasis: asString(invocation.constructionBasis) } : {})
      }),
      observationDerivation: Object.freeze({
        ...(asString(observation.rawObservationLocation) ? { rawObservationLocation: asString(observation.rawObservationLocation) } : {}),
        ...(asString(observation.extractionExpression) ? { extractionExpression: asString(observation.extractionExpression) } : {}),
        ...(asString(observation.semanticOutcome) ? { semanticOutcome: asString(observation.semanticOutcome) } : {}),
        normalizations: stringArray(observation.normalizations),
        rawObservationMustBePreserved: asBoolean(observation.rawObservationMustBePreserved) ?? true
      }),
      comparison: Object.freeze({
        ...(asString(comparison.canonicalExpectedOutcomeReference) ? { canonicalExpectedOutcomeReference: asString(comparison.canonicalExpectedOutcomeReference) } : {}),
        ...(asString(comparison.comparisonType) ? { comparisonType: asString(comparison.comparisonType) } : {}),
        ...((asString(comparison.toleranceReference) ?? asNumber(comparison.toleranceReference)) !== undefined ? { toleranceReference: asString(comparison.toleranceReference) ?? asNumber(comparison.toleranceReference)! } : {}),
        representationSpecificHandling: stringArray(comparison.representationSpecificHandling),
        mustPermitFailResult: asBoolean(comparison.mustPermitFailResult) ?? true
      }),
      evidenceLinkageRequirements: stringArray(document.evidenceLinkageRequirements),
      limitations: stringArray(document.limitations),
      provenance: provenance(resource)
    }) as RealizationTestCaseManifestation;
  }

  private uniqueByIdentifier<T extends { readonly identifier: string; readonly provenance: PublicationDeclarationProvenance }>(items: readonly T[], label: string, limitations: InterpretationLimitation[]): T[] {
    const result = new Map<string, T>();
    for (const item of [...items].sort((a, b) => a.identifier.localeCompare(b.identifier))) {
      if (result.has(item.identifier)) limitations.push({ code: "duplicate_declaration", message: `Duplicate ${label} declaration ${item.identifier} was ignored.`, resourcePath: item.provenance.resourcePath, location: item.provenance.location });
      else result.set(item.identifier, item);
    }
    return [...result.values()];
  }

  private uniqueApplicability(items: readonly PublicationTestCaseApplicability[], limitations: InterpretationLimitation[]): PublicationTestCaseApplicability[] {
    const result = new Map<string, PublicationTestCaseApplicability>();
    for (const item of items) {
      const key = `${item.ptcIdentifier}|${item.realizationIdentifier}`;
      const prior = result.get(key);
      if (!prior) result.set(key, item);
      else if (prior.status !== item.status && item.status !== "undetermined") limitations.push({ code: "publication_relationship_inconsistency", message: `Conflicting applicability declarations for ${key}: ${prior.status} and ${item.status}.`, resourcePath: item.provenance.resourcePath, location: item.provenance.location });
    }
    return [...result.values()].sort((a, b) => `${a.ptcIdentifier}|${a.realizationIdentifier}`.localeCompare(`${b.ptcIdentifier}|${b.realizationIdentifier}`));
  }

  private buildIndex(ptcs: readonly PublicationTestCase[], rtcms: readonly RealizationTestCaseManifestation[], applicability: readonly PublicationTestCaseApplicability[]): PublicationExerciseDiscoveryIndex {
    const ptcToRealizations = new Map<string, string[]>();
    const realizationToPtcs = new Map<string, string[]>();
    for (const item of applicability.filter((candidate) => candidate.status === "applicable")) {
      (ptcToRealizations.get(item.ptcIdentifier) ?? (ptcToRealizations.set(item.ptcIdentifier, []), ptcToRealizations.get(item.ptcIdentifier)!)).push(item.realizationIdentifier);
      (realizationToPtcs.get(item.realizationIdentifier) ?? (realizationToPtcs.set(item.realizationIdentifier, []), realizationToPtcs.get(item.realizationIdentifier)!)).push(item.ptcIdentifier);
    }
    const pairingEntries: Array<readonly [string, string]> = [];
    const pairingCounts = new Map<string, number>();
    for (const rtcm of rtcms.filter((candidate) => candidate.status === "authoritative" && candidate.applicability.status === "applicable")) {
      const key = `${rtcm.ptcIdentifier}|${rtcm.realizationIdentifier}`;
      pairingCounts.set(key, (pairingCounts.get(key) ?? 0) + 1);
      pairingEntries.push([key, rtcm.identifier]);
    }
    return Object.freeze({
      ptcIdentifiers: sortedUnique(ptcs.map((item) => item.identifier)),
      rtcmIdentifiers: sortedUnique(rtcms.map((item) => item.identifier)),
      ptcToRealizationIdentifiers: freezeRecord([...ptcToRealizations].map(([key, values]) => [key, sortedUnique(values)] as const)),
      realizationToPtcIdentifiers: freezeRecord([...realizationToPtcs].map(([key, values]) => [key, sortedUnique(values)] as const)),
      pairingToRtcmIdentifier: freezeRecord(pairingEntries.filter(([key]) => pairingCounts.get(key) === 1))
    });
  }
}
