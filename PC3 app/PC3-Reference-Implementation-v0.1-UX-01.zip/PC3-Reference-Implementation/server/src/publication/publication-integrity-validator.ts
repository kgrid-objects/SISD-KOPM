import { posix } from "node:path";
import type { InterpretedRealizationDeclaration, PublicationDeclarationProvenance } from "./interpretation-model.js";
import type { PublicationExerciseDiscoveryIndex } from "./publication-exercise-discovery.js";
import type {
  PublicationTestCase,
  PublicationTestCaseApplicability,
  RealizationTestCaseManifestation
} from "./publication-exercise-model.js";

export type PublicationValidationCategory =
  | "referential-integrity"
  | "applicability-consistency"
  | "inventory-synchronization"
  | "declaration-completeness"
  | "publication-invariant";

export type PublicationValidationSeverity = "error" | "warning";

export type PublicationValidationIssueCode =
  | "duplicate_ptc_identifier"
  | "duplicate_rtcm_identifier"
  | "duplicate_applicability_declaration"
  | "conflicting_applicability_declaration"
  | "ptc_publication_identifier_mismatch"
  | "rtcm_ptc_reference_not_found"
  | "rtcm_realization_reference_not_found"
  | "rtcm_realization_type_mismatch"
  | "applicability_ptc_reference_not_found"
  | "applicability_realization_reference_not_found"
  | "referenced_publication_resource_not_found"
  | "applicability_declaration_missing"
  | "rtcm_applicability_without_ptc_declaration"
  | "rtcm_applicability_conflict"
  | "rtcm_pairing_key_mismatch"
  | "applicable_pairing_missing_authoritative_rtcm"
  | "applicable_pairing_has_ambiguous_authoritative_rtcm"
  | "not_applicable_pairing_has_applicable_rtcm"
  | "ptc_applicable_inventory_count_mismatch"
  | "ptc_not_applicable_inventory_count_mismatch"
  | "ptc_total_inventory_count_mismatch"
  | "discovery_index_out_of_sync"
  | "ptc_declaration_incomplete"
  | "rtcm_declaration_incomplete"
  | "ptc_not_authoritative"
  | "rtcm_not_authoritative"
  | "rtcm_embeds_runtime"
  | "rtcm_does_not_preserve_raw_observation"
  | "rtcm_does_not_permit_fail_result"
  | "rtcm_asserts_conformance";

export interface PublicationValidationIssue {
  readonly code: PublicationValidationIssueCode;
  readonly severity: PublicationValidationSeverity;
  readonly category: PublicationValidationCategory;
  readonly message: string;
  readonly ptcIdentifier?: string;
  readonly realizationIdentifier?: string;
  readonly rtcmIdentifier?: string;
  readonly resourcePath?: string;
  readonly location?: string;
}

export interface PublicationValidationCheckSummary {
  readonly category: PublicationValidationCategory;
  readonly status: "passed" | "failed";
  readonly issueCount: number;
  readonly errorCount: number;
  readonly warningCount: number;
}

export interface PublicationValidationReport {
  readonly status: "valid" | "valid-with-warnings" | "invalid" | "not-applicable";
  readonly validationScope: "publication-declarations";
  readonly checkedPtcCount: number;
  readonly checkedRtcmCount: number;
  readonly checkedRealizationCount: number;
  readonly checkedApplicabilityPairingCount: number;
  readonly issueCount: number;
  readonly errorCount: number;
  readonly warningCount: number;
  readonly checks: readonly PublicationValidationCheckSummary[];
  readonly issues: readonly PublicationValidationIssue[];
  readonly statement: string;
}

export interface PublicationIntegrityValidationInput {
  readonly publicationIdentifier?: string;
  readonly publicationTestCases: readonly PublicationTestCase[];
  readonly realizationTestCaseManifestations: readonly RealizationTestCaseManifestation[];
  readonly applicabilityDeclarations: readonly PublicationTestCaseApplicability[];
  readonly rawPublicationTestCases?: readonly PublicationTestCase[];
  readonly rawRealizationTestCaseManifestations?: readonly RealizationTestCaseManifestation[];
  readonly declaredApplicabilityDeclarations?: readonly PublicationTestCaseApplicability[];
  readonly realizations: readonly InterpretedRealizationDeclaration[];
  readonly discoveryIndex: PublicationExerciseDiscoveryIndex;
  readonly publicationResourcePaths: readonly string[];
}

const categories: readonly PublicationValidationCategory[] = Object.freeze([
  "referential-integrity",
  "applicability-consistency",
  "inventory-synchronization",
  "declaration-completeness",
  "publication-invariant"
]);

function pairingKey(ptcIdentifier: string, realizationIdentifier: string): string {
  return `${ptcIdentifier}|${realizationIdentifier}`;
}

function sortedUnique(values: Iterable<string>): readonly string[] {
  return [...new Set(values)].sort();
}

function sameStrings(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function sameStringRecord(left: Readonly<Record<string, readonly string[]>>, right: Readonly<Record<string, readonly string[]>>): boolean {
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return sameStrings(leftKeys, rightKeys) && leftKeys.every((key) => sameStrings(left[key] ?? [], right[key] ?? []));
}

function sameScalarRecord(left: Readonly<Record<string, string>>, right: Readonly<Record<string, string>>): boolean {
  const leftEntries = Object.entries(left).sort(([a], [b]) => a.localeCompare(b));
  const rightEntries = Object.entries(right).sort(([a], [b]) => a.localeCompare(b));
  return leftEntries.length === rightEntries.length && leftEntries.every(([key, value], index) => {
    const candidate = rightEntries[index];
    return candidate?.[0] === key && candidate[1] === value;
  });
}

function groupBy<T>(values: readonly T[], key: (value: T) => string): Map<string, T[]> {
  const groups = new Map<string, T[]>();
  for (const value of values) {
    const groupKey = key(value);
    const group = groups.get(groupKey) ?? [];
    group.push(value);
    groups.set(groupKey, group);
  }
  return groups;
}

function issueFromProvenance(
  code: PublicationValidationIssueCode,
  severity: PublicationValidationSeverity,
  category: PublicationValidationCategory,
  message: string,
  provenance: PublicationDeclarationProvenance | undefined,
  identifiers: Pick<PublicationValidationIssue, "ptcIdentifier" | "realizationIdentifier" | "rtcmIdentifier"> = {}
): PublicationValidationIssue {
  return Object.freeze({
    code,
    severity,
    category,
    message,
    ...identifiers,
    ...(provenance?.resourcePath ? { resourcePath: provenance.resourcePath } : {}),
    ...(provenance?.location ? { location: provenance.location } : {})
  });
}

function isPathReference(reference: string): boolean {
  if (/^[a-z][a-z0-9+.-]*:/i.test(reference) || reference.startsWith("#")) return false;
  return reference.includes("/") || reference.startsWith(".") || /\.[a-z0-9]{1,10}(?:[#?].*)?$/i.test(reference);
}

function resolvePublicationPath(reference: string, declarationPath: string): string {
  const withoutFragment = reference.split(/[?#]/, 1)[0] ?? reference;
  const normalized = withoutFragment.startsWith("/")
    ? posix.normalize(withoutFragment.slice(1))
    : posix.normalize(posix.join(posix.dirname(declarationPath), withoutFragment));
  return normalized.replace(/^\.\//, "");
}

/**
 * Audits the declaration graph only. It neither repairs publication declarations nor
 * evaluates runtime availability, execution success, scientific validity, or conformance.
 */
export class PublicationIntegrityValidator {
  validate(input: PublicationIntegrityValidationInput): PublicationValidationReport {
    const issues: PublicationValidationIssue[] = [];
    const rawPtcs = input.rawPublicationTestCases ?? input.publicationTestCases;
    const rawRtcms = input.rawRealizationTestCaseManifestations ?? input.realizationTestCaseManifestations;
    const declaredApplicability = input.declaredApplicabilityDeclarations ?? input.applicabilityDeclarations;
    const ptcs = input.publicationTestCases;
    const rtcms = input.realizationTestCaseManifestations;
    const ptcById = new Map(ptcs.map((ptc) => [ptc.identifier, ptc]));
    const realizationById = new Map(input.realizations.map((realization) => [realization.identifier, realization]));
    const resources = new Set(input.publicationResourcePaths.map((path) => posix.normalize(path)));

    for (const [identifier, declarations] of groupBy(rawPtcs, (ptc) => ptc.identifier)) {
      if (declarations.length > 1) issues.push(issueFromProvenance(
        "duplicate_ptc_identifier", "error", "declaration-completeness",
        `Publication Test Case identifier ${identifier} is declared ${declarations.length} times.`, declarations[1]?.provenance,
        { ptcIdentifier: identifier }
      ));
    }
    for (const [identifier, declarations] of groupBy(rawRtcms, (rtcm) => rtcm.identifier)) {
      if (declarations.length > 1) issues.push(issueFromProvenance(
        "duplicate_rtcm_identifier", "error", "declaration-completeness",
        `RTCM identifier ${identifier} is declared ${declarations.length} times.`, declarations[1]?.provenance,
        { rtcmIdentifier: identifier }
      ));
    }

    for (const ptc of ptcs) {
      const identifiers = { ptcIdentifier: ptc.identifier };
      if (input.publicationIdentifier && ptc.publicationIdentifier && ptc.publicationIdentifier !== input.publicationIdentifier) {
        issues.push(issueFromProvenance(
          "ptc_publication_identifier_mismatch", "error", "referential-integrity",
          `Publication Test Case ${ptc.identifier} identifies publication ${ptc.publicationIdentifier}, not ${input.publicationIdentifier}.`, ptc.provenance, identifiers
        ));
      }
      const missing = [
        !ptc.purpose ? "purpose" : undefined,
        !ptc.publicationIdentifier ? "publicationIdentifier" : undefined,
        !ptc.publishedCapabilitySpecificationReference ? "publishedCapabilitySpecification" : undefined,
        ptc.canonicalInput.value === undefined ? "canonicalInput" : undefined,
        ptc.canonicalExpectedOutcome.value === undefined ? "canonicalExpectedOutcome" : undefined,
        ptc.canonicalExpectedOutcome.outcomeKind === "declared-outcome" ? "canonicalExpectedOutcome.outcomeKind" : undefined,
        ptc.comparisonSemantics.comparisonType === "declared-comparison" ? "comparisonSemantics.comparisonType" : undefined
      ].filter((value): value is string => Boolean(value));
      if (missing.length) issues.push(issueFromProvenance(
        "ptc_declaration_incomplete", "error", "declaration-completeness",
        `Publication Test Case ${ptc.identifier} is missing required declaration content: ${missing.join(", ")}.`, ptc.provenance, identifiers
      ));
      if (ptc.status !== "authoritative") issues.push(issueFromProvenance(
        "ptc_not_authoritative", "warning", "declaration-completeness",
        `Publication Test Case ${ptc.identifier} is not declared authoritative.`, ptc.provenance, identifiers
      ));
      this.checkResourceReference(ptc.publishedCapabilitySpecificationReference, ptc.provenance, resources, issues, identifiers);
    }

    for (const rtcm of rtcms) {
      const identifiers = { ptcIdentifier: rtcm.ptcIdentifier, realizationIdentifier: rtcm.realizationIdentifier, rtcmIdentifier: rtcm.identifier };
      if (!ptcById.has(rtcm.ptcIdentifier)) issues.push(issueFromProvenance(
        "rtcm_ptc_reference_not_found", "error", "referential-integrity",
        `RTCM ${rtcm.identifier} references undeclared Publication Test Case ${rtcm.ptcIdentifier}.`, rtcm.provenance, identifiers
      ));
      const realization = realizationById.get(rtcm.realizationIdentifier);
      if (!realization) issues.push(issueFromProvenance(
        "rtcm_realization_reference_not_found", "error", "referential-integrity",
        `RTCM ${rtcm.identifier} references undiscovered realization ${rtcm.realizationIdentifier}.`, rtcm.provenance, identifiers
      ));
      else if (realization.realizationType !== rtcm.realizationType) issues.push(issueFromProvenance(
        "rtcm_realization_type_mismatch", "error", "referential-integrity",
        `RTCM ${rtcm.identifier} declares ${rtcm.realizationType} for ${rtcm.realizationIdentifier}, but the realization declaration identifies ${realization.realizationType}.`, rtcm.provenance, identifiers
      ));

      const expectedPairingKey = pairingKey(rtcm.ptcIdentifier, rtcm.realizationIdentifier);
      if (rtcm.applicability.pairingKey && rtcm.applicability.pairingKey !== expectedPairingKey) issues.push(issueFromProvenance(
        "rtcm_pairing_key_mismatch", "error", "applicability-consistency",
        `RTCM ${rtcm.identifier} declares pairing key ${rtcm.applicability.pairingKey}; expected ${expectedPairingKey}.`, rtcm.provenance, identifiers
      ));
      const missing = [
        !rtcm.inputDerivation.canonicalInputReference ? "inputDerivation.canonicalInputReference" : undefined,
        !rtcm.invocation.mode || rtcm.invocation.mode === "unspecified" ? "invocation.mode" : undefined,
        !rtcm.observationDerivation.rawObservationLocation && !rtcm.observationDerivation.extractionExpression && !rtcm.observationDerivation.semanticOutcome ? "observationDerivation" : undefined,
        !rtcm.comparison.canonicalExpectedOutcomeReference ? "comparison.canonicalExpectedOutcomeReference" : undefined,
        !rtcm.comparison.comparisonType ? "comparison.comparisonType" : undefined,
        rtcm.applicability.status === "undetermined" ? "applicabilityBasis.status" : undefined
      ].filter((value): value is string => Boolean(value));
      if (missing.length) issues.push(issueFromProvenance(
        "rtcm_declaration_incomplete", "error", "declaration-completeness",
        `RTCM ${rtcm.identifier} is missing required declaration content: ${missing.join(", ")}.`, rtcm.provenance, identifiers
      ));
      if (rtcm.status !== "authoritative") issues.push(issueFromProvenance(
        "rtcm_not_authoritative", "warning", "declaration-completeness",
        `RTCM ${rtcm.identifier} is not declared authoritative.`, rtcm.provenance, identifiers
      ));
      if (!rtcm.invocation.doesNotEmbedRuntime) issues.push(issueFromProvenance(
        "rtcm_embeds_runtime", "error", "publication-invariant",
        `RTCM ${rtcm.identifier} does not preserve the external-runtime boundary.`, rtcm.provenance, identifiers
      ));
      if (!rtcm.observationDerivation.rawObservationMustBePreserved) issues.push(issueFromProvenance(
        "rtcm_does_not_preserve_raw_observation", "error", "publication-invariant",
        `RTCM ${rtcm.identifier} does not require preservation of the raw observation.`, rtcm.provenance, identifiers
      ));
      if (!rtcm.comparison.mustPermitFailResult) issues.push(issueFromProvenance(
        "rtcm_does_not_permit_fail_result", "error", "publication-invariant",
        `RTCM ${rtcm.identifier} does not permit a failed comparison result.`, rtcm.provenance, identifiers
      ));
      if (rtcm.applicability.conformanceAssertion !== false) issues.push(issueFromProvenance(
        "rtcm_asserts_conformance", "error", "publication-invariant",
        `RTCM ${rtcm.identifier} improperly asserts conformance.`, rtcm.provenance, identifiers
      ));
      this.checkResourceReference(rtcm.inputDerivation.artifactReference, rtcm.provenance, resources, issues, identifiers);
      this.checkResourceReference(rtcm.invocation.requestArtifactReference, rtcm.provenance, resources, issues, identifiers);
      this.checkResourceReference(rtcm.invocation.supportAdapterReference, rtcm.provenance, resources, issues, identifiers);
    }

    const canonicalGroups = groupBy(declaredApplicability, (item) => pairingKey(item.ptcIdentifier, item.realizationIdentifier));
    for (const [key, declarations] of canonicalGroups) {
      const first = declarations[0]!;
      const statuses = sortedUnique(declarations.map((item) => item.status));
      if (declarations.length > 1) issues.push(issueFromProvenance(
        statuses.length > 1 ? "conflicting_applicability_declaration" : "duplicate_applicability_declaration",
        "error", "applicability-consistency",
        statuses.length > 1
          ? `Applicability pairing ${key} has conflicting declarations: ${statuses.join(", ")}.`
          : `Applicability pairing ${key} is declared ${declarations.length} times.`,
        declarations[1]?.provenance,
        { ptcIdentifier: first.ptcIdentifier, realizationIdentifier: first.realizationIdentifier }
      ));
      if (!ptcById.has(first.ptcIdentifier)) issues.push(issueFromProvenance(
        "applicability_ptc_reference_not_found", "error", "referential-integrity",
        `Applicability declaration ${key} references an undeclared Publication Test Case.`, first.provenance,
        { ptcIdentifier: first.ptcIdentifier, realizationIdentifier: first.realizationIdentifier }
      ));
      if (!realizationById.has(first.realizationIdentifier)) issues.push(issueFromProvenance(
        "applicability_realization_reference_not_found", "error", "referential-integrity",
        `Applicability declaration ${key} references an undiscovered realization.`, first.provenance,
        { ptcIdentifier: first.ptcIdentifier, realizationIdentifier: first.realizationIdentifier }
      ));
    }

    for (const ptc of ptcs) {
      for (const realization of input.realizations) {
        const key = pairingKey(ptc.identifier, realization.identifier);
        if (!canonicalGroups.has(key)) issues.push(issueFromProvenance(
          "applicability_declaration_missing", "error", "applicability-consistency",
          `Publication Test Case ${ptc.identifier} does not explicitly determine applicability for realization ${realization.identifier}.`, ptc.provenance,
          { ptcIdentifier: ptc.identifier, realizationIdentifier: realization.identifier }
        ));
      }
    }

    const rtcmPairings = groupBy(rtcms, (rtcm) => pairingKey(rtcm.ptcIdentifier, rtcm.realizationIdentifier));
    for (const rtcm of rtcms) {
      const key = pairingKey(rtcm.ptcIdentifier, rtcm.realizationIdentifier);
      const canonical = canonicalGroups.get(key);
      if (!canonical) issues.push(issueFromProvenance(
        "rtcm_applicability_without_ptc_declaration", "error", "applicability-consistency",
        `RTCM ${rtcm.identifier} has no corresponding PTC applicability determination for ${key}.`, rtcm.provenance,
        { ptcIdentifier: rtcm.ptcIdentifier, realizationIdentifier: rtcm.realizationIdentifier, rtcmIdentifier: rtcm.identifier }
      ));
      else if (!canonical.some((item) => item.status === rtcm.applicability.status)) issues.push(issueFromProvenance(
        "rtcm_applicability_conflict", "error", "applicability-consistency",
        `RTCM ${rtcm.identifier} declares ${rtcm.applicability.status}, inconsistent with the PTC applicability determination for ${key}.`, rtcm.provenance,
        { ptcIdentifier: rtcm.ptcIdentifier, realizationIdentifier: rtcm.realizationIdentifier, rtcmIdentifier: rtcm.identifier }
      ));
    }

    for (const [key, declarations] of canonicalGroups) {
      const canonical = declarations[0]!;
      const matchingRtcms = rtcmPairings.get(key) ?? [];
      const authoritativeApplicable = matchingRtcms.filter((rtcm) => rtcm.status === "authoritative" && rtcm.applicability.status === "applicable");
      if (canonical.status === "applicable" && authoritativeApplicable.length === 0) issues.push(issueFromProvenance(
        "applicable_pairing_missing_authoritative_rtcm", "error", "applicability-consistency",
        `Applicable pairing ${key} has no authoritative applicable RTCM.`, canonical.provenance,
        { ptcIdentifier: canonical.ptcIdentifier, realizationIdentifier: canonical.realizationIdentifier }
      ));
      if (canonical.status === "applicable" && authoritativeApplicable.length > 1) issues.push(issueFromProvenance(
        "applicable_pairing_has_ambiguous_authoritative_rtcm", "error", "applicability-consistency",
        `Applicable pairing ${key} has ${authoritativeApplicable.length} authoritative applicable RTCMs.`, canonical.provenance,
        { ptcIdentifier: canonical.ptcIdentifier, realizationIdentifier: canonical.realizationIdentifier }
      ));
      if (canonical.status === "not-applicable" && matchingRtcms.some((rtcm) => rtcm.applicability.status === "applicable")) issues.push(issueFromProvenance(
        "not_applicable_pairing_has_applicable_rtcm", "error", "applicability-consistency",
        `Not-applicable pairing ${key} has an RTCM that declares it applicable.`, canonical.provenance,
        { ptcIdentifier: canonical.ptcIdentifier, realizationIdentifier: canonical.realizationIdentifier }
      ));
    }

    for (const ptc of ptcs) {
      const declarations = [...canonicalGroups.values()].map((items) => items[0]!).filter((item) => item.ptcIdentifier === ptc.identifier);
      const applicableCount = declarations.filter((item) => item.status === "applicable").length;
      const notApplicableCount = declarations.filter((item) => item.status === "not-applicable").length;
      if (ptc.applicability.applicableRealizationCount !== undefined && ptc.applicability.applicableRealizationCount !== applicableCount) issues.push(issueFromProvenance(
        "ptc_applicable_inventory_count_mismatch", "error", "inventory-synchronization",
        `Publication Test Case ${ptc.identifier} declares ${ptc.applicability.applicableRealizationCount} applicable realizations, but ${applicableCount} are enumerated.`, ptc.provenance,
        { ptcIdentifier: ptc.identifier }
      ));
      if (ptc.applicability.notApplicableRealizationCount !== undefined && ptc.applicability.notApplicableRealizationCount !== notApplicableCount) issues.push(issueFromProvenance(
        "ptc_not_applicable_inventory_count_mismatch", "error", "inventory-synchronization",
        `Publication Test Case ${ptc.identifier} declares ${ptc.applicability.notApplicableRealizationCount} not-applicable realizations, but ${notApplicableCount} are enumerated.`, ptc.provenance,
        { ptcIdentifier: ptc.identifier }
      ));
      if (declarations.length !== input.realizations.length) issues.push(issueFromProvenance(
        "ptc_total_inventory_count_mismatch", "error", "inventory-synchronization",
        `Publication Test Case ${ptc.identifier} enumerates ${declarations.length} realization applicability determinations for an inventory of ${input.realizations.length} realizations.`, ptc.provenance,
        { ptcIdentifier: ptc.identifier }
      ));
    }

    if (!this.indexIsSynchronized(input)) issues.push(Object.freeze({
      code: "discovery_index_out_of_sync",
      severity: "error",
      category: "inventory-synchronization",
      message: "The publication exercise discovery index is not synchronized with the validated declaration graph."
    }));

    const sortedIssues = Object.freeze(issues.sort((left, right) =>
      `${left.category}|${left.code}|${left.ptcIdentifier ?? ""}|${left.realizationIdentifier ?? ""}|${left.rtcmIdentifier ?? ""}|${left.resourcePath ?? ""}`
        .localeCompare(`${right.category}|${right.code}|${right.ptcIdentifier ?? ""}|${right.realizationIdentifier ?? ""}|${right.rtcmIdentifier ?? ""}|${right.resourcePath ?? ""}`)
    ));
    const checks = Object.freeze(categories.map((category) => {
      const categoryIssues = sortedIssues.filter((candidate) => candidate.category === category);
      const errorCount = categoryIssues.filter((candidate) => candidate.severity === "error").length;
      return Object.freeze({
        category,
        status: errorCount === 0 ? "passed" : "failed",
        issueCount: categoryIssues.length,
        errorCount,
        warningCount: categoryIssues.length - errorCount
      }) as PublicationValidationCheckSummary;
    }));
    const errorCount = sortedIssues.filter((candidate) => candidate.severity === "error").length;
    const warningCount = sortedIssues.length - errorCount;
    const noExerciseArchitecture = rawPtcs.length === 0 && rawRtcms.length === 0 && declaredApplicability.length === 0;
    const status: PublicationValidationReport["status"] = noExerciseArchitecture
      ? "not-applicable"
      : errorCount > 0
        ? "invalid"
        : warningCount > 0
          ? "valid-with-warnings"
          : "valid";
    const statement = status === "not-applicable"
      ? "No Publication Test Case architecture was discovered, so UKO 1.1 publication exercise validation was not applicable."
      : status === "invalid"
        ? `Publication declaration integrity validation found ${errorCount} error${errorCount === 1 ? "" : "s"}.`
        : status === "valid-with-warnings"
          ? `Publication declaration integrity validation passed with ${warningCount} warning${warningCount === 1 ? "" : "s"}.`
          : "Publication declaration integrity validation passed. This result does not assert runtime availability, execution success, scientific validity, or conformance.";
    return Object.freeze({
      status,
      validationScope: "publication-declarations",
      checkedPtcCount: ptcs.length,
      checkedRtcmCount: rtcms.length,
      checkedRealizationCount: input.realizations.length,
      checkedApplicabilityPairingCount: canonicalGroups.size,
      issueCount: sortedIssues.length,
      errorCount,
      warningCount,
      checks,
      issues: sortedIssues,
      statement
    });
  }

  private checkResourceReference(
    reference: string | undefined,
    provenance: PublicationDeclarationProvenance,
    resources: ReadonlySet<string>,
    issues: PublicationValidationIssue[],
    identifiers: Pick<PublicationValidationIssue, "ptcIdentifier" | "realizationIdentifier" | "rtcmIdentifier">
  ): void {
    if (!reference || !isPathReference(reference)) return;
    const resolved = resolvePublicationPath(reference, provenance.resourcePath);
    if (!resources.has(resolved)) issues.push(issueFromProvenance(
      "referenced_publication_resource_not_found", "error", "referential-integrity",
      `Publication reference ${reference} resolves to ${resolved}, which is not present in the publication inventory.`, provenance, identifiers
    ));
  }

  private indexIsSynchronized(input: PublicationIntegrityValidationInput): boolean {
    const expectedPtcIdentifiers = sortedUnique(input.publicationTestCases.map((ptc) => ptc.identifier));
    const expectedRtcmIdentifiers = sortedUnique(input.realizationTestCaseManifestations.map((rtcm) => rtcm.identifier));
    const ptcToRealizations = new Map<string, string[]>();
    const realizationToPtcs = new Map<string, string[]>();
    for (const declaration of input.applicabilityDeclarations.filter((item) => item.status === "applicable")) {
      const byPtc = ptcToRealizations.get(declaration.ptcIdentifier) ?? [];
      byPtc.push(declaration.realizationIdentifier);
      ptcToRealizations.set(declaration.ptcIdentifier, byPtc);
      const byRealization = realizationToPtcs.get(declaration.realizationIdentifier) ?? [];
      byRealization.push(declaration.ptcIdentifier);
      realizationToPtcs.set(declaration.realizationIdentifier, byRealization);
    }
    const expectedPtcToRealizations = Object.fromEntries([...ptcToRealizations].map(([key, values]) => [key, sortedUnique(values)]));
    const expectedRealizationToPtcs = Object.fromEntries([...realizationToPtcs].map(([key, values]) => [key, sortedUnique(values)]));
    const rtcmGroups = groupBy(
      input.realizationTestCaseManifestations.filter((rtcm) => rtcm.status === "authoritative" && rtcm.applicability.status === "applicable"),
      (rtcm) => pairingKey(rtcm.ptcIdentifier, rtcm.realizationIdentifier)
    );
    const expectedPairingToRtcm = Object.fromEntries(
      [...rtcmGroups].filter(([, values]) => values.length === 1).map(([key, values]) => [key, values[0]!.identifier])
    );
    return sameStrings(input.discoveryIndex.ptcIdentifiers, expectedPtcIdentifiers)
      && sameStrings(input.discoveryIndex.rtcmIdentifiers, expectedRtcmIdentifiers)
      && sameStringRecord(input.discoveryIndex.ptcToRealizationIdentifiers, expectedPtcToRealizations)
      && sameStringRecord(input.discoveryIndex.realizationToPtcIdentifiers, expectedRealizationToPtcs)
      && sameScalarRecord(input.discoveryIndex.pairingToRtcmIdentifier, expectedPairingToRtcm);
  }
}
