import type { Clock, IdentifierGenerator } from "../domain/time.js";
import type { IsoInstant } from "../domain/time.js";
import { iorId, type IorId, type PublicationInterpretationId, type PublicationLoadId } from "../domain/identifiers.js";
import type { PublicationDeclarationProvenance, PublicationInterpretation } from "./interpretation-model.js";

export interface IorRealizationNode {
  readonly identifier: string;
  readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly artifactReference?: string;
  readonly invocationMechanism?: string;
  readonly traceability: PublicationDeclarationProvenance;
}

export interface IorRelationshipEdge {
  readonly relationshipType: string;
  readonly sourceIdentifier: string;
  readonly targetIdentifier: string;
  readonly sourceResolved: boolean;
  readonly targetResolved: boolean;
  readonly traceability: PublicationDeclarationProvenance;
}

export interface IorConstructionLimitation {
  readonly code: "duplicate_realization_identifier" | "unresolved_relationship_endpoint";
  readonly message: string;
  readonly sourceResourcePath?: string;
}

/** Replaceable PC3-owned operational representation; it has no authority over the publication. */
export interface InternalOperationalRepresentation {
  readonly id: IorId;
  readonly publicationLoadId: PublicationLoadId;
  readonly interpretationId: PublicationInterpretationId;
  readonly createdAt: IsoInstant;
  readonly publicationIdentifier?: string;
  readonly realizationNodes: readonly IorRealizationNode[];
  readonly relationshipEdges: readonly IorRelationshipEdge[];
  readonly constructionLimitations: readonly IorConstructionLimitation[];
}

export interface IorManagerDependencies {
  readonly clock: Clock;
  readonly identifiers: IdentifierGenerator;
}

export class InternalOperationalRepresentationManager {
  constructor(private readonly dependencies: IorManagerDependencies) {}

  construct(interpretation: PublicationInterpretation): InternalOperationalRepresentation {
    const identifiers = new Set<string>();
    const nodes: IorRealizationNode[] = [];
    const constructionLimitations: IorConstructionLimitation[] = [];

    for (const declaration of interpretation.realizations) {
      if (identifiers.has(declaration.identifier)) {
        constructionLimitations.push({
          code: "duplicate_realization_identifier",
          message: `The realization identifier ${declaration.identifier} is declared for more than one realization. The first deterministic declaration is retained.`,
          sourceResourcePath: declaration.provenance.resourcePath
        });
        continue;
      }
      identifiers.add(declaration.identifier);
      nodes.push(Object.freeze({
        identifier: declaration.identifier,
        realizationType: declaration.realizationType,
        ...(declaration.artifactReference ? { artifactReference: declaration.artifactReference } : {}),
        ...(declaration.invocationMechanism ? { invocationMechanism: declaration.invocationMechanism } : {}),
        traceability: declaration.provenance
      }));
    }

    const edges = interpretation.relationships.map((declaration): IorRelationshipEdge => {
      const sourceResolved = identifiers.has(declaration.sourceIdentifier);
      const targetResolved = identifiers.has(declaration.targetIdentifier);
      if (!sourceResolved || !targetResolved) {
        constructionLimitations.push({
          code: "unresolved_relationship_endpoint",
          message: `Relationship ${declaration.relationshipType} references ${!sourceResolved ? `unknown source ${declaration.sourceIdentifier}` : `unknown target ${declaration.targetIdentifier}`}.`,
          sourceResourcePath: declaration.provenance.resourcePath
        });
      }
      return Object.freeze({
        relationshipType: declaration.relationshipType,
        sourceIdentifier: declaration.sourceIdentifier,
        targetIdentifier: declaration.targetIdentifier,
        sourceResolved,
        targetResolved,
        traceability: declaration.provenance
      });
    });

    return Object.freeze({
      id: iorId(this.dependencies.identifiers.next()),
      publicationLoadId: interpretation.publicationLoadId,
      interpretationId: interpretation.id,
      createdAt: this.dependencies.clock.now(),
      ...(interpretation.publicationIdentity ? { publicationIdentifier: interpretation.publicationIdentity.value.declaredIdentifier } : {}),
      realizationNodes: Object.freeze(nodes),
      relationshipEdges: Object.freeze(edges),
      constructionLimitations: Object.freeze(constructionLimitations)
    });
  }
}
