import type { PublicationSourceReference } from "./model.js";

export interface AcquiredPublicationResource {
  readonly path: string;
  readonly byteLength: number;
  readonly sha256: string;
  readBytes(): Promise<Uint8Array>;
}

export interface AcquiredPublication {
  readonly source: PublicationSourceReference;
  readonly resources: readonly AcquiredPublicationResource[];
}

/** Deliberately read-only: no authoring, repair, rename, delete, commit, or repository administration operations exist. */
export interface PublicationSourceAdapter {
  supports(source: PublicationSourceReference): boolean;
  acquire(source: PublicationSourceReference): Promise<AcquiredPublication>;
}
