# Publication module

Owns read-only publication acquisition, provenance-bearing interpretation, and Internal Operational Representation construction.

DEV-4 responsibilities:

- Publication Loader acquires resources and reports loading outcomes.
- Publication Interpreter reads supported explicit JSON/YAML declarations and reports PC3 Interpretation plus limitations.
- IOR Manager constructs a traceable PC3-owned graph from the interpretation.

The module does not activate a publication, own session state, assess publication conformance, construct the Executable Realization Matrix, or exercise a realization. Repository structure is not promoted to architectural meaning in DEV-4.
