import type { RtcmInvocationSupportAssessment } from "../adapter/publication-reference-execution.js";
import type { ExecutableRealizationType, PublicationInterpretation } from "./interpretation-model.js";

export type ExerciseOpportunityCoverageLevel = ExecutableRealizationType | "total";

export interface ExerciseOpportunityCoverageRow {
  readonly level: ExerciseOpportunityCoverageLevel;
  readonly possible: number;
  readonly applicable: number;
  readonly rtcmResolved: number;
  readonly exerciseEnabled: number;
  readonly blocked: number;
  readonly notApplicable: number;
  readonly unclassified: number;
  readonly coveragePercent: number | null;
}

export interface ExerciseOpportunityCoverageProjection {
  readonly status: "available" | "projection-error";
  readonly population: "ptc-by-unique-realization";
  readonly supportAssessmentBasis: "active-context-latest-assessment";
  readonly rows: readonly ExerciseOpportunityCoverageRow[];
  readonly errors: readonly string[];
  readonly statement: string;
}

const levels: readonly ExecutableRealizationType[] = ["implementation-representation", "service-realization", "deployment-package"];

function pair(ptcIdentifier: string, realizationIdentifier: string): string {
  return `${ptcIdentifier}\u0000${realizationIdentifier}`;
}

function row(level: ExerciseOpportunityCoverageLevel, values: Omit<ExerciseOpportunityCoverageRow, "level" | "coveragePercent">): ExerciseOpportunityCoverageRow {
  return Object.freeze({
    level,
    ...values,
    coveragePercent: values.applicable === 0 ? null : values.exerciseEnabled / values.applicable * 100
  });
}

/** Deterministic UII-06 projection over existing interpretation and invocation-support results. */
export function projectExerciseOpportunityCoverage(
  interpretation: PublicationInterpretation,
  invocationSupport: readonly RtcmInvocationSupportAssessment[]
): ExerciseOpportunityCoverageProjection {
  const ptcIdentifiers = [...new Set(interpretation.publicationTestCases.map((item) => item.identifier))].sort();
  const realizationsByLevel = new Map(levels.map((level) => [level, [...new Set(interpretation.realizations.filter((item) => item.realizationType === level).map((item) => item.identifier))].sort()] as const));
  const errors: string[] = [];
  const realizationLevels = new Map<string, Set<string>>();
  for (const realization of interpretation.realizations) {
    const declaredLevels = realizationLevels.get(realization.identifier) ?? new Set<string>();
    declaredLevels.add(realization.realizationType);
    realizationLevels.set(realization.identifier, declaredLevels);
  }
  for (const [identifier, declaredLevels] of realizationLevels) if (declaredLevels.size > 1) errors.push(`Realization identity is declared at multiple levels: ${identifier}.`);
  const candidatePairs = new Set(ptcIdentifiers.flatMap((ptcIdentifier) => levels.flatMap((level) => realizationsByLevel.get(level)!.map((realizationIdentifier) => pair(ptcIdentifier, realizationIdentifier)))));
  const applicability = new Map<string, Set<string>>();
  for (const item of interpretation.publicationTestCaseApplicability) {
    const key = pair(item.ptcIdentifier, item.realizationIdentifier);
    if (!candidatePairs.has(key)) continue;
    const values = applicability.get(key) ?? new Set<string>();
    values.add(item.status);
    applicability.set(key, values);
  }
  const applicablePairs = new Set([...candidatePairs].filter((key) => {
    const values = applicability.get(key);
    return values?.size === 1 && values.has("applicable");
  }));
  const notApplicablePairs = new Set([...candidatePairs].filter((key) => {
    const values = applicability.get(key);
    return values?.size === 1 && values.has("not-applicable");
  }));
  const resolvedByPair = new Map<string, Set<string>>();
  for (const exercise of interpretation.resolvedExercises) {
    const key = pair(exercise.ptc.identifier, exercise.realization.identifier);
    if (!candidatePairs.has(key)) continue;
    const rtcms = resolvedByPair.get(key) ?? new Set<string>();
    rtcms.add(exercise.rtcm.identifier);
    resolvedByPair.set(key, rtcms);
  }
  const resolvedPairs = new Set([...resolvedByPair].filter(([, rtcms]) => rtcms.size === 1).map(([key]) => key));
  const enabledPairs = new Set<string>();
  for (const key of resolvedPairs) {
    const separator = key.indexOf("\u0000");
    const ptcIdentifier = key.slice(0, separator);
    const realizationIdentifier = key.slice(separator + 1);
    const rtcmIdentifier = [...resolvedByPair.get(key)!][0]!;
    const matches = invocationSupport.filter((item) => item.ptcIdentifier === ptcIdentifier && item.realizationIdentifier === realizationIdentifier && item.rtcmIdentifier === rtcmIdentifier);
    if (matches.length > 1) errors.push(`Invocation support is not unique for ${ptcIdentifier} × ${realizationIdentifier} × ${rtcmIdentifier}.`);
    if (matches.length === 1 && matches[0]!.executable) enabledPairs.add(key);
  }
  for (const key of resolvedPairs) if (!applicablePairs.has(key)) errors.push(`Resolved exercise is not deterministically applicable: ${key.replace("\u0000", " × ")}.`);
  for (const key of enabledPairs) if (!resolvedPairs.has(key)) errors.push(`Enabled exercise is not uniquely resolved: ${key.replace("\u0000", " × ")}.`);

  const rows = levels.map((level) => {
    const realizationIdentifiers = new Set(realizationsByLevel.get(level)!);
    const belongs = (key: string): boolean => realizationIdentifiers.has(key.slice(key.indexOf("\u0000") + 1));
    const possible = [...candidatePairs].filter(belongs).length;
    const applicable = [...applicablePairs].filter(belongs).length;
    const rtcmResolved = [...resolvedPairs].filter(belongs).length;
    const exerciseEnabled = [...enabledPairs].filter(belongs).length;
    const notApplicable = [...notApplicablePairs].filter(belongs).length;
    const values = { possible, applicable, rtcmResolved, exerciseEnabled, blocked: applicable - exerciseEnabled, notApplicable, unclassified: possible - applicable - notApplicable };
    if (values.possible !== values.applicable + values.notApplicable + values.unclassified) errors.push(`${level} Possible partition invariant failed.`);
    if (values.applicable !== values.exerciseEnabled + values.blocked) errors.push(`${level} Applicable partition invariant failed.`);
    if (!(values.exerciseEnabled <= values.rtcmResolved && values.rtcmResolved <= values.applicable && values.applicable <= values.possible)) errors.push(`${level} exercise hierarchy invariant failed.`);
    return row(level, values);
  });
  const totalValues = {
    possible: rows.reduce((sum, item) => sum + item.possible, 0),
    applicable: rows.reduce((sum, item) => sum + item.applicable, 0),
    rtcmResolved: rows.reduce((sum, item) => sum + item.rtcmResolved, 0),
    exerciseEnabled: rows.reduce((sum, item) => sum + item.exerciseEnabled, 0),
    blocked: rows.reduce((sum, item) => sum + item.blocked, 0),
    notApplicable: rows.reduce((sum, item) => sum + item.notApplicable, 0),
    unclassified: rows.reduce((sum, item) => sum + item.unclassified, 0)
  };
  const allRows = Object.freeze([...rows, row("total", totalValues)]);
  return Object.freeze({
    status: errors.length ? "projection-error" : "available",
    population: "ptc-by-unique-realization",
    supportAssessmentBasis: "active-context-latest-assessment",
    rows: allRows,
    errors: Object.freeze(errors),
    statement: ptcIdentifiers.length === 0
      ? "Pairing coverage is unavailable because no Publication Test Cases are declared."
      : "Pairing coverage counts exact Publication Test Case × unique realization identities. Enabled reflects the active context's latest invocation-support assessment, not execution or conformance."
  });
}
