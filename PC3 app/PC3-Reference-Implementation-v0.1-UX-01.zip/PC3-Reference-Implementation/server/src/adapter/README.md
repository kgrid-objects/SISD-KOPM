# External Execution Adapter Foundation

DEV-11 introduces a PC3-owned adapter contract and registry. The first reference adapter launches a separate local operating-system process and exchanges the Exercise Attempt input over standard input/output.

The adapter coordinates the boundary; it is not the runtime. EX-03B adds explicit capability matching without fallback. EX-03C keeps that separation: the selected adapter captures the Docker client process while a distinct Docker environment provider supplies the digest-pinned disposable container in which the publication-declared adapter artifact runs. Realization identity assurance remains reported-only.
