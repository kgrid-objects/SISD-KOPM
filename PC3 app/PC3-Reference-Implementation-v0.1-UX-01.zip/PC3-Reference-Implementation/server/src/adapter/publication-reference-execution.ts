import { chmod, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, relative, resolve } from "node:path";
import { parse as parseYaml } from "yaml";
import type { ExerciseAttempt } from "../operation/model.js";
import type { ResolvedExercise } from "../publication/publication-exercise-model.js";
import type { AcquiredPublication } from "../publication/source-adapter.js";
import type { RtcmInvocationPlan } from "./model.js";
import { AdapterCapabilityResolutionError, type InvocationCapabilityMatch, type InvocationCapabilityRequest } from "./execution-adapter-registry.js";
import type { DockerEnvironmentProvider } from "../environment/docker-environment-provider.js";

type JsonObject = Record<string, unknown>;
type DeclarationIdentityField = RtcmInvocationPlan["declarationIdentityField"];

export class ReferenceExecutionPlanningError extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
    this.name = "ReferenceExecutionPlanningError";
  }
}

export interface MaterializedReferenceExecution {
  readonly plan: RtcmInvocationPlan;
  readonly workingDirectory: string;
  readonly adapterPath?: string;
  readonly infrastructureDirectory?: string;
  cleanup(): Promise<void>;
}

export interface RtcmInvocationSupportAssessment {
  readonly ptcIdentifier: string;
  readonly realizationIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly executable: boolean;
  readonly code: string;
  readonly reason: string;
}

function object(value: unknown): JsonObject | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as JsonObject : undefined;
}

function string(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function immutableSnapshot<T>(value: T): T {
  const clone = structuredClone(value);
  const freeze = (candidate: unknown): void => {
    if (!candidate || typeof candidate !== "object" || Object.isFrozen(candidate)) return;
    for (const child of Object.values(candidate)) freeze(child);
    Object.freeze(candidate);
  };
  freeze(clone);
  return clone;
}

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

function declarationMentionsIdentity(declaration: string, identities: readonly string[]): boolean {
  const normalized = declaration.toLowerCase().replaceAll("-", "_");
  return identities.some((identity) => normalized.includes(identity.toLowerCase().replaceAll("-", "_")));
}

function isDotnet8Runtime(value: string | undefined): boolean {
  const normalized = value?.trim().toLowerCase();
  return normalized === ".net 8" || normalized === "dotnet 8" || normalized === "c# / .net / native aot target";
}

function declarationIdentityFields(realizationType: ResolvedExercise["realization"]["realizationType"]): readonly DeclarationIdentityField[] {
  const typedField: DeclarationIdentityField = realizationType === "implementation-representation"
    ? "implementation_representation_id"
    : realizationType === "service-realization"
      ? "service_realization_id"
      : "deployment_package_id";
  return realizationType === "implementation-representation" ? [typedField, "representation_id", "realization_id"] : [typedField, "realization_id"];
}

const PYTHON_LIBRARY_BRIDGE = `import argparse, contextlib, hashlib, importlib, io, json, sys, traceback
parser = argparse.ArgumentParser()
parser.add_argument("--source-root", required=True)
parser.add_argument("--entry-point", required=True)
parser.add_argument("--bindings-json", required=True)
args = parser.parse_args()
diagnostic_out, diagnostic_err = io.StringIO(), io.StringIO()
envelope = {"schema":"pc3.python-library-return.v1"}
try:
    sys.path.insert(0, args.source_root)
    module_name, function_name = args.entry_point.rsplit(".", 1)
    bindings = json.loads(args.bindings_json)
    with contextlib.redirect_stdout(diagnostic_out), contextlib.redirect_stderr(diagnostic_err):
        value = getattr(importlib.import_module(module_name), function_name)(**bindings)
    envelope.update({"status":"returned","value":value,"diagnosticStdout":diagnostic_out.getvalue(),"diagnosticStderr":diagnostic_err.getvalue()})
except Exception:
    envelope.update({"status":"exception","diagnosticStdout":diagnostic_out.getvalue(),"diagnosticStderr":diagnostic_err.getvalue(),"exception":traceback.format_exc()})
payload = json.dumps(envelope, sort_keys=True, separators=(",",":"), allow_nan=False)
sys.stdout.write(payload)
sys.exit(0 if envelope["status"] == "returned" else 70)
`;

const PYTHON_HTTP_LOOPBACK_BRIDGE = `import argparse, hashlib, http.client, json, os, subprocess, sys, threading, traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
parser = argparse.ArgumentParser()
parser.add_argument("--adapter", required=True)
parser.add_argument("--source-root", required=True)
parser.add_argument("--method", required=True)
parser.add_argument("--route", required=True)
parser.add_argument("--request-json", required=True)
args = parser.parse_args()
transfer = {"schema":"pc3.python-http-loopback.v1"}
class Handler(BaseHTTPRequestHandler):
    adapter_envelope = ""
    adapter_stderr = ""
    adapter_evidence = None
    failure = None
    def log_message(self, *_):
        return
    def do_POST(self):
        try:
            if args.method != "POST" or self.path != args.route:
                raise RuntimeError("The loopback request did not match the declared HTTP method and route.")
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > 5000000:
                raise RuntimeError("The HTTP request body exceeded the bounded bridge limit.")
            body = self.rfile.read(length).decode("utf-8")
            env = dict(os.environ)
            env["PYTHONPATH"] = args.source_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
            completed = subprocess.run([sys.executable, args.adapter], input=body, text=True, capture_output=True, timeout=20, env=env)
            Handler.adapter_envelope = completed.stdout
            Handler.adapter_stderr = completed.stderr
            if completed.returncode != 0:
                raise RuntimeError("The declared REST adapter exited unsuccessfully.")
            adapter_result = json.loads(completed.stdout)
            response = adapter_result.get("response")
            if not isinstance(response, dict) or not isinstance(response.get("status"), int) or not isinstance(response.get("body"), dict):
                raise RuntimeError("The declared REST adapter did not return its declared response envelope.")
            Handler.adapter_evidence = adapter_result.get("evidence")
            response_body = json.dumps(response["body"], sort_keys=True, separators=(",",":"), allow_nan=False)
            self.send_response(response["status"])
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_body.encode("utf-8"))))
            self.end_headers()
            self.wfile.write(response_body.encode("utf-8"))
        except Exception:
            Handler.failure = traceback.format_exc()
            response_body = json.dumps({"error":{"code":"PC3_HTTP_ARRANGEMENT_FAILURE","message":"The declared REST adapter arrangement failed."}}, sort_keys=True, separators=(",",":"))
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_body.encode("utf-8"))))
            self.end_headers()
            self.wfile.write(response_body.encode("utf-8"))
server = HTTPServer(("127.0.0.1", 0), Handler)
thread = threading.Thread(target=server.handle_request, daemon=True)
thread.start()
try:
    connection = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=25)
    connection.request(args.method, args.route, body=args.request_json.encode("utf-8"), headers={"Content-Type":"application/json","Accept":"application/json"})
    response = connection.getresponse()
    response_body = response.read().decode("utf-8")
    headers = {key.lower(): value for key, value in response.getheaders()}
    thread.join(timeout=5)
    if Handler.failure:
        raise RuntimeError(Handler.failure)
    transfer.update({"status":"returned","method":args.method,"route":args.route,"requestBody":args.request_json,"statusCode":response.status,"responseHeaders":headers,"responseBody":response_body,"adapterEnvelope":Handler.adapter_envelope,"adapterEnvelopeSha256":hashlib.sha256(Handler.adapter_envelope.encode("utf-8")).hexdigest(),"adapterStderr":Handler.adapter_stderr,"adapterEvidence":Handler.adapter_evidence})
except Exception:
    transfer.update({"status":"exception","exception":traceback.format_exc(),"adapterEnvelope":Handler.adapter_envelope,"adapterStderr":Handler.adapter_stderr})
finally:
    connection.close() if "connection" in locals() else None
    server.server_close()
payload = json.dumps(transfer, sort_keys=True, separators=(",",":"), allow_nan=False)
sys.stdout.write(payload)
sys.exit(0 if transfer["status"] == "returned" else 70)
`;

function xmlAttribute(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function dotnetCliBridgeProject(invocation: NonNullable<RtcmInvocationPlan["dotnetCliInvocation"]>): string {
  const entry = xmlAttribute(`/workspace/${invocation.adapterEntryPointReference}`);
  const sources = xmlAttribute(`/workspace/${invocation.implementationSourceRootReference}/*.cs`);
  return `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>${invocation.targetFramework}</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <UseAppHost>false</UseAppHost>
    <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="${entry}" Link="PublicationAdapterEntryPoint.cs" />
    <Compile Include="${sources}" Link="Implementation/%(Filename)%(Extension)" />
  </ItemGroup>
</Project>
`;
}

function assertSafeRelativePath(path: string): void {
  const normalized = path.replaceAll("\\", "/");
  if (isAbsolute(normalized) || normalized.split("/").some((part) => part === "..")) {
    throw new ReferenceExecutionPlanningError("unsafe_publication_resource_path", "The publication contains a resource path that cannot be materialized safely.");
  }
}

export class PublicationReferenceExecutionPlanner {
  constructor(
    private readonly capabilityResolver?: { resolveCapability(request: InvocationCapabilityRequest): InvocationCapabilityMatch },
    private readonly environmentProvider?: DockerEnvironmentProvider
  ) {}

  private async resolveDotnetCli(
    exercise: ResolvedExercise,
    publication: AcquiredPublication,
    declaration: { resourcePath: string; document: JsonObject },
    adapterArtifactReference: string
  ): Promise<NonNullable<RtcmInvocationPlan["dotnetCliInvocation"]>> {
    if (exercise.realization.realizationType !== "service-realization") {
      throw new ReferenceExecutionPlanningError("dotnet_cli_realization_type_not_supported", "The .NET 8 CLI bridge supports only an explicitly declared Service Realization.");
    }
    const adapter = object(declaration.document.adapter);
    const binding = object(declaration.document.adapter_binding);
    const bindingEntry = object(binding?.entry_point);
    const projectReference = string(adapter?.project_file);
    const sourceRoot = string(binding?.implementation_representation_path);
    if (!projectReference || !sourceRoot || string(binding?.runtime_resolution) !== "relative_to_uko_root" || string(binding?.binding_type) !== "dotnet_project_reference_static_method") {
      throw new ReferenceExecutionPlanningError("dotnet_cli_declaration_incomplete", "The .NET CLI realization must explicitly declare its project file, publication-root implementation source path, runtime resolution, and static-method binding type.");
    }
    if (![string(bindingEntry?.namespace), string(bindingEntry?.class), string(bindingEntry?.method)].every(Boolean)) {
      throw new ReferenceExecutionPlanningError("dotnet_cli_entry_point_incomplete", "The .NET CLI realization does not explicitly identify the bound implementation namespace, class, and method.");
    }
    const projectFileReference = resolvePublicationReference(declaration.resourcePath, projectReference);
    assertSafeRelativePath(sourceRoot);
    const declaredSourceRoot = sourceRoot.replaceAll("\\", "/").replace(/\/$/, "");
    const projectResource = publication.resources.find((resource) => resource.path === projectFileReference);
    if (!projectResource) throw new ReferenceExecutionPlanningError("dotnet_cli_project_missing", `The declared .NET project file is absent: ${projectFileReference}.`);
    const projectXml = Buffer.from(await projectResource.readBytes()).toString("utf8");
    if (!/<TargetFramework>\s*net8\.0\s*<\/TargetFramework>/i.test(projectXml)) {
      throw new ReferenceExecutionPlanningError("dotnet_cli_target_framework_not_supported", "The declared .NET CLI project does not target net8.0.");
    }
    const sourceMarker = `/${declaredSourceRoot}/`;
    const sourceRoots = new Set(publication.resources.filter((resource) => /\.cs$/i.test(resource.path)).flatMap((resource) => {
      if (resource.path.startsWith(`${declaredSourceRoot}/`)) return [declaredSourceRoot];
      const markerIndex = resource.path.indexOf(sourceMarker);
      return markerIndex < 0 ? [] : [`${resource.path.slice(0, markerIndex + 1)}${declaredSourceRoot}`];
    }));
    if (sourceRoots.size !== 1) {
      throw new ReferenceExecutionPlanningError("dotnet_cli_source_root_missing", `The declared .NET implementation source root must resolve once and contain C# sources; found ${sourceRoots.size} matches for ${declaredSourceRoot}.`);
    }
    const implementationSourceRootReference = [...sourceRoots][0]!;
    const implementationProjects = publication.resources.filter((resource) => resource.path.startsWith(`${implementationSourceRootReference}/`) && /\.csproj$/i.test(resource.path));
    if (implementationProjects.length !== 1) {
      throw new ReferenceExecutionPlanningError("dotnet_cli_implementation_project_not_unique", `The declared .NET implementation source root must contain exactly one project file; found ${implementationProjects.length}.`);
    }
    const implementationProjectXml = Buffer.from(await implementationProjects[0]!.readBytes()).toString("utf8");
    if (!/<TargetFramework>\s*net8\.0\s*<\/TargetFramework>/i.test(implementationProjectXml)) {
      throw new ReferenceExecutionPlanningError("dotnet_cli_implementation_framework_not_supported", "The declared .NET implementation project does not target net8.0.");
    }
    return Object.freeze({
      bridgeId: "pc3.dotnet-cli-source.v1" as const,
      projectFileReference,
      adapterEntryPointReference: adapterArtifactReference,
      implementationSourceRootReference,
      implementationProjectReference: implementationProjects[0]!.path,
      serviceDeclarationReference: declaration.resourcePath,
      targetFramework: "net8.0" as const
    });
  }

  private async resolveLibrary(exercise: ResolvedExercise, publication: AcquiredPublication, canonical: JsonObject) {
    if (exercise.realization.realizationType !== "implementation-representation") throw new ReferenceExecutionPlanningError("library_realization_type_not_supported", "Library invocation is supported only for an explicitly declared Implementation Representation.");
    if (exercise.rtcm.observationDerivation.rawObservationLocation?.toLowerCase() !== "return-value" || !exercise.rtcm.observationDerivation.rawObservationMustBePreserved) throw new ReferenceExecutionPlanningError("library_return_contract_invalid", "The RTCM must declare preservation of the language-level return value.");
    const candidates: Array<{ resourcePath: string; document: JsonObject }> = [];
    for (const resource of publication.resources.filter((candidate) => /representation\.ya?ml$/i.test(candidate.path))) {
      try {
        const document = object(parseYaml(Buffer.from(await resource.readBytes()).toString("utf8")));
        if (document && string(document.representation_id) === exercise.realization.identifier && string(document.canonical_entry_point) && string(document.location) && string(document.language)) candidates.push({ resourcePath: resource.path, document });
      } catch { /* unrelated representation material */ }
    }
    if (candidates.length !== 1) throw new ReferenceExecutionPlanningError("rtcm_realization_declaration_not_unique", `Expected exactly one explicit primary representation declaration for realization ${exercise.realization.identifier}; found ${candidates.length}.`);
    const declaration = candidates[0]!;
    const contractReference = string(declaration.document.execution_contract);
    if (!contractReference) throw new ReferenceExecutionPlanningError("library_execution_contract_missing", "The representation does not explicitly reference an execution contract.");
    const contractPath = resolvePublicationReference(declaration.resourcePath, contractReference);
    const contractResource = publication.resources.find((resource) => resource.path === contractPath);
    if (!contractResource) throw new ReferenceExecutionPlanningError("library_execution_contract_missing", `The declared execution contract is absent: ${contractPath}.`);
    const contract = object(parseYaml(Buffer.from(await contractResource.readBytes()).toString("utf8")));
    const contractEntry = object(contract?.entry_point);
    const entryPoint = string(declaration.document.canonical_entry_point);
    if (!contract || string(contract.representation_id) !== exercise.realization.identifier || string(contractEntry?.name) !== entryPoint || string(contractEntry?.kind) !== "language_function") throw new ReferenceExecutionPlanningError("library_entry_point_inconsistent", "The primary representation declaration and referenced execution contract do not identify one matching language-function entry point.");
    const signature = Array.isArray(contract.input_signature) ? contract.input_signature.map(object) : [];
    const rtcmBindings = exercise.rtcm.inputDerivation.bindings;
    if (!rtcmBindings.length || rtcmBindings.length !== signature.length) throw new ReferenceExecutionPlanningError("library_binding_arity_mismatch", "The RTCM bindings and execution-contract input signature do not have the same non-zero arity.");
    const seenCanonical = new Set<string>(); const seenParameters = new Set<string>();
    const namedBindings = rtcmBindings.map((binding, index) => {
      if (binding.bindingKind?.toLowerCase() !== "named" || binding.transformation?.toLowerCase() !== "identity" || (binding.unitMapping && binding.unitMapping.toLowerCase() !== "identity")) throw new ReferenceExecutionPlanningError("library_binding_not_identity_named", `Binding for ${binding.canonicalField} is not a supported named identity binding.`);
      const parameter = string(signature[index]?.name);
      if (!parameter || seenCanonical.has(binding.canonicalField) || seenParameters.has(parameter)) throw new ReferenceExecutionPlanningError("library_binding_ambiguous", "The explicit named bindings are missing, duplicate, or ambiguous.");
      if (!(binding.canonicalField in canonical)) throw new ReferenceExecutionPlanningError("reference_canonical_field_missing", `The canonical input snapshot does not contain ${binding.canonicalField}.`);
      seenCanonical.add(binding.canonicalField); seenParameters.add(parameter);
      return Object.freeze({ canonicalField: binding.canonicalField, rtcmLocalBinding: binding.localBinding, parameter, value: immutableSnapshot(canonical[binding.canonicalField]) });
    });
    const sourceRootReference = resolvePublicationReference(declaration.resourcePath, string(declaration.document.location)!);
    const prefix = sourceRootReference.endsWith("/") ? sourceRootReference : `${sourceRootReference}/`;
    if (!publication.resources.some((resource) => resource.path.startsWith(prefix))) throw new ReferenceExecutionPlanningError("library_source_root_missing", `The declared source root is absent: ${sourceRootReference}.`);
    return Object.freeze({
      declaration, contractPath, entryPoint: entryPoint!, sourceRootReference,
      runtimeRequirement: string(declaration.document.language)!,
      namedBindings: Object.freeze(namedBindings)
    });
  }

  private async resolveHttp(exercise: ResolvedExercise, publication: AcquiredPublication, canonical: JsonObject) {
    if (exercise.realization.realizationType !== "service-realization") throw new ReferenceExecutionPlanningError("http_realization_type_not_supported", "HTTP invocation is supported only for an explicitly declared Service Realization.");
    if (exercise.rtcm.observationDerivation.rawObservationLocation?.toLowerCase() !== "response-field" || !exercise.rtcm.observationDerivation.rawObservationMustBePreserved) throw new ReferenceExecutionPlanningError("http_response_contract_invalid", "The RTCM must declare preservation of a raw HTTP response-field observation.");
    const documents: Array<{ resourcePath: string; document: JsonObject }> = [];
    for (const resource of publication.resources.filter((candidate) => /\.ya?ml$/i.test(candidate.path))) {
      try { const document = object(parseYaml(Buffer.from(await resource.readBytes()).toString("utf8"))); if (document) documents.push({ resourcePath: resource.path, document }); } catch { /* unrelated YAML */ }
    }
    const metadata = documents.filter(({ document }) => {
      const describes = object(document.describes);
      return string(describes?.identifier) === exercise.realization.identifier && string(describes?.parentLayerIdentifier) === "UKO-LAYER-SR";
    });
    if (metadata.length !== 1) throw new ReferenceExecutionPlanningError("http_realization_metadata_not_unique", `Expected exactly one explicit Service Realization metadata declaration for ${exercise.realization.identifier}; found ${metadata.length}.`);
    const describes = object(metadata[0]!.document.describes)!;
    if (string(describes.architecturalType)?.toLowerCase() !== "rest api") throw new ReferenceExecutionPlanningError("http_architectural_type_not_supported", "The selected Service Realization is not explicitly typed as a REST API.");
    const applicable = object(object(describes.instanceArchitecture)?.applicableInformation);
    const references = Array.isArray(applicable?.complementaryMetadataArtifacts) ? applicable!.complementaryMetadataArtifacts.map(string).filter((item): item is string => Boolean(item)) : [];
    const complementary = references.map((reference) => {
      const resourcePath = resolveDeclaredRootReference(publication, reference);
      return documents.find((candidate) => candidate.resourcePath === resourcePath);
    }).filter((item): item is { resourcePath: string; document: JsonObject } => Boolean(item));
    const services = complementary.filter(({ document }) => string(document.service_mode)?.toLowerCase() === "rest" && string(document.adapter) && string(document.binding));
    if (services.length !== 1) throw new ReferenceExecutionPlanningError("http_service_declaration_not_unique", `Expected exactly one explicitly associated REST service declaration; found ${services.length}.`);
    const service = services[0]!;
    const bindingReference = resolvePublicationReference(service.resourcePath, string(service.document.binding)!);
    if (!references.some((reference) => resolveDeclaredRootReference(publication, reference) === bindingReference)) throw new ReferenceExecutionPlanningError("http_binding_not_associated", "The service's REST binding is not explicitly associated by the Service Realization metadata.");
    const binding = documents.find((candidate) => candidate.resourcePath === bindingReference);
    if (!binding || string(binding.document.service_mode)?.toLowerCase() !== "rest" || string(binding.document.service_realization_id) !== string(service.document.service_realization_id)) throw new ReferenceExecutionPlanningError("http_binding_inconsistent", "The associated REST binding and service declaration do not identify the same service realization.");
    const adapterArtifactReference = resolvePublicationReference(service.resourcePath, string(service.document.adapter)!);
    if (!publication.resources.some((resource) => resource.path === adapterArtifactReference)) throw new ReferenceExecutionPlanningError("reference_adapter_asset_missing", `The declared REST adapter asset is absent: ${adapterArtifactReference}.`);
    if (!/\.py$/i.test(adapterArtifactReference)) throw new ReferenceExecutionPlanningError("http_adapter_runtime_not_supported", "EX-03E supports only an explicitly declared Python REST adapter.");
    const httpInterface = object(binding.document.http_interface);
    const method = string(httpInterface?.method)?.toUpperCase();
    const route = string(httpInterface?.route);
    if (method !== "POST" || !route?.startsWith("/") || route.startsWith("//") || route.includes("://") || string(httpInterface?.consumes)?.toLowerCase() !== "application/json" || string(httpInterface?.produces)?.toLowerCase() !== "application/json") throw new ReferenceExecutionPlanningError("http_interface_not_supported", "EX-03E requires one explicitly declared local POST route consuming and producing application/json.");
    const implementation = object(binding.document.implementation_representation);
    const implementationIdentifier = string(implementation?.id);
    const implementationEntryPoint = string(implementation?.canonical_entry_point);
    if (!implementationIdentifier || !implementationEntryPoint) throw new ReferenceExecutionPlanningError("http_implementation_binding_incomplete", "The REST binding does not explicitly identify its Implementation Representation and canonical entry point.");
    const representations = documents.filter(({ document }) => string(document.representation_id) === implementationIdentifier && string(document.canonical_entry_point) === implementationEntryPoint && string(document.language) && string(document.location));
    if (representations.length !== 1) throw new ReferenceExecutionPlanningError("http_implementation_declaration_not_unique", `Expected exactly one matching implementation declaration for ${implementationIdentifier}; found ${representations.length}.`);
    const representation = representations[0]!;
    const sourceRootReference = resolvePublicationReference(representation.resourcePath, string(representation.document.location)!);
    if (!publication.resources.some((resource) => resource.path.startsWith(`${sourceRootReference.replace(/\/$/, "")}/`))) throw new ReferenceExecutionPlanningError("http_implementation_source_root_missing", `The declared implementation source root is absent: ${sourceRootReference}.`);
    const requestMapping = object(binding.document.request_mapping);
    const parameters = Array.isArray(requestMapping?.parameters) ? requestMapping!.parameters.map(object).filter((item): item is JsonObject => Boolean(item)) : [];
    if (string(requestMapping?.source) !== "json_body" || string(requestMapping?.parameter_container) !== "body.inputs") throw new ReferenceExecutionPlanningError("http_request_mapping_not_supported", "The REST binding must explicitly map a JSON body through body.inputs.");
    const seen = new Set<string>();
    const resolvedBindingFields = exercise.rtcm.inputDerivation.bindings.map((rtcmBinding) => {
      if (rtcmBinding.transformation?.toLowerCase() !== "identity" || (rtcmBinding.unitMapping && rtcmBinding.unitMapping.toLowerCase() !== "identity")) throw new ReferenceExecutionPlanningError("http_binding_not_identity", `HTTP binding for ${rtcmBinding.canonicalField} is not an identity mapping.`);
      const matches = parameters.filter((parameter) => {
        const name = string(parameter.name);
        return (name === rtcmBinding.localBinding || name === rtcmBinding.canonicalField) && string(parameter.from) === `body.inputs.${name}` && parameter.required === true;
      });
      const requestField = string(matches[0]?.name);
      if (matches.length !== 1 || !requestField || seen.has(requestField)) throw new ReferenceExecutionPlanningError("http_request_binding_ambiguous", `The REST request mapping for ${rtcmBinding.canonicalField} / ${rtcmBinding.localBinding} is missing, duplicate, optional, or ambiguous.`);
      seen.add(requestField);
      return Object.freeze({ canonicalField: rtcmBinding.canonicalField, rtcmLocalBinding: rtcmBinding.localBinding, localBinding: requestField });
    });
    if (!resolvedBindingFields.length) throw new ReferenceExecutionPlanningError("http_request_binding_empty", "The HTTP RTCM does not declare any canonical request bindings.");
    const responseMapping = object(binding.document.response_mapping);
    const responseBody = object(responseMapping?.body);
    const responseValueMappings = Object.entries(responseBody ?? {}).filter(([, mapping]) => string(object(mapping)?.from) === "implementation.result");
    const responseValuePath = responseValueMappings[0]?.[0];
    if (responseMapping?.status_success !== 200 || responseValueMappings.length !== 1 || !responseValuePath || !/^[A-Za-z_][A-Za-z0-9_-]*$/u.test(responseValuePath)) {
      throw new ReferenceExecutionPlanningError("http_response_mapping_not_supported", "EX-03E-C1 requires one explicit successful response-body field mapped from implementation.result.");
    }
    let requestBindings: readonly { readonly canonicalField: string; readonly localBinding: string; readonly value: unknown }[];
    let requestBody: string;
    let negativeConditionPlan: RtcmInvocationPlan["negativeConditionPlan"];
    const negative = exercise.ptc.canonicalNegativeInputCondition;
    if (!negative) {
      requestBindings = Object.freeze(resolvedBindingFields.map((bindingField) => {
        if (!(bindingField.canonicalField in canonical)) throw new ReferenceExecutionPlanningError("reference_canonical_field_missing", `The canonical input snapshot does not contain ${bindingField.canonicalField}.`);
        return Object.freeze({ canonicalField: bindingField.canonicalField, localBinding: bindingField.localBinding, value: immutableSnapshot(canonical[bindingField.canonicalField]) });
      }));
      requestBody = JSON.stringify({ inputs: Object.fromEntries(requestBindings.map((item) => [item.localBinding, item.value])) });
    } else {
      const rtcmNegative = exercise.rtcm.inputDerivation.negativeConditionDerivation;
      const rejection = exercise.ptc.canonicalSemanticRejection;
      if (!rtcmNegative || !rejection) throw new ReferenceExecutionPlanningError("negative_condition_declaration_incomplete", "The negative PTC and exact RTCM do not provide a complete semantic rejection derivation.");
      if (exercise.comparisonSemantics.comparisonType.trim().toLowerCase() !== "semantic error comparison" || exercise.rtcm.comparison.comparisonType?.trim().toLowerCase() !== "semantic error comparison") throw new ReferenceExecutionPlanningError("negative_comparison_contract_incomplete", "The negative PTC and RTCM must both declare semantic error comparison.");
      const conditionType = negative.conditionType.trim().toLowerCase();
      let operation: NonNullable<RtcmInvocationPlan["negativeConditionPlan"]>["operation"];
      let semanticSubject: string;
      let localSubject: string | undefined;
      let expectedErrorCondition: NonNullable<RtcmInvocationPlan["negativeConditionPlan"]>["expectedErrorCondition"];
      let concreteInputs: unknown;
      if (conditionType === "missing required canonical predictor") {
        operation = "omit-required-binding";
        semanticSubject = negative.omittedCanonicalPredictor ?? "";
        const target = resolvedBindingFields.find((item) => item.canonicalField === semanticSubject);
        if (!semanticSubject || !target) throw new ReferenceExecutionPlanningError("negative_condition_declaration_incomplete", "The omitted canonical predictor does not resolve to one request binding.");
        localSubject = target.localBinding;
        if (!declarationMentionsIdentity(rtcmNegative.concreteDerivation, [semanticSubject, target.rtcmLocalBinding, target.localBinding])) throw new ReferenceExecutionPlanningError("negative_derivation_subject_mismatch", `The PTC requires omission of ${semanticSubject}, but the RTCM concrete derivation does not identify that subject or its exact mapped equivalent.`);
        const supplied = negative.suppliedCanonicalPredictors;
        if (!supplied) throw new ReferenceExecutionPlanningError("negative_condition_declaration_incomplete", "The missing-input PTC does not declare its other supplied canonical predictors.");
        requestBindings = Object.freeze(resolvedBindingFields.filter((item) => item.canonicalField !== semanticSubject).map((item) => {
          if (!(item.canonicalField in supplied)) throw new ReferenceExecutionPlanningError("negative_concrete_input_not_deterministic", `The negative PTC does not supply ${item.canonicalField}.`);
          return Object.freeze({ canonicalField: item.canonicalField, localBinding: item.localBinding, value: immutableSnapshot(supplied[item.canonicalField]) });
        }));
        concreteInputs = Object.fromEntries(requestBindings.map((item) => [item.localBinding, item.value]));
        expectedErrorCondition = "missing_required_parameter";
      } else if (conditionType === "nonnumeric required canonical predictor") {
        operation = "supply-invalid-lexical-value";
        semanticSubject = negative.invalidCanonicalPredictor ?? "";
        const target = resolvedBindingFields.find((item) => item.canonicalField === semanticSubject);
        if (!semanticSubject || !target || negative.illustrativeLexicalValue === undefined || !negative.otherSuppliedCanonicalPredictors) throw new ReferenceExecutionPlanningError("negative_condition_declaration_incomplete", "The invalid-value PTC does not completely declare its subject, illustrative value, and other supplied predictors.");
        localSubject = target.localBinding;
        if (!declarationMentionsIdentity(rtcmNegative.concreteDerivation, [semanticSubject, target.rtcmLocalBinding, target.localBinding])) throw new ReferenceExecutionPlanningError("negative_derivation_subject_mismatch", `The PTC requires an invalid value for ${semanticSubject}, but the RTCM concrete derivation identifies a different subject.`);
        requestBindings = Object.freeze(resolvedBindingFields.map((item) => {
          const value = item.canonicalField === semanticSubject ? negative.illustrativeLexicalValue : negative.otherSuppliedCanonicalPredictors![item.canonicalField];
          if (value === undefined) throw new ReferenceExecutionPlanningError("negative_concrete_input_not_deterministic", `The negative PTC does not supply ${item.canonicalField}.`);
          return Object.freeze({ canonicalField: item.canonicalField, localBinding: item.localBinding, value: immutableSnapshot(value) });
        }));
        concreteInputs = Object.fromEntries(requestBindings.map((item) => [item.localBinding, item.value]));
        expectedErrorCondition = "invalid_parameter_type";
      } else if (conditionType === "structurally unusable canonical input aggregate") {
        operation = "supply-invalid-aggregate-shape";
        semanticSubject = rejection.subject;
        if (negative.illustrativeInvalidAggregate === undefined || !/aggregate|structure|association/iu.test(`${rtcmNegative.semanticCondition} ${rtcmNegative.concreteDerivation}`)) throw new ReferenceExecutionPlanningError("negative_derivation_kind_mismatch", "The RTCM does not preserve the PTC's invalid aggregate-structure condition.");
        requestBindings = Object.freeze([]);
        concreteInputs = immutableSnapshot(negative.illustrativeInvalidAggregate);
        expectedErrorCondition = "invalid_request_shape";
      } else {
        throw new ReferenceExecutionPlanningError("negative_ptc_condition_not_supported", `Negative PTC condition is not supported by EX-03F: ${negative.conditionType}.`);
      }
      const errorMapping = object(binding.document.error_mapping);
      const errorMappings = Array.isArray(errorMapping?.errors) ? errorMapping!.errors.map(object).filter((item): item is JsonObject => Boolean(item)) : [];
      const matchingErrors = errorMappings.filter((item) => string(item.condition) === expectedErrorCondition && Number.isInteger(item.status) && string(item.code));
      if (errorMapping?.standard_error_object !== true || matchingErrors.length !== 1) throw new ReferenceExecutionPlanningError("negative_error_mapping_not_unique", `The REST binding does not declare one standard error mapping for ${expectedErrorCondition}.`);
      const error = matchingErrors[0]!;
      requestBody = JSON.stringify({ inputs: concreteInputs });
      negativeConditionPlan = Object.freeze({
        inputSource: "publication-derived-negative" as const,
        operation,
        conditionType: negative.conditionType,
        semanticSubject,
        ...(localSubject ? { localSubject } : {}),
        semanticCondition: rtcmNegative.semanticCondition,
        concreteDerivation: rtcmNegative.concreteDerivation,
        ...(rtcmNegative.mustNotConflateWith ? { mustNotConflateWith: rtcmNegative.mustNotConflateWith } : {}),
        expectedCategory: rejection.category,
        expectedErrorCondition,
        expectedErrorCode: string(error.code)!,
        declaredStatus: Number(error.status),
        requestBodySha256: sha256(requestBody),
        ptcDeclarationProvenance: immutableSnapshot(negative.provenance),
        rtcmDeclarationProvenance: immutableSnapshot(exercise.rtcm.provenance),
        bindingDeclarationResourcePath: binding.resourcePath
      });
    }
    return Object.freeze({ metadata: metadata[0]!, service, binding, adapterArtifactReference, representation, sourceRootReference, implementationIdentifier, implementationEntryPoint, method: "POST" as const, route, requestBody, requestBodySha256: sha256(requestBody), requestBindings: Object.freeze(requestBindings), responseValuePath, runtimeRequirement: string(representation.document.language)!, ...(negativeConditionPlan ? { negativeConditionPlan } : {}) });
  }

  async assessAll(exercises: readonly ResolvedExercise[], publication: AcquiredPublication): Promise<readonly RtcmInvocationSupportAssessment[]> {
    const documents: Array<{ resourcePath: string; document: JsonObject }> = [];
    for (const resource of publication.resources.filter((candidate) => /\.ya?ml$/i.test(candidate.path))) {
      try {
        const document = object(parseYaml(Buffer.from(await resource.readBytes()).toString("utf8")));
        if (document) documents.push({ resourcePath: resource.path, document });
      } catch {
        // Unrelated malformed YAML remains an interpretation concern, not invocation support.
      }
    }
    const resourcePaths = new Set(publication.resources.map((resource) => resource.path));
    const environmentAssessments = new Map<string, Promise<Awaited<ReturnType<NonNullable<typeof this.environmentProvider>["assess"]>>>>();
    return Object.freeze(await Promise.all(exercises.map(async (exercise) => {
      const result = (executable: boolean, code: string, reason: string): RtcmInvocationSupportAssessment => Object.freeze({
        ptcIdentifier: exercise.ptc.identifier,
        realizationIdentifier: exercise.realization.identifier,
        rtcmIdentifier: exercise.rtcm.identifier,
        executable,
        code,
        reason
      });
      try {
        if (exercise.rtcm.invocation.mode.toLowerCase() === "library") {
          const canonical = object(exercise.canonicalInput.value);
          if (!canonical) return result(false, "reference_canonical_input_invalid", "The canonical input is not a JSON object.");
          const library = await this.resolveLibrary(exercise, publication, canonical);
          if (!this.capabilityResolver) return result(false, "adapter_capability_resolver_unavailable", "Adapter capability resolution is unavailable.");
          const match = this.capabilityResolver.resolveCapability({ invocationMode: "library", realizationType: exercise.realization.realizationType, observationLocation: "return-value", rawObservationMustBePreserved: true, runtimeRequirement: library.runtimeRequirement });
          if (!this.environmentProvider) return result(false, "docker_environment_provider_unavailable", "The Docker environment provider is unavailable.");
          let assessment = environmentAssessments.get(match.canonicalRuntime);
          if (!assessment) { assessment = this.environmentProvider.assess(match.canonicalRuntime); environmentAssessments.set(match.canonicalRuntime, assessment); }
          const environment = await assessment;
          return environment.ready ? result(true, "executable", "Canonical exercise ready.") : result(false, environment.code, environment.reason);
        }
        if (exercise.rtcm.invocation.mode.toLowerCase() === "http") {
          const canonical = object(exercise.canonicalInput.value) ?? (exercise.ptc.canonicalNegativeInputCondition ? {} : undefined);
          if (!canonical) return result(false, "reference_canonical_input_invalid", "The canonical input is not a JSON object.");
          const http = await this.resolveHttp(exercise, publication, canonical);
          if (!this.capabilityResolver) return result(false, "adapter_capability_resolver_unavailable", "Adapter capability resolution is unavailable.");
          const match = this.capabilityResolver.resolveCapability({ invocationMode: "http", realizationType: exercise.realization.realizationType, observationLocation: "response-body", rawObservationMustBePreserved: true, runtimeRequirement: http.runtimeRequirement });
          if (!this.environmentProvider) return result(false, "docker_environment_provider_unavailable", "The Docker environment provider is unavailable.");
          let assessment = environmentAssessments.get(match.canonicalRuntime);
          if (!assessment) { assessment = this.environmentProvider.assess(match.canonicalRuntime); environmentAssessments.set(match.canonicalRuntime, assessment); }
          const environment = await assessment;
          return environment.ready ? result(true, "executable", "Canonical exercise ready.") : result(false, environment.code, environment.reason);
        }
        if (exercise.rtcm.invocation.mode.toLowerCase() !== "cli") return result(false, "rtcm_invocation_mode_not_supported", "Invocation mode not yet supported by PC3.");
        if (exercise.rtcm.observationDerivation.rawObservationLocation?.toLowerCase() !== "stdout" || !exercise.rtcm.observationDerivation.rawObservationMustBePreserved) {
          return result(false, "reference_stdout_contract_invalid", "The RTCM does not declare the supported raw-stdout preservation contract.");
        }
        const declarations = documents.flatMap((candidate) => {
          const identityField = declarationIdentityFields(exercise.realization.realizationType)
            .find((field) => string(candidate.document[field]) === exercise.realization.identifier);
          return identityField ? [{ ...candidate, identityField }] : [];
        });
        if (declarations.length !== 1) return result(false, "rtcm_realization_declaration_not_unique", `Expected exactly one explicit declaration for realization ${exercise.realization.identifier}; found ${declarations.length}.`);
        const declaration = declarations[0]!;
        const adapter = object(declaration.document.adapter);
        const binding = object(declaration.document.adapter_binding);
        const adapterEntry = string(object(binding?.adapter_entry_point)?.path) ?? string(adapter?.entry_point);
        const translations = object(binding?.input_translation);
        if (!adapterEntry || !translations) return result(false, "rtcm_cli_declaration_incomplete", "The realization declaration does not explicitly identify its CLI adapter entry point and input translation.");
        const adapterArtifactReference = resolvePublicationReference(declaration.resourcePath, adapterEntry);
        if (!resourcePaths.has(adapterArtifactReference)) return result(false, "reference_adapter_asset_missing", `The declared adapter asset is absent: ${adapterArtifactReference}.`);
        const canonical = object(exercise.canonicalInput.value);
        const argumentOrder = exercise.rtcm.invocation.argumentOrder;
        const optionEntries = Object.entries(translations).filter(([, localName]) => string(localName) && string(localName) !== "strict");
        if (!canonical || !argumentOrder.length || optionEntries.length !== argumentOrder.length) return result(false, "reference_binding_order_mismatch", "The canonical input, RTCM argument order, and CLI input translation cannot form one deterministic invocation.");
        const unsupportedField = argumentOrder.find((field) => !(field in canonical) || !["string", "number", "boolean"].includes(typeof canonical[field]));
        if (unsupportedField) return result(false, "reference_canonical_field_unsupported", `Canonical field ${unsupportedField} is missing or is not a CLI scalar.`);
        const runtimeField = (["language_or_ecosystem", "runtime", "runtime_requirement"] as const).find((field) => string(declaration.document[field]));
        const runtimeRequirement = runtimeField ? string(declaration.document[runtimeField]) : exercise.rtcm.invocation.externalEnvironmentRequirements.length === 1 ? exercise.rtcm.invocation.externalEnvironmentRequirements[0] : undefined;
        if (!runtimeRequirement) return result(false, "rtcm_runtime_requirement_not_unique", "No single explicit realization runtime is available to the current execution bridge.");
        if (!this.capabilityResolver) return result(false, "adapter_capability_resolver_unavailable", "Adapter capability resolution is unavailable.");
        const match = this.capabilityResolver.resolveCapability({
          invocationMode: exercise.rtcm.invocation.mode,
          realizationType: exercise.realization.realizationType,
          observationLocation: exercise.rtcm.observationDerivation.rawObservationLocation,
          rawObservationMustBePreserved: exercise.rtcm.observationDerivation.rawObservationMustBePreserved,
          runtimeRequirement
        });
        if (match.canonicalRuntime === ".NET 8") await this.resolveDotnetCli(exercise, publication, declaration, adapterArtifactReference);
        if (!this.environmentProvider) return result(false, "docker_environment_provider_unavailable", "The Docker environment provider is unavailable.");
        let assessment = environmentAssessments.get(match.canonicalRuntime);
        if (!assessment) { assessment = this.environmentProvider.assess(match.canonicalRuntime); environmentAssessments.set(match.canonicalRuntime, assessment); }
        const environment = await assessment;
        if (!environment.ready) return result(false, environment.code, environment.reason);
        return result(true, "executable", "Canonical exercise ready.");
      } catch (error) {
        return result(false, error instanceof ReferenceExecutionPlanningError || error instanceof AdapterCapabilityResolutionError ? error.code : "rtcm_invocation_assessment_failed", error instanceof Error ? error.message : "Invocation support could not be assessed.");
      }
    })));
  }

  async plan(attempt: ExerciseAttempt, exercise: ResolvedExercise, publication: AcquiredPublication): Promise<RtcmInvocationPlan> {
    if (attempt.exerciseDisposition !== "canonical" || (attempt.input.source !== "publication-canonical" && attempt.input.source !== "publication-derived-negative")) {
      throw new ReferenceExecutionPlanningError("canonical_rtcm_attempt_required", "RTCM invocation planning requires a publication-derived canonical Exercise Attempt.");
    }
    const attemptBinding = attempt.publicationExerciseBinding;
    if (!attemptBinding || exercise.ptc.identifier !== attemptBinding.ptcIdentifier || exercise.realization.identifier !== attemptBinding.realizationIdentifier || exercise.rtcm.identifier !== attemptBinding.rtcmIdentifier) {
      throw new ReferenceExecutionPlanningError("rtcm_invocation_binding_mismatch", "The immutable Exercise Attempt does not exactly match the supplied Resolved Exercise PTC, realization, and RTCM identities.");
    }
    if (exercise.rtcm.invocation.mode.toLowerCase() === "http") {
      let canonical: JsonObject;
      try { canonical = object(JSON.parse(attempt.input.value)) ?? (exercise.ptc.canonicalNegativeInputCondition ? {} : undefined) ?? {}; } catch { throw new ReferenceExecutionPlanningError("reference_canonical_input_invalid", "The immutable canonical input snapshot is not valid JSON."); }
      const http = await this.resolveHttp(exercise, publication, canonical);
      if (exercise.ptc.canonicalNegativeInputCondition && attempt.input.source !== "publication-derived-negative") throw new ReferenceExecutionPlanningError("negative_attempt_source_invalid", "A canonical negative PTC requires a publication-derived-negative Attempt snapshot.");
      if (!exercise.ptc.canonicalNegativeInputCondition && attempt.input.source !== "publication-canonical") throw new ReferenceExecutionPlanningError("canonical_attempt_source_invalid", "A positive canonical PTC requires a publication-canonical Attempt snapshot.");
      const runtimeRequirements = exercise.rtcm.invocation.externalEnvironmentRequirements.map((item) => item.trim()).filter(Boolean);
      return Object.freeze({
        pathIdentifier: `${exercise.ptc.identifier}×${exercise.realization.identifier}`,
        declarationResourcePath: http.metadata.resourcePath,
        declarationIdentityField: "describes.identifier",
        adapterArtifactReference: http.adapterArtifactReference,
        realizationIdentifier: exercise.realization.identifier, realizationType: exercise.realization.realizationType,
        ptcIdentifier: exercise.ptc.identifier, rtcmIdentifier: exercise.rtcm.identifier,
        invocationMode: "http", runtimeRequirements: Object.freeze(runtimeRequirements),
        runtimeDeclaration: Object.freeze({ value: http.runtimeRequirement, field: "language", resourcePath: http.representation.resourcePath }),
        arguments: Object.freeze([]),
        orderedBindings: Object.freeze(http.requestBindings.map((item) => Object.freeze({ canonicalField: item.canonicalField, option: `body.inputs.${item.localBinding}`, value: JSON.stringify(item.value) }))),
        responseMediaType: "application/json", observationLocation: "response-body", rawObservationMustBePreserved: true,
        httpInvocation: Object.freeze({ bridgeId: "pc3.python-http-loopback.v1", serviceDeclarationReference: http.service.resourcePath, bindingDeclarationReference: http.binding.resourcePath, implementationRepresentationIdentifier: http.implementationIdentifier, implementationSourceRootReference: http.sourceRootReference, implementationEntryPoint: http.implementationEntryPoint, method: http.method, route: http.route, requestMediaType: "application/json", responseMediaType: "application/json", responseValuePath: http.responseValuePath, requestBody: http.requestBody, requestBodySha256: http.requestBodySha256, requestBindings: http.requestBindings }),
        ...(http.negativeConditionPlan ? { negativeConditionPlan: http.negativeConditionPlan } : {}),
        ...(exercise.rtcm.observationDerivation.extractionExpression ? { extractionExpression: exercise.rtcm.observationDerivation.extractionExpression } : {}),
        ...(exercise.rtcm.observationDerivation.semanticOutcome ? { semanticOutcome: exercise.rtcm.observationDerivation.semanticOutcome } : {}),
        normalizationDeclarations: Object.freeze([...exercise.rtcm.observationDerivation.normalizations]), rtcmDeclarationProvenance: immutableSnapshot(exercise.rtcm.provenance),
        ...(exercise.comparisonSemantics.comparisonType ? { comparisonType: exercise.comparisonSemantics.comparisonType } : {}),
        ...(exercise.comparisonSemantics.absoluteTolerance !== undefined ? { absoluteTolerance: exercise.comparisonSemantics.absoluteTolerance } : {}),
        ...(exercise.comparisonSemantics.relativeTolerance !== undefined ? { relativeTolerance: exercise.comparisonSemantics.relativeTolerance } : {}),
        expectedOutcomeValue: immutableSnapshot(exercise.canonicalExpectedOutcome.value), expectedOutcomeKind: exercise.canonicalExpectedOutcome.outcomeKind,
        ...(exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath ? { normativeExpectedValuePath: exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath } : {}),
        ...(exercise.canonicalExpectedOutcome.authorityReference ? { expectedOutcomeAuthorityReference: exercise.canonicalExpectedOutcome.authorityReference } : {}),
        ...(exercise.comparisonSemantics.requiredRepresentation ? { requiredRepresentation: exercise.comparisonSemantics.requiredRepresentation } : {}),
        ...(exercise.comparisonSemantics.requiredUnit ? { requiredUnit: exercise.comparisonSemantics.requiredUnit } : {}),
        ...(exercise.comparisonSemantics.roundingPermittedBeforeComparison !== undefined ? { roundingPermittedBeforeComparison: exercise.comparisonSemantics.roundingPermittedBeforeComparison } : {}),
        semanticExtractionStrategy: http.negativeConditionPlan ? "semantic-rejection" : "json-declared-path",
        semanticObservationPath: http.responseValuePath
      } satisfies RtcmInvocationPlan);
    }
    if (exercise.rtcm.invocation.mode.toLowerCase() === "library") {
      let canonical: JsonObject;
      try { canonical = object(JSON.parse(attempt.input.value)) ?? {}; } catch { throw new ReferenceExecutionPlanningError("reference_canonical_input_invalid", "The immutable canonical input snapshot is not a JSON object."); }
      const library = await this.resolveLibrary(exercise, publication, canonical);
      const runtimeRequirements = exercise.rtcm.invocation.externalEnvironmentRequirements.map((item) => item.trim()).filter(Boolean);
      return Object.freeze({
        pathIdentifier: `${exercise.ptc.identifier}×${exercise.realization.identifier}`,
        declarationResourcePath: library.declaration.resourcePath,
        declarationIdentityField: "representation_id",
        realizationIdentifier: exercise.realization.identifier, realizationType: exercise.realization.realizationType,
        ptcIdentifier: exercise.ptc.identifier, rtcmIdentifier: exercise.rtcm.identifier,
        invocationMode: "library", runtimeRequirements: Object.freeze(runtimeRequirements),
        runtimeDeclaration: Object.freeze({ value: library.runtimeRequirement, field: "language", resourcePath: library.declaration.resourcePath }),
        arguments: Object.freeze([]), orderedBindings: Object.freeze([]), responseMediaType: "application/json",
        observationLocation: "return-value", rawObservationMustBePreserved: true,
        libraryInvocation: Object.freeze({ bridgeId: "pc3.python-library-return.v1", sourceRootReference: library.sourceRootReference, entryPoint: library.entryPoint, entryPointKind: "language_function", namedBindings: library.namedBindings, executionContractResourcePath: library.contractPath }),
        ...(exercise.rtcm.observationDerivation.extractionExpression ? { extractionExpression: exercise.rtcm.observationDerivation.extractionExpression } : {}),
        ...(exercise.rtcm.observationDerivation.semanticOutcome ? { semanticOutcome: exercise.rtcm.observationDerivation.semanticOutcome } : {}),
        normalizationDeclarations: Object.freeze([...exercise.rtcm.observationDerivation.normalizations]), rtcmDeclarationProvenance: immutableSnapshot(exercise.rtcm.provenance),
        ...(exercise.comparisonSemantics.comparisonType ? { comparisonType: exercise.comparisonSemantics.comparisonType } : {}),
        ...(exercise.comparisonSemantics.absoluteTolerance !== undefined ? { absoluteTolerance: exercise.comparisonSemantics.absoluteTolerance } : {}),
        ...(exercise.comparisonSemantics.relativeTolerance !== undefined ? { relativeTolerance: exercise.comparisonSemantics.relativeTolerance } : {}),
        expectedOutcomeValue: immutableSnapshot(exercise.canonicalExpectedOutcome.value), expectedOutcomeKind: exercise.canonicalExpectedOutcome.outcomeKind,
        ...(exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath ? { normativeExpectedValuePath: exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath } : {}),
        ...(exercise.canonicalExpectedOutcome.authorityReference ? { expectedOutcomeAuthorityReference: exercise.canonicalExpectedOutcome.authorityReference } : {}),
        ...(exercise.comparisonSemantics.requiredRepresentation ? { requiredRepresentation: exercise.comparisonSemantics.requiredRepresentation } : {}),
        ...(exercise.comparisonSemantics.requiredUnit ? { requiredUnit: exercise.comparisonSemantics.requiredUnit } : {}),
        ...(exercise.comparisonSemantics.roundingPermittedBeforeComparison !== undefined ? { roundingPermittedBeforeComparison: exercise.comparisonSemantics.roundingPermittedBeforeComparison } : {}),
        semanticExtractionStrategy: "direct-json-return-value"
      } satisfies RtcmInvocationPlan);
    }
    if (exercise.rtcm.invocation.mode.toLowerCase() !== "cli") {
      throw new ReferenceExecutionPlanningError("rtcm_invocation_mode_not_supported", `The current generic RTCM planner supports only explicitly declared CLI invocation; ${exercise.rtcm.invocation.mode || "no mode"} was declared.`);
    }
    if (exercise.rtcm.observationDerivation.rawObservationLocation?.toLowerCase() !== "stdout" || !exercise.rtcm.observationDerivation.rawObservationMustBePreserved) {
      throw new ReferenceExecutionPlanningError("reference_stdout_contract_invalid", "The resolved RTCM must declare raw stdout preservation.");
    }

    const declarations: Array<{ resourcePath: string; document: JsonObject; identityField: DeclarationIdentityField }> = [];
    for (const resource of publication.resources.filter((candidate) => /\.ya?ml$/i.test(candidate.path))) {
      try {
        const parsed = object(parseYaml(Buffer.from(await resource.readBytes()).toString("utf8")));
        if (!parsed) continue;
        const identityField = declarationIdentityFields(exercise.realization.realizationType)
          .find((candidate) => string(parsed[candidate]) === exercise.realization.identifier);
        if (identityField) declarations.push({ resourcePath: resource.path, document: parsed, identityField });
      } catch {
        // Other publication YAML resources remain outside this narrow declaration search.
      }
    }
    if (declarations.length !== 1) {
      throw new ReferenceExecutionPlanningError("rtcm_realization_declaration_not_unique", `Expected exactly one explicit declaration for realization ${exercise.realization.identifier}; found ${declarations.length}.`);
    }
    const declaration = declarations[0]!;
    const adapter = object(declaration.document.adapter);
    const binding = object(declaration.document.adapter_binding);
    const adapterEntry = string(object(binding?.adapter_entry_point)?.path) ?? string(adapter?.entry_point);
    const translations = object(binding?.input_translation);
    if (!adapterEntry || !translations) {
      throw new ReferenceExecutionPlanningError("rtcm_cli_declaration_incomplete", "The realization declaration does not explicitly identify its CLI adapter entry point and input translation.");
    }
    const adapterArtifactReference = resolvePublicationReference(declaration.resourcePath, adapterEntry);
    if (!publication.resources.some((resource) => resource.path === adapterArtifactReference)) {
      throw new ReferenceExecutionPlanningError("reference_adapter_asset_missing", `The declared adapter asset is absent: ${adapterArtifactReference}.`);
    }

    let canonical: JsonObject;
    try {
      canonical = object(JSON.parse(attempt.input.value)) ?? {};
    } catch {
      throw new ReferenceExecutionPlanningError("reference_canonical_input_invalid", "The immutable canonical input snapshot is not a JSON object.");
    }
    const argumentOrder = exercise.rtcm.invocation.argumentOrder;
    const optionEntries = Object.entries(translations).filter(([, localName]) => string(localName) && string(localName) !== "strict");
    if (!argumentOrder.length || optionEntries.length !== argumentOrder.length) {
      throw new ReferenceExecutionPlanningError("reference_binding_order_mismatch", "The RTCM argument order and service CLI input translation do not have the same arity.");
    }
    const orderedBindings = argumentOrder.map((canonicalField, index) => {
      if (!(canonicalField in canonical)) throw new ReferenceExecutionPlanningError("reference_canonical_field_missing", `The canonical input snapshot does not contain ${canonicalField}.`);
      const [option] = optionEntries[index]!;
      const value = canonical[canonicalField];
      if (!["string", "number", "boolean"].includes(typeof value)) throw new ReferenceExecutionPlanningError("reference_canonical_value_unsupported", `Canonical field ${canonicalField} is not a CLI scalar.`);
      return Object.freeze({ canonicalField, option: `--${option}`, value: String(value) });
    });
    const argumentsList = orderedBindings.flatMap((item) => [item.option, item.value]);
    const runtimeRequirements = exercise.rtcm.invocation.externalEnvironmentRequirements.map((item) => item.trim()).filter(Boolean);
    const runtimeField = (["language_or_ecosystem", "runtime", "runtime_requirement"] as const)
      .find((candidate) => string(declaration.document[candidate]));
    const runtimeDeclaration = runtimeField ? Object.freeze({
      value: string(declaration.document[runtimeField])!,
      field: runtimeField,
      resourcePath: declaration.resourcePath
    }) : undefined;
    const dotnetCliInvocation = isDotnet8Runtime(runtimeDeclaration?.value)
      ? await this.resolveDotnetCli(exercise, publication, declaration, adapterArtifactReference)
      : undefined;
    const preferredOutput = string(declaration.document.preferred_output_format)?.toLowerCase();
    return Object.freeze({
      pathIdentifier: `${exercise.ptc.identifier}×${exercise.realization.identifier}`,
      declarationResourcePath: declaration.resourcePath,
      declarationIdentityField: declaration.identityField,
      adapterArtifactReference,
      realizationIdentifier: exercise.realization.identifier,
      realizationType: exercise.realization.realizationType,
      ptcIdentifier: exercise.ptc.identifier,
      rtcmIdentifier: exercise.rtcm.identifier,
      invocationMode: "cli",
      runtimeRequirements: Object.freeze(runtimeRequirements),
      ...(runtimeDeclaration ? { runtimeDeclaration } : {}),
      ...(dotnetCliInvocation ? { dotnetCliInvocation } : {}),
      arguments: Object.freeze(argumentsList),
      orderedBindings: Object.freeze(orderedBindings),
      responseMediaType: preferredOutput === "json" ? "application/json" : "text/plain; charset=utf-8",
      observationLocation: "stdout",
      rawObservationMustBePreserved: true,
      ...(exercise.rtcm.observationDerivation.extractionExpression ? { extractionExpression: exercise.rtcm.observationDerivation.extractionExpression } : {}),
      ...(exercise.rtcm.observationDerivation.semanticOutcome ? { semanticOutcome: exercise.rtcm.observationDerivation.semanticOutcome } : {}),
      normalizationDeclarations: Object.freeze([...exercise.rtcm.observationDerivation.normalizations]),
      rtcmDeclarationProvenance: immutableSnapshot(exercise.rtcm.provenance),
      ...(exercise.comparisonSemantics.comparisonType ? { comparisonType: exercise.comparisonSemantics.comparisonType } : {}),
      ...(exercise.comparisonSemantics.absoluteTolerance !== undefined ? { absoluteTolerance: exercise.comparisonSemantics.absoluteTolerance } : {}),
      ...(exercise.comparisonSemantics.relativeTolerance !== undefined ? { relativeTolerance: exercise.comparisonSemantics.relativeTolerance } : {}),
      expectedOutcomeValue: immutableSnapshot(exercise.canonicalExpectedOutcome.value),
      expectedOutcomeKind: exercise.canonicalExpectedOutcome.outcomeKind,
      ...(exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath ? { normativeExpectedValuePath: exercise.comparisonSemantics.normativeValuePath ?? exercise.canonicalExpectedOutcome.normativeValuePath } : {}),
      ...(exercise.canonicalExpectedOutcome.authorityReference ? { expectedOutcomeAuthorityReference: exercise.canonicalExpectedOutcome.authorityReference } : {}),
      ...(exercise.comparisonSemantics.requiredRepresentation ? { requiredRepresentation: exercise.comparisonSemantics.requiredRepresentation } : {}),
      ...(exercise.comparisonSemantics.requiredUnit ? { requiredUnit: exercise.comparisonSemantics.requiredUnit } : {}),
      ...(exercise.comparisonSemantics.roundingPermittedBeforeComparison !== undefined ? { roundingPermittedBeforeComparison: exercise.comparisonSemantics.roundingPermittedBeforeComparison } : {}),
      semanticExtractionStrategy: "json-result-risk"
    } satisfies RtcmInvocationPlan);
  }

  async materialize(plan: RtcmInvocationPlan, publication: AcquiredPublication): Promise<MaterializedReferenceExecution> {
    const directory = await mkdtemp(resolve(tmpdir(), "pc3-ex-03-np1-publication-"));
    let infrastructureDirectory: string | undefined;
    try {
      await chmod(directory, 0o755);
      for (const resource of publication.resources) {
        assertSafeRelativePath(resource.path);
        const destination = resolve(directory, resource.path);
        if (relative(directory, destination).startsWith("..")) throw new ReferenceExecutionPlanningError("unsafe_publication_resource_path", "A publication resource escaped the temporary execution workspace.");
        if (resource.path.replaceAll("\\", "/").endsWith("/")) {
          await mkdir(destination, { recursive: true });
          continue;
        }
        await mkdir(dirname(destination), { recursive: true });
        await writeFile(destination, await resource.readBytes());
      }
      if (plan.libraryInvocation || plan.dotnetCliInvocation || plan.httpInvocation) {
        infrastructureDirectory = await mkdtemp(resolve(tmpdir(), plan.dotnetCliInvocation ? "pc3-ex-03d-infrastructure-" : plan.httpInvocation ? "pc3-ex-03e-infrastructure-" : "pc3-ex-03-np1-infrastructure-"));
        await chmod(infrastructureDirectory, plan.dotnetCliInvocation ? 0o777 : 0o755);
        if (plan.libraryInvocation) await writeFile(resolve(infrastructureDirectory, "python-library-bridge.py"), PYTHON_LIBRARY_BRIDGE, { mode: 0o555 });
        if (plan.dotnetCliInvocation) await writeFile(resolve(infrastructureDirectory, "pc3-dotnet-cli-bridge.csproj"), dotnetCliBridgeProject(plan.dotnetCliInvocation), { mode: 0o666 });
        if (plan.httpInvocation) await writeFile(resolve(infrastructureDirectory, "python-http-loopback-bridge.py"), PYTHON_HTTP_LOOPBACK_BRIDGE, { mode: 0o555 });
      }
      const adapterPath = plan.adapterArtifactReference ? resolve(directory, plan.adapterArtifactReference) : undefined;
      return Object.freeze({
        plan,
        workingDirectory: directory,
        ...(adapterPath ? { adapterPath } : {}),
        ...(infrastructureDirectory ? { infrastructureDirectory } : {}),
        cleanup: async () => { await rm(directory, { recursive: true, force: true }); if (infrastructureDirectory) await rm(infrastructureDirectory, { recursive: true, force: true }); }
      });
    } catch (error) {
      await rm(directory, { recursive: true, force: true });
      if (infrastructureDirectory) await rm(infrastructureDirectory, { recursive: true, force: true });
      throw error;
    }
  }
}

function resolvePublicationReference(declarationPath: string, reference: string): string {
  assertSafeRelativePath(declarationPath);
  assertSafeRelativePath(reference);
  const base = declarationPath.replaceAll("\\", "/").split("/").slice(0, -1).join("/");
  const combined = resolve("/publication", base, reference).replace(/^\/publication\//, "");
  assertSafeRelativePath(combined);
  return combined;
}

function resolveDeclaredRootReference(publication: AcquiredPublication, reference: string): string {
  assertSafeRelativePath(reference);
  const normalized = reference.replaceAll("\\", "/").replace(/^\.\//, "");
  const matches = publication.resources.filter((resource) => resource.path === normalized || resource.path.endsWith(`/${normalized}`));
  if (matches.length !== 1) throw new ReferenceExecutionPlanningError("declared_resource_reference_not_unique", `The explicitly declared publication resource ${normalized} resolved ${matches.length} times.`);
  return matches[0]!.path;
}
