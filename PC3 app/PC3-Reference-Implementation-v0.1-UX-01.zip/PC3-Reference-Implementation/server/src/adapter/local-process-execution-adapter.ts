import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { arch, platform, release } from "node:os";
import { resolve as resolvePath } from "node:path";
import type { AdapterExecutionResult, ExecutionAdapter, ExecutionAdapterDescriptor, LocalProcessExecutionRequest } from "./model.js";
import type { ExerciseAttempt } from "../operation/model.js";

const MAX_CAPTURE_BYTES = 5_000_000;
const DEFAULT_TIMEOUT_MS = 30_000;

export class LocalProcessExecutionAdapter implements ExecutionAdapter {
  readonly descriptor: ExecutionAdapterDescriptor = Object.freeze({
    id: "pc3.local-process.stdio.v1",
    name: "PC3 Local Process STDIO Adapter",
    version: "1.0.0",
    kind: "local-process",
    transport: "stdio",
    supports: Object.freeze(["exercise-attempt"] as const),
    executionBoundary: "external-process" as const,
    capabilities: Object.freeze([Object.freeze({
      id: "python-cli-stdout.v1",
      invocationModes: Object.freeze(["cli"] as const),
      realizationTypes: Object.freeze(["implementation-representation", "service-realization", "deployment-package"] as const),
      observation: Object.freeze({ location: "stdout" as const, rawMustBePreserved: true as const }),
      runtimeBindings: Object.freeze([Object.freeze({
        canonicalRuntime: "Python",
        aliases: Object.freeze(["python", "python 3", "python3"]),
        executable: "python3"
      })])
    }), Object.freeze({
      id: "python-library-return-value.v1",
      invocationModes: Object.freeze(["library"] as const),
      realizationTypes: Object.freeze(["implementation-representation"] as const),
      observation: Object.freeze({ location: "return-value" as const, rawMustBePreserved: true as const }),
      runtimeBindings: Object.freeze([Object.freeze({
        canonicalRuntime: "Python",
        aliases: Object.freeze(["python", "python 3", "python3"]),
        executable: "python3"
      })])
    }), Object.freeze({
      id: "dotnet8-cli-stdout.v1",
      invocationModes: Object.freeze(["cli"] as const),
      realizationTypes: Object.freeze(["service-realization"] as const),
      observation: Object.freeze({ location: "stdout" as const, rawMustBePreserved: true as const }),
      runtimeBindings: Object.freeze([Object.freeze({
        canonicalRuntime: ".NET 8",
        aliases: Object.freeze([".NET 8", "dotnet 8", "C# / .NET / Native AOT target"]),
        executable: "dotnet"
      })])
    }), Object.freeze({
      id: "python-http-response-body.v1",
      invocationModes: Object.freeze(["http"] as const),
      realizationTypes: Object.freeze(["service-realization"] as const),
      observation: Object.freeze({ location: "response-body" as const, rawMustBePreserved: true as const }),
      runtimeBindings: Object.freeze([Object.freeze({
        canonicalRuntime: "Python",
        aliases: Object.freeze(["python", "python 3", "python3"]),
        executable: "python3"
      })])
    })]),
    explanation: "PC3 starts a separate operating-system process, transmits the immutable Exercise Attempt input through standard input, and captures standard output, standard error, exit status, and timeout disposition. The child process is the execution environment; PC3 remains the coordinator and observer."
  });

  async execute(attempt: ExerciseAttempt, request: LocalProcessExecutionRequest): Promise<AdapterExecutionResult> {
    const executable = request.executable.trim();
    if (!executable) throw new Error("Local-process execution requires a non-empty executable.");
    const args = Object.freeze([...(request.arguments ?? [])]);
    const timeoutMilliseconds = request.timeoutMilliseconds ?? DEFAULT_TIMEOUT_MS;
    if (!Number.isInteger(timeoutMilliseconds) || timeoutMilliseconds < 1 || timeoutMilliseconds > 300_000) {
      throw new Error("Local-process timeout must be an integer from 1 through 300000 milliseconds.");
    }

    return await new Promise<AdapterExecutionResult>((resolve, reject) => {
      const child = spawn(executable, args, {
        ...(request.workingDirectory?.trim() ? { cwd: request.workingDirectory.trim() } : {}),
        stdio: ["pipe", "pipe", "pipe"],
        shell: false,
        windowsHide: true
      });
      const stdout: Buffer[] = [];
      const stderr: Buffer[] = [];
      let capturedBytes = 0;
      let timedOut = false;
      let settled = false;
      let timer: NodeJS.Timeout;
      const fail = (error: Error): void => { if (!settled) { settled = true; clearTimeout(timer); reject(error); } };
      const capture = (target: Buffer[], chunk: Buffer): void => {
        capturedBytes += chunk.byteLength;
        if (capturedBytes > MAX_CAPTURE_BYTES) {
          child.kill("SIGKILL");
          fail(new Error("External process output exceeded the DEV-11 five-megabyte capture limit."));
          return;
        }
        target.push(chunk);
      };
      child.stdout.on("data", (chunk: Buffer) => capture(stdout, chunk));
      child.stderr.on("data", (chunk: Buffer) => capture(stderr, chunk));
      child.on("error", fail);
      timer = setTimeout(() => { timedOut = true; child.kill("SIGKILL"); }, timeoutMilliseconds);
      child.on("close", (exitCode, signal) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        const runtimeReportedAt = new Date().toISOString();
        const out = Buffer.concat(stdout).toString("utf8");
        const err = Buffer.concat(stderr).toString("utf8");
        const outcome = timedOut ? "indeterminate" : exitCode === 0 ? "completed" : "failed";
        const environmentIdentity = request.environmentIdentity?.trim() || `local-process:${executable}`;
        const workingDirectory = request.workingDirectory?.trim() ? resolvePath(request.workingDirectory.trim()) : process.cwd();
        resolve(Object.freeze({
          adapter: this.descriptor,
          environmentDescription: Object.freeze({
            environmentType: "local-process" as const,
            executionBoundary: "external-process" as const,
            externalEnvironmentIdentifier: environmentIdentity,
            operatingSystem: Object.freeze({ platform: platform(), release: release(), architecture: arch() }),
            runtime: Object.freeze({ executable, ...(executable === process.execPath || executable === "node" ? { version: process.version } : {}) }),
            workingDirectory
          }),
          externalInteractionId: `local-process:${randomUUID()}`,
          receivedFrom: this.descriptor.id,
          environmentIdentity,
          outcome,
          responseMediaType: "text/plain; charset=utf-8",
          responseValue: out,
          runtimeReportedAt,
          process: Object.freeze({ executable, arguments: args, exitCode, signal, timedOut, stderr: err })
        }));
      });
      child.stdin.on("error", fail);
      child.stdin.end(request.standardInput === "none" ? undefined : attempt.input.value);
    });
  }
}
