import type { ExerciseAttempt } from "../operation/model.js";

export interface ExecutionAdapterDescriptor {
  readonly id: string;
  readonly name: string;
  readonly version: string;
  readonly kind: "local-process";
  readonly transport: "stdio";
  readonly supports: readonly ["exercise-attempt"];
  readonly executionBoundary: "external-process";
  readonly capabilities: readonly ExecutionAdapterCapabilityDescriptor[];
  readonly explanation: string;
}

export interface ExecutionAdapterCapabilityDescriptor {
  readonly id: string;
  readonly invocationModes: readonly ("cli" | "library" | "http")[];
  readonly realizationTypes: readonly ("implementation-representation" | "service-realization" | "deployment-package")[];
  readonly observation: { readonly location: "stdout" | "return-value" | "response-body"; readonly rawMustBePreserved: true };
  readonly runtimeBindings: readonly {
    readonly canonicalRuntime: string;
    readonly aliases: readonly string[];
    readonly executable: string;
  }[];
}

export interface LocalProcessExecutionRequest {
  readonly executable: string;
  readonly arguments?: readonly string[];
  readonly workingDirectory?: string;
  readonly timeoutMilliseconds?: number;
  readonly environmentIdentity?: string;
  readonly standardInput?: "attempt-input" | "none";
}

/** Immutable, declaration-derived plan for one exact PTC/realization/RTCM pairing. */
export interface RtcmInvocationPlan {
  readonly pathIdentifier: string;
  readonly declarationResourcePath: string;
  readonly declarationIdentityField: "realization_id" | "implementation_representation_id" | "representation_id" | "service_realization_id" | "deployment_package_id" | "describes.identifier";
  readonly adapterArtifactReference?: string;
  readonly realizationIdentifier: string;
  readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
  readonly ptcIdentifier: string;
  readonly rtcmIdentifier: string;
  readonly invocationMode: "cli" | "library" | "http";
  readonly runtimeRequirements: readonly string[];
  readonly runtimeDeclaration?: {
    readonly value: string;
    readonly field: "language_or_ecosystem" | "runtime" | "runtime_requirement" | "language";
    readonly resourcePath: string;
  };
  readonly arguments: readonly string[];
  readonly orderedBindings: readonly { readonly canonicalField: string; readonly option: string; readonly value: string }[];
  readonly responseMediaType: string;
  readonly observationLocation: "stdout" | "return-value" | "response-body";
  readonly libraryInvocation?: {
    readonly bridgeId: "pc3.python-library-return.v1";
    readonly sourceRootReference: string;
    readonly entryPoint: string;
    readonly entryPointKind: "language_function";
    readonly namedBindings: readonly { readonly canonicalField: string; readonly rtcmLocalBinding: string; readonly parameter: string; readonly value: unknown }[];
    readonly executionContractResourcePath: string;
  };
  readonly dotnetCliInvocation?: {
    readonly bridgeId: "pc3.dotnet-cli-source.v1";
    readonly projectFileReference: string;
    readonly adapterEntryPointReference: string;
    readonly implementationSourceRootReference: string;
    readonly implementationProjectReference: string;
    readonly serviceDeclarationReference: string;
    readonly targetFramework: "net8.0";
  };
  readonly httpInvocation?: {
    readonly bridgeId: "pc3.python-http-loopback.v1";
    readonly serviceDeclarationReference: string;
    readonly bindingDeclarationReference: string;
    readonly implementationRepresentationIdentifier: string;
    readonly implementationSourceRootReference: string;
    readonly implementationEntryPoint: string;
    readonly method: "POST";
    readonly route: string;
    readonly requestMediaType: "application/json";
    readonly responseMediaType: "application/json";
    readonly responseValuePath: string;
    readonly requestBody: string;
    readonly requestBodySha256: string;
    readonly requestBindings: readonly { readonly canonicalField: string; readonly localBinding: string; readonly value: unknown }[];
  };
  readonly negativeConditionPlan?: {
    readonly inputSource: "publication-derived-negative";
    readonly operation: "omit-required-binding" | "supply-invalid-lexical-value" | "supply-invalid-aggregate-shape";
    readonly conditionType: string;
    readonly semanticSubject: string;
    readonly localSubject?: string;
    readonly semanticCondition: string;
    readonly concreteDerivation: string;
    readonly mustNotConflateWith?: string;
    readonly expectedCategory: string;
    readonly expectedErrorCondition: "missing_required_parameter" | "invalid_parameter_type" | "invalid_request_shape";
    readonly expectedErrorCode: string;
    readonly declaredStatus: number;
    readonly requestBodySha256: string;
    readonly ptcDeclarationProvenance: { readonly resourcePath: string; readonly resourceSha256: string; readonly location: string; readonly basis: "explicit-declaration" | "provisional-structure-inference" };
    readonly rtcmDeclarationProvenance: { readonly resourcePath: string; readonly resourceSha256: string; readonly location: string; readonly basis: "explicit-declaration" | "provisional-structure-inference" };
    readonly bindingDeclarationResourcePath: string;
  };
  readonly rawObservationMustBePreserved: true;
  readonly extractionExpression?: string;
  readonly semanticOutcome?: string;
  readonly normalizationDeclarations: readonly string[];
  readonly rtcmDeclarationProvenance: { readonly resourcePath: string; readonly resourceSha256: string; readonly location: string; readonly basis: "explicit-declaration" | "provisional-structure-inference" };
  readonly comparisonType?: string;
  readonly absoluteTolerance?: number;
  readonly relativeTolerance?: number;
  readonly expectedOutcomeValue: unknown;
  readonly expectedOutcomeKind: string;
  readonly normativeExpectedValuePath?: string;
  readonly expectedOutcomeAuthorityReference?: string;
  readonly requiredRepresentation?: string;
  readonly requiredUnit?: string;
  readonly roundingPermittedBeforeComparison?: boolean;
  readonly semanticExtractionStrategy: "json-result-risk" | "direct-json-return-value" | "json-declared-path" | "semantic-rejection";
  readonly semanticObservationPath?: string;
}

/** An RTCM plan bound to exactly one explicitly compatible registered adapter. */
export interface ReferenceExecutionPlan extends RtcmInvocationPlan {
  readonly executable: string;
  readonly runtimeRequirement: string;
  readonly runtimeResolutionBasis: "registered-adapter-capability-match";
  readonly adapterResolution: {
    readonly adapterId: string;
    readonly adapterVersion: string;
    readonly capabilityId: string;
    readonly canonicalRuntime: string;
  };
}

export interface AdapterExecutionEnvironmentDescription {
  readonly environmentType: "local-process" | "docker-container";
  readonly executionBoundary: "external-process" | "external-container";
  readonly externalEnvironmentIdentifier: string;
  readonly operatingSystem: { readonly platform: string; readonly release: string; readonly architecture: string };
  readonly runtime: { readonly executable: string; readonly version?: string };
  readonly workingDirectory: string;
  readonly container?: {
    readonly providerId: "pc3.docker.environment.v1";
    readonly imageReference: string;
    readonly imageId: string;
    readonly containerName: string;
    readonly networkMode: "none";
    readonly rootFilesystem: "read-only";
    readonly publicationMount: { readonly hostPath: string; readonly containerPath: "/workspace"; readonly mode: "read-only" };
    readonly limits: { readonly cpus: string; readonly memory: string; readonly pids: string; readonly tmpfs: string; readonly timeoutMilliseconds: number };
    readonly cleanupDisposition: "removed" | "cleanup-failed";
  };
}

export interface AdapterExecutionResult {
  readonly adapter: ExecutionAdapterDescriptor;
  readonly environmentDescription: AdapterExecutionEnvironmentDescription;
  readonly externalInteractionId: string;
  readonly receivedFrom: string;
  readonly environmentIdentity: string;
  readonly outcome: "completed" | "failed" | "indeterminate";
  readonly responseMediaType: string;
  readonly responseValue: string;
  readonly libraryReturn?: {
    readonly bridgeId: "pc3.python-library-return.v1";
    readonly transferredEnvelope: string;
    readonly transferredEnvelopeSha256: string;
    readonly value: unknown;
    readonly valueJson: string;
    readonly diagnosticStdout: string;
    readonly diagnosticStderr: string;
  };
  readonly httpExchange?: {
    readonly bridgeId: "pc3.python-http-loopback.v1";
    readonly transferredEnvelope: string;
    readonly transferredEnvelopeSha256: string;
    readonly method: "POST";
    readonly route: string;
    readonly requestBody: string;
    readonly statusCode: number;
    readonly responseHeaders: Readonly<Record<string, string>>;
    readonly responseBody: string;
    readonly adapterEnvelope: string;
    readonly adapterEnvelopeSha256: string;
    readonly adapterStderr: string;
    readonly adapterEvidence: unknown;
  };
  readonly runtimeReportedAt: string;
  readonly process: {
    readonly executable: string;
    readonly arguments: readonly string[];
    readonly exitCode: number | null;
    readonly signal: string | null;
    readonly timedOut: boolean;
    readonly stderr: string;
  };
}

export interface ExecutionAdapter {
  readonly descriptor: ExecutionAdapterDescriptor;
  execute(attempt: ExerciseAttempt, request: LocalProcessExecutionRequest): Promise<AdapterExecutionResult>;
}
