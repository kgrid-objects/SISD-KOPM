import type { ExecutionAdapter, ReferenceExecutionPlan, RtcmInvocationPlan } from "./model.js";

export class AdapterCapabilityResolutionError extends Error {
  constructor(readonly code: "adapter_capability_not_found" | "adapter_capability_ambiguous" | "rtcm_runtime_requirement_not_unique", message: string) {
    super(message);
    this.name = "AdapterCapabilityResolutionError";
  }
}

export interface InvocationCapabilityRequest {
  readonly invocationMode: string;
  readonly realizationType: RtcmInvocationPlan["realizationType"];
  readonly observationLocation?: string;
  readonly rawObservationMustBePreserved: boolean;
  readonly runtimeRequirement?: string;
}

export interface InvocationCapabilityMatch {
  readonly adapter: ExecutionAdapter;
  readonly capabilityId: string;
  readonly canonicalRuntime: string;
  readonly executable: string;
  readonly runtimeRequirement: string;
}

export class ExecutionAdapterRegistry {
  private readonly adapters = new Map<string, ExecutionAdapter>();
  constructor(initial: readonly ExecutionAdapter[]) { for (const adapter of initial) this.register(adapter); }
  register(adapter: ExecutionAdapter): void {
    if (this.adapters.has(adapter.descriptor.id)) throw new Error(`Execution adapter ${adapter.descriptor.id} is already registered.`);
    this.adapters.set(adapter.descriptor.id, adapter);
  }
  list(): readonly ExecutionAdapter[] { return Object.freeze([...this.adapters.values()]); }
  find(id: string): ExecutionAdapter | undefined { return this.adapters.get(id); }

  resolveCapability(request: InvocationCapabilityRequest): InvocationCapabilityMatch {
    const runtimeRequirement = request.runtimeRequirement?.trim();
    if (!runtimeRequirement) throw new AdapterCapabilityResolutionError("rtcm_runtime_requirement_not_unique", "No single explicit realization runtime is available for adapter capability resolution.");
    const normalizedRuntime = runtimeRequirement.toLowerCase();
    const matches = this.list().flatMap((adapter) => adapter.descriptor.capabilities.flatMap((capability) => {
      if (!capability.invocationModes.some((mode) => mode === request.invocationMode.toLowerCase())) return [];
      if (!capability.realizationTypes.includes(request.realizationType)) return [];
      if (capability.observation.location !== request.observationLocation || capability.observation.rawMustBePreserved !== request.rawObservationMustBePreserved) return [];
      const runtime = capability.runtimeBindings.find((binding) => binding.aliases.some((alias) => alias.trim().toLowerCase() === normalizedRuntime));
      return runtime ? [{ adapter, capabilityId: capability.id, canonicalRuntime: runtime.canonicalRuntime, executable: runtime.executable, runtimeRequirement }] : [];
    }));
    if (matches.length === 0) throw new AdapterCapabilityResolutionError("adapter_capability_not_found", `No registered execution adapter capability matches ${request.invocationMode} / ${runtimeRequirement} / ${request.observationLocation ?? "unspecified observation"}.`);
    if (matches.length > 1) throw new AdapterCapabilityResolutionError("adapter_capability_ambiguous", `Adapter capability resolution found ${matches.length} matches for ${request.invocationMode} / ${runtimeRequirement}; PC3 will not choose by registration order.`);
    return Object.freeze(matches[0]!);
  }

  resolve(plan: RtcmInvocationPlan): { readonly adapter: ExecutionAdapter; readonly plan: ReferenceExecutionPlan } {
    const runtimeRequirement = plan.runtimeDeclaration?.value ?? (plan.runtimeRequirements.length === 1 ? plan.runtimeRequirements[0] : undefined);
    const match = this.resolveCapability({ invocationMode: plan.invocationMode, realizationType: plan.realizationType, observationLocation: plan.observationLocation, rawObservationMustBePreserved: plan.rawObservationMustBePreserved, ...(runtimeRequirement ? { runtimeRequirement } : {}) });
    return Object.freeze({
      adapter: match.adapter,
      plan: Object.freeze({
        ...plan,
        executable: match.executable,
        runtimeRequirement: match.runtimeRequirement,
        runtimeResolutionBasis: "registered-adapter-capability-match" as const,
        adapterResolution: Object.freeze({ adapterId: match.adapter.descriptor.id, adapterVersion: match.adapter.descriptor.version, capabilityId: match.capabilityId, canonicalRuntime: match.canonicalRuntime })
      })
    });
  }
}
