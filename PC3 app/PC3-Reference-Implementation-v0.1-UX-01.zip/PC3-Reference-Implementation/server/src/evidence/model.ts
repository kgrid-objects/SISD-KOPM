import type { IsoInstant } from "../domain/time.js";
import type { ActiveOperationalContextId, ExecutionEvidenceId, SessionId } from "../domain/identifiers.js";
import type { ExecutionInteraction } from "../interaction/model.js";
import type { RuntimeObservation } from "../observation/model.js";
import type { ExerciseAttempt } from "../operation/model.js";
import type { ExecutionEnvironmentDescription } from "../environment/model.js";
import type { ExpectedOutcomeComparison } from "../comparison/model.js";

export interface ExecutionEvidenceProvenance {
  readonly publication: {
    readonly activeContextId: ActiveOperationalContextId;
    readonly publicationLoadId: string;
    readonly publicationIdentifier?: string;
    readonly sourceName: string;
    readonly iorId: string;
  };
  readonly realizationPathway: {
    readonly id: string;
    readonly endpointIdentifier: string;
    readonly endpointType: "implementation-representation" | "service-realization" | "deployment-package";
    readonly relationshipTypes: readonly string[];
    readonly steps: readonly {
      readonly identifier: string;
      readonly realizationType: "implementation-representation" | "service-realization" | "deployment-package";
      readonly artifactReference?: string;
      readonly invocationMechanism?: string;
    }[];
  };
  readonly exerciseAttempt: ExerciseAttempt;
  readonly executionInteraction: ExecutionInteraction;
  readonly executionEnvironmentDescription?: ExecutionEnvironmentDescription;
}

/** Immutable PC3-attested evidentiary artifact. It does not attest execution correctness. */
export interface ExecutionEvidence {
  readonly id: ExecutionEvidenceId;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly status: "attested-ephemeral";
  readonly persistenceDisposition: "not-saved";
  readonly attestedAt: IsoInstant;
  readonly attestation: {
    readonly attester: "PC3";
    readonly implementation: string;
    readonly implementationVersion: string;
    readonly developmentPass: string;
    readonly scope: "faithful-record-attestation";
    readonly statement: string;
    readonly cryptographicSignatureDisposition: "not-implemented";
  };
  readonly pc3Identity: { readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly evidenceScope: "complete-ptc-exercise-chain" | "runtime-observation-with-provenance";
  readonly inputDisposition: {
    readonly exerciseDisposition: "canonical" | "exploratory";
    readonly source: "publication-canonical" | "publication-derived-negative" | "user-exploratory";
    readonly snapshot: { readonly mediaType: string; readonly value: string; readonly sha256: string };
  };
  readonly ptcExerciseChain?: {
    readonly publicationLoadId: string;
    readonly publicationIdentifier?: string;
    readonly ptcIdentifier: string;
    readonly rtcmIdentifier: string;
    readonly realizationIdentifier: string;
    readonly attemptId: string;
    readonly interactionId: string;
    readonly observationId: string;
    readonly comparisonId: string;
  };
  readonly runtimeObservation: RuntimeObservation;
  readonly expectedOutcomeComparison?: ExpectedOutcomeComparison;
  readonly provenance: ExecutionEvidenceProvenance;
  readonly integrity: {
    readonly algorithm: "SHA-256";
    readonly canonicalization: "pc3-canonical-json-v1";
    readonly digest: string;
    readonly coveredContent: "attested-exercise-record-and-pc3-identity";
  };
  readonly explanation: string;
}

export interface SavedExecutionEvidenceRecord {
  readonly recordType: "pc3-execution-evidence";
  readonly recordSchemaVersion: "2.0";
  readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly savedAt: IsoInstant;
  readonly evidence: ExecutionEvidence;
  readonly statement: string;
}

export interface SavedObservationCollectionAttestationRecord {
  readonly recordType: "pc3-observation-collection-attestation";
  readonly recordSchemaVersion: "1.0";
  readonly source: { readonly product: "PC3"; readonly implementation: string; readonly version: string; readonly developmentPass: string };
  readonly savedAt: IsoInstant;
  readonly sessionId: SessionId;
  readonly activeContextId: ActiveOperationalContextId;
  readonly observationCount: number;
  readonly evidence: readonly ExecutionEvidence[];
  readonly integrity: { readonly algorithm: "SHA-256"; readonly canonicalization: "pc3-canonical-json-v1"; readonly digest: string; readonly coveredContent: "ordered-current-observation-evidence-and-pc3-identity" };
  readonly statement: string;
}
