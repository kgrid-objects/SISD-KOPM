# Evidence module

ATT-01 extends the DEV-10 PC3 attestation act across the complete PTC exercise chain.

Execution Evidence is not a realization derived from a Runtime Observation. It is a new immutable, PC3-attested evidentiary artifact containing:

- publication, PTC, RTCM, realization, attempt, interaction, observation, and comparison identities;
- canonical or exploratory input disposition and an independently hashed exact input snapshot;
- the complete Runtime Observation, including immutable raw identity and SHA-256;
- the separate Expected Outcome comparison with raw, normalized, extracted, expected, and comparison representations;
- publication, realization-pathway, Exercise Attempt, Execution Interaction, and external environment provenance held by PC3;
- exact PC3 implementation identity and version;
- a bounded attestation statement;
- a SHA-256 integrity digest covering the attested exercise record and PC3 identity.

PTC-scoped evidence is not created unless the PTC/RTCM/realization binding and comparison match the originating attempt, interaction, and observation. PC3 attests faithful record composition only. It does not attest publication or realization conformance, computational correctness, scientific validity, safety, or independent verification. UII-04 retains individual Evidence as internal infrastructure and exposes one formal collection save covering all current Observations; saving never writes to the UKO.
