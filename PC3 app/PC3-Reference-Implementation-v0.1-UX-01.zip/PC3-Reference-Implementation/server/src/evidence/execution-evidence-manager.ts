import { createHash } from "node:crypto";
import { executionEvidenceId, type ActiveOperationalContextId, type ExecutionEvidenceId, type RuntimeObservationId, type SessionId } from "../domain/identifiers.js";
import type { Clock, IdentifierGenerator } from "../domain/time.js";
import type { ExecutionInteraction } from "../interaction/model.js";
import type { RuntimeObservation } from "../observation/model.js";
import type { ExerciseAttempt } from "../operation/model.js";
import type { ExpectedOutcomeComparison } from "../comparison/model.js";
import type { ExecutionEvidence, ExecutionEvidenceProvenance, SavedExecutionEvidenceRecord, SavedObservationCollectionAttestationRecord } from "./model.js";

export type AttestExecutionEvidenceResult =
  | { readonly status: "attested"; readonly evidence: ExecutionEvidence }
  | { readonly status: "already-attested"; readonly evidence: ExecutionEvidence }
  | { readonly status: "context-mismatch" }
  | { readonly status: "incomplete-ptc-chain" };

export class ExecutionEvidenceManager {
  private readonly bySession = new Map<SessionId, ExecutionEvidence[]>();
  constructor(private readonly dependencies: { readonly clock: Clock; readonly identifiers: IdentifierGenerator }) {}

  attest(input: {
    readonly observation: RuntimeObservation;
    readonly interaction: ExecutionInteraction;
    readonly attempt: ExerciseAttempt;
    readonly expectedActiveContextId: ActiveOperationalContextId;
    readonly publication: ExecutionEvidenceProvenance["publication"];
    readonly pathway: ExecutionEvidenceProvenance["realizationPathway"];
    readonly comparison?: ExpectedOutcomeComparison;
    readonly environment?: ExecutionEvidenceProvenance["executionEnvironmentDescription"];
    readonly identity: { readonly implementation: string; readonly version: string; readonly developmentPass: string };
  }): AttestExecutionEvidenceResult {
    if (input.observation.activeContextId !== input.expectedActiveContextId || input.interaction.activeContextId !== input.expectedActiveContextId || input.attempt.activeContextId !== input.expectedActiveContextId || (input.comparison && input.comparison.activeContextId !== input.expectedActiveContextId)) return { status: "context-mismatch" };
    const scope = input.observation.publicationExerciseScope;
    const binding = input.attempt.publicationExerciseBinding;
    if (scope && (!input.comparison || input.comparison.observationId !== input.observation.id || input.comparison.executionInteractionId !== input.interaction.id || binding?.ptcIdentifier !== scope.ptcIdentifier || binding?.rtcmIdentifier !== scope.rtcmIdentifier || binding?.realizationIdentifier !== scope.realizationIdentifier)) return { status: "incomplete-ptc-chain" };
    const existing = (this.bySession.get(input.observation.sessionId) ?? []).find((item) => item.runtimeObservation.id === input.observation.id);
    if (existing) return { status: "already-attested", evidence: existing };

    const provenance: ExecutionEvidenceProvenance = deepFreeze({
      publication: input.publication,
      realizationPathway: input.pathway,
      exerciseAttempt: input.attempt,
      executionInteraction: input.interaction,
      ...(input.environment ? { executionEnvironmentDescription: input.environment } : {})
    });
    const inputDisposition: ExecutionEvidence["inputDisposition"] = deepFreeze({
      exerciseDisposition: input.attempt.exerciseDisposition ?? (input.attempt.input.source === "user-exploratory" ? "exploratory" : "canonical"),
      source: input.attempt.input.source ?? "user-exploratory",
      snapshot: {
        mediaType: input.attempt.input.mediaType,
        value: input.attempt.input.value,
        sha256: createHash("sha256").update(input.attempt.input.value, "utf8").digest("hex")
      }
    });
    const ptcExerciseChain = scope && input.comparison ? deepFreeze({
      publicationLoadId: input.publication.publicationLoadId,
      ...(input.publication.publicationIdentifier ? { publicationIdentifier: input.publication.publicationIdentifier } : {}),
      ptcIdentifier: scope.ptcIdentifier,
      rtcmIdentifier: scope.rtcmIdentifier,
      realizationIdentifier: scope.realizationIdentifier,
      attemptId: input.attempt.id,
      interactionId: input.interaction.id,
      observationId: input.observation.id,
      comparisonId: input.comparison.id
    }) : undefined;
    const pc3Identity = deepFreeze({ ...input.identity });
    const covered = { inputDisposition, ...(ptcExerciseChain ? { ptcExerciseChain } : {}), runtimeObservation: input.observation, ...(input.comparison ? { expectedOutcomeComparison: input.comparison } : {}), provenance, pc3Identity };
    const digest = createHash("sha256").update(canonicalJson(covered), "utf8").digest("hex");
    const evidence: ExecutionEvidence = deepFreeze({
      id: executionEvidenceId(this.dependencies.identifiers.next()),
      sessionId: input.observation.sessionId,
      activeContextId: input.observation.activeContextId,
      status: "attested-ephemeral",
      persistenceDisposition: "not-saved",
      attestedAt: this.dependencies.clock.now(),
      attestation: {
        attester: "PC3",
        implementation: input.identity.implementation,
        implementationVersion: input.identity.version,
        developmentPass: input.identity.developmentPass,
        scope: "faithful-record-attestation",
        statement: "PC3 attests that this Execution Evidence faithfully preserves the identified exercise record captured and compared by this PC3 implementation. PC3 does not attest publication or realization conformance, computational correctness, scientific validity, safety, or independent verification.",
        cryptographicSignatureDisposition: "not-implemented"
      },
      pc3Identity,
      evidenceScope: ptcExerciseChain ? "complete-ptc-exercise-chain" : "runtime-observation-with-provenance",
      inputDisposition,
      ...(ptcExerciseChain ? { ptcExerciseChain } : {}),
      runtimeObservation: input.observation,
      ...(input.comparison ? { expectedOutcomeComparison: input.comparison } : {}),
      provenance,
      integrity: { algorithm: "SHA-256", canonicalization: "pc3-canonical-json-v1", digest, coveredContent: "attested-exercise-record-and-pc3-identity" },
      explanation: ptcExerciseChain ? "Execution Evidence is created only by explicit PC3 attestation. It preserves the complete PTC exercise identity chain, input disposition, raw and separately normalized representations, comparison result and semantics, external execution provenance, PC3 identity, and integrity digest." : "Legacy Execution Evidence preserves the Runtime Observation, input disposition, PC3-held provenance, integrity digest, and bounded attestation. It is not a complete PTC exercise-chain record."
    });
    const list = this.bySession.get(evidence.sessionId) ?? [];
    this.bySession.set(evidence.sessionId, [...list, evidence]);
    return { status: "attested", evidence };
  }

  list(sessionId: SessionId, activeContextId: ActiveOperationalContextId): readonly ExecutionEvidence[] {
    return (this.bySession.get(sessionId) ?? []).filter((item) => item.activeContextId === activeContextId);
  }

  find(sessionId: SessionId, id: ExecutionEvidenceId): ExecutionEvidence | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.id === id);
  }

  findByObservation(sessionId: SessionId, observationId: RuntimeObservationId): ExecutionEvidence | undefined {
    return (this.bySession.get(sessionId) ?? []).find((item) => item.runtimeObservation.id === observationId);
  }

  discard(sessionId: SessionId, activeContextId: ActiveOperationalContextId, id: ExecutionEvidenceId): "discarded" | "not-found" | "context-mismatch" {
    const list = this.bySession.get(sessionId) ?? [];
    const evidence = list.find((item) => item.id === id);
    if (!evidence) return "not-found";
    if (evidence.activeContextId !== activeContextId) return "context-mismatch";
    this.bySession.set(sessionId, list.filter((item) => item.id !== id));
    return "discarded";
  }

  saveRecord(evidence: ExecutionEvidence): SavedExecutionEvidenceRecord {
    return deepFreeze({
      recordType: "pc3-execution-evidence",
      recordSchemaVersion: "2.0",
      source: { product: "PC3", implementation: evidence.attestation.implementation, version: evidence.attestation.implementationVersion, developmentPass: evidence.attestation.developmentPass },
      savedAt: this.dependencies.clock.now(),
      evidence,
      statement: "This PC3-attested Execution Evidence record was saved at the user's discretion. Saving was optional. It remains external to the published computational capability and does not modify the UKO."
    });
  }

  saveCollectionRecord(sessionId: SessionId, activeContextId: ActiveOperationalContextId, orderedObservationIds: readonly RuntimeObservationId[]): SavedObservationCollectionAttestationRecord | undefined {
    const byObservation = new Map(this.list(sessionId, activeContextId).map((item) => [item.runtimeObservation.id, item]));
    const orderedEvidence = orderedObservationIds.map((id) => byObservation.get(id));
    if (orderedEvidence.some((item) => !item)) return undefined;
    const completeEvidence = orderedEvidence as readonly ExecutionEvidence[];
    const source = { product: "PC3" as const, implementation: completeEvidence[0]!.attestation.implementation, version: completeEvidence[0]!.attestation.implementationVersion, developmentPass: completeEvidence[0]!.attestation.developmentPass };
    const covered = { sessionId, activeContextId, evidence: completeEvidence.map((item) => ({ id: item.id, observationId: item.runtimeObservation.id, digest: item.integrity.digest })), source };
    return deepFreeze({
      recordType: "pc3-observation-collection-attestation",
      recordSchemaVersion: "1.0",
      source,
      savedAt: this.dependencies.clock.now(),
      sessionId,
      activeContextId,
      observationCount: completeEvidence.length,
      evidence: completeEvidence,
      integrity: { algorithm: "SHA-256", canonicalization: "pc3-canonical-json-v1", digest: createHash("sha256").update(canonicalJson(covered), "utf8").digest("hex"), coveredContent: "ordered-current-observation-evidence-and-pc3-identity" },
      statement: "PC3 formally saved one attestation artifact covering all Runtime Observations currently present in the active publication session. The artifact remains external to the UKO and does not attest conformance, correctness, scientific validity, or safety."
    });
  }

  clearSession(sessionId: SessionId): void { this.bySession.delete(sessionId); }
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`).join(",")}}`;
}

function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const nested of Object.values(value as Record<string, unknown>)) deepFreeze(nested);
  }
  return value;
}
