# UX-01 Pass Report — Operational Refinement and Reference Release

Date: 2026-07-20  
Implementation identity: `0.1.0 / UX-01`  
Status: **passed external verification and accepted on 2026-07-20**

## Outcome

UX-01 conservatively closes the specified PC3 v0.1 release gate without adding an invocation modality or changing publication, PTC, RTCM, exercise, Observation, comparison, or attestation semantics.

- Existing keyboard and accessibility behavior was reviewed and retained. Accessible board naming now consistently says **Console View**, decorative connection lights are hidden from assistive technology, and the persistent connected status visibly discloses the exact implementation version and pass.
- Dense realization rendering uses memoized identity, readiness, RTCM, resolved-exercise, and invocation-support indexes instead of repeated full-population searches.
- A release-level two-session regression proves publication, matrix, and selection isolation, supplementing the established atomic-replacement and stale-context tests.
- A supported/unsupported capability matrix and exceptional-condition guide state the v0.1 boundaries without implying conformance, correctness, scientific validity, or safety.
- The Accepted.F release script verifies stable corpus counts, records activation duration, optionally exercises the accepted Python CLI PTC-001 vertical slice through comparison and collection attestation, and proves the supplied archive hash is unchanged.
- Release traceability maps every UX-01 goal to implementation and verification evidence.

## Deliberately unchanged

- No UKO resource is written, repaired, renamed, or repackaged.
- No MCP, messaging, runtime, adapter, invocation, persistence, or signing capability is added.
- No unsupported realization becomes Exercise-enabled.
- No dashboard, collection, Instrument Display, Detail Panel, or attestation workflow is redesigned.
- No machine-specific activation-time threshold is claimed.

## Verification

`npm run verify` passes: architectural boundaries, strict type checks, 143 server tests, 117 UI tests, shared-package checks, and the production build.

The read-only Accepted.F gate also passes with 2,983 resources, 6 PTCs, 52 realizations, 298 RTCMs, 298 resolved exercises, 55 realization pathways, zero declaration errors, and an unchanged source SHA-256 of `38c19ce7743af2236378650f235168ef32ee81f52b6f4f2c5b2fc9b836ccaf`. Activation completed in 9.24 seconds in the implementation environment; this is an observation, not a release threshold.

The implementation environment could not reach a Docker daemon, so the script truthfully rejected its optional `--exercise` mode before creating an attempt. Docker-backed external verification remains required. Accepted-corpus commands and keyboard/visual checks are documented in `docs/release/UX-01-RELEASE-VERIFICATION.md`.

External verification demonstrated the loaded v0.1 identity and the Docker-backed `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` path through execution and deterministic comparison. The comparison truthfully returned `fail`: Accepted.F declares `0.17099497442391187` with `1e-12` tolerance while the realization returned `0.1687`. The auxiliary verifier's stricter `pass` assertion stopped before its attestation step; the user accepted that bounded verifier limitation without requesting a v0.1 correction. PC3 v0.1 and UX-01 were externally accepted on 2026-07-20.
