# UII-02 Pass Report

## Show Exercisable Realizations Toggle

UII-02 adds the specified one-control realization filter to the externally accepted UII-01 baseline.

### Delivered behavior

- Added exactly one compact **Show Exercisable** On/Off button at Realization Level.
- Exposed a true accessible pressed state, visible On/Off value, disabled state, focus treatment, title, and live selection announcement.
- Defaulted to Off and reset to Off whenever a publication is loaded or replaced.
- Defined exercisable endpoints exclusively from materialized immutable Resolved Computational Exercises for the PTC selected in the sole Test Cases list.
- Filtered IR, SR, and DP lists independently without using filenames, applicability hints, incomplete RTCMs, or inferred execution behavior.
- Updated local realization-level counts to match the filtered or unfiltered list.
- Preserved the selected PTC when toggling, changing levels, or selecting realization channels.
- Preserved a filtered-out realization internally without presenting it as the active visible channel or selecting a replacement.
- Presented an explicit empty state when the selected PTC has no exercisable realization at the active level; no fallback to all realizations occurs.
- Kept the toggle disabled and Off without an active PTC/Test Case context and explained the requirement.
- Left the upper publication dashboard, Resolved Exercise semantics, execution, observation, comparison, evidence, and UKO content unchanged.

### Exercisable boundary

UII-02 uses the server-produced `resolvedExercises` collection as its sole filter authority. A merely related or declared-applicable realization is not included unless the existing resolution rules produced one Resolved Computational Exercise with one authoritative applicable RTCM. This is publication exercise resolution, not a claim that PC3 currently supports the invocation mode or that a runtime is available.

### External verification path

1. Start PC3 and load the accepted UKO 1.1 publication.
2. Select a Test Case from the Test Cases list and open **Realizations**.
3. Confirm **Show Exercisable** appears once at Realization Level and initially reads **Off**.
4. Note the IR, SR, and DP counts and realization lists while Off.
5. Turn the toggle On and confirm only realizations having resolved exercises for the selected Test Case remain.
6. Confirm the local IR, SR, and DP counts match the filtered lists.
7. Change realization level and confirm the toggle remains On and the filter applies at each level.
8. Return to Test Cases and confirm UII-01 preserved the selected Test Case.
9. Choose a different Test Case, return to Realizations, and confirm the On filter follows that Test Case without silently choosing a realization.
10. If a level has no resolved exercises, confirm the explicit **No exercisable realizations for the selected Test Case at this level** state appears without fallback.
11. Turn the toggle Off and confirm all realizations return and any previously filtered selection becomes available again.
12. Load a new publication and confirm the toggle resets to Off; for a non-PTC publication, confirm it is disabled with an explanation.

### Verification

Focused regression coverage checks the single accessible toggle, exact Resolved Exercise filtering, filtered counts, hidden-selection behavior, default and publication reset, unavailable context, bounded empty state, and UII-01 single-source PTC selection. `npm run verify` passes with architectural-boundary checks, TypeScript checks, **101 server tests**, **77 web tests**, and the production build.
