# DEV-12B — Information Density & Visual Hierarchy

## Baseline

Externally verified `PC3-Reference-Implementation-v0.1-DEV12.zip`.

## Implemented

- Added a mutually exclusive IR/SR/DP realization-level selector at the top of the Realization Channel bank.
- Limited the visible channel population to the active endpoint level only.
- Added per-level counts and disabled empty levels.
- Preserved the most recently selected channel for each level and restored it when returning to that level.
- Selected the first selectable channel when entering a level without a remembered selection.
- Kept exactly one shared Input, Execute, Monitor, Attest workspace.
- Narrowed the channel bank and reduced channel height, padding, typography, and repeated labels.
- Strengthened selected-level and selected-channel hierarchy while retaining keyboard and reduced-motion behavior.
- Preserved pathway-scoped attempts, interactions, observations, environment descriptions, and evidence.

## Architectural boundary

DEV-12B is presentation-only. It does not change publication interpretation, pathway construction, execution adapters, external environments, environment identity, execution behavior, Runtime Observations, Execution Evidence, optional persistence, realization identity assurance, or UKO immutability.
