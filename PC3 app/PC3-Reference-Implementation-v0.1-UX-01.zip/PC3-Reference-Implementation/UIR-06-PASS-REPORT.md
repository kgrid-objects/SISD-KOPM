# UIR-06 Pass Report

Status: **passed external verification and accepted on 2026-07-20**.

## Delivered

- Added one **Close/Open** dashboard windowshade control to the permanent header band beside the Load action.
- Kept publication identity, board readiness, the windowshade control, and **Load another…** visible in both states.
- Grouped the 12 numeric readouts, Exercise opportunity coverage table, and four rounded status readouts into one controlled collapsible body.
- Added a short coordinated height-and-opacity transition so the dashboard closes or opens in one motion.
- Released the collapsed body's vertical space so the left collection panel and right Instrument Display move upward naturally.
- Defaulted the dashboard to open and added `aria-expanded`, `aria-controls`, and collapsed-region `aria-hidden` semantics.
- Updated the implementation identity to `0.0.0-uir-06 / UIR-06`.

## Boundaries

UIR-06 changes dashboard presentation only. It does not change any dashboard data, readiness calculation, collection state, selected realization, Exercise opportunity projection, load behavior, execution, Observation, comparison, attestation, or publication content.

## Verification

The complete repository verification suite passes: architectural boundaries, typechecks, 134 server tests, 106 UI tests, shared-package checks, and the production build.

## External acceptance path

1. Load a publication and confirm the dashboard initially opens fully.
2. Choose **Close** beside **Load another…**.
3. Confirm the 12 numeric readouts, opportunity-coverage table, and four rounded status readouts collapse together in one motion.
4. Confirm publication identity, readiness, **Open**, and **Load another…** remain visible in the header band.
5. Confirm the left collection panel and right Instrument Display move upward into the released space.
6. Choose **Open** and confirm the complete dashboard body returns together without changing its data.
