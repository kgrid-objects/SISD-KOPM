# EX-01 Pass Report

## PTC-Bound Exercise Attempt Integration

EX-01 integrates the accepted Resolved Exercise model with the existing Exercise Attempt, adapter, interaction, observation, and evidence architecture.

### Delivered behavior

- PTC-profile attempts require an explicitly selected Publication Test Case.
- PC3 resolves the selected PTC and realization to exactly one authoritative applicable RTCM before creating an attempt.
- Each bound attempt immutably records PTC, RTCM, realization, publication-load, active-context, IOR, pathway, endpoint, timestamp, and exact input snapshot identities.
- Canonical attempts use the Resolved Exercise's canonical input and concrete RTCM media type; client input cannot replace that snapshot.
- Exploratory attempts preserve user-supplied input while retaining the same PTC/RTCM/realization binding.
- Incomplete or invalid authority, missing PTCs, non-applicable pairings, absent RTCMs, ambiguous RTCMs, stale contexts, and realization mismatches prevent attempt creation.
- Resolved Exercise review does not create an attempt. The user must explicitly choose Prepare canonical attempt or Prepare exploratory attempt.
- The existing local-process adapter continues to execute only through a separate operating-system process.
- Legacy exploratory attempt behavior remains available when no PTC architecture governs the publication; it cannot be mislabeled canonical or PTC-bound.

### Architectural boundary

The UKO remains read-only. Attempt preparation neither initiates computation nor asserts environment availability, execution success, comparison, scientific validity, or conformance. EX-02 remains responsible for the first complete canonical reference execution.

### Verification

The full repository verification suite covers immutable binding, canonical input authority, exploratory preservation, explicit-action preparation, resolution failures, legacy compatibility, external adapter continuity, and all previously accepted behavior. `npm run verify` passes with 89 server tests and 65 web tests, plus architectural-boundary checks, TypeScript checks, shared-package checks, and the production build.
