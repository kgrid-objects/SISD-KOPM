# OBS-02 Pass Report

## Expected Outcome Comparison

OBS-02 adds deterministic Expected Outcome comparison after the accepted EX-02 execution and OBS-01 raw-observation capture paths.

### Delivered behavior

- The accepted Python Command Line reference plan retains the canonical Expected Outcome, normative expected-value path, authority, representation, unit, comparison type, absolute and relative tolerances, rounding permission, and bounded semantic-extraction strategy.
- A separate comparison service evaluates each eligible reference Runtime Observation exactly once and stores an immutable result linked to the observation and Execution Interaction.
- Completed JSON output is parsed and the finite numeric `result.risk` semantic observation is extracted.
- Only allow-listed, explicitly declared normalization is applied, and only to a separate normalized representation. Unsupported normalization returns `comparison-error`.
- Numeric absolute-tolerance and exact numeric comparison are supported without pre-comparison rounding.
- The service returns `pass`, `fail`, `indeterminate`, or `comparison-error`.
- External failed or indeterminate execution yields an indeterminate comparison rather than a fabricated semantic value.
- Invalid JSON, absent or non-numeric semantic values, non-numeric expected values, invalid tolerance, and unsupported comparison types produce attributable comparison errors.
- Raw, normalized, extracted, expected, and comparison representations remain separately inspectable. Raw identity and SHA-256 attribution are carried forward from OBS-01.
- Every result states `comparison-result-not-conformance`; pass and fail do not assert conformance, scientific validity, execution correctness, or realization equivalence.
- Results are available through the reference-execution response and `GET /api/sessions/{sessionId}/observation-comparisons`.
- The Pub Board Check surface displays the bounded status, observed and expected values, absolute difference and tolerance, errors, representation details, and explicit non-conformance disposition.

### Accepted-reference discrepancy behavior

The RTCM requires PC3 to compare the raw realization result directly with the CKS-authoritative expected outcome and preserve any discrepancy without repair. Therefore, a visible `fail` can be the correct successful outcome of OBS-02. PC3 does not round the canonical value or widen the declared tolerance to force a pass.

### Architectural boundary

OBS-02 compares declared values. It does not alter the Runtime Observation, repair a discrepancy, assert conformance, attest evidence, establish scientific validity, or prove realization equivalence. ATT-01 remains responsible for the later bounded evidence-attestation extension.

### External verification path

1. Load the accepted UKO 1.1 publication.
2. Select `UKO-001-SR-PYTHON-COMMAND-LINE` and `UKO-001-PTC-001`.
3. Prepare and run the canonical publication-declared reference.
4. In **Check**, find **Expected Outcome comparison** below the immutable raw observation.
5. Confirm the status is pass, fail, indeterminate, or comparison-error and is distinct from the execution outcome.
6. For pass or fail, confirm observed value, canonical expected value, absolute difference, and `1e-12` tolerance are shown.
7. Open **Comparison representations** and confirm raw identity, normalized disposition, `result.risk` extraction, comparison rule, no rounding, and `comparison-result-not-conformance`.
8. If the result is fail, confirm the discrepancy is displayed rather than repaired.
9. Confirm the OBS-01 raw value and SHA-256 remain unchanged.

### Verification

The suite covers pass, fail, exceptional indeterminate outcome, malformed-output comparison error, permitted separate normalization, rejected normalization, exact discrepancy retention, raw immutability, list retrieval, UI inspection, and all accepted predecessor behavior. `npm run verify` passes with 98 server tests, 71 web tests, architectural-boundary checks, TypeScript checks, and the production build.
