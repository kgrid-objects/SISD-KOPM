# PC3 Architectural Reference Implementation

Development baseline: **UX-01 — Operational Refinement and Reference Release**  
Implementation version: **0.1.0**

External verification status: **PC3 v0.1 and UX-01 passed external verification and were accepted on 2026-07-20**

EX-03 workstream status: **closed on 2026-07-20**. See `EX-03-WORKSTREAM-CLOSURE.md`. UIR-09 is the current user-directed UI refinement baseline.

UIR workstream status: **closed on 2026-07-20**. See `UIR-WORKSTREAM-CLOSURE.md`. UIR-09 is the final accepted UIR baseline; no additional UIR passes are planned.

## UX-01 release capability

UX-01 is the conservative PC3 v0.1 release-refinement pass. It retains the accepted UI and operational semantics while completing keyboard/accessibility review, indexed dense-list lookups, session/publication isolation regression, exact visible version disclosure, release traceability, an Accepted.F end-to-end verification script, and documented supported/unsupported capability and exceptional-condition matrices. See `UX-01-PASS-REPORT.md` and `docs/release/UX-01-RELEASE-VERIFICATION.md`.

PC3 v0.1 passed external verification and was accepted on 2026-07-20. See `docs/release/PC3-v0.1-RELEASE-RECORD.md`.

## SEC-01 capability

Publication ZIP intake now applies bounded compressed, entry-count, per-resource, and aggregate-expanded limits before oversized entries are inflated. Unsafe, parent-traversing, drive-qualified, null-containing, and portable case-colliding paths are rejected. Corresponding limits apply to local-directory acquisition before regular files are read. Accepted.F remains within the defaults.

Canonical reference execution retains exact adapter/runtime resolution and digest-pinned disposable Docker environments with no network, read-only root and publication mount, dropped capabilities, no-new-privileges, non-root execution, CPU/memory/swap/PID/tmpfs/time limits, bounded process output, and forced cleanup. An unavailable runtime mapping cannot invoke an adapter or fall back to host computation. Temporary host publication paths are no longer disclosed through operational environment records.

These controls reduce exposure; they do not establish that arbitrary executable publication content or Docker itself is safe. See `docs/security/SEC-01-BOUNDARIES.md` and `SEC-01-PASS-REPORT.md`.

## UIR-09 capability

During initial or replacement publication loading, the Load button now becomes its own left-to-right progress surface. The loading label remains readable above the fill; the button remains disabled and exposes `aria-busy` throughout the operation.

PC3 does not claim byte-accurate server processing percentages. Visual activity advances gradually but is capped at 90 percent until activation returns. It advances to an established post-activation phase, reaches 100 percent only after the realization matrix is ready, remains visibly full for a brief completion beat, and then returns to **Load another…**. Failure restores the normal button and retains the established error presentation. Reduced-motion preference removes the width transition.

UIR-09 passed external verification and was accepted on 2026-07-20.

## UIR-08 capability

Realization Level rows now prefer the realization's explicitly declared publication title. Their supporting line shows a compact identifier formed only by removing the exact active-publication and current-layer prefix: `<publication>-RCI-` for IRs, `<publication>-SR-` for SRs, and `<publication>-DP-` for DPs. If no declared title or exact matching prefix exists, the original identifier is retained rather than interpreted or rewritten.

Each row uses a compact two-line hierarchy with a fixed Exercise column. The former multi-realization pathway string is removed from list rows and remains available in the Instrument Display and Detail Panel. Complete identifiers remain in the row's accessible name and tooltip and continue to appear unchanged elsewhere. Selection, ordering, readiness, Limit filtering, exercisability, and invocation behavior are unchanged.

UIR-08 passed external verification and was accepted on 2026-07-20.

## UIR-07 capability

The entire right-hand Instrument Display now uses one restrained vacuum-fluorescent-display visual system. Its near-black glass surface, cool cyan-white primary readout, muted cyan labels, and tightly reserved amber and red exception signals apply consistently to Realization output, Test Case and resolved-exercise review, legacy Input Object display, Observation inspection, and empty states.

The treatment favors clarity over simulation: prose retains a conventional readable face and generous line height, while identifiers, values, labels, and status use crisp monospaced forms with tabular numerals. Glow is deliberately subtle, the glass texture is stationary, and there are no decorative animations. The Instrument Display gains no buttons, inputs, selectors, or execution behavior; user actions remain in the left control panel.

UIR-07 passed external verification and was accepted on 2026-07-20.

## UIR-06 capability

The loaded-publication dashboard now operates as one accessible windowshade. Its permanent header band retains the publication identity, readiness summary, **Open/Close** control, and **Load another…** action. Closing the dashboard collapses the 12 numeric readouts, Exercise opportunity coverage table, and four rounded status readouts together with one short motion; opening restores them together. The released height immediately allows the left collection panel and right Instrument Display to move upward.

The dashboard defaults open. The control exposes `aria-expanded` and owns the complete collapsible region through `aria-controls`; the closed content is visually hidden, non-interactive, and removed from accessibility reading through `aria-hidden` until reopened.

## UIR-05 capability

Test Case, Realization, and Observation lists now share the same page-flow behavior: each expands naturally to show its contents and none creates an internal list scrollbar. The surrounding page supplies any scrolling required by the viewport. The Test Cases heading now uses **Test Level**, and the Observations heading uses **Observation Level**.

UIR-05 passed external verification and was accepted on 2026-07-20.

## UIR-04 capability

Publication loading is now a direct console action. **Choose publication…** opens the operating system file chooser without an intermediate PC3 dialog, backdrop, or confirmation form; choosing a ZIP begins loading immediately, while canceling the chooser does nothing. After activation, the action becomes **Load another…**. Working and failure feedback remain compactly attached to that action.

The current publication is held separately from transient loading status, so a failed replacement keeps the active publication and its interpreted UI intact. Successful activation still atomically replaces the publication-specific attempts, interactions, Observations, comparisons, Evidence, environments, and matrix.

The empty console removes the specified Session collections unavailable, Current object, and Awaiting publication instructional blocks. It retains only a quiet **No publication loaded** dashboard prompt, the direct chooser, the empty structural surfaces, and Detail Panel.

## UIR-03 capability

The complete **Publication declarations** presentation—including its checks result, declaration checks, issues, and interpretation limitations—now appears inside the Detail Panel rather than above the Session Collection controls. Test Cases, Realizations, and Observations therefore begin at the top of the left control panel. The Detail Panel remains closed by default, but the visible words **Normally closed** have been removed from both empty and loaded states.

## UIR-02 capability

The primary application-view heading now reads **Console View** instead of **Pub Board**. The pass changes that user-facing label only; the established board structure, internal component identifiers, accessibility regions, behavior, and architecture remain unchanged.

## UIR-01 capability

The former **Show Exercisable** control is now a single **Limit** toggle in the Realizations upper band, immediately left of the visible-realization count in the same action pattern used by **Attest** on Observations. Its off state is raised; its on state uses an inset pressed treatment. It retains native `aria-pressed` semantics and requires a selected Publication Test Case.

Limit no longer equates a materialized Resolved Exercise with an enabled action. It now uses the exact `CanonicalExerciseEligibility` result supplied to each row's blue **Exercise** button, including active-context, pathway-selectability, exact resolution, supported invocation, adapter capability, and adapter-availability checks. With Limit on, every visible row therefore has an enabled Exercise action; disabled rows remain available when Limit is off.

## EX-03F capability

EX-03F extends only the accepted Python REST pathway with declaration-derived canonical negative exercises. It preserves a negative PTC's semantic condition separately from ordinary canonical Input Objects, requires an exact compatible RTCM derivation and REST error mapping, records the concrete request and SHA-256 digest, and compares the immutable structured rejection without interpreting message prose.

For accepted.F, PTC-005 supplies the declared nonnumeric age value and PTC-006 places the declared invalid aggregate at `body.inputs`. Their declared HTTP `400` responses are completed Interactions and immutable Observations rather than infrastructure failures. Stored comparison separately evaluates absence of a finite risk, declared error code, mapped subject, and the PTC's must-not-conflate distinction.

PTC-004 remains disabled as `negative_derivation_subject_mismatch`: its canonical PTC requires omission of PSD while its Python REST RTCM directs omission of age. PC3 does not repair either declaration. Negative CLI exits, library exceptions, .NET negative invocation, other REST runtimes, and additional transports remain outside this pass.

## Accepted EX-03E-C1 correction

EX-03E-C1 resolves the numeric HTTP observation through the explicit REST response mapping. In accepted.F, `response_mapping.body.result.from: implementation.result` establishes response path `result`. PC3 no longer applies the CLI-shaped `result.risk` assumption to this REST response. A missing or ambiguous response mapping leaves Exercise disabled rather than triggering guessed extraction.

For accepted.F PTC-001, the observed REST value `0.16871769066837483` is therefore compared with canonical Expected Outcome `0.17099497442391187` under tolerance `1e-12`. The correct stored comparison is `fail`, not `comparison-error`; this remains a comparison result, not a conformance determination.

## EX-03E capability

PC3 now supports an explicit `http` RTCM for a Python REST API Service Realization. It resolves the exact Service Realization metadata, associated service and binding declarations, Python adapter, bound Implementation Representation, canonical entry point, POST route, JSON media types, request-field mappings, runtime, response-body observation contract, and canonical Expected Outcome before enabling Exercise.

The realization remains a Service Realization rather than a Deployment Package. PC3 creates a temporary `pc3.python-http-loopback.v1` arrangement in the accepted digest-pinned Python container, hosts only the declared framework-neutral adapter on container loopback, sends the declared HTTP request, captures status, headers, and the exact response body, then removes the container. Docker networking remains `none`; only in-container loopback is used.

The immutable execution record preserves the mapped request, HTTP status and headers, raw response body, adapter envelope and digest, adapter evidence, REST binding and implementation identities, bridge transfer envelope and digest, image identity, and cleanup disposition. The Runtime Observation is the HTTP response body, not bridge stdout or the adapter's local-harness envelope.

EX-03E does not enable arbitrary URLs, remote services, GET or other HTTP methods, Java or JavaScript REST adapters, gRPC, messaging, MCP, production hosting, Deployment Package connectors, service discovery, authentication, or TLS. It does not claim deployment verification, realization authentication, correctness, conformance, safety, or scientific validity.

## EX-03D capability

PC3 now enables an exact C#/.NET 8 command-line Service Realization when its RTCM, realization declaration, adapter entry point, project, implementation binding, canonical CLI translation, and Docker environment all resolve uniquely. It uses capability `dotnet8-cli-stdout.v1` and the digest-pinned Microsoft .NET 8.0.422 SDK image.

The accepted UKO remains read-only. PC3 creates a separate temporary `pc3.dotnet-cli-source.v1` project that compiles the declared adapter entry point against the unique project under the declared implementation source root. This external orchestration bridge contains no computational logic and is retained by identity and source references in the execution record.

EX-03D-C1 corrected the initial bridge launch path by giving the disposable bridge its own writable `bin` and `obj` locations. External verification then showed that NuGet restore still attempted to create the referenced implementation project's `obj` directory inside the read-only UKO mount.

EX-03D-C2 removes that child-project build. The bridge compiles only the C# source files under the explicitly declared implementation source root, together with the declared adapter entry point. The original implementation project remains validated and recorded as provenance but is never restored or written. All build output stays under the disposable bridge workspace.

EX-03D-C3 prevents SDK-owned first-use workload diagnostics from contaminating a successful realization's stdout. The container uses documented .NET CLI environment controls to skip workload-integrity verification and background workload-update notifications and to disable telemetry and the SDK logo. PC3 does not filter successful process output: the immutable raw Observation remains the exact stdout returned by the adapter boundary.

PC3 never pulls images or downloads dependencies. If the image is absent, pull it explicitly and reload the publication:

`docker pull mcr.microsoft.com/dotnet/sdk:8.0.422-bookworm-slim@sha256:d80fdd84f7e18eea12f8e45c52914f1353395009c95c41197178ea19944e6d48`

EX-03D does not enable C# library or IR invocation, Native AOT artifact selection, service transports, or Deployment Package connectors.

## UII-06 capability

The upper Pub Board dashboard now adds one compact exercise-opportunity matrix directly beneath the accepted twelve UII-05 boxes. Its IR, SR, DP, and TOTAL rows expose Possible, Applicable, uniquely RTCM-resolved, Exercise-enabled, Blocked, N/A, Unclassified, and executable Coverage values simultaneously.

The server computes the projection from exact `PTC identifier × unique realization identifier` pair identities. Applicable and N/A use deterministic publication applicability; RTCM counts immutable Resolved Exercises; Enabled uses the same exact invocation-support tuple that controls each row-level Exercise action. Blocked is Applicable minus Enabled, Unclassified is Possible minus Applicable minus N/A, and Coverage is Enabled divided by Applicable.

The matrix reports invariant or identity ambiguity as a projection error rather than repairing counts. It adds no invocation capability, execution, conformance conclusion, automatic Docker refresh, or historical test-result measure. The accepted PTC, RZN, IR, SR, DP, and TOTAL readouts remain unchanged.

## EX-03-NP1 capability

PC3 now supports explicit `library` RTCMs for Python Implementation Representations whose raw observation is the language-level return value. The planner resolves the exact `representation_id`, language, source root, canonical entry point, referenced execution contract, input signature, and named canonical bindings. The accepted Python Source IR resolves to `uko_ohts.compute` without turning that IR into a Service Realization.

A distinct `python-library-return-value.v1` capability runs through the accepted digest-pinned Docker environment. PC3 mounts a bounded bridge separately from the read-only publication, imports the declared module, calls the declared function, and transfers a deterministic envelope. The immutable Runtime Observation contains only the returned value; function stdout and stderr remain diagnostics, and the exact envelope bytes and digest remain evidence provenance. Import or call failure retains an attributable failed Interaction without retaining a fabricated Observation.

Python CLI remains on its separate `python-cli-stdout.v1` path. Unsupported library languages, missing or ambiguous declarations, non-identity mappings, unavailable Docker, and absent pinned images remain visible and disabled. This pass does not add package installation, non-Python libraries, or service transports.

## EX-03C capability

Canonical reference execution now occurs inside a disposable Docker environment supplied after EX-03B resolves the exact adapter capability. PC3 maps canonical Python explicitly to the digest-pinned `python:3.12-slim@sha256:57cd7c3a7a273101a6485ba99423ee568157882804b1124b4dd04266317710de` image. Publication activation checks the Docker daemon and exact local image without pulling; absent operational prerequisites disable Exercise with an attributable reason.

The provider creates a uniquely named container with network disabled, a read-only root, dropped capabilities, no-new-privileges, an unprivileged user, a read-only temporary publication mount, and bounded CPU, memory, process count, tmpfs, and time. It captures stdout, stderr, exit and timeout state through the accepted adapter and force-removes the container in every outcome. Cleanup failure is explicit.

The Execution Environment Description and attested evidence retain the provider, immutable image reference, observed local image ID, container name, mount, isolation policy, limits, and cleanup disposition. These facts establish environment identity and lifecycle provenance; they do not authenticate the realization or prove reproducibility, safety, correctness, or conformance.

## EX-03B capability (accepted prerequisite)

PC3 now resolves each immutable generic RTCM invocation plan against explicit capabilities published by its registered execution adapters. The capability contract includes invocation mode, realization layer, observation location and preservation requirement, canonical runtime, bounded aliases, and launcher executable. Resolution requires exactly one match: no match and multiple matches are distinct bounded failures, and PC3 never chooses by registration order or fallback.

The accepted local-process STDIO adapter declares `python-cli-stdout.v1`. It supports explicit Python aliases for CLI plans across IR, SR, and DP realization layers when raw stdout must be preserved. The publication-activation support projection and the execution route use the same resolver, so a row cannot appear executable under rules different from those used at execution time.

Completed execution records retain the adapter ID and version, capability ID, canonical runtime, publication-declared runtime requirement, selected launcher, and `registered-adapter-capability-match` resolution basis. EX-03B adds no new runtime or transport; Rust, C#/.NET, REST, missing declarations, and ambiguous adapter matches remain explicit non-executable outcomes.

## EX-03A capability (accepted prerequisite)

PC3 now derives an immutable CLI invocation plan from the exact publication-bound Exercise Attempt and its server-resolved PTC, realization, and RTCM. The planner no longer names one UKO-001 PTC or realization. It computes the pairing identity, finds one realization declaration through the layer-appropriate explicit identity field, resolves the declared adapter asset, binds the canonical input in RTCM argument order, and retains the declaration and runtime-resolution basis in the Execution Interaction.

EX-03A is intentionally a planning pass, not the complete runtime integration. It plans explicitly declared CLI environment requirements generically. EX-03B now performs the separate adapter-capability resolution step. Other invocation modes and unmatched runtimes remain bounded outcomes for later adapter and environment passes. No runtime or realization identity is inferred from filenames, directory names, or executable contents.

The accepted UKO uses deliberately generic RTCM external-environment wording and identifies Python explicitly in the realization declaration. PC3 therefore enables the CLI exercise from the Resolved Exercise and resolves the current bridge from `language_or_ecosystem: Python`, retaining that declaration as provenance. It does not require the RTCM to duplicate the realization's language.

Publication activation also assesses the current local invocation support of every exact PTC, realization, and RTCM tuple. A row's blue Exercise action is enabled only when the accepted bridge can execute that tuple. Resolved but currently unsupported rows remain visible with disabled actions and attributable reasons; a readable generic plan alone never signals executability.

## UII-05 capability

The upper dashboard now presents twelve permanently visible numeric readouts in one aligned desktop row: four PTC completeness boxes, four unique-realization completeness boxes marked **RZN**, and the four black **IR**, **SR**, **DP**, and **TOTAL** pathway boxes. Both completeness groups use fixed Complete, Partial, None, and N/A order with the accepted status colors. All boxes share the same height, numeric baseline, and lower-label baseline.

The visible **Exercise Completeness** heading and the **By Realization / By PTC** toggle are removed, along with their state and reset behavior. PTC values continue to come from the per-Test-Case projection, RZN values from unique realization readiness records, and the black values from pathway inventory; PC3 does not force these different populations to reconcile. Publications without PTC capability retain four explained zero-valued PTC boxes. Narrow layouts wrap only complete four-box groups.

The left-hand capability-profile banner is also removed. The bounded publication surface now uses **Declaration checks** language, while the interpreted exercise model and its rationale remain available only through the normally closed **Advanced publication inspection** details.

## UII-04 capability (accepted prerequisite)

Every item in the **Observations** collection is now a selectable, first-class operational object. Selecting one renders that exact immutable Runtime Observation in the Instrument Display: identity and PTC/RTCM scope, external execution outcome, exact raw value and integrity metadata, and its separately stored Expected Outcome comparison. The execution outcome and comparison status remain distinct, and a missing comparison is stated without inferring pass, failure, or error.

The normally closed Detail Panel provides exact extraction and RTCM provenance, normalization and property classifications, associated external interaction and process diagnostics, execution-environment assurance, and any already-attested Evidence. Associations use exact stored identities; rendering never recomputes, executes, or changes a record. Selection survives collection switching, clears when the selected item disappears or the publication is replaced, and is not displaced by a newly produced Observation.

Observation history appears only in the left Observations collection; the redundant right-hand Session Observations and Evidence panels and all individual save/discard/attest controls are removed. The reclaimed Instrument Display is devoted to **Latest output**. One **Attest** button immediately left of the Observations count is the sole formal save function: it covers every current Observation and downloads one integrity-bound collection-attestation artifact external to the UKO.

## UII-03 capability (accepted prerequisite)

Each visible IR, SR, and DP realization row now includes a small **Exercise** action separate from row selection. For the accepted `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` reference path, that one action uses the Test Case selected in the sole Test Cases list, selects the clicked realization, prepares a fresh immutable canonical attempt, executes it through the existing external Python process boundary, automatically captures a new Runtime Observation, and refreshes the separate Expected Outcome comparison.

The action exposes a per-row busy state and prevents duplicate activation. Repeated exercises create distinct attempts, interactions, and observations. Unsupported invocation modes, unresolved pairings, absent adapters, and inactive contexts remain visible with disabled controls; their reasons are accessible without persistent text beneath each button. The former right-hand Prepare and Run modules are removed and their space is reclaimed so the Instrument Display concentrates on output, observation history, and attestation. UII-03 does not broaden EX-02 invocation support, change Test Case selection, or automatically save observations or attest evidence.

## UII-02 capability (accepted prerequisite)

The Realizations collection now provides one accessible **Show Exercisable** On/Off toggle at Realization Level. Off preserves the complete IR, SR, or DP list. On shows only endpoint pathways for which PC3 has materialized a Resolved Computational Exercise for the Test Case selected in the sole Test Cases list. Counts follow the filtered view; empty and unavailable contexts are explicit. Filtering never changes the selected Test Case or silently selects a replacement realization, and publication replacement resets the control to Off.

## UII-01 capability (accepted prerequisite)

The existing **Publication Test Cases** list is now the only user-facing Test Case selection control. The duplicate **Applicable realizations** button block beneath Test Cases and the **Test case for [realization]** dropdown in Realizations have been removed. Changing realization level or channel no longer silently substitutes another PTC. The Test Case explicitly selected in the list persists, and PC3 resolves only its exact pairing with the selected realization; unavailable or incompatible pairings remain explicit and blocked without fallback.

## ATT-01 capability

ATT-01 extends the existing optional PC3 attestation path across the complete PTC exercise record: publication load and identifier, PTC, RTCM, realization, immutable Exercise Attempt, canonical or exploratory input disposition and hashed snapshot, Execution Interaction, immutable raw Runtime Observation, separate Expected Outcome comparison, external executor/environment description, and exact PC3 implementation identity.

For PTC-scoped observations, PC3 refuses attestation unless the comparison and every identity in the chain match. Comparison outcomes are preserved exactly, including `fail`, `indeterminate`, and `comparison-error`; attestation never turns them into conformance or correctness claims. Each internal Evidence digest covers its exercise record and PC3 identity. UII-04 invokes that accepted infrastructure only through the single formal collection-level **Attest** save.

## OBS-02 capability (accepted prerequisite)

OBS-02 adds a separate deterministic comparison service for the accepted `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` reference path. It extracts the numeric `result.risk` semantic observation from completed CLI JSON, applies only explicitly permitted normalization to a separate representation, and compares the extracted value with the canonical Expected Outcome using the declared numeric absolute tolerance.

Each immutable result is `pass`, `fail`, `indeterminate`, or `comparison-error`. Raw, normalized, extracted, expected, and comparison representations remain separate. A fail preserves the exact discrepancy; an indeterminate or comparison error preserves its cause. No result changes the OBS-01 observation or constitutes a conformance claim.

## OBS-01 capability (accepted prerequisite)

Every Runtime Observation now preserves a separately identified immutable raw observation with its exact value, media type, source location, SHA-256 digest, and direct-observation or external-report classification. PTC-bound observations inherit the immutable PTC, RTCM, and realization binding from their Exercise Interaction. Reference observations also retain the RTCM extraction declaration and its provenance.

Declared normalizations are represented as explicit `declared-not-applied` records linked to the raw-observation identity. OBS-01 performs no extraction, normalization, comparison, scientific validation, or conformance determination. The existing `response` view remains for compatibility and contains the same unchanged raw value.

## EX-02 capability (accepted prerequisite)

EX-02 implements the deliberately narrow reference path `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE`. From a canonical EX-01 attempt, PC3 requires one matching resolved RTCM, one explicit service-realization declaration, the declared adapter asset, the RTCM argument order, and the service declaration's ordered CLI input translation. It constructs the exact named-argument invocation and launches the publication adapter only in a temporary external Python process. The UKO remains read-only.

The immutable Execution Interaction retains declaration and adapter provenance, the canonical field-to-option bindings, concrete invocation, raw stdout, stderr, exit code, signal, and timeout state. Completed, failed, and indeterminate outcomes are recorded without substitution or repair. The publication's comparison declaration is retained as `declared-not-yet-evaluated`; comparison remains OBS-02 work.

## EX-01 capability (accepted prerequisite)

Exercise Attempt preparation now extends the accepted attempt and external-adapter architecture with an immutable publication-exercise binding. Under an authoritative PTC capability profile, an attempt records the selected PTC, uniquely resolved authoritative RTCM, selected realization, publication load, active context, pathway, exact input snapshot, and canonical or exploratory disposition. Canonical input is supplied from the server-owned Resolved Exercise; exploratory input is user supplied but retains the same resolved binding. PC3 creates no attempt when authority is incomplete or invalid, the PTC is absent, the pairing is non-applicable, or RTCM resolution is missing or ambiguous. Review remains non-executing, preparation requires explicit user action, and the existing local-process adapter remains an external execution boundary.

## UI-10 capability

The upper Pub Board dashboard now contains one exercise-completeness projection immediately to the left of the dark IR, SR, DP, and Total realization boxes. Its green Complete, yellow Partial, red None, and grey Not applicable counts can be switched in place between **By Realization** and **By PTC**. By Realization is the default and is restored when a new publication loads; By PTC is unavailable when the active publication declares no PTC capability. The former duplicate projections have been removed from the Session Collection Panel, which retains the publication-validation disclosure.

## UI-08 capability

The contextual Detail Panel now contains a normally closed **Advanced publication inspection** surface. Nested disclosures expose RTCM provenance and SHA-256 integrity attribution, applicability basis, relationship and coverage indexes, authoritative versus supporting declarations, validation issues, and grouped unresolved or conflicting publication information. Repeated limitations with the same meaning are presented once with all attributable declaration locations. RTCMs remain automatically resolved implementation objects and are not introduced as primary navigation choices.

## UI-07 capability

PC3 now materializes every uniquely authoritative, applicable PTC/realization/RTCM resolution as an immutable Resolved Computational Exercise during publication interpretation. The Test Cases display uses that server-produced object as its sole review authority. Before any execution action, the user can inspect the selected PTC and realization, resolved RTCM, canonical input, canonical Expected Outcome, comparison semantics, invocation and input mapping, observation mapping, execution boundary, external-environment requirements, and RTCM limitations. The review explicitly creates no Exercise Attempt and performs no execution.

## UI-06 capability

The Pub Board now presents publication exercise completeness separately by realization and by Publication Test Case. Both projections distinguish `complete`, `partial`, `none`, and `not-applicable` declaration states. Realization channels and PTC entries expose their own publication-readiness state, while the selected object provides attributable counts and missing-RTCM details. An expandable validation surface presents the declaration-validation status, category checks, issues, and interpretation limitations. The interface explicitly states that publication completeness is not deployment status, environment availability, runtime readiness, an execution result, scientific validity, or conformance.

## UI-05 capability

The Session Collection Panel is now governed by the publication capability profile. A PTC-profile publication presents **Test Cases** in place of legacy standalone **Inputs**. Each Publication Test Case exposes its purpose, classification, canonical input, Expected Outcome, comparison semantics, applicability, and provenance. PTC-first navigation lists applicable IR, SR, and DP realization endpoints; realization-first navigation lists the PTCs applicable to the selected endpoint. Both routes update one shared PTC/realization pairing and resolve the same authoritative RTCM from the publication discovery index. Legacy-input publications retain the accepted UI-04 Inputs collection. Ambiguous/mixed publications preserve their inputs and display unresolved exercise authority without guessing.

## PC3-PTC-04 capability

PC3 Interpretation now selects an explicit publication capability profile from declarations rather than filenames or version labels. A complete, valid PTC architecture is authoritative for exercise behavior and makes any coexisting standalone Input Objects subordinate. Standalone Input Objects retain legacy UI-04 behavior only when no explicit PTC architecture is declared. Explicit but incomplete or invalid PTC authority produces an explained ambiguous/mixed profile: both sources are preserved and PC3 refuses to guess. Publications declaring neither capability receive the bounded `none` profile. Profile rationale, limitations, counts, authority, and declaration provenance are exposed through the interpretation API; the visible UI is unchanged in this pass.

DEV-10 introduces a separate PC3 attestation act after automatic Runtime Observation capture.

```text
Exercise Attempt
  -> Execution Interaction
  -> Ephemeral Runtime Observation
  -> PC3 Attestation
  -> Ephemeral Execution Evidence
  -> Optional external save
```

Execution Evidence is not "derived" in the realization-architecture sense. PC3 creates it by attesting that a self-contained evidence package faithfully preserves:

- the Runtime Observation;
- publication and active-context identity;
- the complete realization pathway and endpoint;
- the Exercise Attempt and exact input snapshot;
- the Execution Interaction and exact response snapshot;
- PC3 implementation identity and version;
- a SHA-256 integrity digest over the observation and provenance.

The attestation is bounded. PC3 does **not** attest that the external execution was correct, scientifically valid, or independently verified. DEV-10 records `cryptographicSignatureDisposition: not-implemented`; the architectural attestation does not falsely imply a digital signature.

Execution Evidence is held in memory by default. The Pub Board exposes one formal **Attest** save for all current Observations, producing one PC3-authored collection JSON file external to the UKO without modifying the published computational capability.

## DEV-11C capability

DEV-11C refines the Pub Board into a split-view operating surface. Realization Channels are compact selectors in a persistent channel bank. The Pub Board owns exactly one shared **Input, Execute, Monitor, Attest** workspace. Selecting a channel transfers that pathway's attempts, interactions, observations, and evidence into the universal workspace, allowing rapid inspection and attestation across many realizations without opening channel-specific mini-applications. The pass changes presentation and context projection only; all accepted execution, observation, evidence, and UKO-immutability semantics remain unchanged.

## DEV-11B capability

DEV-11B establishes the **Pub Board** as the primary workspace for one active publication. Every executable realization pathway appears as a **Realization Channel** with immediate state signals and direct access to input preparation, external exercise, output observation, and optional evidence attestation. Engineering detail remains available through progressive disclosure. The pass changes presentation only and preserves all DEV-11 execution and DEV-10 evidence semantics.

## DEV-11 capability

DEV-11 introduces the first external execution adapter. The registered local-process STDIO adapter launches a separate operating-system process, sends the latest immutable Exercise Attempt input through standard input, captures standard output/error and process disposition, and automatically creates the existing Execution Interaction and ephemeral Runtime Observation. PC3 coordinates and observes this boundary; the child process is the execution environment. Realization identity assurance is `reported`, not verified.


## Requirements

- Node.js 22 or later
- npm 10 or later

## Local development

```bash
npm ci
npm run verify
npm run dev
```

Open `http://localhost:5173`.

## PC3-PTC-03 publication validation

PC3 validates a discovered UKO 1.1 Publication Test Case architecture across five declaration-only lanes:

- referential integrity;
- applicability consistency;
- inventory synchronization;
- declaration completeness;
- fixed publication invariants.

The immutable `publicationValidation` result is included in publication interpretation responses. It reports `valid`, `valid-with-warnings`, `invalid`, or `not-applicable`, retains declaration provenance for individual issues, and never repairs the publication. Validation does not execute a realization or assert runtime availability, execution success, scientific validity, or conformance. The PC3-PTC-03 pass does not change the visible UI.

## PC3-PTC-03-C1 authority correction

Publication identity is selected by declaration authority: an explicit `describes` object typed as a Publication outranks generic publication containers and identifiers. Exercise declarations, inventories, summaries, evidence, and development artifacts cannot masquerade as publication identity declarations. Resources below `_Development` remain loaded and inspectable as Publication Truth but are excluded from operational discovery.

Repeated declarations of the same semantic realization relationship are treated as corroborating provenance. Conflicting semantic relationships remain visible limitations. Unresolved references remain attributable to their source declarations and are never repaired.

## Browser acceptance path

1. Load and activate the accepted UKO ZIP.
2. Select `UKO-001-PTC-001`, open **Realizations**, and choose the **SR** level.
3. On `UKO-001-SR-PYTHON-COMMAND-LINE`, choose the row-level **Exercise** action once; confirm it reads **Exercising…** while duplicate activation is disabled.
4. Confirm the row becomes completed, the Observations count increases, and **Latest output** uses the full right-hand result area without a duplicated Session Observations or Evidence panel.
5. Open **Observations** and select different Observation rows. Confirm each exact immutable Observation and comparison renders without individual Save, Discard, or Attest controls.
6. Confirm one **Attest** button appears immediately left of the Observations count.
7. Choose **Attest** and confirm one `pc3-observation-collection-attestation-*.json` file downloads.
8. Confirm its `observationCount` equals the current collection count, its ordered `evidence` covers every current Observation, and its collection integrity digest is present.
9. Return to **IR**, locate `UKO-001-RCI-PYTHON-IR-001`, and confirm its Exercise action is enabled when Docker and the pinned Python image are ready. Exercise it and confirm the raw Observation location is `return-value`, with a numeric value rather than process stdout.
10. Confirm the dashboard shows one compact **Exercise opportunity coverage** matrix with IR, SR, DP, and TOTAL rows and all eight metrics visible. Across all PTCs and realization levels, confirm Enabled matches the exact pairings whose Exercise actions are blue, and confirm that the accepted twelve boxes remain unchanged.
11. Return to **SR**, locate `UKO-001-SR-CSHARP-NATIVE-COMMAND-LINE`, and confirm its Exercise action is enabled when Docker and the pinned .NET image are ready. Exercise it and confirm the raw Observation location is `stdout`.
12. In progressive detail, confirm canonical runtime `.NET 8`, capability `dotnet8-cli-stdout.v1`, bridge `pc3.dotnet-cli-source.v1`, the pinned image identity, and cleanup `removed`.
13. With `UKO-001-Version-1.1-Accepted.F.zip` loaded, select `UKO-001-PTC-001` and `UKO-001-SR-PYTHON-REST`; confirm its Exercise action is enabled when Docker and the pinned Python image are ready. Exercise it and confirm Latest output is the JSON HTTP response body rather than the adapter harness envelope.
14. In progressive detail, confirm mode `http`, capability `python-http-response-body.v1`, bridge `pc3.python-http-loopback.v1`, POST route `/ohts-egps/5-year-risk`, HTTP status `200`, REST binding `uko-001-python-rest-binding`, implementation `UKO-001-RCI-PYTHON-IR-001`, pinned image identity, network `none`, and cleanup `removed`.
15. Confirm the resulting comparison truthfully reports pass, fail, indeterminate, or comparison error from the publication's Expected Outcome; execution success does not force a pass.
16. Select `UKO-001-PTC-005` and confirm Python REST becomes exercisable when Docker is ready. Exercise it and verify a completed HTTP `400` Observation with `REST_INVALID_PARAMETER`, subject `age_years`, no risk result, and comparison `pass`.
17. Select `UKO-001-PTC-006`, exercise Python REST, and verify `REST_INVALID_REQUEST_SHAPE`, no risk result, the invalid-aggregate distinction, and comparison `pass`.
18. Select `UKO-001-PTC-004` and confirm Python REST remains disabled with the PSD-versus-age negative-derivation subject mismatch.
19. Confirm progressive detail shows the negative operation, subject, exact request and digest, PTC/RTCM/binding provenance, observed rejection, and semantic assertions.
20. Open **Realizations** and confirm one **Limit** button appears in the upper band immediately left of the visible count; confirm the former full-width Show Exercisable control and On/Off text are absent.
21. Toggle **Limit** on and off; confirm the on state appears pushed in and the off state appears raised.
22. With **Limit** on, switch among IR, SR, and DP and confirm every visible realization has an enabled blue **Exercise** button. Turn Limit off and confirm disabled realization rows return.
23. Confirm the primary application heading reads **Console View**, with no **Pub Board** heading remaining.
24. Confirm Test Cases, Realizations, and Observations begin at the top of the left control panel with no Publication declarations block above them.
25. Open **Detail Panel** and confirm Publication declarations, its checks result, declaration checks, issues, and interpretation limitations remain present.
26. Confirm the words **Normally closed** do not appear beside Detail Panel in either the empty or loaded state.
27. From the empty console, confirm the specified Session collections unavailable, Current object, and Awaiting publication copy is absent.
28. Choose **Choose publication…** and confirm the operating-system file chooser opens directly with no PC3 modal or dimmed backdrop.
29. Cancel the chooser and confirm nothing changes; choose a ZIP and confirm loading begins immediately.
30. After activation, confirm the action reads **Load another…** and a failed replacement leaves the current publication intact.
31. Confirm the Test Cases, Realizations, and Observations lists have no internal scrollbars and expand naturally with their contents.
32. Confirm the Test Cases heading reads **Test Level** and the Observations heading reads **Observation Level**.
33. Choose **Close** in the dashboard header and confirm the 12 numeric readouts, opportunity-coverage table, and four rounded status readouts collapse together.
34. Confirm the publication identity, readiness, **Open**, and **Load another…** remain visible in the header band and the panels below move upward.
35. Choose **Open** and confirm the complete dashboard body returns together.
36. Confirm the artifact identifies version `0.1.0` and pass `UX-01` and does not attest conformance, correctness, deployment verification, scientific validity, or safety.
37. Confirm the artifact is external to the UKO and the UKO remains unchanged.

## External execution-response intake

```http
POST /api/sessions/{sessionId}/exercise-attempts/{attemptId}/execution-responses?expectedActiveContextId={contextId}
Content-Type: application/json
```

```json
{
  "externalInteractionId": "adapter-owned-unique-id",
  "receivedFrom": "adapter-or-external-system-identity",
  "outcome": "completed",
  "responseMediaType": "application/json",
  "responseValue": "{\"result\":42}",
  "runtimeReportedAt": "2026-07-17T12:00:00Z",
  "environmentIdentity": "optional-external-environment-identity"
}
```

## Execution Evidence API

```http
POST /api/sessions/{sessionId}/runtime-observations/{observationId}/attest?expectedActiveContextId={contextId}
GET  /api/sessions/{sessionId}/execution-evidence
GET  /api/sessions/{sessionId}/execution-evidence/{evidenceId}/save
DELETE /api/sessions/{sessionId}/execution-evidence/{evidenceId}?expectedActiveContextId={contextId}
```


## DEV-12 capability

DEV-12 makes the external execution environment an explicit, immutable PC3 description linked to the Exercise Attempt, Execution Interaction, Runtime Observation, and resulting evidence provenance. Properties are individually classified as observed, reported, or unavailable. PC3 describes environments but does not provision, manage, authenticate, or claim reproducibility for them.


## DEV-12B Pub Board refinement

DEV-12B adds a mutually exclusive IR/SR/DP realization-level selector to the Realization Channel bank. The bank displays only pathways whose endpoint belongs to the active level, restores the last-used channel for each level when possible, and keeps the single shared Input, Execute, Monitor, Attest workspace unchanged. Channel rows, headings, spacing, typography, and the split-view proportion are tightened to improve scanability and reduce information overload. No server, execution, environment, observation, evidence, or publication behavior changes.


## DEV-12C Operational Workspace refinement

DEV-12C reorganizes the right-hand Shared Operational Workspace into one explicit four-stage flow: Input, Execute, Monitor, and Attest. A persistent selected-realization header now shows endpoint identity, pathway context, operating status, and identity-assurance scope. Stage navigation and stage headers display current, pending, and complete state without changing any action semantics. Input and Execute remain paired; Monitor now cohesively contains the latest output and its Runtime Observation records; Attest remains a distinct evidence stage. Pathway and Execution Environment Description information remains available in a visually subordinate engineering-details disclosure. No publication, pathway, adapter, execution, environment, observation, evidence, or persistence behavior changes.


## DEV-12D Operational Status Panel

DEV-12D replaces the oversized active-publication banner with a compact instrumentation-style status panel at the top of the Pub Board. The existing Executable Realization Matrix is promoted from Engineering Inspection into this persistent readout, showing IR, SR, DP, and total executable-realization counts. The active realization layer is indicated by a thin layer-specific border on its count box. Redundant channel-count text is removed, while pathway integrity and coverage details remain available in Engineering Inspection without duplicating the matrix. This is a presentation-only pass; publication interpretation, realization selection, execution, environment description, observation, evidence, and persistence semantics are unchanged.


## DEV-12E Realization Switching Behavior

DEV-12E makes realization switching immediate within and across IR, SR, and DP views. Selecting a different channel resets the transient Input → Execute → Monitor → Attest workspace without warning or confirmation. Existing Runtime Observations, Execution Evidence, Execution Interactions, and Execution Environment Descriptions remain session records; they are not deleted, but prior records no longer drive the newly selected workspace's stage state. Failed selection requests restore the prior workspace context.


## DEV-12F Session Observation Sequencing

DEV-12F assigns every Runtime Observation an immutable, monotonic sequence number owned by the publication session rather than by a realization channel. UII-04 presents that accumulated sequence only in the left Observations collection across IR, SR, and DP switching. Each record still identifies the realization that produced it; the sequence remains monotonic and immutable.


## NEW UI PASS X — Pub Board Rebalancing

The Pub Board is rebalanced away from an explorer-and-details presentation. Realization selectors are wider and materially shorter, with secondary pathway and activity detail removed from each visible row. The right-hand operating surface is one vertical Input → Execute → Check → Attest sequence. “Monitor” is renamed “Check” because the stage evaluates the produced observation rather than continuously monitoring a runtime. This pass changes presentation and user-facing terminology only; switching, execution, observation sequencing, evidence, accessibility, and UKO immutability behavior remain unchanged.


## UI PASS Z Instrument Character

UI Pass Z establishes the Pub Board as one dedicated publication-centered computational instrument. The board is divided into a Publication Session Dashboard, Realization Selector Bank, and Operating Deck. The four operational stages remain Input, Execute, Check, and Attest, but they now read as one continuous process frame. The selector bank remains compact and adds bounded scrolling for publications with many realization pathways. This pass changes presentation only.
