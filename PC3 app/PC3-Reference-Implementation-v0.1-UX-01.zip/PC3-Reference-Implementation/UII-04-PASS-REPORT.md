# UII-04 Pass Report

Status: **implementation complete; awaiting external validation**

Baseline: externally accepted **UII-03 — One-Click Canonical Exercise from Realization Lists**

Implementation identity: **0.0.0-uii-04 / UII-04**

## Delivered behavior

- Selecting an item in the Observations collection renders that exact Runtime Observation in the Instrument Display.
- The display separates the external execution outcome from the stored Expected Outcome comparison status.
- Observation number, immutable identity, captured time, realization, PTC, RTCM, Attempt, and Interaction identities are visible.
- The exact immutable raw value remains selectable and scrollable with media type, raw identity, SHA-256, location, preservation disposition, and source classification.
- The accepted OBS-02 presentation renders the exact stored comparison, including pass, fail, indeterminate, comparison-error, representations, tolerance, difference, extraction, normalization, attributable error, and the comparison-result-not-conformance boundary.
- An Observation without a comparison states that none is recorded without inferring pass, failure, or error.
- The normally closed Detail Panel progressively exposes extraction/RTCM provenance, normalization records, property classifications, exact Interaction and external-process diagnostics, environment assurance, and exactly associated Evidence.
- Associations are identity-exact: comparison by Observation identifier, Interaction by Execution Interaction identifier, environment by Execution Environment Description identifier, and Evidence by its embedded Runtime Observation identifier. No latest-record fallback is used.
- Selection survives collection switching, clears when stale or when the publication is replaced, and is not displaced by a newly created Observation.
- Rendering is read-only and performs no execution, recomputation, saving, discard, attestation, or publication mutation.
- The obsolete “Observation rendering begins in UI-04” placeholder is removed.
- The left Observations collection is the sole Observation list and selection surface. The redundant right-hand Session Observations list is removed.
- All individual Observation and Evidence Save, Discard, and Attest controls are removed from the Pub Board.
- The right-hand **Latest output** surface occupies the space reclaimed from the duplicate Session Observations and Evidence panels.
- One **Attest** button appears immediately left of the count in the Observations heading. It is the sole formal save action and always covers the complete current Observation collection.
- A successful Attest action downloads one `pc3-observation-collection-attestation` artifact containing ordered per-Observation Evidence and an integrity digest covering the current Observation Evidence identities, their digests, and PC3 identity.

## Verification

`npm run verify` passes:

- architectural dependency boundary check;
- shared, server, and web type checks;
- **104/104 server tests**;
- **87/87 web tests**, including the focused UII-04 rendering and correction checks;
- shared, server, and production web builds.

## External validation path

1. Start PC3 with `npm run dev` and open the web address printed by the development server.
2. Load the accepted UKO 1.1 publication and exercise the supported Python command-line realization at least twice.
3. Open **Observations** and select an Observation other than the newest if more than one exists.
4. Confirm the Instrument Display shows the selected Observation number and identifier, execution outcome, realization, PTC/RTCM scope, Attempt/Interaction identities, exact raw value and metadata, and a separately labelled stored Expected Outcome comparison.
5. Expand **Detail Panel**, then inspect extraction/RTCM provenance, normalization, classifications, Interaction/process, environment, and associated Evidence sections. Missing optional information must say unavailable or not recorded.
6. Switch to Test Cases or Realizations and back. Confirm the explicitly selected Observation remains selected.
7. In Realizations, confirm **Latest output** uses the full right-hand result area. Confirm no duplicate Session Observations list, Evidence panel, or individual Save/Discard/Attest action appears anywhere in the right-hand display.
8. Return to Observations and confirm exactly one **Attest** button appears immediately left of the Observation count. Choose it once.
9. Confirm one `pc3-observation-collection-attestation-*.json` downloads. Its `observationCount` must equal the current left-hand count; its ordered `evidence` must cover every current Observation; and its collection integrity digest must be present. Confirm the artifact identifies `0.0.0-uii-04 / UII-04` and retains the non-conformance boundary.
10. Load a replacement publication and confirm stale Observation selection is cleared. Confirm inspection itself creates no attempt, interaction, observation, comparison, saved file, or evidence and that the UKO archive remains unchanged.

## Scope boundary

UII-04 changes Observation inspection, removes redundant individual lifecycle controls, and establishes one collection-level formal attestation save. It does not change Observation capture, comparison computation, one-click exercise, invocation support, or dashboard alignment. The established per-Observation Evidence composition remains internal infrastructure of the collection artifact. UII-05 remains separately gated.
