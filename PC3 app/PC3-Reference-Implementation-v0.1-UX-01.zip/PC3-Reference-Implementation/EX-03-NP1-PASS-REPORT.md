# EX-03-NP1 Pass Report

Status: **externally verified and accepted — 2026-07-19**.

## Delivered

- Added the distinct `python-library-return-value.v1` adapter capability.
- Resolved Python IR identity through `representation_id` and the primary representation declaration.
- Resolved language, source root, `uko_ohts.compute`, execution-contract signature, and canonical named bindings from explicit publication material.
- Added a separately mounted, PC3-owned Python bridge; publication resources remain read-only and unmodified.
- Preserved the language return value as the raw Runtime Observation while retaining bridge transfer bytes, SHA-256, and function diagnostics separately.
- Added direct-return Expected Outcome comparison without changing the accepted CLI `result.risk` comparison.
- Retained failed library calls as exceptional Interactions without retaining a fabricated Observation.
- Enabled the one-click Exercise action for server-assessed `library` RTCMs.

## Verification

- Type checking passes.
- Focused server, Docker-provider, and UI tests pass.
- Tests cover library success, distinct diagnostic stdout, direct return comparison, exact bridge envelope provenance, failed import behavior, separate infrastructure mount, and unchanged CLI support.
- The accepted Python IR declarations were resolved directly from the read-only accepted corpus copy, including the RTCM `age` / execution-contract `age_years` distinction.

## Boundaries

Only Python language-function IR invocation is added. Non-Python libraries, dependency installation, C#/.NET CLI, HTTP and other service transports remain deferred. No result is a conformance, correctness, safety, or scientific-validity claim.
