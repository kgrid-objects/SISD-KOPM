# EX-03E-C1 Pass Report

Status: **externally verified and accepted**.

## Correction

EX-03E completed the accepted.F Python REST exchange and preserved the correct immutable response body, but its comparison stage imposed `result.risk`. The governing REST binding declares `response_mapping.body.result.from: implementation.result`, and the actual response contains the finite numeric observation at `result`.

EX-03E-C1 now:

- requires exactly one successful REST response-body field explicitly mapped from `implementation.result`;
- derives the semantic observation path from that declaration rather than from a realization-specific output assumption;
- records extraction strategy `json-declared-path` and the resolved path in the immutable reference-execution and comparison records;
- extracts the numeric value without modifying the raw response body;
- disables missing, duplicate, unsafe, or unsupported response mappings instead of guessing;
- preserves all EX-03E execution, isolation, provenance, Observation, Attestation, and UI boundaries.

## Governing accepted.F result

For `UKO-001-PTC-001 × UKO-001-SR-PYTHON-REST`, accepted.F resolves response path `result`. The externally observed value `0.16871769066837483` is extracted successfully and compared with canonical Expected Outcome `0.17099497442391187` under absolute tolerance `1e-12`. The truthful result is **fail**, with absolute difference `0.0022772837555370407`. This remains a comparison result, not a conformance determination.

## External verification

1. Load `UKO-001-Version-1.1-Accepted.F.zip`.
2. Select `UKO-001-PTC-001` and exercise `UKO-001-SR-PYTHON-REST`.
3. Confirm Latest output preserves the response body with numeric field `result`.
4. Confirm Stored Expected Outcome comparison is `fail`, not `comparison-error`.
5. Confirm Comparison representations show extracted path `result`, observed value `0.16871769066837483`, expected value `0.17099497442391187`, tolerance `1e-12`, and absolute difference `0.0022772837555370407`.
6. Confirm the raw Observation remains unchanged and the comparison remains explicitly non-conformance.
