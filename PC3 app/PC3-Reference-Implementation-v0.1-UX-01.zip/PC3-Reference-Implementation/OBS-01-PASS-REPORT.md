# OBS-01 Pass Report

## PTC-Scoped Observation Capture

OBS-01 extends the accepted EX-02 execution path and the existing Runtime Observation architecture without performing comparison.

### Delivered behavior

- A PTC-bound Execution Interaction immutably carries the Exercise Attempt's exact PTC, RTCM, realization, and unique-resolution association.
- Its derived Runtime Observation exposes the same association as `publicationExerciseScope`.
- Every Runtime Observation contains a separately identifiable `rawObservation` with stable interaction-linked identity, exact media type and value, source location, SHA-256 digest, preservation disposition, and source classification.
- The compatibility `response` view remains and contains the same unchanged value as `rawObservation`.
- Reference observations retain RTCM extraction expression, semantic outcome, raw observation location, and declaration provenance when explicitly declared.
- Missing extraction provenance remains explicitly unavailable; PC3 does not infer it.
- Each declared normalization produces a `declared-not-applied` record linked to the raw-observation identity. An empty declaration produces an empty record set. Neither case changes raw content.
- Observation properties are grouped as `directly-observed`, `externally-reported`, or `pc3-derived`, with an explicit basis for each classification.
- Saved Runtime Observation schema version 1.3 contains the complete OBS-01 object and remains external to the UKO.
- The Pub Board Check surface shows the immutable raw content first and provides a progressive **Raw identity and PTC scope** inspection containing the digest, binding, extraction disposition, normalization status, and classifications.

### Architectural boundary

OBS-01 captures and classifies observations. It does not extract a semantic result, apply normalization, compare against the canonical Expected Outcome, alter the raw observation, independently verify execution, determine scientific validity, or assert conformance. Those boundaries remain explicit; deterministic comparison is OBS-02.

### External verification path

1. Load the accepted UKO 1.1 publication.
2. Select `UKO-001-SR-PYTHON-COMMAND-LINE` with `UKO-001-PTC-001`.
3. Prepare a canonical attempt and run the publication-declared reference.
4. In **Check**, confirm **Immutable raw observation** displays the exact adapter stdout.
5. Open **Raw identity and PTC scope**.
6. Confirm the raw identifier, SHA-256 digest, `stdout` location, `immutable-raw-preserved` disposition, PTC, RTCM, and realization.
7. Confirm extraction says `rtcm-declaration-captured-not-applied` and normalization says none were applied.
8. Confirm directly observed, externally reported, and PC3-derived property groups are displayed.
9. Save the observation and confirm the JSON identifies schema version `1.3`, version `0.0.0-obs-01`, and pass `OBS-01`.

### Verification

The repository suite covers PTC/RTCM scope inheritance, raw-value identity and hashing, direct versus reported capture classification, extraction provenance, non-applied normalization records, generic-intake compatibility, saved-record compatibility, UI inspection, and all accepted predecessor behavior. `npm run verify` passes with 94 server tests, 69 web tests, architectural-boundary checks, TypeScript checks, and the production build.
