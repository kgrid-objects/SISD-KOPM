import { readdir, readFile } from "node:fs/promises";
import { extname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const forbiddenByArea = new Map([
  ["server/src/publication", ["fastify", "react", "docker", "sqlite"]],
  ["server/src/operation", ["fastify", "react", "docker", "sqlite"]],
  ["server/src/environment", ["fastify", "react"]],
  ["server/src/observation", ["fastify", "react", "docker", "sqlite"]],
  ["server/src/evidence", ["fastify", "react", "docker", "sqlite"]],
  ["server/src/conformance", ["fastify", "react", "docker", "sqlite"]],
  ["shared/src", ["fastify", "react", "docker", "sqlite"]]
]);

async function sourceFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await sourceFiles(path));
    else if ([".ts", ".tsx", ".js", ".mjs"].includes(extname(entry.name))) files.push(path);
  }
  return files;
}

const violations = [];
for (const [area, forbidden] of forbiddenByArea) {
  const directory = join(root, area);
  for (const file of await sourceFiles(directory)) {
    const content = (await readFile(file, "utf8")).toLowerCase();
    for (const dependency of forbidden) {
      const importPattern = new RegExp(`(?:from\\s+["']|import\\s*\\(["'])[^"']*${dependency}`, "i");
      if (importPattern.test(content)) violations.push(`${relative(root, file)} imports forbidden dependency ${dependency}`);
    }
  }
}

if (violations.length > 0) {
  console.error(violations.join("\n"));
  process.exit(1);
}
console.log("Architectural dependency boundary check passed.");
