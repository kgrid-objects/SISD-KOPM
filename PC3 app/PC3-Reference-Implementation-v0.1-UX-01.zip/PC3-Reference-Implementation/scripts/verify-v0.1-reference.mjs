import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { performance } from "node:perf_hooks";
import { createServer } from "../server/dist/app/create-server.js";

const archivePath = process.argv.find((argument) => argument !== "--exercise" && argument !== process.argv[0] && argument !== process.argv[1]);
const exercise = process.argv.includes("--exercise");
if (!archivePath) throw new Error("Usage: npm run verify:accepted-corpus -- /absolute/path/to/UKO-001-Version-1.1-Accepted.F.zip [--exercise]");

const bytes = await readFile(archivePath);
const sourceSha256 = createHash("sha256").update(bytes).digest("hex");
let sequence = 0;
const server = createServer({
  config: {
    host: "127.0.0.1",
    port: 3000,
    logLevel: "silent",
    maximumUploadBytes: 268_435_456,
    maximumPublicationResources: 10_000,
    maximumPublicationExpandedBytes: 536_870_912,
    maximumPublicationResourceBytes: 201_326_592
  },
  clock: { now: () => new Date().toISOString() },
  identifiers: { next: () => `ux-01-${++sequence}` }
});

const report = { source: { path: archivePath, sha256: sourceSha256 }, corpus: {}, referencePath: { status: exercise ? "pending" : "not-requested" } };
try {
  const application = await server.inject({ method: "GET", url: "/api/application" });
  assert.equal(application.statusCode, 200);
  assert.equal(application.json().implementationVersion, "0.1.0");
  assert.equal(application.json().developmentPass, "UX-01");

  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const started = performance.now();
  const activation = await server.inject({
    method: "POST",
    url: `/api/sessions/${session.id}/publications/activate?filename=${encodeURIComponent(basename(archivePath))}`,
    headers: { "content-type": "application/zip" },
    payload: bytes
  });
  assert.equal(activation.statusCode, 200, activation.body);
  const activated = activation.json();
  const elapsedMilliseconds = Math.round(performance.now() - started);
  assert.equal(activated.interpretation.publicationIdentity?.declaredIdentifier, "UKO-001");
  assert.equal(activated.load.resourceCount, 2_983);
  assert.equal(activated.interpretation.publicationTestCases.length, 6);
  assert.equal(activated.interpretation.realizations.length, 52);
  assert.equal(activated.interpretation.realizationTestCaseManifestations.length, 298);
  assert.equal(activated.interpretation.resolvedExercises.length, 298);
  assert.equal(activated.interpretation.publicationValidation.errorCount, 0);

  const matrixResponse = await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` });
  assert.equal(matrixResponse.statusCode, 200, matrixResponse.body);
  const matrix = matrixResponse.json();
  report.corpus = {
    activationMilliseconds: elapsedMilliseconds,
    resources: activated.load.resourceCount,
    publicationTestCases: activated.interpretation.publicationTestCases.length,
    realizations: activated.interpretation.realizations.length,
    realizationTestCaseManifestations: activated.interpretation.realizationTestCaseManifestations.length,
    resolvedExercises: activated.interpretation.resolvedExercises.length,
    realizationPathways: matrix.realizationPathwayCount,
    validationErrors: activated.interpretation.publicationValidation.errorCount
  };

  if (exercise) {
    const ptcIdentifier = "UKO-001-PTC-001";
    const realizationIdentifier = "UKO-001-SR-PYTHON-COMMAND-LINE";
    const support = activated.invocationSupport.find((item) => item.ptcIdentifier === ptcIdentifier && item.realizationIdentifier === realizationIdentifier);
    assert.ok(support, "The release reference pairing has no invocation-support assessment.");
    assert.equal(support.executable, true, support.reason);
    const pathway = matrix.pathways.find((item) => item.kind === "realization-pathway" && item.endpointIdentifier === realizationIdentifier);
    assert.ok(pathway?.selectable, "The release reference realization pathway is absent or not selectable.");
    const contextId = activated.activeContext.contextId;
    const selection = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathway.id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}` });
    assert.equal(selection.statusCode, 200, selection.body);
    const attempt = await server.inject({
      method: "POST",
      url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`,
      headers: { "content-type": "application/json" },
      payload: { ptcIdentifier, exerciseDisposition: "canonical" }
    });
    assert.equal(attempt.statusCode, 201, attempt.body);
    const execution = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.json().id}/execute-reference?expectedActiveContextId=${encodeURIComponent(contextId)}` });
    assert.equal(execution.statusCode, 201, execution.body);
    const result = execution.json();
    assert.equal(result.interaction.response.outcome, "completed");
    assert.equal(result.observation.publicationExerciseScope.ptcIdentifier, ptcIdentifier);
    assert.equal(result.observation.publicationExerciseScope.realizationIdentifier, realizationIdentifier);
    assert.equal(result.comparison?.status, "pass");
    const attestation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/execution-evidence/attest-current?expectedActiveContextId=${encodeURIComponent(contextId)}` });
    assert.equal(attestation.statusCode, 200, attestation.body);
    assert.match(attestation.headers["content-disposition"] ?? "", /pc3-observation-collection-attestation-/);
    report.referencePath = {
      status: "passed",
      ptcIdentifier,
      realizationIdentifier,
      observationId: result.observation.id,
      comparisonStatus: result.comparison.status,
      attestationIdentity: attestation.json().pc3Identity
    };
  }
} finally {
  await server.close();
}

const finalSha256 = createHash("sha256").update(await readFile(archivePath)).digest("hex");
assert.equal(finalSha256, sourceSha256, "The accepted corpus changed during release verification.");
report.source.unchanged = true;
process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
