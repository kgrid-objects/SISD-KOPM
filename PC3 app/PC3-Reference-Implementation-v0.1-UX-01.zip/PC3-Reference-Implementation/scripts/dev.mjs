import { spawn } from "node:child_process";

const processes = [
  spawn("npm", ["run", "dev", "--workspace", "server"], { stdio: "inherit", shell: true }),
  spawn("npm", ["run", "dev", "--workspace", "web"], { stdio: "inherit", shell: true })
];

function stop(signal) {
  for (const child of processes) child.kill(signal);
}
process.on("SIGINT", () => { stop("SIGINT"); process.exit(0); });
process.on("SIGTERM", () => { stop("SIGTERM"); process.exit(0); });
