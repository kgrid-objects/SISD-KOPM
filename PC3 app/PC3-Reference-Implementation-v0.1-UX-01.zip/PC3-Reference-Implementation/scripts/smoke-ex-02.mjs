import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { createServer } from "../server/dist/app/create-server.js";

const archivePath = process.argv[2];
if (!archivePath) throw new Error("Usage: node scripts/smoke-ex-02.mjs publication.zip");
let sequence = 0;
const server = createServer({
  config: { host: "127.0.0.1", port: 3000, logLevel: "silent", maximumUploadBytes: 1_073_741_824 },
  clock: { now: () => new Date().toISOString() },
  identifiers: { next: () => `smoke-${++sequence}` }
});

try {
  const session = (await server.inject({ method: "POST", url: "/api/sessions" })).json();
  const activation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/publications/activate?filename=${encodeURIComponent(basename(archivePath))}`, headers: { "content-type": "application/zip" }, payload: await readFile(archivePath) });
  if (activation.statusCode !== 200) throw new Error(activation.body);
  const contextId = activation.json().activeContext.contextId;
  const matrix = (await server.inject({ method: "GET", url: `/api/sessions/${session.id}/realization-matrix` })).json();
  const pathway = matrix.pathways.find((item) => item.endpointIdentifier === "UKO-001-SR-PYTHON-COMMAND-LINE");
  if (!pathway?.selectable) throw new Error("The Python Command Line realization pathway is absent or not selectable.");
  const selection = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/realization-matrix/${encodeURIComponent(pathway.id)}/select?expectedActiveContextId=${encodeURIComponent(contextId)}` });
  if (selection.statusCode !== 200) throw new Error(selection.body);
  const attempt = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts?expectedActiveContextId=${encodeURIComponent(contextId)}`, headers: { "content-type": "application/json" }, payload: { ptcIdentifier: "UKO-001-PTC-001", exerciseDisposition: "canonical" } });
  if (attempt.statusCode !== 201) throw new Error(attempt.body);
  const execution = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/exercise-attempts/${attempt.json().id}/execute-reference?expectedActiveContextId=${encodeURIComponent(contextId)}` });
  if (execution.statusCode !== 201) throw new Error(execution.body);
  const result = execution.json();
  const attestation = await server.inject({ method: "POST", url: `/api/sessions/${session.id}/runtime-observations/${encodeURIComponent(result.observation.id)}/attest?expectedActiveContextId=${encodeURIComponent(contextId)}` });
  if (attestation.statusCode !== 201) throw new Error(attestation.body);
  process.stdout.write(`${JSON.stringify({
    outcome: result.interaction.response.outcome,
    response: result.interaction.response.value,
    stderr: result.interaction.externalProcess?.stderr ?? "",
    exitCode: result.interaction.externalProcess?.exitCode ?? null,
    invocation: result.referenceExecution.invocation,
    observation: {
      publicationExerciseScope: result.observation.publicationExerciseScope,
      rawObservation: result.observation.rawObservation,
      extractionProvenance: result.observation.extractionProvenance,
      normalizationRecords: result.observation.normalizationRecords,
      propertyClassifications: result.observation.propertyClassifications
    },
    comparison: result.comparison,
    evidence: attestation.json()
  }, null, 2)}\n`);
} finally {
  await server.close();
}
