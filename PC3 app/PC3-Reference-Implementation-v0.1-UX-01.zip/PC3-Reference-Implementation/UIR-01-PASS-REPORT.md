# UIR-01 Pass Report

Status: **passed external verification and accepted on 2026-07-20**.

## Delivered

- Moved the realization filter out from beneath the IR/SR/DP selector and into the Realizations upper band, immediately left of the visible count.
- Replaced the former **Show Exercisable** and On/Off presentation with one **Limit** toggle and no separate label.
- Added a raised off state and an inset, visibly pushed-in on state while retaining `aria-pressed` and keyboard focus behavior.
- Changed filtering to use the same complete `CanonicalExerciseEligibility` decision that controls every row's blue **Exercise** action.
- Kept Limit unavailable without a selected Publication Test Case and preserved the default/reset behavior of showing all realizations.

## Verification

- UI typechecking passes.
- UI tests prove unique placement, label removal, pressed-state styling, accessibility state, publication reset, and exact shared eligibility logic.
- The complete repository verification suite passes: architectural boundaries, typechecks, 134 server tests, 98 UI tests, shared-package checks, and the production build.

## Boundaries

UIR-01 changes presentation and filtering only. It does not change Test Case selection, RTCM resolution, invocation support assessment, adapter readiness, execution, Observation capture, comparison, attestation, or publication content. “Limit” means show only rows whose current Exercise action is enabled; it does not mean successful execution or conformance.

## External acceptance path

1. Load and activate the accepted UKO 1.1.F publication and select a PTC.
2. Open **Realizations** and confirm **Limit** appears in the upper band immediately left of the visible count.
3. Confirm the former full-width **Show Exercisable** control, On/Off text, and separate explanatory label are absent.
4. Toggle **Limit** and confirm the on state appears pushed in and the off state appears raised.
5. With Limit on, inspect IR, SR, and DP: every visible row must have an enabled blue **Exercise** button.
6. Turn Limit off and confirm realizations with disabled Exercise actions return.
