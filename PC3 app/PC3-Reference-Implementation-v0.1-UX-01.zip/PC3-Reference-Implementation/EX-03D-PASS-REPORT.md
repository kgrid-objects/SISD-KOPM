# EX-03D-C3 Correction Pass Report

Status: **externally verified and accepted on 2026-07-19**.

## Corrected external failure

The initial EX-03D package built into a redirected artifacts directory, but `dotnet run` attempted to launch a project-relative DLL that did not exist. EX-03D-C1 corrected that launch path with a writable disposable bridge workspace.

External verification of C1 then showed NuGet restore attempting to create the referenced implementation project's `obj` directory beneath read-only `/workspace`. EX-03D-C2 removes the `ProjectReference` build entirely. It validates and records the declared implementation project, but compiles the explicitly declared C# source set directly into the disposable bridge. No publication path becomes writable or participates as an MSBuild output location.

External verification of C2 produced a successful computational result, but the .NET SDK prefixed the adapter JSON with its workload-integrity warning. EX-03D-C3 disables that SDK-owned startup behavior through documented .NET CLI environment controls. It does not inspect, strip, repair, or substitute process stdout; the adapter result remains byte-for-byte evidence.

## Delivered

- Added one exact `.NET 8` CLI/stdout adapter capability for Service Realizations.
- Recognizes the accepted corpus runtime declaration without broadening to C# libraries, IRs, Native AOT artifacts, services, or Deployment Packages.
- Resolves and records the declaration's adapter source, original project, implementation source root, unique implementation project, static-method binding, ordered canonical options, and `net8.0` target.
- Generates a temporary external bridge project containing no computational logic and leaves the UKO read-only and unchanged.
- Added the official digest-pinned .NET 8.0.422 SDK image to the accepted Docker provider; PC3 assesses but never pulls it.
- Runs the bridge in a disposable no-network, read-only, non-root container with bounded CPU, memory, PIDs, temporary storage, timeout, exact stdout/stderr capture, and mandatory cleanup.
- Suppresses SDK-owned workload integrity, workload-update notification, telemetry, and logo output before launch so successful adapter stdout remains a clean realization observation.
- Retains the exact .NET bridge and adapter provenance in the immutable reference-execution record.
- Uses the existing one-click Exercise, Observation, Comparison, Attestation, and UII-06 opportunity-coverage flows without adding UI duplication.

## Verification

- Capability tests prove exact alias, mode, realization-type, observation, and no-fallback matching.
- Planning tests prove unique declaration resolution, canonical binding, `net8.0`, implementation-project resolution, and bridge provenance.
- Materialization tests inspect the external bridge and prove it references only the declared adapter entry point and implementation project.
- Docker tests prove the exact pinned image, read-only publication mount, separately writable disposable bridge mount, canonical arguments, no-network constraints, 512 MiB/128 MiB/60-second bounds, and cleanup.
- A regression test proves every SDK diagnostic control is passed to the container and the adapter's JSON stdout is returned byte-for-byte without PC3 filtering.
- API integration tests prove Exercise enablement, immutable reference records, raw stdout Observation, Expected Outcome comparison, and existing workflow preservation.

## External verification

1. Ensure Docker Desktop is running.
2. Pull the image explicitly:
   `docker pull mcr.microsoft.com/dotnet/sdk:8.0.422-bookworm-slim@sha256:d80fdd84f7e18eea12f8e45c52914f1353395009c95c41197178ea19944e6d48`
3. Start PC3 and load the accepted UKO Version 1.1 archive after the pull.
4. Select an applicable PTC, open Realizations, choose SR, and locate `UKO-001-SR-CSHARP-NATIVE-COMMAND-LINE`.
5. Confirm its Exercise action is enabled. Exercise it once.
6. Confirm a new Observation appears and Latest output begins with `{`, contains only the C# adapter's JSON stdout, and does not contain the workload-verification warning. A comparison may pass or fail according to the publication-declared expected outcome; execution success does not force a pass.
7. Inspect progressive detail and confirm canonical runtime `.NET 8`, capability `dotnet8-cli-stdout.v1`, bridge `pc3.dotnet-cli-source.v1`, the digest-pinned image identity, and cleanup `removed`.
8. Confirm C# imported-library, C# IR, Native AOT, HTTP/gRPC/messaging, and DP paths were not enabled by this pass.
9. Confirm the UII-06 Enabled/Blocked/Coverage projection reflects the newly enabled exact C# CLI pairings after publication reload.

## Boundary

EX-03D demonstrates declaration-backed C#/.NET CLI execution. It does not validate UKO conformance, authenticate realization identity, prove reproducibility, or assert computational correctness, safety, or scientific validity.
