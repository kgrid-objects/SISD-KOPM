# UII-05 Pass Report

Status: **implementation complete; awaiting external validation**

Baseline: externally accepted **UII-04 — Observation Rendering**

Implementation identity: **0.0.0-uii-05 / UII-05**

## Delivered behavior

- The upper dashboard presents twelve permanently visible numeric readout boxes in fixed left-to-right group order: PTC, RZN, and pathway inventory.
- The PTC group maps the existing per-Test-Case projection in Complete, Partial, None, and N/A order. Every box places `PTC` at lower left.
- The RZN group maps `interpretation.exerciseReadiness` classifications of unique realization identities in the same order. Every box places `RZN` at lower left.
- The black pathway group retains the exact IR, SR, DP, and TOTAL pathway counts and lower-left labels.
- All twelve boxes share the same height, numeric baseline, lower-label baseline, spacing rhythm, and tabular-number treatment.
- Accepted green, yellow, red, and grey completeness meanings are preserved.
- The visible **Exercise Completeness** heading, **By Realization / By PTC** toggle, projection-mode state, pressed states, disabled PTC mode, and publication-reset state are removed.
- PTC and RZN data remain simultaneously visible and are never derived from one another.
- A publication without a PTC capability retains four structurally present zero-valued PTC boxes with an accessible explanation; PC3 does not fabricate a Not applicable count.
- Accessible labels identify the population and status or endpoint count of every box. The dashboard explicitly distinguishes unique-realization completeness from realization-pathway inventory.
- At narrow widths, complete four-box groups wrap without clipping or reordering their contents.
- The prominent blue **Exercise Model** capability banner is removed from the left Session Collection Panel.
- The bounded publication presentation now uses **Declaration checks**, **Check result**, and **Declaration issues** language in place of the former visible validation terminology.
- Exercise-model classification remains inspectable in the normally closed **Advanced publication inspection** disclosure, including profile, exercise authority, PTC capability, standalone-input disposition, and interpretation rationale.
- UII-04 Observation rendering and collection-level Attest behavior remain unchanged.

## Verification

`npm run verify` passes:

- architectural dependency boundary check;
- shared, server, and web type checks;
- **104/104 server tests**;
- **88/88 web tests**, including focused UII-05 mapping, removal, zero-PTC, alignment, accessibility, and responsive checks;
- shared, server, and production web builds.

## External validation path

1. Start PC3 with `npm run dev` and open the web address printed by the development server.
2. Load the accepted UKO 1.1 publication.
3. In the upper dashboard, confirm one continuous desktop row contains exactly twelve boxes in this order: four PTC boxes, four RZN boxes, then black IR, SR, DP, and TOTAL boxes.
4. Confirm the PTC and RZN groups both read Complete, Partial, None, and N/A from left to right. Confirm every PTC box has `PTC` at lower left and every realization box has `RZN` at lower left.
5. Confirm the twelve boxes have matching heights, aligned numeric baselines, aligned lower labels, and no stacked completeness section at normal desktop width.
6. Confirm **Exercise Completeness**, **By Realization**, and **By PTC** do not appear and there is no toggle in their former location.
7. For UKO 1.1, compare the displayed PTC counts with the Test Cases collection and the RZN counts with the publication realization-readiness population. Confirm IR/SR/DP/TOTAL remain the pathway inventory and are not visually forced to reconcile with RZN.
8. Load a publication without a PTC capability. Confirm all four PTC boxes remain present at zero, including N/A zero, with no invented PTC classification.
9. Narrow the browser. Confirm boxes wrap as intact PTC, RZN, and pathway groups without clipping or arbitrary reordering; restore desktop width and confirm all twelve return to one row.
10. Exercise a realization, inspect Observations, and use the collection-level **Attest** action to confirm UII-01 through UII-04 interactions remain unchanged and the UKO remains unmodified.
11. Confirm the blue Exercise Model banner is absent. Confirm the left panel says **Declaration checks**, then open **Detail Panel → Advanced publication inspection → Exercise model** and verify the PTC profile, authority, capability, and rationale remain available there.

## Scope boundary

UII-05 changes dashboard presentation and maps already accepted counts. It does not change readiness definitions, applicability, RTCM resolution, interpretation, pathway construction, Board Readiness, lower operational readouts, Test Case selection, execution, Observation capture/rendering, comparison, attestation, or UKO immutability. No UII-06 or later UII pass is inferred.
