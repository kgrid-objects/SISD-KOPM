# EX-03A Pass Report

Status: **externally verified and accepted on 2026-07-19**

Baseline: externally accepted **UII-05 — Dashboard Data Alignment**

Implementation identity: **0.0.0-ex-03a / EX-03A**

## Delivered behavior

- Removed the server planner's literal UKO-001 PTC, realization, and pairing gates.
- Removed the browser readiness gate's literal UKO-001 PTC and realization identifiers.
- Corrected Exercise eligibility: publication activation projects current local invocation support for every exact PTC × realization × RTCM tuple; an Exercise action is enabled only when that tuple can complete through the accepted compatibility bridge.
- Keeps resolved but non-executable IR, SR, and DP rows visible with disabled actions and an attributable reason, including missing declarations and unsupported Rust or C#/.NET runtimes.
- Requires the immutable canonical Exercise Attempt to match the exact server-resolved PTC, realization, and RTCM identities.
- Locates exactly one realization declaration by its layer-appropriate explicit identity field, with a bounded generic `realization_id` alternative.
- Resolves the declared adapter artifact relative to that declaration and refuses absent or unsafe resources.
- Builds ordered CLI arguments from the RTCM canonical field order and the declaration's explicit input translation without inspecting executable behavior.
- Retains generic pairing, realization type, declaration-identity, runtime-requirement, binding, observation, comparison, and provenance fields in the immutable execution record.
- Preserves the accepted external Python execution only through an explicit RTCM runtime-requirement compatibility map.
- For the accepted corpus pattern, resolves Python from the realization declaration's explicit `language_or_ecosystem: Python` field and retains that field, value, and declaration resource in the execution record.
- Produces a generic plan for an explicitly declared .NET CLI requirement, then rejects execution only at the bounded accepted-local-process compatibility bridge.
- Rejects non-CLI invocation modes before planning, leaving their invocation planning to later transport passes.
- Preserves UII-05 interaction, Observation, comparison, and collection-attestation behavior.

## Verification

`npm run verify` passes:

- architectural dependency boundary check;
- shared, server, and web type checks;
- **108/108 server tests**;
- **90/90 web tests**;
- shared test suite (no standalone cases);
- production builds.

Focused coverage proves that a renamed publication-defined PTC and realization execute through the same declaration-driven planner, while REST, .NET runtime, and missing-declaration cases remain explicit disabled outcomes.
It also reproduces the accepted UKO structure in which the RTCM declares only a compatible external environment and the realization declaration explicitly identifies Python.

## External validation path

1. Run `npm ci`, then `npm run dev`, and open the web address printed by the development server.
2. Load the accepted UKO 1.1 publication.
3. Select a Test Case, open SR Realizations, and exercise the accepted Python command-line realization.
4. Confirm a new Observation is produced and the Expected Outcome comparison remains available.
5. Inspect the associated execution details and confirm the PTC, RTCM, realization, declaration resource, adapter artifact, CLI arguments, and Python runtime are retained.
6. Confirm the application identity is `0.0.0-ex-03a / EX-03A`.
7. Confirm the Pub Board retains the accepted UII-05 dashboard and Observation-level interaction behavior.
8. Confirm the accepted Python CLI row has an enabled blue Exercise action. Confirm missing declarations and unsupported non-CLI, Rust, or C#/.NET runtime declarations remain visible but have disabled Exercise actions whose accessible description gives the reason.

## Scope boundary

EX-03A establishes a generic, immutable RTCM planning seam. It does not implement general adapter matching, Docker lifecycle, C#/.NET execution, service invocation, imported-library execution, messaging, MCP, Deployment Package connectors, runtime installation, comparison broadening, conformance assessment, or UKO modification.
