# PC3-PTC-01 Pass Report — UKO 1.1 Publication Model Foundation

## Baseline

`PC3-Reference-Implementation-v0.1-UI-04` (externally verified)

## Result

PC3-PTC-01 establishes the internal, publication-subordinate domain foundation required to represent UKO Version 1.1 Publication Test Cases and Realization Test Case Manifestations without changing the verified UI-04 interaction model.

## Implemented

- Added first-class immutable models for:
  - Publication Test Cases;
  - canonical Input Objects;
  - canonical Expected Outcomes;
  - comparison semantics;
  - explicit PTC/realization applicability declarations;
  - Realization Test Case Manifestations;
  - realization-specific input bindings;
  - invocation declarations;
  - observation derivation declarations;
  - Exercise Readiness;
  - Resolved Exercises.
- Added `PublicationExerciseModelManager` to:
  - derive readiness from explicit applicability and authoritative RTCM coverage;
  - resolve a unique authoritative RTCM for a selected PTC/realization pairing;
  - report non-applicable, missing, and ambiguous pairings without inference.
- Extended PC3 Interpretation and the shared API contract with empty UKO 1.1 model collections ready for the discovery pass.
- Preserved the publication/runtime boundary: a resolved exercise is explicitly external to the publication and does not assert runtime availability, execution success, or conformance.
- Preserved all existing UI-04 Input Object and realization behavior.

## Deliberately deferred

PC3-PTC-01 does not yet:

- discover PTC or RTCM declarations from a publication;
- validate the accepted UKO 1.1 PTC/RTCM corpus;
- alter visible navigation or replace the Inputs collection;
- execute a resolved exercise;
- capture or compare observations.

Those responsibilities begin with PC3-PTC-02 and subsequent planned passes.

## Verification

- Architectural dependency boundary check passed.
- TypeScript checks passed.
- Server tests: 68 passed.
- Web tests: 45 passed.
- Shared tests passed.
- Production build passed.

Run `npm ci` and then `npm run verify` from the repository root.
