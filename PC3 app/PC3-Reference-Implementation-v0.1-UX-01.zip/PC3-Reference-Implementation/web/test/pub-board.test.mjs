import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const appSource = await readFile(new URL("../src/app/App.tsx", import.meta.url), "utf8");
const styleSource = await readFile(new URL("../src/styles.css", import.meta.url), "utf8");

test("UIR-02 labels the primary application view Console View", () => {
  assert.equal((appSource.match(/<h1>Console View<\/h1>/g) ?? []).length, 1);
  assert.doesNotMatch(appSource, /<h1>Pub Board<\/h1>/);
});

test("UI-01 preserves one shared operational compatibility surface inside the Instrument Display", () => {
  assert.match(appSource, /SharedOperationalWorkspace/);
  assert.match(appSource, /aria-label="Current operational object"/);
  assert.match(appSource, /className="shell-instrument-display"/);
  assert.equal((appSource.match(/<ExerciseAttemptPanel/g) ?? []).length, 0);
  assert.equal((appSource.match(/<ExecutionAdapterPanel/g) ?? []).length, 0);
  assert.equal((appSource.match(/<OutputMonitor/g) ?? []).length, 1);
  assert.equal((appSource.match(/<ExecutionEvidencePanel/g) ?? []).length, 0);
});

test("Realization Channels are compact selectors rather than workspaces", () => {
  assert.match(appSource, /RealizationChannelSelector/);
  assert.match(appSource, /className={`channel-selector/);
  assert.match(appSource, /aria-pressed={props\.selected}/);
  assert.doesNotMatch(appSource, /channel-console/);
  assert.doesNotMatch(appSource, /aria-expanded={props\.expanded}/);
});

test("selection grabs pathway-scoped context for the shared workspace", () => {
  assert.match(appSource, /selectedAttempts = selectedPathway \? props\.attempts\.filter/);
  assert.match(appSource, /selectedInteractions = selectedPathway \? props\.interactions\.filter/);
  assert.match(appSource, /selectedObservations = selectedPathway \? props\.observations\.filter/);
  assert.match(appSource, /selectedEvidence = selectedPathway \? props\.evidence\.filter/);
  assert.match(appSource, /onSelect=\{\(\) => switchPathway\(pathway\.id\)\}/);
});

test("the board uses a dense split-view layout", () => {
  assert.match(styleSource, /\.pub-board \{ display: grid; grid-template-columns: minmax\(17rem, 22rem\) minmax\(0, 1fr\)/);
  assert.match(styleSource, /\.channel-selector \{[\s\S]*min-height: 3\.65rem/);
  assert.match(styleSource, /\.channel-bank \{[\s\S]*position: sticky/);
  assert.match(styleSource, /\.shared-workspace/);
  assert.doesNotMatch(styleSource, /\.realization-channel/);
});

test("channel state remains visible while Observation inspection and collection attestation remain available", () => {
  assert.match(appSource, /channelStatusLabel/);
  assert.match(appSource, /Identity assurance: reported/);
  assert.equal((appSource.match(/<ExerciseAttemptPanel/g) ?? []).length, 0);
  assert.equal((appSource.match(/<ExecutionAdapterPanel/g) ?? []).length, 0);
  assert.equal((appSource.match(/<OutputMonitor/g) ?? []).length, 1);
  assert.equal((appSource.match(/<ExecutionEvidencePanel/g) ?? []).length, 0);
  assert.match(appSource, /className="collection-attest-action"/);
});

test("DEV-11 execution remains intact and attestation is promoted to the Observation collection", () => {
  assert.match(appSource, /executeReferenceExerciseAttempt/);
  assert.match(appSource, /onCanonicalExercise/);
  assert.match(appSource, /automatically captured Runtime Observation/);
  assert.match(appSource, /attestCurrentObservationCollection/);
  assert.match(appSource, /All \$\{props\.observations\.length\} current Observations were attested and formally saved/);
  assert.doesNotMatch(appSource, /Attest as Execution Evidence/);
});

test("platform-native accessibility conventions remain intact", () => {
  assert.match(styleSource, /-apple-system/);
  assert.match(styleSource, /SF Pro Display/);
  assert.match(styleSource, /prefers-reduced-motion/);
  assert.match(styleSource, /focus-visible/);
  assert.match(styleSource, /min-height: 2\.5rem/);
  assert.match(styleSource, /backdrop-filter: blur/);
});

test("DEV-12 exposes the selected channel's environment description without adding another workspace", () => {
  assert.match(appSource, /Execution Environment Description/);
  assert.match(appSource, /selectedEnvironments = selectedPathway \? props\.environments\.filter/);
  assert.match(appSource, /identityAssurance\.level/);
  assert.match(appSource, /item\.assurance/);
  assert.match(appSource, /Identity assurance/);
  assert.equal((appSource.match(/<EnvironmentDetails/g) ?? []).length, 2);
});


test("DEV-12B presents exactly one realization level at a time", () => {
  assert.match(appSource, /type RealizationLayer/);
  assert.match(appSource, /className="layer-selector"/);
  assert.match(appSource, /aria-label="Realization level"/);
  for (const short of ["IR", "SR", "DP"]) assert.match(appSource, new RegExp(`short: "${short}"`));
  assert.match(appSource, /visiblePathways = pathways\.filter\(\(item\) => item\.endpointType === activeLayer && isVisibleForExerciseFilter\(item\)\)/);
  assert.match(appSource, /visiblePathways\.map\(\(pathway\)/);
  assert.doesNotMatch(appSource, /pathways\.map\(\(pathway\) => <RealizationChannelSelector/);
});

test("layer changes place a layer-appropriate channel into the universal workspace", () => {
  assert.match(appSource, /async function chooseLayer/);
  assert.match(appSource, /layerSelections = React\.useRef/);
  assert.match(appSource, /rememberedId = layerSelections\.current\[layer\]/);
  assert.match(appSource, /await switchPathway\(target\.id\)/);
  assert.match(appSource, /layerLabel=\{activeLayerDescriptor\.singular\}/);
  assert.equal((appSource.match(/<SharedOperationalWorkspace/g) ?? []).length, 1);
});

test("DEV-12B tightens visual density and hierarchy", () => {
  assert.match(styleSource, /DEV-12B — layer-focused channel bank/);
  assert.match(styleSource, /\.pub-board \{ grid-template-columns: minmax\(15rem, 19rem\)/);
  assert.match(styleSource, /\.channel-selector \{ min-height: 3\.1rem/);
  assert.match(styleSource, /\.layer-selector button\[aria-pressed="true"\]/);
  assert.match(styleSource, /\.shared-workspace \{ padding: \.9rem/);
});

test("UII-03 removes the obsolete Prepare and Run modules while preserving result services", () => {
  assert.match(appSource, /workspace-stage-stack/);
  assert.doesNotMatch(appSource, /WorkspaceStageLink/);
  assert.doesNotMatch(appSource, /StageMarker/);
  assert.doesNotMatch(appSource, /Universal Pub Board functions/);
  assert.equal((appSource.match(/<ExerciseAttemptPanel/g) ?? []).length, 0);
  assert.equal((appSource.match(/<ExecutionAdapterPanel/g) ?? []).length, 0);
  assert.doesNotMatch(appSource, /workspace-input|workspace-execute/);
  assert.equal((appSource.match(/<OutputMonitor/g) ?? []).length, 1);
  assert.equal((appSource.match(/<ExecutionEvidencePanel/g) ?? []).length, 0);
});

test("DEV-12C keeps selected-realization orientation persistent", () => {
  assert.match(appSource, /workspace-identity/);
  assert.match(appSource, /workspace-title-row/);
  assert.match(appSource, /workspace-pathway-summary/);
  assert.match(appSource, /workspace-orientation/);
  assert.match(appSource, /channelStatusLabel\(workspaceStatus\)/);
  assert.match(appSource, /Identity assurance: reported/);
});

test("UI-01 moves realization detail into the Detail Panel", () => {
  assert.match(appSource, /className="check-workspace"/);
  assert.doesNotMatch(appSource, /<RuntimeObservationPanel observations=/);
  assert.match(appSource, /className="shell-detail-panel"/);
  assert.match(appSource, /<EnvironmentDetails environment=/);
  assert.match(styleSource, /UI-01 — Four Component Shell/);
  assert.match(styleSource, /\.shell-detail-panel/);
});

test("DEV-12D promotes the executable realization matrix into a compact status panel", () => {
  assert.match(appSource, /function OperationalDashboard/);
  assert.match(appSource, /aria-label="Realization pathway inventory by endpoint level"/);
  assert.match(appSource, /matrix\.irEndpointPathwayCount/);
  assert.match(appSource, /matrix\.srEndpointPathwayCount/);
  assert.match(appSource, /matrix\.dpEndpointPathwayCount/);
  assert.match(appSource, /matrix\.realizationPathwayCount/);
  assert.match(styleSource, /DEV-12D — compact operational status panel/);
  assert.match(styleSource, /\.operational-dashboard \{/);
  assert.match(styleSource, /\.status-count-box\.is-active\[data-layer="ir"\]/);
  assert.match(styleSource, /\.status-count-box\.is-active\[data-layer="sr"\]/);
  assert.match(styleSource, /\.status-count-box\.is-active\[data-layer="dp"\]/);
});

test("DEV-12D removes matrix duplication and the redundant channel-count subtitle", () => {
  assert.equal((appSource.match(/<OperationalDashboard/g) ?? []).length, 1);
  assert.doesNotMatch(appSource, /function MatrixInspection/);
  assert.match(appSource, /function PathwayIntegrityInspection/);
  assert.doesNotMatch(appSource, /realization channel\{matrix\.realizationPathwayCount/);
  assert.doesNotMatch(appSource, /<h3>Executable Realization Matrix<\/h3>/);
});

test("DEV-12D correction binds the status readout immediately to IR, SR, and DP switching", () => {
  assert.match(appSource, /const \[activeLayer, setActiveLayer\] = React\.useState<RealizationLayer>/);
  assert.match(appSource, /setActiveLayer\(layer\);/);
  assert.match(appSource, /setActiveLayer\(previousLayer\);/);
  assert.match(appSource, /aria-current=\{isActive \? "true" : undefined\}/);
  assert.match(styleSource, /\.status-count-box\.is-active \{/);
  assert.match(styleSource, /border-width: 2px/);
  assert.match(styleSource, /rgba\(64,156,255,\.98\)/);
  assert.match(styleSource, /rgba\(191,90,242,\.98\)/);
  assert.match(styleSource, /rgba\(48,209,88,\.98\)/);
});


test("DEV-12E resets the transient workspace immediately on realization switching", () => {
  assert.match(appSource, /function beginWorkspaceSwitch/);
  assert.match(appSource, /setWorkspaceBaseline\(\{/);
  assert.match(appSource, /setWorkspaceRevision\(\(value\) => value \+ 1\)/);
  assert.match(appSource, /key=\{`workspace:\$\{workspaceRevision\}`\}/);
  assert.match(appSource, /async function switchPathway/);
  assert.doesNotMatch(appSource, /confirm\(/);
  assert.doesNotMatch(appSource, /Discard changes/);
});

test("DEV-12E separates the current workspace cycle while collection history stays solely in the left control center", () => {
  assert.match(appSource, /currentAttempts = selectedAttempts\.filter/);
  assert.match(appSource, /currentObservations = selectedObservations\.filter/);
  assert.match(appSource, /className="observation-collection-list"/);
  assert.doesNotMatch(appSource, /observationHistory=\{props\.observations\}/);
  assert.doesNotMatch(appSource, /evidenceHistory=\{selectedEvidence\}/);
  assert.doesNotMatch(appSource, /RuntimeObservationPanel|ExecutionEvidencePanel/);
});

test("DEV-12E supports switching within and across realization levels", () => {
  assert.match(appSource, /onSelect=\{\(\) => switchPathway\(pathway\.id\)\}/);
  assert.match(appSource, /await switchPathway\(target\.id\)/);
  assert.match(appSource, /if \(switchingPathwayId \|\| pathwayId === props\.matrix\.selectedPathwayId\) return/);
  assert.match(appSource, /setWorkspaceBaseline\(previous\.baseline\)/);
});


test("DEV-12F presents one monotonic session Observation sequence only in the collection", () => {
  assert.match(appSource, /className="observation-collection-list"/);
  assert.doesNotMatch(appSource, /Session Observations/);
  assert.match(appSource, /Observation \{observation\.sessionSequence\}/);
  assert.match(appSource, /observation\.endpointIdentifier/);
  assert.match(appSource, /sort\(\(a,b\) => a\.sessionSequence - b\.sessionSequence\)/);
});

test("DEV-12G supports keyboard traversal and focus transfer across layers and channels", () => {
  assert.match(appSource, /function moveFocus/);
  assert.match(appSource, /"ArrowLeft", "ArrowRight"/);
  assert.match(appSource, /"ArrowUp", "ArrowDown"/);
  assert.match(appSource, /"Home", "End"/);
  assert.match(appSource, /function focusChannel/);
  assert.match(appSource, /data-pathway-id=\{props\.pathway\.id\}/);
  assert.match(appSource, /role="listbox"/);
  assert.match(appSource, /role="option"/);
});

test("DEV-12G exposes busy, selected, current-step, and live announcement semantics", () => {
  assert.match(appSource, /interactionAnnouncement/);
  assert.match(appSource, /role="status" aria-live="polite"/);
  assert.match(appSource, /aria-busy=\{Boolean\(switchingPathwayId\)\}/);
  assert.match(appSource, /aria-selected=\{props\.selected\}/);
  assert.match(appSource, /props\.exercising \? "Exercising…" : "Exercise"/);
  assert.match(appSource, /disabled=\{!props\.exerciseEligibility\.enabled \|\| props\.busy\}/);
});

test("DEV-12G strengthens focus, touch, and reduced-motion behavior", () => {
  assert.match(styleSource, /DEV-12G — interaction behavior and accessibility/);
  assert.match(styleSource, /\.sr-only/);
  assert.match(styleSource, /channel-selector:focus-visible/);
  assert.match(styleSource, /@media \(pointer: coarse\)/);
  assert.match(styleSource, /@media \(prefers-reduced-motion: reduce\)/);
});

test("UX-01 keeps the release console keyboard-readable and consistently named", () => {
  assert.equal((appSource.match(/aria-label="Console View"/g) ?? []).length, 2);
  assert.match(appSource, /role="tablist" aria-label="Session collections"/);
  assert.match(appSource, /onKeyDown=\{\(event\) => moveFocus\(event, "\[role=tab\]", "horizontal"\)\}/);
  assert.match(appSource, /role="status" aria-live="polite" aria-atomic="true"/);
  assert.match(appSource, /aria-hidden="true" \/>Connected · v\{connection\.info\.implementationVersion\} · \{connection\.info\.developmentPass\}/);
});

test("UX-01 uses indexed publication lookups for dense realization lists", () => {
  for (const index of ["realizationByIdentifier", "readinessByRealization", "rtcmByIdentifier", "resolvedExerciseByPair", "invocationSupportByExercise"]) {
    assert.match(appSource, new RegExp(`const ${index} = React\\.useMemo\\(\\(\\) => new Map`));
  }
  assert.doesNotMatch(appSource, /resolvedExercises\.find\(\(item\) => item\.ptc\.identifier === selectedPtcId/);
});


test("NEW UI PASS X rebalances the board around wide low-profile realization selectors", () => {
  assert.match(styleSource, /NEW UI PASS X — Pub Board rebalancing/);
  assert.match(styleSource, /grid-template-columns: minmax\(22rem, 28rem\) minmax\(0, 1fr\)/);
  assert.match(styleSource, /min-height: 2\.35rem/);
  assert.match(appSource, /className="realization-identity"><strong>\{primaryLabel\}<\/strong>/);
  assert.doesNotMatch(appSource, /<span className="channel-signals"/);
});

test("UI-01 retains existing operational modules without the stage navigator", () => {
  assert.match(appSource, /className="workspace-stage-stack"/);
  assert.match(appSource, /id="workspace-check"/);
  assert.doesNotMatch(appSource, /WorkspaceStageLink/);
  assert.doesNotMatch(appSource, /StageMarker/);
  assert.match(styleSource, /\.instrument-display-compatibility \.workspace-stage-stack/);
});

test("NEW UI PASS X-C1 restores inline pathway context without increasing selector height", () => {
  assert.match(styleSource, /NEW UI PASS X correction — contained status elements and restored inline pathway context/);
  assert.match(styleSource, /grid-template-columns: minmax\(30rem, 38rem\) minmax\(0, 1fr\)/);
  assert.match(appSource, /workspace-pathway-summary">\{compactPathwaySummary\(props\.pathway\)\}/);
  assert.match(styleSource, /\.realization-identity-meta > small:first-child \{[\s\S]*white-space: nowrap/);
  assert.match(styleSource, /\.channel-selector \{[\s\S]*min-height: 2\.35rem/);
});

test("NEW UI PASS X-C1 contains assurance and Attest status within the workspace", () => {
  assert.match(styleSource, /\.shared-workspace \{[\s\S]*overflow: hidden/);
  assert.match(styleSource, /\.workspace-header \{[\s\S]*flex-wrap: wrap/);
  assert.match(styleSource, /\.assurance-chip \{[\s\S]*overflow-wrap: anywhere/);
  assert.match(styleSource, /\.module-heading,[\s\S]*flex-wrap: wrap/);
  assert.match(styleSource, /\.stage-marker \.stage-state \{[\s\S]*overflow-wrap: anywhere/);
  assert.match(styleSource, /\.attestation-row > \* \{[\s\S]*max-width: 100%/);
});

test("UI PASS Y presents one publication-session operational dashboard", () => {
  assert.match(appSource, /function OperationalDashboard/);
  assert.equal((appSource.match(/<OperationalDashboard/g) ?? []).length, 1);
  assert.match(appSource, /aria-label="Current Console View state"/);
  assert.match(appSource, /label="Active realization"/);
  assert.match(appSource, /label="Environment"/);
  assert.match(appSource, /label="Latest observation"/);
  assert.match(appSource, /label="Attestation"/);
});

test("UI PASS Y derives dashboard readiness from existing operational state", () => {
  assert.match(appSource, /matrix\.pathwayIntegrityIssueCount/);
  assert.match(appSource, /!selectedPathway\.selectable/);
  assert.match(appSource, /!adapterAvailable/);
  assert.match(appSource, /Ready to exercise/);
  assert.match(appSource, /Observation \$\{latestObservation\.sessionSequence\}/);
  assert.match(appSource, /latestEnvironment\?\.externalEnvironmentIdentifier\.value/);
});

test("UI PASS Y remains bounded and responsive", () => {
  assert.match(styleSource, /UI PASS Y — operational dashboard/);
  assert.match(styleSource, /\.operational-dashboard \{/);
  assert.match(styleSource, /\.dashboard-windowshade-header \{[^}]*grid-template-areas: "publication readiness actions"/);
  assert.match(styleSource, /\.dashboard-windowshade-content \{[^}]*grid-template-areas: "metrics" "coverage" "readouts"/);
  assert.match(styleSource, /\.dashboard-readouts \{[\s\S]*repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(styleSource, /@media \(max-width: 34rem\)/);
});

test("UIR-06 makes the dashboard a single accessible windowshade", () => {
  assert.match(appSource, /const \[dashboardOpen, setDashboardOpen\] = React\.useState\(true\)/);
  assert.match(appSource, /className="dashboard-windowshade-toggle" aria-expanded=\{dashboardOpen\} aria-controls="dashboard-windowshade-content"/);
  assert.match(appSource, /dashboardOpen \? "Close" : "Open"/);
  assert.match(appSource, /setDashboardOpen\(\(current\) => !current\)/);
  assert.match(appSource, /aria-hidden=\{!dashboardOpen\}/);
});

test("UIR-06 keeps the publication, readiness, windowshade, and Load actions visible above one collapsible body", () => {
  assert.match(appSource, /<div className="dashboard-windowshade-header">[\s\S]*className="dashboard-publication"[\s\S]*className="dashboard-readiness"[\s\S]*className="dashboard-actions"/);
  assert.match(appSource, /id="dashboard-windowshade-content"[\s\S]*className="dashboard-data-alignment"[\s\S]*<ExerciseOpportunityCoverageMatrix[\s\S]*className="dashboard-readouts"/);
  assert.match(styleSource, /\.dashboard-windowshade-body\.is-closed \{[^}]*grid-template-rows: minmax\(0, 0fr\)[^}]*opacity: 0[^}]*visibility: hidden/);
  assert.match(styleSource, /transition: grid-template-rows \.22s ease/);
});

test("UI-01 establishes the four stable Pub Board components", () => {
  assert.match(appSource, /className="pub-board four-component-shell"/);
  assert.match(appSource, /className="shell-dashboard"/);
  assert.match(appSource, /aria-label="Session Collection Panel"/);
  assert.match(appSource, /aria-label="Instrument Display"/);
  assert.match(appSource, />Detail Panel</);
  assert.match(styleSource, /grid-template-areas:[\s\S]*"dashboard dashboard"[\s\S]*"collection display"[\s\S]*"detail detail"/);
});

test("UI-03-C1 removes numbered visual region labels while retaining semantic regions", () => {
  assert.doesNotMatch(appSource, /01<\/span> Dashboard session summary/);
  assert.doesNotMatch(appSource, /02<\/span> Session Collection Panel/);
  assert.doesNotMatch(appSource, /03<\/span> Instrument Display/);
  assert.doesNotMatch(appSource, /shell-component-number[^>]*>04/);
  assert.match(appSource, /aria-label="Session Collection Panel"/);
  assert.match(appSource, /aria-label="Instrument Display"/);
  assert.match(appSource, />Detail Panel</);
});

test("UI PASS Z presents one continuous operating instrument", () => {
  assert.match(styleSource, /UI PASS Z — instrument character/);
  assert.match(styleSource, /\.instrument-operating-deck \.workspace-stage-stack \{[\s\S]*gap: 0/);
  assert.match(styleSource, /\.instrument-operating-deck \.operational-stage \{[\s\S]*border-bottom/);
  assert.match(styleSource, /\.instrument-operating-deck \.workspace-stage-link::after/);
  assert.match(styleSource, /\.instrument-operating-deck \.operational-stage:has\(\.stage-marker\.current\)::before/);
});

test("UIR-05 supersedes internal realization-list scrolling while preserving responsive columns", () => {
  assert.match(styleSource, /\.instrument-selector-bank \.channel-list \{[\s\S]*max-height: none;[\s\S]*overflow: visible/);
  assert.doesNotMatch(styleSource, /\.instrument-selector-bank \.channel-list \{[\s\S]{0,180}overflow-y: auto/);
  assert.doesNotMatch(styleSource, /scrollbar-gutter: stable/);
  assert.match(styleSource, /grid-template-columns: repeat\(auto-fit, minmax\(18rem, 1fr\)\)/);
});


test("UI-01 keeps the Pub Board shell visible before publication loading", () => {
  assert.match(appSource, /function EmptyPubBoardShell/);
  assert.match(appSource, /No publication loaded/);
  assert.doesNotMatch(appSource, /Session collections unavailable/);
  assert.doesNotMatch(appSource, /Awaiting publication/);
  assert.doesNotMatch(appSource, /className="welcome-surface"/);
});

test("UI-01 keeps the Detail Panel normally closed and responsive", () => {
  assert.match(appSource, /<details className="shell-detail-panel">/);
  assert.doesNotMatch(appSource, /<details className="shell-detail-panel" open/);
  assert.match(styleSource, /grid-template-areas:[\s\S]*"dashboard"[\s\S]*"collection"[\s\S]*"display"[\s\S]*"detail"/);
});

test("UIR-04 makes publication loading a direct main-screen file action", () => {
  assert.match(appSource, /function LoadPublicationButton/);
  assert.match(appSource, /fileInputRef\.current\?\.click\(\)/);
  assert.match(appSource, /accept="\.zip,application\/zip" type="file"/);
  assert.match(appSource, /Choose publication…/);
  assert.match(appSource, /Load another…/);
  assert.doesNotMatch(appSource, /function LoadPublicationDialog|<dialog|showModal\(\)/);
  assert.doesNotMatch(styleSource, /load-publication-dialog|::backdrop/);
});

test("UIR-04 begins immediately after file choice and replaces state only after successful loading", () => {
  assert.match(appSource, /if \(file\) void props\.onFile\(file\)/);
  assert.match(appSource, /const result = await pc3Api\.activatePublication/);
  assert.match(appSource, /setActivePublication\(result\)/);
  assert.match(appSource, /setAttempts\(\[\]\)/);
  assert.match(appSource, /setInteractions\(\[\]\)/);
  assert.match(appSource, /setObservations\(\[\]\)/);
  assert.match(appSource, /setExecutionEvidence\(\[\]\)/);
  assert.match(appSource, /setEnvironments\(\[\]\)/);
  assert.match(appSource, /setActivation\(\{ status: "failed"/);
  assert.doesNotMatch(appSource, /setActivePublication\(undefined\)/);
});

test("UI-02 keeps the four-component Pub Board visible before loading", () => {
  assert.match(appSource, /<EmptyPubBoardShell/);
  assert.match(appSource, /loadAction={<LoadPublicationButton activation=\{activation\}/);
  assert.match(appSource, /className="pub-board four-component-shell empty-four-component-shell"/);
  assert.match(styleSource, /UI-02 — main-screen load and session initialization/);
  assert.match(styleSource, /\.direct-load-control/);
});

test("UIR-04 removes specified empty-shell instructional clutter", () => {
  assert.doesNotMatch(appSource, /Session collections unavailable/);
  assert.doesNotMatch(appSource, /Test Cases or Inputs, Realizations, and Observations appear after a publication is loaded/);
  assert.doesNotMatch(appSource, />Current object<|Awaiting publication|The selected session object will be presented here/);
  assert.match(appSource, /shell-collection-panel shell-empty-surface/);
  assert.match(appSource, /shell-instrument-display shell-empty-surface/);
});

test("UIR-05 uses Test Level and Observation Level collection headings", () => {
  assert.match(appSource, /<p className="module-index">Test Level<\/p><h3>Test Cases<\/h3>/);
  assert.match(appSource, /<p className="module-index">Observation Level<\/p><h3>Observations<\/h3>/);
  assert.doesNotMatch(appSource, /Publication exercise authority/);
});

test("UIR-05 lets Test Case, Realization, and Observation lists expand without internal scrollbars", () => {
  assert.match(styleSource, /\.test-case-list \{[\s\S]*?max-height: none;[\s\S]*?overflow: visible;/);
  assert.match(styleSource, /\.channel-list \{ display: grid; max-height: none; overflow: visible; \}/);
  assert.match(styleSource, /\.instrument-selector-bank \.channel-list \{[\s\S]*?max-height: none;[\s\S]*?overflow: visible;/);
  assert.match(styleSource, /\.observation-collection-list \{[^}]*max-height: none;[^}]*overflow: visible;/);
  assert.doesNotMatch(styleSource, /\.test-case-list \{[^}]*overflow: auto/);
  assert.doesNotMatch(styleSource, /\.observation-collection-list \{[^}]*overflow: auto/);
});

test("UI-03 establishes one three-context Session Collection Panel", () => {
  assert.match(appSource, /type SessionCollection = "inputs" \| "test-cases" \| "realizations" \| "observations"/);
  assert.match(appSource, /role="tablist" aria-label="Session collections"/);
  assert.match(appSource, /label="Inputs"/);
  assert.match(appSource, /label="Realizations"/);
  assert.match(appSource, /label="Observations"/);
  assert.match(appSource, /activeCollection === "inputs"/);
  assert.match(appSource, /activeCollection === "realizations"/);
  assert.match(appSource, /activeCollection === "observations"/);
});

test("UI-03 preserves collection-local state without changing execution semantics", () => {
  assert.match(appSource, /const \[selectedObservationId, setSelectedObservationId\]/);
  assert.match(appSource, /layerSelections = React\.useRef/);
  assert.match(appSource, /activeCollection === "realizations" \? <SharedOperationalWorkspace/);
  assert.match(appSource, /activeCollection === "inputs" \? <InputObjectDisplay input=\{selectedInput\} \/>/);
  assert.match(appSource, /selectedCollectionObservation \? <ObservationDisplay/);
  assert.doesNotMatch(appSource, /Observation rendering begins in UI-04/);
});

test("UI-03 keeps only one collection visible and provides accessible switching", () => {
  assert.match(appSource, /role="tabpanel" aria-labelledby="collection-tab-inputs"/);
  assert.match(appSource, /role="tabpanel" aria-labelledby="collection-tab-realizations"/);
  assert.match(appSource, /role="tabpanel" aria-labelledby="collection-tab-observations"/);
  assert.match(appSource, /tabIndex=\{props\.active \? 0 : -1\}/);
  assert.match(appSource, /moveFocus\(event, "\[role=tab\]", "horizontal"\)/);
  assert.match(styleSource, /\.session-collection-selector/);
});

test("UI-04 establishes publication-defined input discovery and read-only selection", () => {
  assert.match(appSource, /type PublicationInputObject = PublicationActivationResponse\["interpretation"\]\["inputObjects"\]\[number\]/);
  assert.match(appSource, /inputObjects=\{activePublication\?\.interpretation\.inputObjects \?\? \[\]\}/);
  assert.match(appSource, /count=\{props\.inputObjects\.length\}/);
  assert.match(appSource, /aria-label="Publication input objects"/);
  assert.match(appSource, /function InputObjectDisplay/);
  assert.match(appSource, /Publication input · read-only in UI-04/);
  assert.doesNotMatch(appSource, /contentEditable/);
});

test("UI-04 presents selected input content and provenance in stable shell regions", () => {
  assert.match(appSource, /<InputObjectDisplay input=\{selectedInput\} \/>/);
  assert.match(appSource, /<InputObjectDetails input=\{selectedInput\} \/>/);
  assert.match(appSource, /input\.provenance\.resourcePath/);
  assert.match(appSource, /input\.provenance\.resourceSha256/);
  assert.match(styleSource, /UI-04 — Input Collection Foundation/);
  assert.match(styleSource, /\.input-object-display \{/);
});

test("UI-05 replaces Inputs with Test Cases only for the PTC profile", () => {
  assert.match(appSource, /const ptcProfileActive = capabilityProfile\?\.kind === "ptc"/);
  assert.match(appSource, /ptcProfileActive[\s\S]*label="Test Cases"[\s\S]*label="Inputs"/);
  assert.match(appSource, /aria-label="Publication Test Cases"/);
  assert.match(appSource, /capabilityProfile\?\.kind === "ambiguous-mixed"/);
  assert.match(appSource, /Exercise authority unresolved/);
});

test("UI-05 presents canonical input, Expected Outcome, purpose, classification, and applicability", () => {
  assert.match(appSource, /function PublicationTestCaseDisplay/);
  assert.match(appSource, /Canonical input/);
  assert.match(appSource, /Expected Outcome/);
  assert.match(appSource, /ptc\.purpose/);
  assert.match(appSource, /ptc\.classification/);
  assert.match(appSource, /ptc\.applicability\.applicableRealizationCount/);
  assert.match(styleSource, /UI-05 — Publication Test Case Navigation/);
});

test("UI-05 resolves the selected PTC and realization on one pairing and RTCM", () => {
  assert.match(appSource, /pairingToRtcmIdentifier\[`\$\{selectedPtcId\}\|\$\{selectedRealizationIdentifier\}`\]/);
  assert.match(appSource, /resolvedExerciseByPair\.get\(`\$\{selectedPtcId\}\|\$\{selectedRealizationIdentifier\}`\)/);
  assert.match(appSource, /function ResolvedPairingDetails/);
});

test("UII-01 makes the Publication Test Cases list the only Test Case selection control", () => {
  assert.equal((appSource.match(/setSelectedPtcId\(/g) ?? []).length, 2);
  assert.match(appSource, /aria-label="Publication Test Cases"/);
  assert.match(appSource, /onClick=\{\(\) => \{ setSelectedPtcId\(ptc\.identifier\)/);
  assert.doesNotMatch(appSource, /Applicable realizations/);
  assert.doesNotMatch(appSource, /test-case-realizations/);
  assert.doesNotMatch(appSource, /realization-test-case-selector/);
  assert.doesNotMatch(appSource, /id="realization-test-case"/);
  assert.doesNotMatch(appSource, /realizationPtcIdentifiers/);
  assert.doesNotMatch(appSource, /selectTestCaseRealization/);
  assert.doesNotMatch(styleSource, /test-case-realizations|realization-test-case-selector/);
});

test("UII-01 preserves Test Case selection across realization navigation without substitution", () => {
  assert.match(appSource, /setSelectedPtcId\(\(current\) => publicationTestCases\.some/);
  assert.doesNotMatch(appSource, /setSelectedPtcId\(\(current\) => current &&/);
  assert.doesNotMatch(appSource, /setSelectedPtcId[\s\S]{0,180}selectedRealizationIdentifier/);
  assert.match(appSource, /selectedResolvedExercise = selectedPtcId && selectedRealizationIdentifier \? resolvedExerciseByPair\.get/);
  assert.match(appSource, /No resolved exercise for the selected Test Case/);
});

test("UIR-01 places one accessible Limit toggle in the Realizations upper band", () => {
  assert.equal((appSource.match(/>Limit<\/button>/g) ?? []).length, 1);
  assert.match(appSource, /className="realization-collection-actions"/);
  assert.match(appSource, /className={`collection-limit-action \$\{exercisableFilterActive \? "is-pressed" : ""\}`}/);
  assert.match(appSource, /aria-pressed={exercisableFilterActive}/);
  assert.match(appSource, /disabled={!exercisableFilterAvailable}/);
  assert.doesNotMatch(appSource, /Show Exercisable/);
  assert.doesNotMatch(appSource, /exercisableFilterActive \? "On" : "Off"/);
  assert.match(styleSource, /\.collection-limit-action\.is-pressed[\s\S]*box-shadow: inset/);
  assert.match(styleSource, /\.collection-limit-action:focus-visible/);
});

test("UIR-01 Limit uses the exact same eligibility decision as each Exercise button", () => {
  assert.match(appSource, /const exerciseEligibilityForPathway = \(pathway: RealizationPathwayView\): CanonicalExerciseEligibility/);
  assert.match(appSource, /return canonicalExerciseEligibility\(pathway, selectedPtc, resolvedExercise, invocationSupport, props\.adapters\.length > 0, props\.activeContextAvailable\)/);
  assert.match(appSource, /!exercisableFilterActive \|\| exerciseEligibilityForPathway\(pathway\)\.enabled/);
  assert.match(appSource, /item\.endpointType === activeLayer && isVisibleForExerciseFilter\(item\)/);
  assert.match(appSource, /item\.endpointType === layer\.id && isVisibleForExerciseFilter\(item\)/);
  assert.match(appSource, /const selectedPathway = visiblePathways\.find/);
  assert.match(appSource, /visiblePathways\.map\(\(pathway\) => \{ const eligibility = exerciseEligibilityForPathway\(pathway\)/);
  assert.equal((appSource.match(/setSelectedPtcId\(/g) ?? []).length, 2);
});

test("UIR-01 defaults and resets to all realizations with honest bounded states", () => {
  assert.match(appSource, /useState\(false\)/);
  assert.match(appSource, /setShowExercisable\(false\);\s*setSelectedObservationId\(undefined\)/);
  assert.match(appSource, /if \(!exercisableFilterAvailable\) setShowExercisable\(false\)/);
  assert.match(appSource, /Limited to realizations with enabled Exercise actions/);
  assert.match(appSource, /Showing all realizations/);
  assert.match(appSource, /Select a Publication Test Case to limit realizations/);
  assert.match(appSource, /No exercisable realizations for the selected Test Case at this level/);
  assert.match(appSource, /REALIZATION_LAYERS\.map[\s\S]*isVisibleForExerciseFilter\(item\)\)\.length/);
});

test("UII-03 gives every visible realization row one distinct canonical Exercise action", () => {
  assert.match(appSource, /function RealizationChannelSelector/);
  assert.match(appSource, /className="channel-exercise-action"/);
  assert.match(appSource, /Exercise \$\{props\.pathway\.endpointIdentifier\} with the selected Test Case/);
  assert.match(appSource, /props\.exercising \? "Exercising…" : "Exercise"/);
  assert.match(appSource, /disabled=\{!props\.exerciseEligibility\.enabled \|\| props\.busy\}/);
  assert.match(styleSource, /UII-03 — one-click canonical exercise from realization rows/);
  assert.doesNotMatch(appSource, /<small[^>]*exercise-reason/);
  assert.match(styleSource, /grid-template-columns: minmax\(0, 1fr\) 5\.4rem/);
});

test("UII-03 keeps the right-hand display focused on the latest result", () => {
  assert.doesNotMatch(appSource, /function ExerciseAttemptPanel/);
  assert.doesNotMatch(appSource, /function ExecutionAdapterPanel/);
  assert.doesNotMatch(appSource, /Run publication-declared reference/);
  assert.doesNotMatch(appSource, /Prepare \$\{exerciseDisposition\} attempt/);
  assert.match(appSource, /id="workspace-check"/);
  assert.doesNotMatch(appSource, /id="workspace-attest"/);
});

test("UII-03 uses the sole selected PTC and coordinates a fresh canonical attempt through accepted execution", () => {
  assert.match(appSource, /props\.onCanonicalExercise\(pathway\.id, selectedPtc\.identifier\)/);
  assert.match(appSource, /exerciseDisposition: "canonical"/);
  assert.match(appSource, /pc3Api\.prepareExerciseAttempt\(sessionId, contextId/);
  assert.match(appSource, /pc3Api\.executeReferenceExerciseAttempt\(sessionId, prepared\.id, contextId\)/);
  assert.match(appSource, /getRuntimeObservations\(sessionId\)/);
  assert.match(appSource, /getObservationComparisons\(sessionId\)/);
  assert.doesNotMatch(appSource, /onCanonicalExercise[^\n]+setSelectedPtcId/);
});

test("UII-03 keeps unsupported and unresolved rows visible with bounded reasons", () => {
  assert.match(appSource, /No resolved exercise for the selected Test Case/);
  assert.match(appSource, /Invocation mode not yet supported by PC3/);
  assert.match(appSource, /No compatible execution adapter is available/);
  assert.match(appSource, /Any prepared attempt remains available for inspection/);
  assert.match(appSource, /Canonical exercise complete\. A new Runtime Observation is available/);
});

test("UI-05-C1 opens a PTC publication on Test Cases and keeps the exercise model in progressive detail", () => {
  assert.match(appSource, /useState<SessionCollection>\(ptcProfileActive \? "test-cases"/);
  assert.match(appSource, /setActiveCollection\(ptcProfileActive \? "test-cases"/);
  assert.match(appSource, /profile\.kind === "ptc" \? `PTC · \$\{profile\.ptcCount\} Test Cases`/);
  assert.match(appSource, /<details><summary>Exercise model<\/summary>/);
  assert.doesNotMatch(appSource, /capability-profile-banner/);
  assert.doesNotMatch(styleSource, /capability-profile-banner/);
});

test("UI-05-C2 renders Inputs only for a declared input capability", () => {
  assert.match(appSource, /inputCollectionAvailable = capabilityProfile\?\.kind === "legacy-input" \|\| capabilityProfile\?\.kind === "ambiguous-mixed"/);
  assert.match(appSource, /inputCollectionAvailable \? <CollectionTab id="inputs"/);
  assert.match(appSource, /"no-exercise-collection"/);
  assert.match(styleSource, /\.session-collection-selector\.no-exercise-collection \{ grid-template-columns: repeat\(2/);
});

test("UI-06 presents publication readiness by realization and by PTC", () => {
  assert.match(appSource, /function projectPtcReadiness/);
  assert.match(appSource, /"complete" \| "partial" \| "none" \| "not-applicable"/);
  assert.match(appSource, /marker="PTC" population="Publication Test Cases" counts=\{ptcCounts\}/);
  assert.match(appSource, /marker="RZN" population="Realizations" counts=\{realizationCounts\}/);
  assert.match(appSource, /publicationReadiness=\{readinessByRealization\.get\(pathway\.endpointIdentifier\)\}/);
  assert.match(appSource, /channel-publication-readiness readiness-\$\{props\.publicationReadiness\.status\}`}>\{readinessLabel\(props\.publicationReadiness\.status\)\}/);
});

test("UI-06 presents declaration checks and material limitations through progressive disclosure", () => {
  assert.match(appSource, /function PublicationReadinessPanel/);
  assert.match(appSource, /<details><summary>Declaration checks and limitations/);
  assert.match(appSource, /validation\.checks\.map/);
  assert.match(appSource, /Declaration issues/);
  assert.match(appSource, /Interpretation limitations/);
  assert.match(styleSource, /UI-06 — Publication Exercise Readiness and Declaration Checks/);
  assert.doesNotMatch(appSource, />Validation<|Validation and limitations|Validation issues|Publication validation|publication-validation/);
});

test("UI-06 does not conflate publication completeness with operational outcomes", () => {
  assert.match(appSource, /Declaration completeness only/);
  assert.match(appSource, /does not report deployment, environment availability, runtime readiness, execution results, scientific validity, or conformance/);
  assert.match(appSource, /not runtime readiness or an execution result/);
  assert.match(appSource, /This is declaration completeness, not runtime status/);
});

test("UIR-03 moves Publication Declarations behind the Detail Panel", () => {
  assert.equal((appSource.match(/<PublicationReadinessPanel interpretation=\{props\.interpretation\}/g) ?? []).length, 1);
  assert.match(appSource, /<details className="shell-detail-panel">[\s\S]*<div className="detail-panel-body">[\s\S]*<PublicationReadinessPanel interpretation=\{props\.interpretation\}/);
  assert.match(appSource, /<aside className="channel-bank shell-collection-panel"[\s\S]*<div className=\{`session-collection-selector/);
  assert.doesNotMatch(appSource, /<aside className="channel-bank shell-collection-panel"[\s\S]{0,180}<PublicationReadinessPanel/);
});

test("UIR-03 removes Normally closed copy without forcing the Detail Panel open", () => {
  assert.doesNotMatch(appSource, /Normally closed/);
  assert.equal((appSource.match(/<summary><span>Detail Panel<\/span><\/summary>/g) ?? []).length, 2);
  assert.doesNotMatch(appSource, /<details className="shell-detail-panel" open/);
});

test("UII-05 presents PTC, RZN, and pathway groups simultaneously in the required order", () => {
  assert.match(appSource, /className="dashboard-data-alignment"[\s\S]*marker="PTC"[\s\S]*marker="RZN"[\s\S]*className="dashboard-readout-group dashboard-matrix"/);
  assert.match(appSource, /const statuses: readonly PublicationReadinessStatus\[\] = \["complete", "partial", "none", "not-applicable"\]/);
  assert.match(appSource, /REALIZATION_LAYERS\.map/);
  assert.match(appSource, /className="dashboard-numeric-box status-count-box status-total"/);
  assert.match(styleSource, /UII-05 — twelve aligned dashboard data readouts/);
  assert.match(styleSource, /\.dashboard-data-alignment \{[^}]*grid-template-columns: repeat\(3, minmax\(0, 1fr\)\)/);
});

test("UII-05 removes the completeness heading, toggle, and obsolete projection state", () => {
  assert.doesNotMatch(appSource, /Exercise completeness|By Realization|By PTC/);
  assert.doesNotMatch(appSource, /ReadinessProjectionMode|readinessProjectionMode|setReadinessProjectionMode|readiness-context-toggle|displayedProjectionMode/);
  assert.doesNotMatch(styleSource, /readiness-context-toggle|dashboard-completeness-heading/);
});

test("UII-05 keeps a zero-valued explained PTC group when no PTC capability exists", () => {
  assert.match(appSource, /ptcProjectionAvailable=\{ptcProfileActive\}/);
  assert.match(appSource, /available=\{ptcProjectionAvailable\}/);
  assert.match(appSource, /No Publication Test Cases are declared; PC3 reports zero without fabricating a classification/);
  assert.match(appSource, /const ptcProjections = interpretation\?\.publicationTestCases\.map/);
});

test("UII-05 aligns numeric and lower-label baselines while preserving whole responsive groups", () => {
  assert.match(appSource, /className="numeric-box-footer"><b>\{marker\}<\/b>/);
  assert.match(appSource, /<b>\{layer\.short\}<\/b>/);
  assert.match(appSource, /<b>Total<\/b>/);
  assert.match(styleSource, /\.dashboard-numeric-box \{[\s\S]*min-height: 3\.55rem/);
  assert.match(styleSource, /grid-template-rows: minmax\(1\.45rem, 1fr\) auto/);
  assert.match(styleSource, /\.dashboard-readout-group \{[^}]*grid-template-columns: repeat\(4/);
  assert.match(styleSource, /@media \(max-width: 58rem\)[\s\S]*\.dashboard-data-alignment \{ grid-template-columns: repeat\(2/);
});

test("UII-06 adds one dense pairing matrix without changing the accepted twelve readouts",()=>{
  assert.equal((appSource.match(/<ExerciseOpportunityCoverageMatrix/g)??[]).length,1);
  assert.match(appSource,/className="dashboard-data-alignment"[\s\S]*marker="PTC"[\s\S]*marker="RZN"[\s\S]*status-total[\s\S]*<ExerciseOpportunityCoverageMatrix/);
  assert.match(appSource,/<caption id="opportunity-coverage-heading">Exercise opportunity coverage<\/caption>/);
  for(const heading of ["Possible","Applicable","RTCM","Enabled","Blocked","N/A","Unclass.","Coverage"])assert.ok(appSource.includes(heading),heading);
  assert.match(styleSource,/\.exercise-opportunity-coverage table \{[^}]*table-layout: fixed[^}]*font-variant-numeric: tabular-nums/);
  assert.match(styleSource,/height: 1\.32rem/);
});

test("UII-06 renders the server-owned IR, SR, DP, and TOTAL projection simultaneously",()=>{
  assert.match(appSource,/exerciseOpportunityCoverage=\{activePublication\?\.exerciseOpportunityCoverage\}/);
  assert.match(appSource,/projection\.rows\.map/);
  assert.match(appSource,/"implementation-representation": "IR"/);
  assert.match(appSource,/"service-realization": "SR"/);
  assert.match(appSource,/"deployment-package": "DP"/);
  assert.match(appSource,/total: "TOTAL"/);
  for(const property of ["possible","applicable","rtcmResolved","exerciseEnabled","blocked","notApplicable","unclassified","coveragePercent"])assert.match(appSource,new RegExp(`row\\.${property}`));
});

test("UII-06 keeps pairing meanings dense, attributable, and non-conformance",()=>{
  assert.match(appSource,/active context's latest support assessment/);
  assert.match(appSource,/Blocked<\/dt><dd>Applicable minus Enabled; this is not an execution failure/);
  assert.match(appSource,/this is not conformance or test-result coverage/);
  assert.match(appSource,/projection\.status === "projection-error"/);
  assert.match(appSource,/role="alert"/);
  assert.match(appSource,/value === null \? "—"/);
  assert.match(styleSource,/overflow-x: auto/);
  assert.doesNotMatch(appSource,/Exercise opportunity coverage[\s\S]{0,500}type="button"/);
});

test("UI-07 binds the review surface to server-produced immutable Resolved Exercises", () => {
  assert.match(appSource, /type ResolvedExercise = PublicationInterpretation\["resolvedExercises"\]\[number\]/);
  assert.match(appSource, /selectedResolvedExercise = selectedPtcId && selectedRealizationIdentifier \? resolvedExerciseByPair\.get/);
  assert.match(appSource, /selectedResolvedExercise \? <ResolvedExerciseReview exercise=\{selectedResolvedExercise\}/);
  assert.match(appSource, /function ResolvedExerciseReview/);
});

test("UI-07 shows every resolved exercise component before execution", () => {
  assert.match(appSource, /Resolved Computational Exercise/);
  assert.match(appSource, /Canonical input/);
  assert.match(appSource, /Canonical Expected Outcome/);
  assert.match(appSource, /Comparison semantics/);
  assert.match(appSource, /Invocation and input mapping/);
  assert.match(appSource, /Observation mapping/);
  assert.match(appSource, /Boundary and limitations/);
  assert.match(styleSource, /UI-07 — Resolved Computational Exercise Review/);
});

test("UI-07 review remains non-executing and external-boundary explicit", () => {
  assert.match(appSource, /Reviewing it does not create an Exercise Attempt or execute the realization/);
  assert.match(appSource, /exercise\.executionBoundary/);
  assert.match(appSource, /exercise\.rtcm\.invocation\.doesNotEmbedRuntime/);
  assert.match(appSource, /function ResolvedExerciseReview\(\{ exercise \}: \{ readonly exercise: ResolvedExercise \}\)/);
});

test("UI-08 provides progressive advanced inspection in the contextual Detail Panel", () => {
  assert.match(appSource, /<AdvancedPublicationInspection interpretation=\{props\.interpretation\}/);
  assert.match(appSource, /function AdvancedPublicationInspection/);
  assert.match(appSource, /<details className="advanced-publication-inspection">/);
  assert.match(appSource, /RTCM provenance and integrity/);
  assert.match(appSource, /Applicability basis/);
  assert.match(styleSource, /UI-08 — Advanced Publication Inspection/);
});

test("UI-08 exposes indexes, authority, declaration issues, and grouped unresolved information", () => {
  assert.match(appSource, /Relationship and coverage indexes/);
  assert.match(appSource, /Declaration authority/);
  assert.match(appSource, /Declaration issues/);
  assert.match(appSource, /Unresolved or conflicting information/);
  assert.match(appSource, /groupedLimitations/);
  assert.match(appSource, /declaration location/);
});

test("UI-08 keeps RTCMs resolved and out of primary navigation", () => {
  assert.match(appSource, /RTCMs remain automatically resolved implementation objects—not primary navigation choices/);
  assert.doesNotMatch(appSource, /<CollectionTab id="rtcm/);
  assert.doesNotMatch(appSource, /label="RTCMs"/);
});

test("EX-01 canonical attempt preparation remains inside the coordinated row action", () => {
  assert.match(appSource, /pc3Api\.prepareExerciseAttempt\(sessionId, contextId/);
  assert.match(appSource, /ptcIdentifier,/);
  assert.match(appSource, /exerciseDisposition: "canonical"/);
  assert.match(appSource, /const prepared =/);
});

test("UII-03 removes exploratory preparation from the primary Instrument Display", () => {
  assert.doesNotMatch(appSource, /Exercise disposition/);
  assert.doesNotMatch(appSource, /Prepare exploratory attempt/);
  assert.doesNotMatch(appSource, /Manual external process/);
  assert.doesNotMatch(appSource, /function ResolvedExerciseReview\([^)]*onPrepare/);
});

test("EX-01 blocks canonical preparation at the row before calling the server", () => {
  assert.match(appSource, /if \(!resolvedExercise\) return \{ enabled: false/);
  assert.match(appSource, /disabled=\{!props\.exerciseEligibility\.enabled \|\| props\.busy\}/);
  assert.match(appSource, /No active publication context/);
  assert.match(appSource, /No compatible execution adapter is available/);
});

test("EX-03-NP1 invokes the accepted canonical route from supported declaration-backed rows", () => {
  assert.match(appSource, /executeReferenceExerciseAttempt/);
  assert.match(appSource, /\["cli", "library", "http"\]\.includes\(resolvedExercise\.rtcm\.invocation\.mode\.toLowerCase\(\)\)/);
  assert.doesNotMatch(appSource, /REFERENCE_PTC_IDENTIFIER|REFERENCE_REALIZATION_IDENTIFIER/);
});

test("EX-02 presents exceptional process details without substituting stderr for stdout", () => {
  assert.match(appSource, /Raw stderr \(preserved, not substituted for stdout\)/);
  assert.match(appSource, /externalProcess\?\.exitCode/);
  assert.match(appSource, /externalProcess\?\.timedOut/);
});

test("OBS-01 makes raw observation identity and PTC scope independently inspectable", () => {
  assert.match(appSource, /Immutable raw observation/);
  assert.match(appSource, /Raw identity and PTC scope/);
  assert.match(appSource, /observation\.rawObservation\.sha256/);
  assert.match(appSource, /observation\.publicationExerciseScope\.ptcIdentifier/);
  assert.match(appSource, /observation\.publicationExerciseScope\.rtcmIdentifier/);
  assert.match(appSource, /Raw content remains independently inspectable/);
});

test("OBS-01 exposes extraction, normalization, and property classifications without comparison", () => {
  assert.match(appSource, /observation\.extractionProvenance\.disposition/);
  assert.match(appSource, /declared, none applied/);
  assert.match(appSource, /observation\.propertyClassifications\.map/);
  assert.match(appSource, /Extraction, normalization, and comparison have not changed it/);
  assert.match(styleSource, /OBS-01 — PTC-scoped raw observation inspection/);
});

test("OBS-02 presents a separate Expected Outcome comparison with all four bounded statuses", () => {
  assert.match(appSource, /function ExpectedOutcomeComparisonPanel/);
  assert.match(appSource, /Expected Outcome comparison/);
  assert.match(appSource, /comparison\.status === "pass" \|\| comparison\.status === "fail"/);
  assert.match(appSource, /comparison-error/);
  assert.match(styleSource, /comparison-indeterminate/);
  assert.match(appSource, /Comparison result, not conformance determination/);
});

test("UII-04 renders the exact selected Observation as a read-only operational object", () => {
  assert.match(appSource, /function ObservationDisplay/);
  assert.match(appSource, /Observation \{observation\.sessionSequence\}/);
  assert.match(appSource, /External execution outcome/);
  assert.match(appSource, /Immutable raw Observation/);
  assert.match(appSource, /observation\.rawObservation\.value/);
  assert.match(appSource, /No Expected Outcome comparison is recorded for this Observation/);
  assert.match(appSource, /Read-only inspection · stored records only/);
});

test("UII-04 associates comparison and provenance only by exact stored identities", () => {
  assert.match(appSource, /item\.observationId === selectedCollectionObservation\.id/);
  assert.match(appSource, /item\.id === selectedCollectionObservation\.executionInteractionId/);
  assert.match(appSource, /item\.id === selectedCollectionObservation\.executionEnvironmentDescriptionId/);
  assert.match(appSource, /item\.runtimeObservation\.id === selectedCollectionObservation\.id/);
  assert.match(appSource, /function ObservationEngineeringDetails/);
  assert.doesNotMatch(appSource, /selectedCollectionComparison = .*\.at\(-1\)/);
});

test("UII-04 keeps Observation selection stable and clears stale identities", () => {
  assert.match(appSource, /if \(selectedObservationId && !props\.observations\.some\(\(item\) => item\.id === selectedObservationId\)\)/);
  assert.match(appSource, /setSelectedObservationId\(undefined\)/);
  assert.match(appSource, /setSelectedObservationId\(observation\.id\)/);
  assert.match(appSource, /Observation \$\{observation\.sessionSequence\} selected for inspection/);
});

test("UII-04 provides bounded accessible inspection without automatic lifecycle actions", () => {
  const displaySource = appSource.slice(appSource.indexOf("function ObservationDisplay"), appSource.indexOf("function ObservationEngineeringDetails"));
  assert.match(appSource, /aria-label=\{`Observation \$\{observation\.sessionSequence\}: \$\{observation\.id\}`\}/);
  assert.match(appSource, /<pre tabIndex=\{0\}>\{observation\.rawObservation\.value\}<\/pre>/);
  assert.match(styleSource, /UII-04 — first-class Observation rendering/);
  assert.match(styleSource, /overflow: auto/);
  assert.doesNotMatch(displaySource, /\bon(?:Save|Discard|Attest|Exercise)\b/);
  assert.doesNotMatch(displaySource, /<button/);
});

test("OBS-02 exposes raw, normalized, extracted, expected, and comparison representations separately", () => {
  assert.match(appSource, /comparison\.rawRepresentation\.rawObservationId/);
  assert.match(appSource, /comparison\.normalizedRepresentation\.disposition/);
  assert.match(appSource, /comparison\.extractedRepresentation\.sourcePath/);
  assert.match(appSource, /comparison\.expectedRepresentation\.value/);
  assert.match(appSource, /comparison\.comparisonRepresentation\.absoluteDifference/);
  assert.match(appSource, /comparison\.claimDisposition/);
  assert.match(styleSource, /OBS-02 — separate deterministic Expected Outcome comparison/);
});

test("ATT-01 evidence infrastructure is invoked only through one formal Observation-collection save", () => {
  assert.match(appSource, /className="collection-attest-action"/);
  assert.match(appSource, /props\.onAttestCollection\(\)/);
  assert.match(appSource, /attestCurrentObservationCollection/);
  assert.doesNotMatch(appSource, /Observation eligible for attestation|Inspect attested record before saving/);
  assert.doesNotMatch(appSource, /onSaveObservation|onDiscardObservation|onSaveEvidence|onDiscardEvidence/);
});

test("UII-04 correction places Attest immediately left of the Observations count", () => {
  assert.match(appSource, /<div className="observation-collection-actions"><button[^>]*className="collection-attest-action"[\s\S]*?<span aria-label=\{`\$\{props\.observations\.length\} observations`\}/);
  assert.match(appSource, /disabled=\{!props\.observations\.length \|\| attestingCollection\}/);
  assert.match(styleSource, /\.observation-collection-actions \{ display: flex/);
});

test("UII-04 correction removes redundant right-hand Observation and Evidence collections", () => {
  assert.doesNotMatch(appSource, /function RuntimeObservationPanel|function ExecutionEvidencePanel/);
  assert.doesNotMatch(appSource, />Save<|>Discard<|Attest as Execution Evidence/);
  assert.match(appSource, /<OutputMonitor observation=\{latestObservation\}/);
  assert.match(styleSource, /\.check-workspace \{[\s\S]*grid-template-columns: minmax\(0, 1fr\)/);
});

test("EX-03-NP1 makes CLI and library readiness declaration-driven instead of naming one publication path", () => {
  const eligibilitySource = appSource.slice(appSource.indexOf("function canonicalExerciseEligibility"), appSource.indexOf("type PtcReadinessProjection"));
  assert.match(eligibilitySource, /\["cli", "library", "http"\]\.includes\(resolvedExercise\.rtcm\.invocation\.mode\.toLowerCase\(\)\)/);
  assert.match(eligibilitySource, /!invocationSupport\.executable/);
  assert.match(eligibilitySource, /reason: invocationSupport\.reason/);
  assert.doesNotMatch(eligibilitySource, /UKO-001|REFERENCE_PTC_IDENTIFIER|REFERENCE_REALIZATION_IDENTIFIER/);
  assert.doesNotMatch(eligibilitySource, /EX03A_LOCAL_RUNTIME_REQUIREMENTS|Declared runtime is not supported by the current execution bridge/);
});

test("EX-03A enables Exercise only for the server-assessed exact PTC, realization, and RTCM tuple", () => {
  assert.match(appSource, /invocationSupport=\{activePublication\?\.invocationSupport \?\? \[\]\}/);
  assert.match(appSource, /invocationSupportByExercise\.get\(`\$\{resolvedExercise\.ptc\.identifier\}\|\$\{resolvedExercise\.realization\.identifier\}\|\$\{resolvedExercise\.rtcm\.identifier\}`\)/);
  assert.match(appSource, /canonicalExerciseEligibility\(pathway, selectedPtc, resolvedExercise, invocationSupport,/);
});

test("EX-03C exposes the immutable Docker environment and cleanup record through progressive detail", () => {
  assert.match(appSource, /environment\.container\.providerId/);
  assert.match(appSource, /environment\.container\.imageReference/);
  assert.match(appSource, /environment\.container\.imageId/);
  assert.match(appSource, /environment\.container\.networkMode/);
  assert.match(appSource, /environment\.container\.limits\.timeoutMilliseconds/);
  assert.match(appSource, /environment\.container\.cleanupDisposition/);
});

test("EX-03-NP1 lets server-assessed library RTCMs use the same one-click Exercise action",()=>{
  assert.match(appSource,/\["cli", "library", "http"\]\.includes\(resolvedExercise\.rtcm\.invocation\.mode\.toLowerCase\(\)\)/);
  assert.match(appSource,/invocationSupport\.executable/);
  assert.doesNotMatch(appSource,/resolvedExercise\.rtcm\.invocation\.mode\.toLowerCase\(\) !== "cli"/);
});

test("EX-03D exposes .NET bridge provenance only through progressive Observation detail",()=>{
  const detailsSource=appSource.slice(appSource.indexOf("function ObservationEngineeringDetails"),appSource.indexOf("function OutputMonitor"));
  assert.match(detailsSource,/Resolved reference invocation/);
  assert.match(detailsSource,/adapterResolution\.canonicalRuntime/);
  assert.match(detailsSource,/dotnetCliInvocation\.bridgeId/);
  assert.match(detailsSource,/dotnetCliInvocation\.projectFileReference/);
  assert.match(detailsSource,/dotnetCliInvocation\.implementationProjectReference/);
  assert.doesNotMatch(appSource,/C#.*<button|dotnet.*<button/i);
});

test("EX-03E keeps HTTP mechanics in progressive Observation detail while reusing Exercise",()=>{
  const detailsSource=appSource.slice(appSource.indexOf("function ObservationEngineeringDetails"),appSource.indexOf("function OutputMonitor"));
  assert.match(appSource,/\["cli", "library", "http"\]\.includes\(resolvedExercise\.rtcm\.invocation\.mode\.toLowerCase\(\)\)/);
  assert.match(detailsSource,/httpInvocation\.bridgeId/);
  assert.match(detailsSource,/httpInvocation\.method/);
  assert.match(detailsSource,/httpInvocation\.route/);
  assert.match(detailsSource,/httpTransfer\?\.statusCode/);
  assert.doesNotMatch(appSource,/>Send HTTP<|>POST<|Endpoint invocation/i);
});

test("EX-03F renders negative derivation and semantic assertions only through progressive Observation detail",()=>{
  const detailsSource=appSource.slice(appSource.indexOf("function ObservationEngineeringDetails"),appSource.indexOf("function OutputMonitor"));
  const comparisonSource=appSource.slice(appSource.indexOf("function ExpectedOutcomeComparisonPanel"),appSource.indexOf("function ObservationScopeDetails"));
  assert.match(detailsSource,/negativeConditionPlan\.operation/);
  assert.match(detailsSource,/negativeConditionPlan\.semanticSubject/);
  assert.match(detailsSource,/negativeConditionPlan\.expectedErrorCode/);
  assert.match(detailsSource,/requestBodySha256/);
  assert.match(comparisonSource,/semanticAssertions/);
  assert.doesNotMatch(appSource,/Malformed input editor|Negative input editor|>Send</i);
});

test("UIR-07 applies one restrained VFD system to the entire Instrument Display", () => {
  const vfdSource = styleSource.slice(styleSource.indexOf("UIR-07 — refined vacuum fluorescent Instrument Display"));
  assert.match(vfdSource, /\.shell-instrument-display \{/);
  assert.match(vfdSource, /--vfd-glass: #061012/);
  assert.match(vfdSource, /--vfd-phosphor: #a9f6f1/);
  assert.match(vfdSource, /--vfd-amber: #ffd27c/);
  assert.match(vfdSource, /--vfd-red: #ff8178/);
  assert.match(vfdSource, /repeating-linear-gradient/);
  assert.match(vfdSource, /\.shared-workspace,[\s\S]*\.input-object-display,[\s\S]*\.test-case-display,[\s\S]*\.resolved-exercise-review,[\s\S]*\.observation-display,[\s\S]*\.instrument-display-placeholder/);
});

test("UIR-07 keeps VFD readouts legible and static", () => {
  const vfdSource = styleSource.slice(styleSource.indexOf("UIR-07 — refined vacuum fluorescent Instrument Display"));
  assert.match(vfdSource, /line-height: 1\.48/);
  assert.match(vfdSource, /font-variant-numeric: tabular-nums/);
  assert.match(vfdSource, /prefers-contrast: more/);
  assert.doesNotMatch(vfdSource, /@keyframes|animation\s*:/);
});

test("UIR-07 retains the Instrument Display as a readout without action controls", () => {
  const displayShellStart = appSource.lastIndexOf('<section className="shell-instrument-display" aria-label="Instrument Display">');
  const displayShell = appSource.slice(displayShellStart, appSource.indexOf('<details className="shell-detail-panel">', displayShellStart));
  assert.doesNotMatch(displayShell, /<button|<input|<select|<textarea/);
  assert.match(displayShell, /<SharedOperationalWorkspace/);
  assert.match(displayShell, /<ObservationDisplay/);
});

test("UIR-08 derives list-only compact realization identifiers from publication and layer identity", () => {
  const helperSource = appSource.slice(appSource.indexOf("function compactRealizationIdentifier"), appSource.indexOf("function endpointLabel"));
  assert.match(helperSource, /layer === "implementation-representation" \? "RCI" : layer === "service-realization" \? "SR" : "DP"/);
  assert.match(helperSource, /const prefix = `\$\{publicationIdentifier\}-\$\{layerMarker\}-`/);
  assert.match(helperSource, /identifier\.startsWith\(prefix\)/);
  assert.doesNotMatch(helperSource, /UKO-001/);
});

test("UIR-08 prefers declared titles and keeps complete identity accessible", () => {
  const selectorSource = appSource.slice(appSource.indexOf("function RealizationChannelSelector"), appSource.indexOf("function SharedOperationalWorkspace"));
  assert.match(selectorSource, /const declaredTitle = props\.declaration\?\.title\?\.trim\(\)/);
  assert.match(selectorSource, /const primaryLabel = declaredTitle \|\| compactIdentifier/);
  assert.match(selectorSource, /title=\{props\.pathway\.endpointIdentifier\}/);
  assert.match(selectorSource, /aria-label=\{`\$\{declaredTitle/);
  assert.doesNotMatch(selectorSource, /compactPathwaySummary\(props\.pathway\)/);
});

test("UIR-08 uses a compact two-line identity layout with fixed Exercise alignment", () => {
  const uir08Source = styleSource.slice(styleSource.indexOf("UIR-08 — compact Realization identity rows"));
  assert.match(uir08Source, /\.realization-identity \{[\s\S]*display: grid/);
  assert.match(uir08Source, /\.realization-identity-meta \{[\s\S]*display: flex/);
  assert.match(uir08Source, /-webkit-line-clamp: 2/);
  assert.match(uir08Source, /\.channel-row \.channel-exercise-control \{[\s\S]*width: 5rem/);
  assert.match(uir08Source, /\.channel-row \.channel-exercise-action \{[\s\S]*width: 100%/);
});

test("UIR-09 advances visual load activity but caps estimation below completion", () => {
  assert.match(appSource, /status: "working"; readonly filename: string; readonly progress: number/);
  assert.match(appSource, /current\.progress >= 90/);
  assert.match(appSource, /Math\.min\(90, current\.progress \+ increment\)/);
  assert.match(appSource, /progress: Math\.max\(current\.progress, 72\)/);
  assert.match(appSource, /progress: 100/);
  assert.ok(appSource.indexOf("progress: 100") > appSource.indexOf("await pc3Api.getRealizationMatrix"));
});

test("UIR-09 fills the disabled busy Load button beneath its readable label", () => {
  assert.match(appSource, /--load-progress/);
  assert.match(appSource, /className="load-action-progress" aria-hidden="true"/);
  assert.match(appSource, /className="load-action-label">\{label\}/);
  assert.match(appSource, /aria-busy=\{working\}/);
  const uir09Source = styleSource.slice(styleSource.indexOf("UIR-09 — dynamic publication Load progress"));
  assert.match(uir09Source, /width: var\(--load-progress, 0%\)/);
  assert.match(uir09Source, /transition: width 220ms linear/);
  assert.match(uir09Source, /\.session-action-button\.is-loading:disabled \{[\s\S]*opacity: 1/);
  assert.match(uir09Source, /prefers-reduced-motion: reduce/);
});

test("UIR-09 completes visibly before returning the button to its normal action", () => {
  assert.match(appSource, /await new Promise<void>\(\(resolve\) => window\.setTimeout\(resolve, 180\)\)/);
  assert.ok(appSource.indexOf("progress: 100") < appSource.indexOf('setActivation({ status: "complete", result })'));
  assert.match(appSource, /working \? `Loading \$\{props\.activation\.filename\}…`/);
  assert.doesNotMatch(appSource, />\{props\.activation\.progress\}%</);
});
