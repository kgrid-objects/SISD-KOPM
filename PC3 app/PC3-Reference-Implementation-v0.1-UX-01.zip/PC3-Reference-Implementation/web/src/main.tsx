import React from "react";
import { createRoot } from "react-dom/client";
import { App } from "./app/App.js";
import "./styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("PC3 root element was not found.");
createRoot(root).render(<React.StrictMode><App /></React.StrictMode>);
