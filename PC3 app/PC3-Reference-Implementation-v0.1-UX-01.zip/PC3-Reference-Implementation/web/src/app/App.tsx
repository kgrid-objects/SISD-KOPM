import React from "react";
import {
  PC3_IMPLEMENTATION,
  type ApplicationInfoResponse,
  type HealthResponse,
  type ActiveOperationalContextResponse,
  type PublicationActivationResponse,
  type ExecutableRealizationMatrixResponse,
  type ExerciseAttemptResponse,
  type RuntimeObservationResponse,
  type ExecutionInteractionResponse,
  type ExecutionEvidenceResponse,
  type ExecutionAdapterDescriptorResponse,
  type ExecutionEnvironmentDescriptionResponse,
  type ExpectedOutcomeComparisonResponse
} from "@pc3/shared";
import { pc3Api } from "../api/pc3-api.js";

type ConnectionState =
  | { readonly status: "checking" }
  | { readonly status: "connected"; readonly health: HealthResponse; readonly info: ApplicationInfoResponse }
  | { readonly status: "unavailable"; readonly message: string };

type ActivationState =
  | { readonly status: "idle" }
  | { readonly status: "working"; readonly filename: string; readonly progress: number }
  | { readonly status: "complete"; readonly result: PublicationActivationResponse }
  | { readonly status: "failed"; readonly message: string };

type PublicationInputObject = PublicationActivationResponse["interpretation"]["inputObjects"][number];
type PublicationInterpretation = PublicationActivationResponse["interpretation"];
type PublicationRealization = PublicationInterpretation["realizations"][number];
type PublicationTestCase = PublicationInterpretation["publicationTestCases"][number];
type RealizationTestCaseManifestation = PublicationInterpretation["realizationTestCaseManifestations"][number];
type ExerciseReadiness = PublicationInterpretation["exerciseReadiness"][number];
type ResolvedExercise = PublicationInterpretation["resolvedExercises"][number];
type RtcmInvocationSupport = PublicationActivationResponse["invocationSupport"][number];
type ExerciseOpportunityCoverage = PublicationActivationResponse["exerciseOpportunityCoverage"];
type MatrixPathway = ExecutableRealizationMatrixResponse["pathways"][number];
type RealizationPathwayView = MatrixPathway & { readonly kind: "realization-pathway" };
type RealizationLayer = RealizationPathwayView["endpointType"];

type ChannelStatus = "ready" | "selected" | "prepared" | "completed" | "failed" | "evidence";
type SessionCollection = "inputs" | "test-cases" | "realizations" | "observations";
type PublicationReadinessStatus = "complete" | "partial" | "none" | "not-applicable";

type CanonicalExerciseEligibility = {
  readonly enabled: boolean;
  readonly reason: string;
};

function canonicalExerciseEligibility(
  pathway: RealizationPathwayView,
  selectedPtc: PublicationTestCase | undefined,
  resolvedExercise: ResolvedExercise | undefined,
  invocationSupport: RtcmInvocationSupport | undefined,
  adapterAvailable: boolean,
  activeContextAvailable: boolean
): CanonicalExerciseEligibility {
  if (!selectedPtc) return { enabled: false, reason: "Select a Test Case first." };
  if (!activeContextAvailable) return { enabled: false, reason: "No active publication context." };
  if (!pathway.selectable) return { enabled: false, reason: "This realization pathway is not selectable." };
  if (!resolvedExercise) return { enabled: false, reason: "No resolved exercise for the selected Test Case." };
  if (!["cli", "library", "http"].includes(resolvedExercise.rtcm.invocation.mode.toLowerCase())) {
    return { enabled: false, reason: "Invocation mode not yet supported by PC3." };
  }
  if (!invocationSupport) return { enabled: false, reason: "Invocation support has not been established for this resolved exercise." };
  if (!invocationSupport.executable) return { enabled: false, reason: invocationSupport.reason };
  if (!adapterAvailable) return { enabled: false, reason: "No compatible execution adapter is available." };
  return { enabled: true, reason: "Canonical exercise ready." };
}

type PtcReadinessProjection = {
  readonly status: PublicationReadinessStatus;
  readonly applicableRealizationCount: number;
  readonly authoritativeRtcmCount: number;
  readonly missingRealizationIdentifiers: readonly string[];
};

function projectPtcReadiness(ptcIdentifier: string, interpretation: PublicationInterpretation | undefined): PtcReadinessProjection {
  const applicable = interpretation?.exerciseDiscoveryIndex.ptcToRealizationIdentifiers[ptcIdentifier] ?? [];
  if (applicable.length === 0) return { status: "not-applicable", applicableRealizationCount: 0, authoritativeRtcmCount: 0, missingRealizationIdentifiers: [] };
  const resolved = applicable.filter((realizationIdentifier) => Boolean(interpretation?.exerciseDiscoveryIndex.pairingToRtcmIdentifier[`${ptcIdentifier}|${realizationIdentifier}`]));
  const missing = applicable.filter((realizationIdentifier) => !resolved.includes(realizationIdentifier));
  return {
    status: resolved.length === applicable.length ? "complete" : resolved.length === 0 ? "none" : "partial",
    applicableRealizationCount: applicable.length,
    authoritativeRtcmCount: resolved.length,
    missingRealizationIdentifiers: missing
  };
}

function readinessLabel(status: PublicationReadinessStatus): string {
  return status === "not-applicable" ? "Not applicable" : status[0]!.toUpperCase() + status.slice(1);
}

export function App(): React.JSX.Element {
  const [connection, setConnection] = React.useState<ConnectionState>({ status: "checking" });
  const [activation, setActivation] = React.useState<ActivationState>({ status: "idle" });
  const [activePublication, setActivePublication] = React.useState<PublicationActivationResponse>();
  const [sessionId, setSessionId] = React.useState<string>();
  const [activeContext, setActiveContext] = React.useState<ActiveOperationalContextResponse>();
  const [matrix, setMatrix] = React.useState<ExecutableRealizationMatrixResponse>();
  const [matrixError, setMatrixError] = React.useState<string>();
  const [attempts, setAttempts] = React.useState<readonly ExerciseAttemptResponse[]>([]);
  const [attemptError, setAttemptError] = React.useState<string>();
  const [interactions, setInteractions] = React.useState<readonly ExecutionInteractionResponse[]>([]);
  const [observations, setObservations] = React.useState<readonly RuntimeObservationResponse[]>([]);
  const [comparisons, setComparisons] = React.useState<readonly ExpectedOutcomeComparisonResponse[]>([]);
  const [observationError, setObservationError] = React.useState<string>();
  const [executionEvidence, setExecutionEvidence] = React.useState<readonly ExecutionEvidenceResponse[]>([]);
  const [evidenceError, setEvidenceError] = React.useState<string>();
  const [adapters, setAdapters] = React.useState<readonly ExecutionAdapterDescriptorResponse[]>([]);
  const [executionError, setExecutionError] = React.useState<string>();
  const [environments, setEnvironments] = React.useState<readonly ExecutionEnvironmentDescriptionResponse[]>([]);

  React.useEffect(() => {
    if (activation.status !== "working") return;
    const timer = window.setInterval(() => {
      setActivation((current) => {
        if (current.status !== "working" || current.progress >= 90) return current;
        const increment = current.progress < 30 ? 6 : current.progress < 65 ? 3 : 1;
        return { ...current, progress: Math.min(90, current.progress + increment) };
      });
    }, 220);
    return () => window.clearInterval(timer);
  }, [activation.status]);

  React.useEffect(() => {
    const controller = new AbortController();
    Promise.all([
      pc3Api.getHealth(controller.signal),
      pc3Api.getApplicationInfo(controller.signal),
      pc3Api.createSession(),
      pc3Api.getExecutionAdapters(controller.signal)
    ]).then(([health, info, session, adapterList]) => {
      setConnection({ status: "connected", health, info });
      setSessionId(session.id);
      setActiveContext({ sessionId: session.id });
      setAdapters(adapterList.adapters);
    }).catch((error: unknown) => {
      if (controller.signal.aborted) return;
      setConnection({ status: "unavailable", message: error instanceof Error ? error.message : "The PC3 server is unavailable." });
    });
    return () => controller.abort();
  }, []);

  async function activatePublication(file: File): Promise<void> {
    if (!sessionId) return;
    setActivation({ status: "working", filename: file.name, progress: 4 });
    try {
      const result = await pc3Api.activatePublication(sessionId, file, activeContext?.contextId);
      setActivation((current) => current.status === "working" ? { ...current, progress: Math.max(current.progress, 72) } : current);
      setActiveContext(result.activeContext);
      const projected = await pc3Api.getRealizationMatrix(sessionId);
      setActivation((current) => current.status === "working" ? { ...current, progress: 100 } : current);
      setMatrix(projected);
      setMatrixError(undefined);
      setAttempts([]);
      setAttemptError(undefined);
      setInteractions([]);
      setObservations([]);
      setComparisons([]);
      setObservationError(undefined);
      setExecutionEvidence([]);
      setEvidenceError(undefined);
      setEnvironments([]);
      setActivePublication(result);
      await new Promise<void>((resolve) => window.setTimeout(resolve, 180));
      setActivation({ status: "complete", result });
    } catch (error) {
      setActivation({ status: "failed", message: error instanceof Error ? error.message : "Publication activation failed." });
    }
  }

  React.useEffect(() => {
    if (!sessionId || !activeContext?.contextId || attempts.length === 0) return;
    let cancelled = false;
    const refresh = async (): Promise<void> => {
      try {
        const [interactionList, observationList, comparisonList, evidenceList, environmentList] = await Promise.all([
          pc3Api.getExecutionInteractions(sessionId),
          pc3Api.getRuntimeObservations(sessionId),
          pc3Api.getObservationComparisons(sessionId),
          pc3Api.getExecutionEvidence(sessionId),
          pc3Api.getExecutionEnvironments(sessionId)
        ]);
        if (!cancelled) {
          setInteractions(interactionList.interactions);
          setObservations(observationList.observations);
          setComparisons(comparisonList.comparisons);
          setExecutionEvidence(evidenceList.evidence);
          setEnvironments(environmentList.environments);
          setObservationError(undefined);
          setEvidenceError(undefined);
        }
      } catch (error) {
        if (!cancelled) setObservationError(error instanceof Error ? error.message : "Runtime Observation refresh failed.");
      }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 2000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [sessionId, activeContext?.contextId, attempts.length]);

  async function selectPathway(pathwayId: string): Promise<void> {
    if (!sessionId || !activeContext?.contextId) return;
    try {
      await pc3Api.selectPathway(sessionId, pathwayId, activeContext.contextId);
      const refreshed = await pc3Api.getRealizationMatrix(sessionId);
      setMatrix(refreshed);
      setActiveContext((current) => current ? { ...current, selectedPathwayId: pathwayId } : current);
      setMatrixError(undefined);
    } catch (error) {
      setMatrixError(error instanceof Error ? error.message : "Pathway selection failed.");
      throw error;
    }
  }

  async function exerciseCanonicalPathway(pathwayId: string, ptcIdentifier: string): Promise<void> {
    if (!sessionId || !activeContext?.contextId) throw new Error("No active publication context is available.");
    const contextId = activeContext.contextId;
    setAttemptError(undefined);
    setExecutionError(undefined);
    try {
      await pc3Api.selectPathway(sessionId, pathwayId, contextId);
      const selectedMatrix = await pc3Api.getRealizationMatrix(sessionId);
      setMatrix(selectedMatrix);
      setActiveContext((current) => current ? { ...current, selectedPathwayId: pathwayId } : current);
      setMatrixError(undefined);

      const prepared = await pc3Api.prepareExerciseAttempt(sessionId, contextId, {
        ptcIdentifier,
        exerciseDisposition: "canonical"
      });
      const preparedList = await pc3Api.getExerciseAttempts(sessionId);
      setAttempts(preparedList.attempts);
      setAttemptError(undefined);

      await pc3Api.executeReferenceExerciseAttempt(sessionId, prepared.id, contextId);
      const [interactionList, observationList, comparisonList, environmentList] = await Promise.all([
        pc3Api.getExecutionInteractions(sessionId),
        pc3Api.getRuntimeObservations(sessionId),
        pc3Api.getObservationComparisons(sessionId),
        pc3Api.getExecutionEnvironments(sessionId)
      ]);
      setInteractions(interactionList.interactions);
      setObservations(observationList.observations);
      setComparisons(comparisonList.comparisons);
      setEnvironments(environmentList.environments);
      setExecutionError(undefined);
    } catch (error) {
      const listed = await pc3Api.getExerciseAttempts(sessionId).catch(() => undefined);
      if (listed) setAttempts(listed.attempts);
      const message = error instanceof Error ? error.message : "One-click canonical exercise failed.";
      setExecutionError(message);
      throw error;
    }
  }

  const publicationTitle = activePublication
    ? activePublication.interpretation.publicationIdentity?.title ?? activeContext?.publicationIdentifier ?? activeContext?.sourceName ?? "Loaded publication"
    : activeContext?.publicationIdentifier ?? activeContext?.sourceName ?? "No publication loaded";
  const publicationVersion = activePublication?.interpretation.publicationIdentity?.declaredVersion;
  const loadUnavailable = !sessionId || connection.status !== "connected";

  return (
    <main className="app-shell">
      <header className="app-bar">
        <div className="brand-lockup">
          <span className="product-mark" aria-hidden="true">PC3</span>
          <div><p className="eyebrow">Architectural Reference Implementation</p><h1>Console View</h1></div>
        </div>
        <ConnectionIndicator connection={connection} />
      </header>

      {!matrix ? (
        <EmptyPubBoardShell
          loadAction={<LoadPublicationButton activation={activation} disabled={loadUnavailable} replacingPublication={false} onFile={activatePublication} />}
          connection={connection}
        />
      ) : (
        <>
          {(matrixError || attemptError || executionError || observationError || evidenceError) ? <div className="error-stack" role="alert">{[matrixError, attemptError, executionError, observationError, evidenceError].filter(Boolean).map((message) => <p key={message} className="callout error-callout">{message}</p>)}</div> : null}

          <PubBoard
            matrix={matrix}
            inputObjects={activePublication?.interpretation.inputObjects ?? []}
            interpretation={activePublication?.interpretation}
            invocationSupport={activePublication?.invocationSupport ?? []}
            exerciseOpportunityCoverage={activePublication?.exerciseOpportunityCoverage}
            publicationTitle={publicationTitle}
            publicationVersion={publicationVersion}
            publicationMenu={<LoadPublicationButton activation={activation} disabled={loadUnavailable} replacingPublication onFile={activatePublication} />}
            attempts={attempts}
            interactions={interactions}
            observations={observations}
            comparisons={comparisons}
            evidence={executionEvidence}
            environments={environments}
            adapters={adapters}
            onSelect={selectPathway}
            activeContextAvailable={Boolean(sessionId && activeContext?.contextId)}
            onCanonicalExercise={exerciseCanonicalPathway}
            onAttestCollection={async () => {
              if (!sessionId || !activeContext?.contextId) return;
              try { await pc3Api.attestCurrentObservationCollection(sessionId, activeContext.contextId); const listed = await pc3Api.getExecutionEvidence(sessionId); setExecutionEvidence(listed.evidence); setEvidenceError(undefined); }
              catch (error) { setEvidenceError(error instanceof Error ? error.message : "Observation collection attestation failed."); throw error; }
            }}
          />

          <details className="inspection-drawer legacy-inspection-drawer">
            <summary>Legacy engineering inspection</summary>
            <p className="muted">This temporary compatibility drawer will move into the contextual Detail Panel in a later UI pass.</p>
            <PathwayIntegrityInspection matrix={matrix} />
            {activePublication ? <InterpretationResult result={activePublication} /> : null}
            <ImplementationIdentity connection={connection} />
          </details>
        </>
      )}
    </main>
  );
}

function EmptyPubBoardShell({ loadAction, connection }: { readonly loadAction: React.ReactNode; readonly connection: ConnectionState }): React.JSX.Element {
  return <section className="pub-board four-component-shell empty-four-component-shell" aria-label="Console View">
    <section className="shell-dashboard" aria-labelledby="empty-dashboard-heading">
      <div>
        <h2 id="empty-dashboard-heading">No publication loaded</h2>
        <p>Choose a publication ZIP to begin.</p>
      </div>
      <div className="shell-session-actions" aria-label="Session actions">{loadAction}</div>
    </section>
    <aside className="shell-collection-panel shell-empty-surface" aria-label="Session Collection Panel" />
    <section className="shell-instrument-display shell-empty-surface" aria-label="Instrument Display" />
    <details className="shell-detail-panel">
      <summary><span>Detail Panel</span></summary>
      <div className="detail-panel-body"><p>No object details are available before a publication is loaded.</p><ImplementationIdentity connection={connection} /></div>
    </details>
  </section>;
}

function LoadPublicationButton(props: {
  readonly replacingPublication: boolean;
  readonly activation: ActivationState;
  readonly disabled: boolean;
  readonly onFile: (file: File) => Promise<void>;
}): React.JSX.Element {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const working = props.activation.status === "working";
  const label = working ? `Loading ${props.activation.filename}…` : props.replacingPublication ? "Load another…" : "Choose publication…";
  return <div className="direct-load-control">
    <button className={`session-action-button load-action ${working ? "is-loading" : ""}`} style={working ? { "--load-progress": `${props.activation.progress}%` } as React.CSSProperties : undefined} type="button" disabled={props.disabled || working} aria-busy={working} onClick={() => fileInputRef.current?.click()}><span className="load-action-progress" aria-hidden="true" /><span className="load-action-label">{label}</span></button>
    <input ref={fileInputRef} className="sr-only" accept=".zip,application/zip" type="file" disabled={props.disabled || working} aria-label={props.replacingPublication ? "Choose another publication ZIP" : "Choose publication ZIP"} onChange={(event) => { const file = event.currentTarget.files?.[0]; event.currentTarget.value = ""; if (file) void props.onFile(file); }} />
    {props.activation.status === "failed" ? <span className="direct-load-error" role="alert">{props.activation.message}</span> : null}
  </div>;
}

function PubBoard(props: {
  readonly matrix: ExecutableRealizationMatrixResponse;
  readonly inputObjects: readonly PublicationInputObject[];
  readonly interpretation: PublicationInterpretation | undefined;
  readonly invocationSupport: readonly RtcmInvocationSupport[];
  readonly exerciseOpportunityCoverage: ExerciseOpportunityCoverage | undefined;
  readonly publicationTitle: string;
  readonly publicationVersion: string | undefined;
  readonly publicationMenu: React.ReactNode;
  readonly attempts: readonly ExerciseAttemptResponse[];
  readonly interactions: readonly ExecutionInteractionResponse[];
  readonly observations: readonly RuntimeObservationResponse[];
  readonly comparisons: readonly ExpectedOutcomeComparisonResponse[];
  readonly evidence: readonly ExecutionEvidenceResponse[];
  readonly environments: readonly ExecutionEnvironmentDescriptionResponse[];
  readonly adapters: readonly ExecutionAdapterDescriptorResponse[];
  readonly onSelect: (pathwayId: string) => Promise<void>;
  readonly activeContextAvailable: boolean;
  readonly onCanonicalExercise: (pathwayId: string, ptcIdentifier: string) => Promise<void>;
  readonly onAttestCollection: () => Promise<void>;
}): React.JSX.Element {
  const pathways = React.useMemo(() => props.matrix.pathways.filter((item): item is RealizationPathwayView => item.kind === "realization-pathway"), [props.matrix.pathways]);
  const realizationByIdentifier = React.useMemo(() => new Map((props.interpretation?.realizations ?? []).map((item) => [item.identifier, item])), [props.interpretation?.realizations]);
  const readinessByRealization = React.useMemo(() => new Map((props.interpretation?.exerciseReadiness ?? []).map((item) => [item.realizationIdentifier, item])), [props.interpretation?.exerciseReadiness]);
  const rtcmByIdentifier = React.useMemo(() => new Map((props.interpretation?.realizationTestCaseManifestations ?? []).map((item) => [item.identifier, item])), [props.interpretation?.realizationTestCaseManifestations]);
  const resolvedExerciseByPair = React.useMemo(() => new Map((props.interpretation?.resolvedExercises ?? []).map((item) => [`${item.ptc.identifier}|${item.realization.identifier}`, item])), [props.interpretation?.resolvedExercises]);
  const invocationSupportByExercise = React.useMemo(() => new Map(props.invocationSupport.map((item) => [`${item.ptcIdentifier}|${item.realizationIdentifier}|${item.rtcmIdentifier}`, item])), [props.invocationSupport]);
  const capabilityProfile = props.interpretation?.capabilityProfile;
  const publicationTestCases = props.interpretation?.publicationTestCases ?? [];
  const ptcProfileActive = capabilityProfile?.kind === "ptc" && publicationTestCases.length > 0;
  const inputCollectionAvailable = capabilityProfile?.kind === "legacy-input" || capabilityProfile?.kind === "ambiguous-mixed";
  const exerciseIndex = props.interpretation?.exerciseDiscoveryIndex;
  const firstAvailableLayer = REALIZATION_LAYERS.find((layer) => pathways.some((item) => item.endpointType === layer.id))?.id ?? "implementation-representation";
  const selectedMatrixPathway = pathways.find((item) => item.id === props.matrix.selectedPathwayId);
  const [activeLayer, setActiveLayer] = React.useState<RealizationLayer>(selectedMatrixPathway?.endpointType ?? firstAvailableLayer);
  const layerSelections = React.useRef<Partial<Record<RealizationLayer, string>>>({});
  const [workspaceRevision, setWorkspaceRevision] = React.useState(0);
  const [workspaceBaseline, setWorkspaceBaseline] = React.useState({
    attempts: new Set<string>(),
    interactions: new Set<string>(),
    observations: new Set<string>(),
    evidence: new Set<string>(),
    environments: new Set<string>()
  });
  const [switchingPathwayId, setSwitchingPathwayId] = React.useState<string>();
  const [exercisingPathwayId, setExercisingPathwayId] = React.useState<string>();
  const [interactionAnnouncement, setInteractionAnnouncement] = React.useState("Console ready.");
  const [activeCollection, setActiveCollection] = React.useState<SessionCollection>(ptcProfileActive ? "test-cases" : inputCollectionAvailable ? "inputs" : "realizations");
  const [selectedInputId, setSelectedInputId] = React.useState<string>();
  const [selectedPtcId, setSelectedPtcId] = React.useState<string>();
  const [selectedObservationId, setSelectedObservationId] = React.useState<string>();
  const [showExercisable, setShowExercisable] = React.useState(false);
  const [attestingCollection, setAttestingCollection] = React.useState(false);
  const channelListRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    setSelectedInputId((current) => props.inputObjects.some((item) => item.identifier === current) ? current : props.inputObjects[0]?.identifier);
  }, [props.inputObjects]);

  const selectedInput = props.inputObjects.find((item) => item.identifier === selectedInputId);

  React.useEffect(() => {
    setActiveCollection(ptcProfileActive ? "test-cases" : inputCollectionAvailable ? "inputs" : "realizations");
    setShowExercisable(false);
    setSelectedObservationId(undefined);
    setInteractionAnnouncement(ptcProfileActive ? `${publicationTestCases.length} Publication Test Cases loaded.` : inputCollectionAvailable ? `${props.inputObjects.length} publication inputs loaded.` : "Publication loaded with no declared exercise capability.");
  }, [props.interpretation?.id]);

  React.useEffect(() => {
    if (selectedObservationId && !props.observations.some((item) => item.id === selectedObservationId)) {
      setSelectedObservationId(undefined);
      setInteractionAnnouncement("The selected Observation is no longer available. No replacement was selected.");
    }
  }, [selectedObservationId, props.observations]);

  React.useEffect(() => {
    setSelectedPtcId((current) => publicationTestCases.some((item) => item.identifier === current) ? current : publicationTestCases[0]?.identifier);
  }, [publicationTestCases]);

  React.useEffect(() => {
    if (selectedMatrixPathway) {
      layerSelections.current[selectedMatrixPathway.endpointType] = selectedMatrixPathway.id;
      setActiveLayer(selectedMatrixPathway.endpointType);
    } else if (!pathways.some((item) => item.endpointType === activeLayer)) {
      setActiveLayer(firstAvailableLayer);
    }
  }, [selectedMatrixPathway?.id, selectedMatrixPathway?.endpointType, firstAvailableLayer, pathways, activeLayer]);

  const selectedRealizationIdentifier = selectedMatrixPathway?.endpointIdentifier;
  const selectedCollectionObservation = props.observations.find((item) => item.id === selectedObservationId);
  const selectedCollectionComparison = selectedCollectionObservation ? props.comparisons.find((item) => item.observationId === selectedCollectionObservation.id) : undefined;
  const selectedCollectionInteraction = selectedCollectionObservation ? props.interactions.find((item) => item.id === selectedCollectionObservation.executionInteractionId) : undefined;
  const selectedCollectionEnvironment = selectedCollectionObservation?.executionEnvironmentDescriptionId ? props.environments.find((item) => item.id === selectedCollectionObservation.executionEnvironmentDescriptionId) : undefined;
  const selectedCollectionEvidence = selectedCollectionObservation ? props.evidence.find((item) => item.runtimeObservation.id === selectedCollectionObservation.id) : undefined;
  const selectedPtc = publicationTestCases.find((item) => item.identifier === selectedPtcId);
  const exercisableFilterAvailable = ptcProfileActive && Boolean(selectedPtc);
  const exercisableFilterActive = showExercisable && exercisableFilterAvailable;
  const exerciseEligibilityForPathway = (pathway: RealizationPathwayView): CanonicalExerciseEligibility => {
    const resolvedExercise = selectedPtcId ? resolvedExerciseByPair.get(`${selectedPtcId}|${pathway.endpointIdentifier}`) : undefined;
    const invocationSupport = resolvedExercise ? invocationSupportByExercise.get(`${resolvedExercise.ptc.identifier}|${resolvedExercise.realization.identifier}|${resolvedExercise.rtcm.identifier}`) : undefined;
    return canonicalExerciseEligibility(pathway, selectedPtc, resolvedExercise, invocationSupport, props.adapters.length > 0, props.activeContextAvailable);
  };
  const isVisibleForExerciseFilter = (pathway: RealizationPathwayView): boolean => !exercisableFilterActive || exerciseEligibilityForPathway(pathway).enabled;
  const visiblePathways = pathways.filter((item) => item.endpointType === activeLayer && isVisibleForExerciseFilter(item));
  const selectedPathway = visiblePathways.find((item) => item.id === props.matrix.selectedPathwayId);
  const selectedRtcmIdentifier = selectedPtcId && selectedRealizationIdentifier ? exerciseIndex?.pairingToRtcmIdentifier[`${selectedPtcId}|${selectedRealizationIdentifier}`] : undefined;
  const selectedRtcm = selectedRtcmIdentifier ? rtcmByIdentifier.get(selectedRtcmIdentifier) : undefined;
  const selectedResolvedExercise = selectedPtcId && selectedRealizationIdentifier ? resolvedExerciseByPair.get(`${selectedPtcId}|${selectedRealizationIdentifier}`) : undefined;
  const selectedPtcReadiness = selectedPtc ? projectPtcReadiness(selectedPtc.identifier, props.interpretation) : undefined;
  const selectedRealizationReadiness = selectedRealizationIdentifier ? readinessByRealization.get(selectedRealizationIdentifier) : undefined;
  const selectedAttempts = selectedPathway ? props.attempts.filter((item) => item.pathwayId === selectedPathway.id) : [];
  const selectedInteractions = selectedPathway ? props.interactions.filter((item) => item.pathwayId === selectedPathway.id) : [];
  const selectedObservations = selectedPathway ? props.observations.filter((item) => item.pathwayId === selectedPathway.id) : [];
  const selectedObservationIds = new Set(selectedObservations.map((item) => item.id));
  const selectedComparisons = props.comparisons.filter((item) => selectedObservationIds.has(item.observationId));
  const selectedEvidence = selectedPathway ? props.evidence.filter((item) => item.provenance.realizationPathway.id === selectedPathway.id) : [];
  const selectedEnvironments = selectedPathway ? props.environments.filter((item) => item.pathwayId === selectedPathway.id) : [];
  const currentAttempts = selectedAttempts.filter((item) => !workspaceBaseline.attempts.has(item.id));
  const currentInteractions = selectedInteractions.filter((item) => !workspaceBaseline.interactions.has(item.id));
  const currentObservations = selectedObservations.filter((item) => !workspaceBaseline.observations.has(item.id));
  const currentEvidence = selectedEvidence.filter((item) => !workspaceBaseline.evidence.has(item.id));
  const currentEnvironments = selectedEnvironments.filter((item) => !workspaceBaseline.environments.has(item.id));
  const activeLayerDescriptor = realizationLayerDescriptor(activeLayer);

  React.useEffect(() => {
    if (!exercisableFilterAvailable) setShowExercisable(false);
  }, [exercisableFilterAvailable]);

  function beginWorkspaceSwitch(): { readonly baseline: typeof workspaceBaseline; readonly revision: number } {
    const previous = { baseline: workspaceBaseline, revision: workspaceRevision };
    setWorkspaceBaseline({
      attempts: new Set(props.attempts.map((item) => item.id)),
      interactions: new Set(props.interactions.map((item) => item.id)),
      observations: new Set(props.observations.map((item) => item.id)),
      evidence: new Set(props.evidence.map((item) => item.id)),
      environments: new Set(props.environments.map((item) => item.id))
    });
    setWorkspaceRevision((value) => value + 1);
    return previous;
  }

  function focusChannel(pathwayId: string): void {
    window.requestAnimationFrame(() => {
      channelListRef.current?.querySelector<HTMLButtonElement>(`[data-pathway-id="${CSS.escape(pathwayId)}"]`)?.focus();
    });
  }

  async function switchPathway(pathwayId: string): Promise<void> {
    if (switchingPathwayId || pathwayId === props.matrix.selectedPathwayId) return;
    const target = pathways.find((item) => item.id === pathwayId);
    const previous = beginWorkspaceSwitch();
    setSwitchingPathwayId(pathwayId);
    setInteractionAnnouncement(`Switching to ${target?.endpointIdentifier ?? "selected realization"}.`);
    try {
      await props.onSelect(pathwayId);
      setInteractionAnnouncement(`${target?.endpointIdentifier ?? "Realization"} selected. Workspace reset and ready.`);
      focusChannel(pathwayId);
    } catch (error) {
      setWorkspaceBaseline(previous.baseline);
      setWorkspaceRevision(previous.revision);
      setInteractionAnnouncement("Realization switch failed. Previous workspace restored.");
      throw error;
    } finally {
      setSwitchingPathwayId(undefined);
    }
  }

  async function chooseLayer(layer: RealizationLayer): Promise<void> {
    if (switchingPathwayId || exercisingPathwayId) return;
    const candidates = pathways.filter((item) => item.endpointType === layer && isVisibleForExerciseFilter(item));
    const rememberedId = layerSelections.current[layer];
    const target = candidates.find((item) => item.id === rememberedId) ?? candidates.find((item) => item.selectable) ?? candidates[0];
    if (!target) return;
    const previousLayer = activeLayer;
    setActiveLayer(layer);
    try {
      if (target.id !== props.matrix.selectedPathwayId) await switchPathway(target.id);
      else focusChannel(target.id);
    } catch (error) {
      setActiveLayer(previousLayer);
      throw error;
    }
  }

  async function exerciseCanonical(pathway: RealizationPathwayView): Promise<void> {
    if (!selectedPtc || switchingPathwayId || exercisingPathwayId) return;
    beginWorkspaceSwitch();
    setExercisingPathwayId(pathway.id);
    setInteractionAnnouncement(`Exercising ${pathway.endpointIdentifier} with ${selectedPtc.identifier}.`);
    try {
      await props.onCanonicalExercise(pathway.id, selectedPtc.identifier);
      layerSelections.current[pathway.endpointType] = pathway.id;
      setActiveLayer(pathway.endpointType);
      setInteractionAnnouncement(`Canonical exercise complete. A new Runtime Observation is available for ${pathway.endpointIdentifier}.`);
      focusChannel(pathway.id);
    } catch {
      setInteractionAnnouncement(`Canonical exercise failed for ${pathway.endpointIdentifier}. Any prepared attempt remains available for inspection.`);
    } finally {
      setExercisingPathwayId(undefined);
    }
  }

  function moveFocus(event: React.KeyboardEvent, selector: string, orientation: "horizontal" | "vertical"): void {
    const expected = orientation === "horizontal" ? ["ArrowLeft", "ArrowRight"] : ["ArrowUp", "ArrowDown"];
    if (![...expected, "Home", "End"].includes(event.key)) return;
    const container = event.currentTarget as HTMLElement;
    const items = Array.from(container.querySelectorAll<HTMLButtonElement>(selector)).filter((item) => !item.disabled);
    const currentIndex = items.indexOf(document.activeElement as HTMLButtonElement);
    if (!items.length || currentIndex < 0) return;
    event.preventDefault();
    const backward = event.key === expected[0];
    const nextIndex = event.key === "Home" ? 0 : event.key === "End" ? items.length - 1 : backward ? (currentIndex - 1 + items.length) % items.length : (currentIndex + 1) % items.length;
    items[nextIndex]?.focus();
  }

  return <section className="pub-board four-component-shell" aria-label="Console View">
    <OperationalDashboard
      matrix={props.matrix}
      publicationTitle={props.publicationTitle}
      publicationVersion={props.publicationVersion}
      activeLayer={activeLayer}
      selectedPathway={selectedPathway}
      selectedAttempts={selectedAttempts}
      selectedObservations={selectedObservations}
      selectedEvidence={selectedEvidence}
      selectedEnvironments={selectedEnvironments}
      adapterAvailable={props.adapters.length > 0}
      interpretation={props.interpretation}
      ptcProjectionAvailable={ptcProfileActive}
      exerciseOpportunityCoverage={props.exerciseOpportunityCoverage}
      publicationMenu={props.publicationMenu}
    />
    <aside className="channel-bank shell-collection-panel" aria-label="Session Collection Panel">
      <div className={`session-collection-selector ${ptcProfileActive || inputCollectionAvailable ? "has-exercise-collection" : "no-exercise-collection"}`} role="tablist" aria-label="Session collections" onKeyDown={(event) => moveFocus(event, "[role=tab]", "horizontal")}>
        {ptcProfileActive
          ? <CollectionTab id="test-cases" label="Test Cases" count={publicationTestCases.length} active={activeCollection === "test-cases"} onSelect={() => { setActiveCollection("test-cases"); setInteractionAnnouncement("Test Cases collection selected."); }} />
          : inputCollectionAvailable ? <CollectionTab id="inputs" label="Inputs" count={props.inputObjects.length} active={activeCollection === "inputs"} onSelect={() => { setActiveCollection("inputs"); setInteractionAnnouncement("Inputs collection selected."); }} /> : null}
        <CollectionTab id="realizations" label="Realizations" count={pathways.length} active={activeCollection === "realizations"} onSelect={() => { setActiveCollection("realizations"); setInteractionAnnouncement("Realizations collection selected."); }} />
        <CollectionTab id="observations" label="Observations" count={props.observations.length} active={activeCollection === "observations"} onSelect={() => { setActiveCollection("observations"); setInteractionAnnouncement("Observations collection selected."); }} />
      </div>

      {activeCollection === "inputs" ? <section id="collection-panel-inputs" role="tabpanel" aria-labelledby="collection-tab-inputs" className="session-collection-context">
        <div className="channel-bank-heading"><div><p className="module-index">Active collection</p><h3>Inputs</h3></div><span aria-label={`${props.inputObjects.length} publication input objects`}>{props.inputObjects.length}</span></div>
        {capabilityProfile?.kind === "ambiguous-mixed" ? <div className="profile-ambiguity-note" role="note"><strong>Exercise authority unresolved</strong><p>{capabilityProfile.rationale} PC3 preserves declared inputs without treating them as PTC canonical inputs.</p></div> : null}
        {props.inputObjects.length ? <div className="input-collection-list" role="listbox" aria-label="Publication input objects" onKeyDown={(event) => moveFocus(event, ".input-collection-item", "vertical")}>{props.inputObjects.map((input) => <button key={input.identifier} type="button" role="option" aria-selected={selectedInputId === input.identifier} className={`input-collection-item ${selectedInputId === input.identifier ? "is-selected" : ""}`} onClick={() => { setSelectedInputId(input.identifier); setInteractionAnnouncement(`${input.title ?? input.identifier} selected.`); }}><strong>{input.title ?? input.identifier}</strong><small>{input.mediaType} · {input.contentDisposition === "metadata-only" ? "metadata only" : "content available"}</small></button>)}</div> : <div className="collection-foundation-state"><strong>No publication inputs declared</strong><p>PC3 found no supported input-object declarations in the loaded publication. It does not invent inputs from filenames or executable behavior.</p></div>}
      </section> : null}

      {activeCollection === "test-cases" ? <section id="collection-panel-test-cases" role="tabpanel" aria-labelledby="collection-tab-test-cases" className="session-collection-context">
        <div className="channel-bank-heading"><div><p className="module-index">Test Level</p><h3>Test Cases</h3></div><span aria-label={`${publicationTestCases.length} publication test cases`}>{publicationTestCases.length}</span></div>
        <div className="test-case-list" role="listbox" aria-label="Publication Test Cases" onKeyDown={(event) => moveFocus(event, ".test-case-item", "vertical")}>{publicationTestCases.map((ptc) => { const readiness = projectPtcReadiness(ptc.identifier, props.interpretation); return <button key={ptc.identifier} type="button" role="option" aria-selected={selectedPtcId === ptc.identifier} className={`test-case-item ${selectedPtcId === ptc.identifier ? "is-selected" : ""}`} onClick={() => { setSelectedPtcId(ptc.identifier); setInteractionAnnouncement(`${ptc.title ?? ptc.identifier} selected. Publication readiness ${readinessLabel(readiness.status)}.`); }}><span className="collection-item-title"><strong>{ptc.title ?? ptc.identifier}</strong><span className={`publication-readiness-chip readiness-${readiness.status}`}>{readinessLabel(readiness.status)}</span></span><small>{ptc.identifier} · {ptc.classification ?? "unclassified"}</small><small>{readiness.authoritativeRtcmCount} of {readiness.applicableRealizationCount} applicable pairings have authoritative RTCMs</small></button>; })}</div>
      </section> : null}

      {activeCollection === "realizations" ? <section id="collection-panel-realizations" role="tabpanel" aria-labelledby="collection-tab-realizations" className="session-collection-context">
        <div className="channel-bank-heading">
          <div><p className="module-index">Realization level</p><h3>{activeLayerDescriptor.plural}</h3></div>
          <div className="realization-collection-actions">
            <button type="button" className={`collection-limit-action ${exercisableFilterActive ? "is-pressed" : ""}`} aria-pressed={exercisableFilterActive} disabled={!exercisableFilterAvailable} title={exercisableFilterAvailable ? `Limit to realizations with enabled Exercise actions for ${selectedPtc?.identifier}` : "Select a Publication Test Case to limit realizations"} onClick={() => { if (!exercisableFilterAvailable) return; setShowExercisable((current) => { const next = !current; setInteractionAnnouncement(next ? `Limited to realizations with enabled Exercise actions for ${selectedPtc?.identifier}.` : "Showing all realizations."); return next; }); }}>Limit</button>
            <span aria-label={`${visiblePathways.length} visible channels`}>{visiblePathways.length}</span>
          </div>
        </div>
        <div className="layer-selector" role="group" aria-label="Realization level" aria-busy={Boolean(switchingPathwayId)} onKeyDown={(event) => moveFocus(event, "button", "horizontal")}>
          {REALIZATION_LAYERS.map((layer) => {
            const count = pathways.filter((item) => item.endpointType === layer.id && isVisibleForExerciseFilter(item)).length;
            return <button key={layer.id} type="button" aria-pressed={activeLayer === layer.id} disabled={count === 0 || Boolean(switchingPathwayId || exercisingPathwayId)} aria-controls="realization-channel-list" onClick={() => void chooseLayer(layer.id)}><strong>{layer.short}</strong><span>{count}</span></button>;
          })}
        </div>
        <div className="channel-list" id="realization-channel-list" ref={channelListRef} role="listbox" aria-label={`${activeLayerDescriptor.plural} channels`} aria-busy={Boolean(switchingPathwayId || exercisingPathwayId)} onKeyDown={(event) => moveFocus(event, ".channel-selector", "vertical")}>
          {visiblePathways.map((pathway) => { const eligibility = exerciseEligibilityForPathway(pathway); return <RealizationChannelSelector
            key={pathway.id}
            pathway={pathway}
            declaration={realizationByIdentifier.get(pathway.endpointIdentifier)}
            publicationIdentifier={props.interpretation?.publicationIdentity?.declaredIdentifier}
            selected={props.matrix.selectedPathwayId === pathway.id}
            attempts={props.attempts.filter((item) => item.pathwayId === pathway.id)}
            observations={props.observations.filter((item) => item.pathwayId === pathway.id)}
            evidence={props.evidence.filter((item) => item.provenance.realizationPathway.id === pathway.id)}
            publicationReadiness={readinessByRealization.get(pathway.endpointIdentifier)}
            onSelect={() => switchPathway(pathway.id)}
            onExercise={() => exerciseCanonical(pathway)}
            exerciseEligibility={eligibility}
            busy={Boolean(switchingPathwayId || exercisingPathwayId)}
            switching={switchingPathwayId === pathway.id}
            exercising={exercisingPathwayId === pathway.id}
          />; })}
          {visiblePathways.length === 0 ? <p className="empty-layer">{exercisableFilterActive ? "No exercisable realizations for the selected Test Case at this level." : `No ${activeLayerDescriptor.plural.toLowerCase()} are represented in this publication.`}</p> : null}
        </div>
      </section> : null}

      {activeCollection === "observations" ? <section id="collection-panel-observations" role="tabpanel" aria-labelledby="collection-tab-observations" className="session-collection-context">
        <div className="channel-bank-heading"><div><p className="module-index">Observation Level</p><h3>Observations</h3></div><div className="observation-collection-actions"><button type="button" className="collection-attest-action" disabled={!props.observations.length || attestingCollection} aria-busy={attestingCollection} onClick={() => { setAttestingCollection(true); setInteractionAnnouncement(`Attesting all ${props.observations.length} current Observations.`); void props.onAttestCollection().then(() => setInteractionAnnouncement(`All ${props.observations.length} current Observations were attested and formally saved.`)).catch(() => setInteractionAnnouncement("Observation collection attestation failed.")).finally(() => setAttestingCollection(false)); }}>{attestingCollection ? "Attesting…" : "Attest"}</button><span aria-label={`${props.observations.length} observations`}>{props.observations.length}</span></div></div>
        {props.observations.length ? <div className="observation-collection-list" role="listbox" aria-label="Session observations" onKeyDown={(event) => moveFocus(event, ".observation-collection-item", "vertical")}>{[...props.observations].sort((a,b) => a.sessionSequence - b.sessionSequence).map((observation) => <button key={observation.id} type="button" role="option" aria-selected={selectedObservationId === observation.id} className={`observation-collection-item ${selectedObservationId === observation.id ? "is-selected" : ""}`} onClick={() => { setSelectedObservationId(observation.id); setInteractionAnnouncement(`Observation ${observation.sessionSequence} selected for inspection.`); }}><strong>Observation {observation.sessionSequence}</strong><small>{observation.endpointIdentifier} · execution {observation.outcome}</small></button>)}</div> : <div className="collection-foundation-state"><strong>No observations yet</strong><p>Execution observations will accrue here during the publication session.</p></div>}
      </section> : null}
    </aside>

    <p className="sr-only" role="status" aria-live="polite" aria-atomic="true">{interactionAnnouncement}</p>
    <section className="shell-instrument-display" aria-label="Instrument Display">
      {activeCollection === "realizations" ? <SharedOperationalWorkspace
        key={`workspace:${workspaceRevision}`}
        pathway={selectedPathway}
        layerLabel={activeLayerDescriptor.singular}
        attempts={currentAttempts}
        interactions={currentInteractions}
        observations={currentObservations}
        comparisons={selectedComparisons}
        evidence={currentEvidence}
        environments={currentEnvironments}
      /> : activeCollection === "inputs" ? <InputObjectDisplay input={selectedInput} /> : activeCollection === "test-cases" ? selectedResolvedExercise ? <ResolvedExerciseReview exercise={selectedResolvedExercise} /> : <PublicationTestCaseDisplay ptc={selectedPtc} realizationIdentifier={selectedRealizationIdentifier} rtcm={selectedRtcm} readiness={selectedPtcReadiness} /> : selectedCollectionObservation ? <ObservationDisplay observation={selectedCollectionObservation} comparison={selectedCollectionComparison} /> : <div className="instrument-display-placeholder collection-display-state observation-selection-prompt"><p className="module-index">Observations collection</p><h2>Select an Observation to inspect it</h2><p>Observation inspection is read-only and performs no execution, comparison, saving, discard, or attestation action.</p></div>}
    </section>
    <details className="shell-detail-panel">
      <summary><span>Detail Panel</span></summary>
      <div className="detail-panel-body">
        {props.interpretation ? <PublicationReadinessPanel interpretation={props.interpretation} /> : null}
        {activeCollection === "realizations" ? (selectedPathway ? <><PathwayDetails pathway={selectedPathway} />{selectedRealizationReadiness ? <ExerciseReadinessDetails readiness={selectedRealizationReadiness} /> : null}{ptcProfileActive ? <ResolvedPairingDetails ptc={selectedPtc} realizationIdentifier={selectedRealizationIdentifier} rtcm={selectedRtcm} /> : null}{currentAttempts.at(-1) ? <p><strong>Latest attempt:</strong> <code>{currentAttempts.at(-1)?.id}</code></p> : null}<EnvironmentDetails environment={currentEnvironments.at(-1)} /></> : <p className="empty-state">Select a realization to inspect its architectural and environment details.</p>) : activeCollection === "inputs" ? <InputObjectDetails input={selectedInput} /> : activeCollection === "test-cases" ? <ResolvedPairingDetails ptc={selectedPtc} realizationIdentifier={selectedRealizationIdentifier} rtcm={selectedRtcm} /> : selectedCollectionObservation ? <ObservationEngineeringDetails observation={selectedCollectionObservation} comparison={selectedCollectionComparison} interaction={selectedCollectionInteraction} environment={selectedCollectionEnvironment} evidence={selectedCollectionEvidence} /> : <p className="empty-state">Select an Observation to inspect its provenance.</p>}
        {props.interpretation && activeCollection !== "observations" ? <AdvancedPublicationInspection interpretation={props.interpretation} ptc={selectedPtc} realizationIdentifier={selectedRealizationIdentifier} rtcm={selectedRtcm} /> : null}
      </div>
    </details>
  </section>;
}

function InputObjectDisplay({ input }: { readonly input: PublicationInputObject | undefined }): React.JSX.Element {
  if (!input) return <div className="instrument-display-placeholder collection-display-state"><p className="module-index">Inputs collection</p><h2>No input object selected</h2><p>Select a publication-defined input object from the collection. Input editing is intentionally deferred to UI-05.</p></div>;
  return <article className="input-object-display" aria-label={`Selected input object: ${input.title ?? input.identifier}`}>
    <header className="input-object-header"><div><p className="module-index">Selected input object</p><h2>{input.title ?? input.identifier}</h2>{input.title ? <p className="input-object-identifier">{input.identifier}</p> : null}</div><span>{input.mediaType}</span></header>
    {input.description ? <p className="input-object-description">{input.description}</p> : null}
    {input.value !== undefined ? <pre className="input-object-content" tabIndex={0}>{input.value}</pre> : <div className="input-object-no-content"><strong>Content not embedded</strong><p>The publication declares this input object, but PC3 did not receive a readable inline or referenced content representation.</p></div>}
    <p className="input-object-readonly">Publication input · read-only in UI-04</p>
  </article>;
}

function InputObjectDetails({ input }: { readonly input: PublicationInputObject | undefined }): React.JSX.Element {
  if (!input) return <p className="empty-state">Select an input object to inspect its publication declaration and provenance.</p>;
  return <section className="inspection-section input-object-details"><h3>Input object</h3><dl>
    <dt>Identifier</dt><dd>{input.identifier}</dd>
    <dt>Media type</dt><dd>{input.mediaType}</dd>
    <dt>Content disposition</dt><dd>{input.contentDisposition}</dd>
    {input.artifactReference ? <><dt>Artifact reference</dt><dd><code>{input.artifactReference}</code></dd></> : null}
    {input.schemaReference ? <><dt>Schema reference</dt><dd><code>{input.schemaReference}</code></dd></> : null}
    <dt>Declared in</dt><dd><code>{input.provenance.resourcePath}{input.provenance.location}</code></dd>
    <dt>Interpretation basis</dt><dd>{input.provenance.basis}</dd>
    <dt>Resource SHA-256</dt><dd><code>{input.provenance.resourceSha256}</code></dd>
  </dl></section>;
}

function displayValue(value: unknown): string {
  if (typeof value === "string") return value;
  if (value === undefined) return "Not declared";
  return JSON.stringify(value, null, 2);
}

function PublicationReadinessPanel({ interpretation }: { readonly interpretation: PublicationInterpretation }): React.JSX.Element {
  const validation = interpretation.publicationValidation;
  const checkResult = validation.status === "valid" ? "Checks passed" : validation.status === "valid-with-warnings" ? "Warnings" : validation.status === "invalid" ? "Issues found" : "Not applicable";
  return <section className="publication-readiness-panel" aria-label="Publication declaration checks">
    <header><div><span>Publication declarations</span><strong>Checks</strong></div><span className={`validation-status validation-${validation.status}`}>{checkResult}</span></header>
    <details><summary>Declaration checks and limitations <span>{validation.issueCount + interpretation.limitations.length}</span></summary>
      <p className="readiness-boundary">Declaration completeness only. This does not report deployment, environment availability, runtime readiness, execution results, scientific validity, or conformance.</p>
      <dl className="validation-summary"><dt>Check result</dt><dd>{checkResult}</dd><dt>Scope</dt><dd>Publication declarations</dd><dt>PTCs checked</dt><dd>{validation.checkedPtcCount}</dd><dt>RTCMs checked</dt><dd>{validation.checkedRtcmCount}</dd><dt>Applicability pairings</dt><dd>{validation.checkedApplicabilityPairingCount}</dd></dl>
      <ul className="validation-checks">{validation.checks.map((check) => <li key={check.category}><span>{check.category}</span><strong>{check.status}</strong><small>{check.issueCount} issues</small></li>)}</ul>
      {validation.issues.length ? <section><h4>Declaration issues</h4><ul>{validation.issues.map((issue, index) => <li key={`${issue.code}:${index}`}><strong>{issue.severity}: {issue.code}</strong> — {issue.message}</li>)}</ul></section> : <p>No declaration-check issues were reported.</p>}
      {interpretation.limitations.length ? <section><h4>Interpretation limitations</h4><ul>{interpretation.limitations.map((item, index) => <li key={`${item.code}:${index}`}><strong>{item.code}</strong> — {item.message}</li>)}</ul></section> : <p>No interpretation limitations were reported.</p>}
    </details>
  </section>;
}

function CompletenessReadoutGroup({ marker, population, counts, available = true }: { readonly marker: "PTC" | "RZN"; readonly population: string; readonly counts: Record<PublicationReadinessStatus, number>; readonly available?: boolean }): React.JSX.Element {
  const statuses: readonly PublicationReadinessStatus[] = ["complete", "partial", "none", "not-applicable"];
  return <div className={`dashboard-readout-group completeness-group completeness-group-${marker.toLowerCase()}`} role="group" aria-label={`${population} completeness`}>{statuses.map((status) => {
    const statusLabel = readinessLabel(status);
    const unavailableExplanation = marker === "PTC" && !available ? " No Publication Test Cases are declared; PC3 reports zero without fabricating a classification." : "";
    return <div key={status} className={`dashboard-numeric-box completeness-readout readiness-${status}`} aria-label={`${population} — ${statusLabel}: ${counts[status]}.${unavailableExplanation}`} title={`${population} — ${statusLabel}: ${counts[status]}.${unavailableExplanation}`}><strong>{counts[status]}</strong><span className="numeric-box-footer"><b>{marker}</b><small>{status === "not-applicable" ? "N/A" : statusLabel}</small></span></div>;
  })}</div>;
}

function ExerciseReadinessDetails({ readiness }: { readonly readiness: ExerciseReadiness }): React.JSX.Element {
  return <section className="inspection-section exercise-readiness-details"><h3>Publication exercise readiness</h3><p className="readiness-boundary">Declaration completeness for this realization; not runtime readiness or an execution result.</p><dl><dt>Status</dt><dd><span className={`publication-readiness-chip readiness-${readiness.status}`}>{readinessLabel(readiness.status)}</span></dd><dt>Applicable PTCs</dt><dd>{readiness.applicablePtcCount}</dd><dt>Authoritative RTCMs</dt><dd>{readiness.authoritativeRtcmCount}</dd><dt>Statement</dt><dd>{readiness.statement}</dd>{readiness.missingRtcmPtcIdentifiers.length ? <><dt>Missing RTCMs for</dt><dd>{readiness.missingRtcmPtcIdentifiers.join(", ")}</dd></> : null}</dl></section>;
}

function PublicationTestCaseDisplay(props: {
  readonly ptc: PublicationTestCase | undefined;
  readonly realizationIdentifier: string | undefined;
  readonly rtcm: RealizationTestCaseManifestation | undefined;
  readonly readiness: PtcReadinessProjection | undefined;
}): React.JSX.Element {
  if (!props.ptc) return <div className="instrument-display-placeholder collection-display-state"><p className="module-index">Test Cases collection</p><h2>No Publication Test Case selected</h2><p>Select a publication-defined test case to inspect its canonical input and Expected Outcome.</p></div>;
  const ptc = props.ptc;
  return <article className="test-case-display" aria-label={`Selected Publication Test Case: ${ptc.title ?? ptc.identifier}`}>
    <header className="test-case-header"><div><p className="module-index">Selected Publication Test Case</p><h2>{ptc.title ?? ptc.identifier}</h2><p className="input-object-identifier">{ptc.identifier}</p></div><span>{ptc.classification ?? "unclassified"}</span></header>
    {ptc.purpose ? <p className="test-case-purpose">{ptc.purpose}</p> : null}
    {props.readiness ? <div className="selected-ptc-readiness"><span>Publication readiness</span><strong className={`publication-readiness-chip readiness-${props.readiness.status}`}>{readinessLabel(props.readiness.status)}</strong><small>{props.readiness.authoritativeRtcmCount} of {props.readiness.applicableRealizationCount} applicable realization pairings have authoritative RTCMs. This is declaration completeness, not runtime status.</small></div> : null}
    <div className="test-case-pairing" role="status"><strong>{props.realizationIdentifier ? `Paired with ${props.realizationIdentifier}` : "Select an applicable realization"}</strong><span>{props.rtcm ? `RTCM resolved: ${props.rtcm.identifier}` : props.realizationIdentifier ? "No unique authoritative RTCM resolved" : "Choose a realization from the list to resolve its RTCM"}</span></div>
    <div className="test-case-values">
      <section><p className="module-index">Canonical input</p><h3>{ptc.canonicalInput.objectType ?? "Publication-defined input"}</h3>{ptc.canonicalInput.mediaType ? <small>{ptc.canonicalInput.mediaType}</small> : null}<pre tabIndex={0}>{displayValue(ptc.canonicalInput.value)}</pre></section>
      <section><p className="module-index">Expected Outcome</p><h3>{ptc.canonicalExpectedOutcome.outcomeKind}</h3><pre tabIndex={0}>{displayValue(ptc.canonicalExpectedOutcome.value)}</pre></section>
    </div>
    <dl className="test-case-summary"><dt>Comparison</dt><dd>{ptc.comparisonSemantics.comparisonType}</dd><dt>Applicability</dt><dd>{ptc.applicability.applicableRealizationCount ?? "Unspecified"} applicable · {ptc.applicability.notApplicableRealizationCount ?? "Unspecified"} not applicable</dd></dl>
    <p className="input-object-readonly">PTC canonical input and Expected Outcome · publication-defined · read-only</p>
  </article>;
}

function ResolvedExerciseReview({ exercise }: { readonly exercise: ResolvedExercise }): React.JSX.Element {
  return <article className="resolved-exercise-review" aria-label={`Resolved Computational Exercise: ${exercise.ptc.identifier} and ${exercise.realization.identifier}`}>
    <header className="resolved-exercise-header"><div><p className="module-index">Resolved Computational Exercise</p><h2>{exercise.ptc.title ?? exercise.ptc.identifier}</h2><p><code>{exercise.ptc.identifier}</code> × <code>{exercise.realization.identifier}</code></p></div><span>Publication exercise ready</span></header>
    <div className="review-only-boundary" role="note"><strong>Review only</strong><p>This immutable view describes exactly what PC3 resolved from publication declarations. Reviewing it does not create an Exercise Attempt or execute the realization.</p></div>
    <section className="resolved-exercise-identity" aria-label="Resolved exercise identity"><div><span>Publication Test Case</span><strong>{exercise.ptc.identifier}</strong></div><div><span>Realization</span><strong>{exercise.realization.identifier}</strong><small>{exercise.realization.realizationType}</small></div><div><span>Authoritative RTCM</span><strong>{exercise.rtcm.identifier}</strong></div></section>
    <div className="resolved-exercise-values">
      <section><p className="module-index">Canonical input</p><h3>{exercise.canonicalInput.objectType ?? "Publication-defined input"}</h3>{exercise.canonicalInput.mediaType ? <small>{exercise.canonicalInput.mediaType}</small> : null}<pre tabIndex={0}>{displayValue(exercise.canonicalInput.value)}</pre></section>
      <section><p className="module-index">Canonical Expected Outcome</p><h3>{exercise.canonicalExpectedOutcome.outcomeKind}</h3><pre tabIndex={0}>{displayValue(exercise.canonicalExpectedOutcome.value)}</pre></section>
    </div>
    <section className="resolved-exercise-section"><h3>Comparison semantics</h3><dl><dt>Type</dt><dd>{exercise.comparisonSemantics.comparisonType}</dd><dt>Normative value path</dt><dd>{exercise.comparisonSemantics.normativeValuePath ?? "Not declared"}</dd>{exercise.comparisonSemantics.absoluteTolerance !== undefined ? <><dt>Absolute tolerance</dt><dd>{exercise.comparisonSemantics.absoluteTolerance}</dd></> : null}{exercise.comparisonSemantics.relativeTolerance !== undefined ? <><dt>Relative tolerance</dt><dd>{exercise.comparisonSemantics.relativeTolerance}</dd></> : null}<dt>Required representation</dt><dd>{exercise.comparisonSemantics.requiredRepresentation ?? "Not declared"}</dd><dt>Required unit</dt><dd>{exercise.comparisonSemantics.requiredUnit ?? "Not declared"}</dd></dl></section>
    <div className="resolved-exercise-mapping">
      <section><h3>Invocation and input mapping</h3><dl><dt>Mode</dt><dd>{exercise.rtcm.invocation.mode}</dd><dt>Entry point</dt><dd>{exercise.rtcm.invocation.entryPoint ?? exercise.rtcm.invocation.operation ?? "Not declared"}</dd><dt>Canonical input reference</dt><dd>{exercise.rtcm.inputDerivation.canonicalInputReference ?? "Not declared"}</dd><dt>Concrete media type</dt><dd>{exercise.rtcm.inputDerivation.concreteMediaType ?? "Not declared"}</dd><dt>Argument order</dt><dd>{exercise.rtcm.invocation.argumentOrder.join(", ") || "Not declared"}</dd><dt>Bindings</dt><dd>{exercise.rtcm.inputDerivation.bindings.length ? exercise.rtcm.inputDerivation.bindings.map((binding) => `${binding.canonicalField} → ${binding.localBinding}`).join("; ") : "No explicit bindings"}</dd></dl></section>
      <section><h3>Observation mapping</h3><dl><dt>Raw observation</dt><dd>{exercise.rtcm.observationDerivation.rawObservationLocation ?? "Not declared"}</dd><dt>Extraction</dt><dd>{exercise.rtcm.observationDerivation.extractionExpression ?? "Not declared"}</dd><dt>Semantic outcome</dt><dd>{exercise.rtcm.observationDerivation.semanticOutcome ?? "Not declared"}</dd><dt>Comparison</dt><dd>{exercise.rtcm.comparison.comparisonType ?? exercise.comparisonSemantics.comparisonType}</dd><dt>Preserve raw observation</dt><dd>{exercise.rtcm.observationDerivation.rawObservationMustBePreserved ? "Required" : "Not required"}</dd></dl></section>
    </div>
    <section className="resolved-exercise-boundary"><h3>Boundary and limitations</h3><p>{exercise.statement}</p><dl><dt>Execution boundary</dt><dd>{exercise.executionBoundary}</dd><dt>Runtime embedded by RTCM</dt><dd>{exercise.rtcm.invocation.doesNotEmbedRuntime ? "No" : "Not excluded"}</dd><dt>RTCM limitations</dt><dd>{exercise.rtcm.limitations.length ? exercise.rtcm.limitations.join("; ") : "None declared"}</dd><dt>External environment requirements</dt><dd>{exercise.rtcm.invocation.externalEnvironmentRequirements.length ? exercise.rtcm.invocation.externalEnvironmentRequirements.join("; ") : "None declared"}</dd></dl></section>
  </article>;
}

function ResolvedPairingDetails(props: {
  readonly ptc: PublicationTestCase | undefined;
  readonly realizationIdentifier: string | undefined;
  readonly rtcm: RealizationTestCaseManifestation | undefined;
}): React.JSX.Element {
  if (!props.ptc) return <p className="empty-state">Select a Publication Test Case to inspect its declaration and resolved realization pairing.</p>;
  return <section className="inspection-section resolved-pairing-details"><h3>Publication Test Case pairing</h3><dl>
    <dt>PTC</dt><dd><code>{props.ptc.identifier}</code></dd>
    <dt>Purpose</dt><dd>{props.ptc.purpose ?? "Not declared"}</dd>
    <dt>Classification</dt><dd>{props.ptc.classification ?? "Not declared"}</dd>
    <dt>Realization</dt><dd>{props.realizationIdentifier ? <code>{props.realizationIdentifier}</code> : "Not selected"}</dd>
    <dt>Resolved RTCM</dt><dd>{props.rtcm ? <code>{props.rtcm.identifier}</code> : "No unique authoritative RTCM resolved"}</dd>
    {props.rtcm ? <><dt>Invocation</dt><dd>{props.rtcm.invocation.mode}{props.rtcm.invocation.entryPoint ? ` · ${props.rtcm.invocation.entryPoint}` : ""}</dd><dt>Input derivation</dt><dd>{props.rtcm.inputDerivation.canonicalInputReference ?? "Not declared"}</dd><dt>Observation derivation</dt><dd>{props.rtcm.observationDerivation.semanticOutcome ?? props.rtcm.observationDerivation.rawObservationLocation ?? "Not declared"}</dd></> : null}
    <dt>PTC declaration</dt><dd><code>{props.ptc.provenance.resourcePath}{props.ptc.provenance.location}</code></dd>
    {props.rtcm ? <><dt>RTCM declaration</dt><dd><code>{props.rtcm.provenance.resourcePath}{props.rtcm.provenance.location}</code></dd></> : null}
  </dl></section>;
}

function AdvancedPublicationInspection(props: {
  readonly interpretation: PublicationInterpretation;
  readonly ptc: PublicationTestCase | undefined;
  readonly realizationIdentifier: string | undefined;
  readonly rtcm: RealizationTestCaseManifestation | undefined;
}): React.JSX.Element {
  const pairingKey = props.ptc && props.realizationIdentifier ? `${props.ptc.identifier}|${props.realizationIdentifier}` : undefined;
  const applicability = props.ptc && props.realizationIdentifier ? props.interpretation.publicationTestCaseApplicability.find((item) => item.ptcIdentifier === props.ptc?.identifier && item.realizationIdentifier === props.realizationIdentifier) : undefined;
  const indexedRtcm = pairingKey ? props.interpretation.exerciseDiscoveryIndex.pairingToRtcmIdentifier[pairingKey] : undefined;
  const relatedRelationships = props.realizationIdentifier ? props.interpretation.relationships.filter((item) => item.sourceIdentifier === props.realizationIdentifier || item.targetIdentifier === props.realizationIdentifier) : [];
  const groupedLimitations = Object.values(props.interpretation.limitations.reduce<Record<string, typeof props.interpretation.limitations>>((groups, item) => {
    const key = `${item.code}|${item.message}`;
    groups[key] = [...(groups[key] ?? []), item];
    return groups;
  }, {}));
  const profile = props.interpretation.capabilityProfile;
  const exerciseModel = profile.kind === "ptc" ? `PTC · ${profile.ptcCount} Test Cases` : profile.kind === "legacy-input" ? `Legacy Inputs · ${profile.standaloneInputObjectCount}` : profile.kind === "ambiguous-mixed" ? "Authority unresolved" : "No declared exercise capability";
  return <details className="advanced-publication-inspection">
    <summary><span>Advanced publication inspection</span><small>Provenance, indexes, and integrity</small></summary>
    <div className="advanced-inspection-body">
      <p className="advanced-inspection-guidance">These declaration details support engineering inspection. RTCMs remain automatically resolved implementation objects—not primary navigation choices.</p>
      <details><summary>Exercise model</summary><dl><dt>Operational profile</dt><dd>{exerciseModel}</dd><dt>Exercise authority</dt><dd>{profile.exerciseAuthority}</dd><dt>PTC capability</dt><dd>{profile.ptcCapability}</dd><dt>Standalone inputs</dt><dd>{profile.standaloneInputCapability}</dd><dt>Interpretation rationale</dt><dd>{profile.rationale}</dd></dl></details>
      <details><summary>RTCM provenance and integrity</summary>{props.rtcm ? <dl><dt>RTCM</dt><dd><code>{props.rtcm.identifier}</code></dd><dt>Authority status</dt><dd>{props.rtcm.status ?? "Not declared"}</dd><dt>Declared PTC</dt><dd><code>{props.rtcm.ptcIdentifier}</code></dd><dt>Declared realization</dt><dd><code>{props.rtcm.realizationIdentifier}</code></dd><dt>Indexed for pairing</dt><dd>{indexedRtcm === props.rtcm.identifier ? "Yes — unique authoritative resolution" : "No"}</dd><dt>Declaration</dt><dd><code>{props.rtcm.provenance.resourcePath}{props.rtcm.provenance.location}</code></dd><dt>Resource SHA-256</dt><dd><code>{props.rtcm.provenance.resourceSha256}</code></dd><dt>Interpretation basis</dt><dd>{props.rtcm.provenance.basis}</dd><dt>Declaration checks</dt><dd>{props.interpretation.publicationValidation.status}</dd></dl> : <p>No authoritative RTCM is resolved for the current selection.</p>}</details>
      <details><summary>Applicability basis</summary>{applicability ? <dl><dt>PTC</dt><dd><code>{applicability.ptcIdentifier}</code></dd><dt>Realization</dt><dd><code>{applicability.realizationIdentifier}</code></dd><dt>Declared status</dt><dd>{applicability.status}</dd><dt>Basis reference</dt><dd>{applicability.basisReference ?? "Not declared"}</dd><dt>Pairing key</dt><dd><code>{props.rtcm?.applicability.pairingKey ?? pairingKey}</code></dd><dt>RTCM applicability</dt><dd>{props.rtcm?.applicability.status ?? "No RTCM resolved"}</dd><dt>Conformance assertion</dt><dd>{props.rtcm?.applicability.conformanceAssertion ? "Declared" : "False — applicability is not conformance"}</dd><dt>Declaration</dt><dd><code>{applicability.provenance.resourcePath}{applicability.provenance.location}</code></dd></dl> : <p>No explicit applicability declaration is selected.</p>}</details>
      <details><summary>Relationship and coverage indexes</summary><dl><dt>PTCs indexed</dt><dd>{props.interpretation.exerciseDiscoveryIndex.ptcIdentifiers.length}</dd><dt>RTCMs indexed</dt><dd>{props.interpretation.exerciseDiscoveryIndex.rtcmIdentifiers.length}</dd><dt>Unique pairing resolutions</dt><dd>{Object.keys(props.interpretation.exerciseDiscoveryIndex.pairingToRtcmIdentifier).length}</dd><dt>Realizations for selected PTC</dt><dd>{props.ptc ? (props.interpretation.exerciseDiscoveryIndex.ptcToRealizationIdentifiers[props.ptc.identifier] ?? []).join(", ") || "None" : "No PTC selected"}</dd><dt>PTCs for selected realization</dt><dd>{props.realizationIdentifier ? (props.interpretation.exerciseDiscoveryIndex.realizationToPtcIdentifiers[props.realizationIdentifier] ?? []).join(", ") || "None" : "No realization selected"}</dd><dt>Related topology relationships</dt><dd>{relatedRelationships.length}</dd></dl>{relatedRelationships.length ? <ul>{relatedRelationships.map((relationship, index) => <li key={`${relationship.sourceIdentifier}|${relationship.relationshipType}|${relationship.targetIdentifier}|${index}`}><code>{relationship.sourceIdentifier}</code> {relationship.relationshipType} <code>{relationship.targetIdentifier}</code><small>{relationship.provenance.resourcePath}{relationship.provenance.location}</small></li>)}</ul> : null}</details>
      <details><summary>Declaration authority</summary><dl><dt>PTC declaration</dt><dd>{props.ptc?.status ?? "No PTC selected"} {props.ptc ? `(governing exercise declaration)` : ""}</dd><dt>RTCM declaration</dt><dd>{props.rtcm?.status ?? "No RTCM resolved"} {props.rtcm ? `(governing realization-specific manifestation)` : ""}</dd><dt>Related relationships</dt><dd>{relatedRelationships.length ? `${relatedRelationships.length} explicit supporting topology declarations; corroborating context, not exercise authority` : "No related supporting topology declarations"}</dd></dl></details>
      <details><summary>Declaration issues</summary>{props.interpretation.publicationValidation.issues.length ? <ul>{props.interpretation.publicationValidation.issues.map((issue, index) => <li key={`${issue.code}:${index}`}><strong>{issue.severity}: {issue.code}</strong><span>{issue.message}</span>{issue.resourcePath ? <small>{issue.resourcePath}{issue.location}</small> : null}</li>)}</ul> : <p>No declaration-check issues were reported.</p>}</details>
      <details><summary>Unresolved or conflicting information</summary>{groupedLimitations.length ? <ul>{groupedLimitations.map((items) => { const first = items[0]!; return <li key={`${first.code}|${first.message}`}><strong>{first.code}</strong><span>{first.message}</span><small>{items.length} declaration location{items.length === 1 ? "" : "s"}</small><ul>{items.map((item, index) => <li key={`${item.resourcePath}|${item.location}|${index}`}><code>{item.resourcePath ?? "Publication-level"}{item.location ?? ""}</code></li>)}</ul></li>; })}</ul> : <p>No unresolved or conflicting publication information was reported.</p>}</details>
    </div>
  </details>;
}

function CollectionTab(props: { readonly id: SessionCollection; readonly label: string; readonly count: number; readonly active: boolean; readonly onSelect: () => void }): React.JSX.Element {
  return <button id={`collection-tab-${props.id}`} type="button" role="tab" aria-selected={props.active} aria-controls={`collection-panel-${props.id}`} tabIndex={props.active ? 0 : -1} className={props.active ? "is-active" : ""} onClick={props.onSelect}><span>{props.label}</span><strong>{props.count}</strong></button>;
}

function RealizationChannelSelector(props: {
  readonly pathway: RealizationPathwayView;
  readonly declaration: PublicationRealization | undefined;
  readonly publicationIdentifier: string | undefined;
  readonly selected: boolean;
  readonly attempts: readonly ExerciseAttemptResponse[];
  readonly observations: readonly RuntimeObservationResponse[];
  readonly evidence: readonly ExecutionEvidenceResponse[];
  readonly publicationReadiness: ExerciseReadiness | undefined;
  readonly onSelect: () => Promise<void>;
  readonly onExercise: () => Promise<void>;
  readonly exerciseEligibility: CanonicalExerciseEligibility;
  readonly busy: boolean;
  readonly switching: boolean;
  readonly exercising: boolean;
}): React.JSX.Element {
  const status = channelStatus(props.selected, props.attempts, props.observations, props.evidence);
  const compactIdentifier = compactRealizationIdentifier(props.pathway.endpointIdentifier, props.publicationIdentifier, props.pathway.endpointType);
  const declaredTitle = props.declaration?.title?.trim();
  const primaryLabel = declaredTitle || compactIdentifier;
  return <div className={`channel-row ${props.selected ? "is-selected" : ""}`}>
  <button
    type="button"
    className={`channel-selector ${props.selected ? "is-selected" : ""}`}
    aria-pressed={props.selected}
    aria-selected={props.selected}
    aria-label={`${declaredTitle ? `${declaredTitle}. ` : ""}${props.pathway.endpointIdentifier}. ${channelStatusLabel(status)}${props.switching ? ". Switching" : ""}`}
    title={props.pathway.endpointIdentifier}
    role="option"
    data-pathway-id={props.pathway.id}
    onClick={() => void props.onSelect()}
    disabled={!props.pathway.selectable || props.busy}
  >
    <span className={`status-light ${status}`} aria-hidden="true" />
    <span className="realization-identity"><strong>{primaryLabel}</strong><span className="realization-identity-meta"><small>{declaredTitle ? compactIdentifier : props.declaration?.invocationMechanism ?? realizationLayerDescriptor(props.pathway.endpointType).singular}</small>{props.publicationReadiness ? <small className={`channel-publication-readiness readiness-${props.publicationReadiness.status}`}>{readinessLabel(props.publicationReadiness.status)}</small> : null}</span></span>
    <span className="channel-state">{props.switching ? "Switching…" : channelStatusLabel(status)}</span>
  </button>
  <div className="channel-exercise-control" aria-busy={props.exercising}>
    <button type="button" className="channel-exercise-action" title={props.exerciseEligibility.enabled ? `Exercise ${props.pathway.endpointIdentifier}` : props.exerciseEligibility.reason} aria-label={props.exerciseEligibility.enabled ? `Exercise ${props.pathway.endpointIdentifier} with the selected Test Case` : `Exercise unavailable for ${props.pathway.endpointIdentifier}: ${props.exerciseEligibility.reason}`} disabled={!props.exerciseEligibility.enabled || props.busy} aria-disabled={!props.exerciseEligibility.enabled || props.busy} onClick={() => void props.onExercise()}>{props.exercising ? "Exercising…" : "Exercise"}</button>
  </div>
  </div>;
}

function SharedOperationalWorkspace(props: {
  readonly pathway: RealizationPathwayView | undefined;
  readonly layerLabel: string;
  readonly attempts: readonly ExerciseAttemptResponse[];
  readonly interactions: readonly ExecutionInteractionResponse[];
  readonly observations: readonly RuntimeObservationResponse[];
  readonly comparisons: readonly ExpectedOutcomeComparisonResponse[];
  readonly evidence: readonly ExecutionEvidenceResponse[];
  readonly environments: readonly ExecutionEnvironmentDescriptionResponse[];
}): React.JSX.Element {
  const latestObservation = props.observations.at(-1);
  const latestEnvironment = props.environments.at(-1);
  if (!props.pathway) return <section className="shared-workspace empty-workspace"><h3>No channel selected</h3><p>Select a Realization Channel to place its context into the shared workspace.</p></section>;
  const workspaceStatus = channelStatus(true, props.attempts, props.observations, props.evidence);
  return <section className="shared-workspace instrument-display-compatibility" aria-label="Current operational object">
    <header className="workspace-header">
      <div className="workspace-identity">
        <p className="module-index">Selected {props.layerLabel}</p>
        <div className="workspace-title-row"><span className={`workspace-status-light ${workspaceStatus}`} aria-hidden="true" /><h3>{props.pathway.endpointIdentifier}</h3></div>
        <p className="workspace-pathway-summary">{compactPathwaySummary(props.pathway)}</p>
      </div>
      <div className="workspace-orientation" aria-label="Selected realization status">
        <strong>{channelStatusLabel(workspaceStatus)}</strong>
        <span className="assurance-chip">Identity assurance: reported</span>
      </div>
    </header>
    <div className="workspace-stage-stack">
      <section className="operational-stage" id="workspace-check" aria-labelledby="workspace-check-label">
      <div className="check-workspace">
        <OutputMonitor observation={latestObservation} interaction={props.interactions.at(-1)} environment={latestEnvironment} comparison={latestObservation ? props.comparisons.find((item) => item.observationId === latestObservation.id) : undefined} />
      </div>
      </section>
    </div>
  </section>;
}

function ObservationDisplay({ observation, comparison }: { readonly observation: RuntimeObservationResponse; readonly comparison: ExpectedOutcomeComparisonResponse | undefined }): React.JSX.Element {
  return <article className="observation-display" aria-label={`Observation ${observation.sessionSequence}: ${observation.id}`}>
    <header className="observation-display-header">
      <div><p className="module-index">Observation {observation.sessionSequence}</p><h2>{observation.endpointIdentifier}</h2><p><code>{observation.id}</code></p></div>
      <span className={`observation-outcome outcome-${observation.outcome}`}>Execution {observation.outcome}</span>
    </header>
    <section className="observation-status-separation" aria-label="Execution outcome and comparison status">
      <div><span>External execution outcome</span><strong>{observation.outcome}</strong></div>
      <div><span>Expected Outcome comparison</span><strong className={comparison ? `comparison-${comparison.status}` : "comparison-unavailable"}>{comparison?.status ?? "Not recorded"}</strong></div>
    </section>
    <dl className="observation-identity-grid">
      <dt>Captured</dt><dd>{observation.capturedAt}</dd>
      <dt>Exercise Attempt</dt><dd><code>{observation.attemptId}</code></dd>
      <dt>Execution Interaction</dt><dd><code>{observation.executionInteractionId}</code></dd>
      <dt>Realization</dt><dd><code>{observation.endpointIdentifier}</code></dd>
      <dt>Publication Test Case</dt><dd><code>{observation.publicationExerciseScope?.ptcIdentifier ?? "Unavailable"}</code></dd>
      <dt>RTCM</dt><dd><code>{observation.publicationExerciseScope?.rtcmIdentifier ?? "Unavailable"}</code></dd>
    </dl>
    <section className="observation-raw-content" aria-labelledby="observation-raw-heading">
      <header><div><p className="module-index">Immutable raw Observation</p><h3 id="observation-raw-heading">Exact captured value</h3></div><span>{observation.rawObservation.sourceClassification}</span></header>
      <pre tabIndex={0}>{observation.rawObservation.value}</pre>
      <dl><dt>Media type</dt><dd>{observation.rawObservation.mediaType}</dd><dt>Raw identifier</dt><dd><code>{observation.rawObservation.id}</code></dd><dt>SHA-256</dt><dd><code>{observation.rawObservation.sha256}</code></dd><dt>Source location</dt><dd>{observation.rawObservation.location}</dd><dt>Preservation</dt><dd>{observation.rawObservation.preservationDisposition}</dd><dt>Classification</dt><dd>{observation.rawObservation.sourceClassification}</dd></dl>
    </section>
    {comparison ? <ExpectedOutcomeComparisonPanel comparison={comparison} /> : <section className="observation-no-comparison" role="status"><strong>No Expected Outcome comparison is recorded for this Observation</strong><p>No pass, failure, or comparison error is inferred.</p></section>}
    <p className="observation-readonly-boundary">Read-only inspection · stored records only · no execution, recomputation, persistence, attestation, or publication mutation</p>
  </article>;
}

function ObservationEngineeringDetails(props: {
  readonly observation: RuntimeObservationResponse;
  readonly comparison: ExpectedOutcomeComparisonResponse | undefined;
  readonly interaction: ExecutionInteractionResponse | undefined;
  readonly environment: ExecutionEnvironmentDescriptionResponse | undefined;
  readonly evidence: ExecutionEvidenceResponse | undefined;
}): React.JSX.Element {
  const extraction = props.observation.extractionProvenance;
  const declaration = extraction.declarationProvenance;
  const process = props.interaction?.externalProcess;
  const reference = props.interaction?.referenceExecution;
  return <section className="observation-engineering-details" aria-label="Selected Observation engineering details">
    <h3>Observation provenance</h3>
    <p className="readiness-boundary">Engineering detail for the exact selected Observation. Missing optional information remains unavailable and is not inferred.</p>
    <details><summary>Extraction and RTCM provenance</summary><dl>
      <dt>Disposition</dt><dd>{extraction.disposition}</dd><dt>RTCM</dt><dd><code>{extraction.rtcmIdentifier ?? "Unavailable"}</code></dd><dt>Raw location</dt><dd>{extraction.rawObservationLocation ?? "Unavailable"}</dd><dt>Expression</dt><dd><code>{extraction.extractionExpression ?? "Unavailable"}</code></dd><dt>Semantic outcome</dt><dd>{extraction.semanticOutcome ?? "Unavailable"}</dd>
      <dt>Declaration resource</dt><dd><code>{declaration ? `${declaration.resourcePath}${declaration.location}` : "Unavailable"}</code></dd><dt>Declaration SHA-256</dt><dd><code>{declaration?.resourceSha256 ?? "Unavailable"}</code></dd><dt>Declaration basis</dt><dd>{declaration?.basis ?? "Unavailable"}</dd>
    </dl><p>{extraction.statement}</p></details>
    <details><summary>Normalization records</summary>
      {props.observation.normalizationRecords.length ? <ul>{props.observation.normalizationRecords.map((record, index) => <li key={`${record.declaration}:${index}`}><strong>{record.declaration}</strong><span>{record.disposition}</span><small>{record.statement}</small></li>)}</ul> : <p>No normalization declaration was recorded for this Observation.</p>}
      <dl><dt>Comparison representation</dt><dd>{props.comparison?.normalizedRepresentation.disposition ?? "Unavailable"}</dd><dt>Applied separately by comparison</dt><dd>{props.comparison ? (props.comparison.normalizedRepresentation.appliedNormalizations.join(", ") || "None") : "Unavailable"}</dd></dl>
    </details>
    <details><summary>Property classifications</summary>{props.observation.propertyClassifications.length ? <ul>{props.observation.propertyClassifications.map((item, index) => <li key={`${item.classification}:${index}`}><strong>{item.classification}</strong><span>{item.properties.join(", ")}</span><small>{item.basis}</small></li>)}</ul> : <p>Property classifications are unavailable.</p>}</details>
    <details><summary>Execution Interaction and external process</summary>{props.interaction ? <><dl><dt>Interaction</dt><dd><code>{props.interaction.id}</code></dd><dt>External interaction</dt><dd><code>{props.interaction.externalInteractionId}</code></dd><dt>Response source</dt><dd>{props.interaction.response.receivedFrom}</dd><dt>Execution responsibility</dt><dd>{props.interaction.executionResponsibility}</dd><dt>Response outcome</dt><dd>{props.interaction.response.outcome}</dd><dt>Response received</dt><dd>{props.interaction.response.receivedAt}</dd><dt>Response media type</dt><dd>{props.interaction.response.mediaType}</dd><dt>Exit code</dt><dd>{process ? String(process.exitCode) : "Unavailable"}</dd><dt>Signal</dt><dd>{process?.signal ?? "Unavailable"}</dd><dt>Timed out</dt><dd>{process ? String(process.timedOut) : "Unavailable"}</dd></dl>{process?.stderr ? <><h4>Preserved stderr</h4><pre tabIndex={0}>{process.stderr}</pre></> : <p>Preserved stderr is unavailable.</p>}</> : <p>The associated Execution Interaction is unavailable.</p>}</details>
    <details><summary>Resolved reference invocation</summary>{reference ? <><dl><dt>Runtime</dt><dd>{reference.invocation.adapterResolution.canonicalRuntime}</dd><dt>Adapter capability</dt><dd><code>{reference.invocation.adapterResolution.capabilityId}</code></dd><dt>Executable</dt><dd><code>{reference.invocation.executable}</code></dd><dt>Declared runtime</dt><dd>{reference.runtimeDeclaration?.value ?? reference.invocation.runtimeRequirement}</dd><dt>Arguments</dt><dd><code>{reference.invocation.arguments.join(" ") || "None"}</code></dd><dt>Declaration</dt><dd><code>{reference.declarationResourcePath}</code></dd>{reference.invocation.dotnetCliInvocation ? <><dt>.NET bridge</dt><dd><code>{reference.invocation.dotnetCliInvocation.bridgeId}</code></dd><dt>Target framework</dt><dd>{reference.invocation.dotnetCliInvocation.targetFramework}</dd><dt>Declared adapter project</dt><dd><code>{reference.invocation.dotnetCliInvocation.projectFileReference}</code></dd><dt>Adapter entry point</dt><dd><code>{reference.invocation.dotnetCliInvocation.adapterEntryPointReference}</code></dd><dt>Implementation project</dt><dd><code>{reference.invocation.dotnetCliInvocation.implementationProjectReference}</code></dd></> : null}{reference.invocation.httpInvocation ? <><dt>HTTP bridge</dt><dd><code>{reference.invocation.httpInvocation.bridgeId}</code></dd><dt>Declared operation</dt><dd>{reference.invocation.httpInvocation.method} <code>{reference.invocation.httpInvocation.route}</code></dd><dt>REST binding</dt><dd><code>{reference.invocation.httpInvocation.bindingDeclarationReference}</code></dd><dt>Implementation</dt><dd><code>{reference.invocation.httpInvocation.implementationRepresentationIdentifier} · {reference.invocation.httpInvocation.implementationEntryPoint}</code></dd><dt>HTTP status</dt><dd>{reference.httpTransfer?.statusCode ?? "Unavailable"}</dd><dt>Response media type</dt><dd>{reference.httpTransfer?.responseHeaders["content-type"] ?? reference.invocation.httpInvocation.responseMediaType}</dd><dt>Request SHA-256</dt><dd><code>{reference.invocation.httpInvocation.requestBodySha256}</code></dd><dt>Request body</dt><dd><pre>{reference.invocation.httpInvocation.requestBody}</pre></dd></> : null}{reference.invocation.negativeConditionPlan ? <><dt>Negative operation</dt><dd>{reference.invocation.negativeConditionPlan.operation}</dd><dt>Semantic subject</dt><dd><code>{reference.invocation.negativeConditionPlan.semanticSubject}</code></dd><dt>Mapped subject</dt><dd><code>{reference.invocation.negativeConditionPlan.localSubject ?? "aggregate boundary"}</code></dd><dt>Expected rejection</dt><dd><code>{reference.invocation.negativeConditionPlan.expectedErrorCode}</code> · {reference.invocation.negativeConditionPlan.expectedCategory}</dd><dt>RTCM derivation</dt><dd>{reference.invocation.negativeConditionPlan.concreteDerivation}</dd><dt>Must not conflate with</dt><dd>{reference.invocation.negativeConditionPlan.mustNotConflateWith ?? "Not declared"}</dd><dt>PTC provenance</dt><dd><code>{reference.invocation.negativeConditionPlan.ptcDeclarationProvenance.resourcePath}{reference.invocation.negativeConditionPlan.ptcDeclarationProvenance.location}</code></dd></> : null}</dl><p className="microcopy">Declaration-backed resolution and environment identity do not authenticate realization identity or establish correctness.</p></> : <p>No resolved reference invocation is associated with this Observation.</p>}</details>
    <details><summary>Execution environment</summary><EnvironmentDetails environment={props.environment} /></details>
    <details><summary>Associated Execution Evidence</summary>{props.evidence ? <dl><dt>Evidence</dt><dd><code>{props.evidence.id}</code></dd><dt>Status</dt><dd>{props.evidence.status}</dd><dt>Attested</dt><dd>{props.evidence.attestedAt}</dd><dt>Scope</dt><dd>{props.evidence.evidenceScope}</dd><dt>Comparison status</dt><dd>{props.evidence.expectedOutcomeComparison?.status ?? "Unavailable"}</dd><dt>Integrity</dt><dd><code>{props.evidence.integrity.digest}</code></dd></dl> : <p>No Execution Evidence has been attested for this Observation.</p>}</details>
  </section>;
}

function OutputMonitor({ observation, interaction, environment, comparison }: { readonly observation: RuntimeObservationResponse | undefined; readonly interaction: ExecutionInteractionResponse | undefined; readonly environment: ExecutionEnvironmentDescriptionResponse | undefined; readonly comparison: ExpectedOutcomeComparisonResponse | undefined }): React.JSX.Element {
  return <section className="output-monitor" aria-live="polite"><div className="module-heading"><div><p className="module-index">Check</p><h3>Latest output</h3></div><span className={observation?.outcome === "failed" ? "outcome failed" : observation ? "outcome completed" : "outcome idle"}>{observation ? observation.outcome : "No signal"}</span></div>
    {observation ? <><div className="raw-observation-heading"><strong>Immutable raw observation</strong><span>{observation.rawObservation.sourceClassification}</span></div><pre>{observation.rawObservation.value}</pre><div className="monitor-meta"><span>{observation.rawObservation.mediaType}</span><span>{observation.capturedAt}</span><span>{environment?.externalEnvironmentIdentifier.value ?? observation.environmentIdentity ?? "Environment not supplied"}</span><span>{environment ? `Environment ${environment.identityAssurance.level}` : "Environment undescribed"}</span></div><ObservationScopeDetails observation={observation} />{comparison ? <ExpectedOutcomeComparisonPanel comparison={comparison} /> : null}</> : <p className="empty-state">Exercise this channel to receive an automatically captured Runtime Observation.</p>}
    {interaction && interaction.response.outcome !== "completed" ? <div className="callout error-callout"><strong>External process {interaction.response.outcome}</strong><p>{interaction.externalProcess?.timedOut ? "The declared adapter timed out." : interaction.externalProcess?.exitCode !== null && interaction.externalProcess?.exitCode !== undefined ? `The declared adapter exited with code ${interaction.externalProcess.exitCode}.` : "The external environment did not report a completed outcome."}</p>{interaction.externalProcess?.stderr ? <><small>Raw stderr (preserved, not substituted for stdout)</small><pre className="process-stderr">{interaction.externalProcess.stderr}</pre></> : null}</div> : null}
  </section>;
}

function ExpectedOutcomeComparisonPanel({ comparison }: { readonly comparison: ExpectedOutcomeComparisonResponse }): React.JSX.Element {
  const observed = comparison.extractedRepresentation.value;
  const expected = comparison.expectedRepresentation.value;
  return <section className={`expected-outcome-comparison comparison-${comparison.status}`} aria-label={`Expected Outcome comparison: ${comparison.status}`}>
    <div className="comparison-heading"><div><p className="module-index">Stored Expected Outcome comparison</p><strong>{comparison.status}</strong></div><span>{comparison.claimDisposition}</span></div>
    {comparison.status === "pass" || comparison.status === "fail" ? comparison.comparisonRepresentation.semanticAssertions ? <dl className="comparison-summary semantic-comparison-summary">{comparison.comparisonRepresentation.semanticAssertions.map((assertion) => <React.Fragment key={assertion.assertion}><dt>{assertion.assertion}</dt><dd>{assertion.satisfied ? "Satisfied" : "Not satisfied"} · {assertion.observed}</dd></React.Fragment>)}</dl> : <dl className="comparison-summary"><dt>Observed</dt><dd>{String(observed)}</dd><dt>Expected</dt><dd>{String(expected)}</dd><dt>Absolute difference</dt><dd>{String(comparison.comparisonRepresentation.absoluteDifference)}</dd><dt>Absolute tolerance</dt><dd>{String(comparison.comparisonRepresentation.absoluteTolerance)}</dd></dl> : <p className="comparison-error-message"><strong>{comparison.error?.code ?? "comparison_unavailable"}</strong> — {comparison.error?.message ?? "No deterministic comparison result is available."}</p>}
    <details><summary>Comparison representations</summary><dl>
      <dt>Raw identity</dt><dd><code>{comparison.rawRepresentation.rawObservationId}</code></dd>
      <dt>Raw SHA-256</dt><dd><code>{comparison.rawRepresentation.sha256}</code></dd>
      <dt>Normalized</dt><dd>{comparison.normalizedRepresentation.disposition}{comparison.normalizedRepresentation.appliedNormalizations.length ? ` · ${comparison.normalizedRepresentation.appliedNormalizations.join(", ")}` : ""}</dd>
      <dt>Extraction</dt><dd>{comparison.extractedRepresentation.disposition} · <code>{comparison.extractedRepresentation.declaredExpression ?? comparison.extractedRepresentation.sourcePath}</code>{comparison.extractedRepresentation.value !== undefined ? ` · ${comparison.extractedRepresentation.value}` : ""}</dd>
      <dt>Canonical Expected Outcome</dt><dd>{comparison.expectedRepresentation.outcomeKind} · <code>{displayValue(comparison.expectedRepresentation.value)}</code></dd>
      <dt>Comparison rule</dt><dd>{comparison.comparisonRepresentation.comparisonType ?? "Unavailable"}</dd>
      <dt>Absolute tolerance</dt><dd>{comparison.comparisonRepresentation.absoluteTolerance ?? "Unavailable"}</dd>
      <dt>Relative tolerance</dt><dd>{comparison.comparisonRepresentation.relativeTolerance ?? "Unavailable"}</dd>
      <dt>Absolute difference</dt><dd>{comparison.comparisonRepresentation.absoluteDifference ?? "Unavailable"}</dd>
      <dt>Rounding</dt><dd>{comparison.comparisonRepresentation.roundingApplied ? "Applied" : "Not applied"}</dd>
      <dt>Claim disposition</dt><dd>{comparison.claimDisposition}</dd>
    </dl></details><p className="comparison-boundary">Comparison result, not conformance determination.</p><p className="microcopy">{comparison.statement}</p>
  </section>;
}

function ObservationScopeDetails({ observation }: { readonly observation: RuntimeObservationResponse }): React.JSX.Element {
  return <details className="observation-scope-details"><summary>Raw identity and PTC scope</summary><dl>
    <dt>Raw observation</dt><dd><code>{observation.rawObservation.id}</code></dd>
    <dt>SHA-256</dt><dd><code>{observation.rawObservation.sha256}</code></dd>
    <dt>Location</dt><dd>{observation.rawObservation.location}</dd>
    <dt>Preservation</dt><dd>{observation.rawObservation.preservationDisposition}</dd>
    {observation.publicationExerciseScope ? <><dt>Publication Test Case</dt><dd>{observation.publicationExerciseScope.ptcIdentifier}</dd><dt>RTCM</dt><dd>{observation.publicationExerciseScope.rtcmIdentifier}</dd><dt>Realization</dt><dd>{observation.publicationExerciseScope.realizationIdentifier}</dd></> : <><dt>PTC scope</dt><dd>Not associated</dd></>}
    <dt>Extraction</dt><dd>{observation.extractionProvenance.disposition}</dd>
    {observation.extractionProvenance.extractionExpression ? <><dt>Extraction expression</dt><dd><code>{observation.extractionProvenance.extractionExpression}</code></dd></> : null}
    <dt>Normalization</dt><dd>{observation.normalizationRecords.length ? `${observation.normalizationRecords.length} declared, none applied` : "No normalization declared or applied"}</dd>
  </dl><p className="microcopy">Raw content remains independently inspectable. Extraction, normalization, and comparison have not changed it.</p><div className="observation-classifications">{observation.propertyClassifications.map((item) => <p key={item.classification}><strong>{item.classification}</strong><span>{item.properties.join(", ")}</span><small>{item.basis}</small></p>)}</div></details>;
}

function EnvironmentDetails({ environment }: { readonly environment: ExecutionEnvironmentDescriptionResponse | undefined }): React.JSX.Element {
  if (!environment) return <p className="muted">No Execution Environment Description has been recorded.</p>;
  const property = (label: string, item: ExecutionEnvironmentDescriptionResponse["workingDirectory"]) => <><dt>{label}</dt><dd>{item.value ?? "Unavailable"} <small>({item.assurance})</small></dd></>;
  return <section className="environment-details"><h4>Execution Environment Description</h4><dl>
    <dt>Description</dt><dd><code>{environment.id}</code></dd>
    <dt>Type</dt><dd>{environment.environmentType} · {environment.descriptionDisposition}</dd>
    {property("External identifier", environment.externalEnvironmentIdentifier)}
    {property("Operating system", environment.operatingSystem.platform)}
    {property("OS release", environment.operatingSystem.release)}
    {property("Architecture", environment.operatingSystem.architecture)}
    {property("Executable", environment.runtime.executable)}
    {property("Runtime version", environment.runtime.version)}
    {property("Working directory", environment.workingDirectory)}
    {environment.container ? <>
      <dt>Environment provider</dt><dd><code>{environment.container.providerId}</code></dd>
      {property("Pinned image", environment.container.imageReference)}
      {property("Observed image ID", environment.container.imageId)}
      {property("Container", environment.container.containerName)}
      <dt>Isolation</dt><dd>network {environment.container.networkMode} · root {environment.container.rootFilesystem}</dd>
      <dt>Publication mount</dt><dd>{environment.container.publicationMount.containerPath} · {environment.container.publicationMount.mode}</dd>
      <dt>Limits</dt><dd>{environment.container.limits.cpus} CPU · {environment.container.limits.memory} memory · {environment.container.limits.pids} processes · {environment.container.limits.timeoutMilliseconds} ms timeout</dd>
      <dt>Cleanup</dt><dd>{environment.container.cleanupDisposition}</dd>
    </> : null}
    <dt>Identity assurance</dt><dd>{environment.identityAssurance.level}</dd>
  </dl><p className="microcopy">{environment.identityAssurance.statement}</p></section>;
}

function channelStatus(selected: boolean, attempts: readonly ExerciseAttemptResponse[], observations: readonly RuntimeObservationResponse[], evidence: readonly ExecutionEvidenceResponse[]): ChannelStatus {
  if (evidence.length) return "evidence";
  const latest = observations.at(-1);
  if (latest?.outcome === "failed") return "failed";
  if (latest) return "completed";
  if (attempts.length) return "prepared";
  if (selected) return "selected";
  return "ready";
}

function channelStatusLabel(status: ChannelStatus): string {
  return status === "evidence" ? "Evidence available" : status === "failed" ? "Execution failed" : status === "completed" ? "Result available" : status === "prepared" ? "Attempt prepared" : status === "selected" ? "Selected" : "Ready";
}

function PathwayDetails({ pathway }: { readonly pathway: RealizationPathwayView }): React.JSX.Element {
  return <div className="pathway-detail"><ol>{pathway.steps.map((step, index) => <li key={`${pathway.id}:${step.identifier}`}><strong>{step.identifier}</strong><span>{step.realizationType}</span>{index < pathway.relationshipTypes.length ? <small>{pathway.relationshipTypes[index]}</small> : null}</li>)}</ol><p><strong>Exercise support:</strong> {pathway.exerciseSupport}</p>{pathway.unsupportedExplanations.map((reason, index) => <p key={`${pathway.id}:reason:${index}`} className="muted">{reason}</p>)}</div>;
}

function OperationalDashboard({ matrix, publicationTitle, publicationVersion, activeLayer, selectedPathway, selectedAttempts, selectedObservations, selectedEvidence, selectedEnvironments, adapterAvailable, interpretation, ptcProjectionAvailable, exerciseOpportunityCoverage, publicationMenu }: {
  readonly matrix: ExecutableRealizationMatrixResponse;
  readonly publicationTitle: string;
  readonly publicationVersion: string | undefined;
  readonly activeLayer: RealizationLayer;
  readonly selectedPathway: RealizationPathwayView | undefined;
  readonly selectedAttempts: readonly ExerciseAttemptResponse[];
  readonly selectedObservations: readonly RuntimeObservationResponse[];
  readonly selectedEvidence: readonly ExecutionEvidenceResponse[];
  readonly selectedEnvironments: readonly ExecutionEnvironmentDescriptionResponse[];
  readonly adapterAvailable: boolean;
  readonly interpretation: PublicationInterpretation | undefined;
  readonly ptcProjectionAvailable: boolean;
  readonly exerciseOpportunityCoverage: ExerciseOpportunityCoverage | undefined;
  readonly publicationMenu: React.ReactNode;
}): React.JSX.Element {
  const [dashboardOpen, setDashboardOpen] = React.useState(true);
  const counts: Readonly<Record<RealizationLayer, number>> = {
    "implementation-representation": matrix.irEndpointPathwayCount,
    "service-realization": matrix.srEndpointPathwayCount,
    "deployment-package": matrix.dpEndpointPathwayCount
  };
  const latestObservation = selectedObservations.at(-1);
  const latestEvidence = selectedEvidence.at(-1);
  const latestEnvironment = selectedEnvironments.at(-1);
  const readiness = matrix.pathwayIntegrityIssueCount
    ? { state: "warning", label: "Review required", detail: `${matrix.pathwayIntegrityIssueCount} pathway integrity issue${matrix.pathwayIntegrityIssueCount === 1 ? "" : "s"}` }
    : !selectedPathway
      ? { state: "waiting", label: "Select realization", detail: "No active realization" }
      : !selectedPathway.selectable
        ? { state: "warning", label: "Unavailable", detail: "Selected pathway is not selectable" }
        : !adapterAvailable
          ? { state: "warning", label: "Adapter unavailable", detail: "No execution adapter is connected" }
          : { state: "healthy", label: selectedAttempts.length ? "Ready to continue" : "Ready to exercise", detail: "Publication and selected pathway are operationally available" };
  const environmentLabel = latestEnvironment?.externalEnvironmentIdentifier.value ?? latestObservation?.environmentIdentity ?? "Not yet observed";
  const observationLabel = latestObservation ? `Observation ${latestObservation.sessionSequence}` : "None yet";
  const attestationLabel = latestEvidence ? "Attested" : latestObservation ? "Available" : "Waiting";
  const readinessStatuses: readonly PublicationReadinessStatus[] = ["complete", "partial", "none", "not-applicable"];
  const realizationCounts = Object.fromEntries(readinessStatuses.map((status) => [status, interpretation?.exerciseReadiness.filter((item) => item.status === status).length ?? 0])) as Record<PublicationReadinessStatus, number>;
  const ptcProjections = interpretation?.publicationTestCases.map((ptc) => projectPtcReadiness(ptc.identifier, interpretation)) ?? [];
  const ptcCounts = Object.fromEntries(readinessStatuses.map((status) => [status, ptcProjections.filter((item) => item.status === status).length])) as Record<PublicationReadinessStatus, number>;

  return <section className={`operational-dashboard shell-dashboard ${dashboardOpen ? "is-open" : "is-closed"}`} aria-labelledby="board-heading">
    <div className="dashboard-windowshade-header">
      <div className="dashboard-publication">
        <span className={`status-ready-light ${readiness.state === "healthy" ? "healthy" : readiness.state === "warning" ? "warning" : "waiting"}`} aria-hidden="true" />
        <div><p className="status-label">Publication loaded</p><h2 id="board-heading">{publicationTitle}</h2>{publicationVersion ? <p className="status-version">Version {publicationVersion}</p> : null}</div>
      </div>
      <div className="dashboard-readiness" aria-label={`Board readiness: ${readiness.label}`}>
        <p className="dashboard-label">Board readiness</p><strong>{readiness.label}</strong><small>{readiness.detail}</small>
      </div>
      <div className="dashboard-actions"><button type="button" className="dashboard-windowshade-toggle" aria-expanded={dashboardOpen} aria-controls="dashboard-windowshade-content" onClick={() => setDashboardOpen((current) => !current)}>{dashboardOpen ? "Close" : "Open"}</button>{publicationMenu}</div>
    </div>
    <div id="dashboard-windowshade-content" className={`dashboard-windowshade-body ${dashboardOpen ? "is-open" : "is-closed"}`} aria-hidden={!dashboardOpen}>
      <div className="dashboard-windowshade-content">
        <div className="dashboard-data-alignment" aria-label="Publication Test Case completeness, unique realization completeness, and realization pathway inventory">
          <CompletenessReadoutGroup marker="PTC" population="Publication Test Cases" counts={ptcCounts} available={ptcProjectionAvailable} />
          <CompletenessReadoutGroup marker="RZN" population="Realizations" counts={realizationCounts} />
          <div className="dashboard-readout-group dashboard-matrix" role="group" aria-label="Realization pathway inventory by endpoint level">
            {REALIZATION_LAYERS.map((layer) => {
              const isActive = activeLayer === layer.id;
              return <div key={layer.id} className={`dashboard-numeric-box status-count-box status-count-${layer.short.toLowerCase()} ${isActive ? "is-active" : ""}`} aria-label={`${layer.singular} endpoint pathways: ${counts[layer.id]}`} aria-current={isActive ? "true" : undefined} data-layer={layer.short.toLowerCase()}><strong>{counts[layer.id]}</strong><span className="numeric-box-footer"><b>{layer.short}</b></span></div>;
            })}
            <div className="dashboard-numeric-box status-count-box status-total" aria-label={`Total realization pathways: ${matrix.realizationPathwayCount}`}><strong>{matrix.realizationPathwayCount}</strong><span className="numeric-box-footer"><b>Total</b></span></div>
          </div>
        </div>
        <ExerciseOpportunityCoverageMatrix projection={exerciseOpportunityCoverage} activeLayer={activeLayer} />
        <div className="dashboard-readouts" aria-label="Current Console View state">
          <DashboardReadout label="Active realization" value={selectedPathway?.endpointIdentifier ?? "None selected"} detail={selectedPathway ? compactPathwaySummary(selectedPathway) : "Choose a Realization Channel"} />
          <DashboardReadout label="Environment" value={environmentLabel} detail={latestEnvironment ? `Identity ${latestEnvironment.identityAssurance.level}` : "Created after external execution"} />
          <DashboardReadout label="Latest observation" value={observationLabel} detail={latestObservation ? `${latestObservation.endpointIdentifier} · ${latestObservation.outcome}` : "Session history is empty"} />
          <DashboardReadout label="Attestation" value={attestationLabel} detail={latestEvidence ? `Evidence recorded ${latestEvidence.attestedAt}` : latestObservation ? "Latest observation may be attested" : "Requires an observation"} />
        </div>
      </div>
    </div>
  </section>;
}

function ExerciseOpportunityCoverageMatrix({ projection, activeLayer }: { readonly projection: ExerciseOpportunityCoverage | undefined; readonly activeLayer: RealizationLayer }): React.JSX.Element {
  const labels: Readonly<Record<ExerciseOpportunityCoverage["rows"][number]["level"], string>> = {
    "implementation-representation": "IR",
    "service-realization": "SR",
    "deployment-package": "DP",
    total: "TOTAL"
  };
  if (!projection) return <section className="exercise-opportunity-coverage is-unavailable" aria-label="Exercise opportunity coverage unavailable"><p>Pairing coverage is unavailable.</p></section>;
  const formatCoverage = (value: number | null): string => value === null ? "—" : `${Number(value.toFixed(1))}%`;
  return <section className={`exercise-opportunity-coverage ${projection.status === "projection-error" ? "has-error" : ""}`} aria-labelledby="opportunity-coverage-heading">
    <div className="coverage-table-scroll">
      <table>
        <caption id="opportunity-coverage-heading">Exercise opportunity coverage</caption>
        <thead><tr><th scope="col">Level</th><th scope="col"><abbr title="All possible Publication Test Case by unique realization pairs">Possible</abbr></th><th scope="col">Applicable</th><th scope="col"><abbr title="Applicable pairs resolved to exactly one authoritative Realization Test Case Manifestation">RTCM</abbr></th><th scope="col">Enabled</th><th scope="col">Blocked</th><th scope="col"><abbr title="Explicitly not applicable">N/A</abbr></th><th scope="col"><abbr title="Unclassified applicability">Unclass.</abbr></th><th scope="col">Coverage</th></tr></thead>
        <tbody>{projection.rows.map((row) => <tr key={row.level} className={`${row.level === "total" ? "is-total" : ""} ${row.level === activeLayer ? "is-active" : ""}`}>
          <th scope="row">{labels[row.level]}</th><td>{row.possible}</td><td>{row.applicable}</td><td>{row.rtcmResolved}</td><td className="coverage-enabled">{row.exerciseEnabled}</td><td className="coverage-blocked">{row.blocked}</td><td className="coverage-na">{row.notApplicable}</td><td className="coverage-unclassified">{row.unclassified}</td><td>{formatCoverage(row.coveragePercent)}</td>
        </tr>)}</tbody>
      </table>
    </div>
    {projection.status === "projection-error" ? <div className="coverage-projection-error" role="alert"><strong>Coverage projection error</strong><ul>{projection.errors.map((error) => <li key={error}>{error}</li>)}</ul></div> : null}
    <details className="coverage-legend"><summary>Pairing metric definitions</summary><p>{projection.statement}</p><dl><dt>Possible</dt><dd>Declared PTCs × unique realizations at this level.</dd><dt>Applicable</dt><dd>Pairs deterministically declared applicable.</dd><dt>RTCM</dt><dd>Applicable pairs resolved to exactly one authoritative RTCM.</dd><dt>Enabled</dt><dd>Pairs whose exact Exercise action is enabled by the active context's latest support assessment.</dd><dt>Blocked</dt><dd>Applicable minus Enabled; this is not an execution failure.</dd><dt>N/A</dt><dd>Pairs explicitly declared not applicable.</dd><dt>Unclassified</dt><dd>Possible minus Applicable minus N/A.</dd><dt>Coverage</dt><dd>Enabled divided by Applicable; this is not conformance or test-result coverage.</dd></dl></details>
  </section>;
}

function DashboardReadout({ label, value, detail }: { readonly label: string; readonly value: string; readonly detail: string }): React.JSX.Element {
  return <div className="dashboard-readout"><span>{label}</span><strong title={value}>{value}</strong><small title={detail}>{detail}</small></div>;
}

function PathwayIntegrityInspection({ matrix }: { readonly matrix: ExecutableRealizationMatrixResponse }): React.JSX.Element {
  const issues = matrix.pathways.filter((pathway) => pathway.kind === "pathway-integrity-issue");
  return <section className="inspection-section"><h3>Pathway integrity and coverage</h3><div className="summary-grid"><div><span>IR coverage</span><strong>{matrix.representedImplementationRepresentationCount} of {matrix.totalImplementationRepresentationCount}</strong></div><div><span>Integrity issues</span><strong>{matrix.pathwayIntegrityIssueCount}</strong></div></div>{issues.length ? <details><summary>Pathway-integrity issues ({issues.length})</summary><ul>{issues.map((issue) => <li key={issue.id}><strong>{issue.endpointIdentifier}</strong>: {issue.integrityIssue?.message}</li>)}</ul></details> : <p>No pathway-integrity issues were reported.</p>}</section>;
}

function ActiveContextSummary({ activeContext }: { readonly activeContext: ActiveOperationalContextResponse | undefined }): React.JSX.Element {
  if (!activeContext?.contextId) return <p className="empty-state">No publication is active.</p>;
  return <details className="context-details"><summary>Publication context</summary><dl><dt>Publication</dt><dd>{activeContext.publicationIdentifier ?? activeContext.sourceName ?? "Unidentified"}</dd><dt>Session</dt><dd>{activeContext.sessionId}</dd><dt>Context</dt><dd>{activeContext.contextId}</dd><dt>IOR</dt><dd>{activeContext.iorId}</dd></dl></details>;
}

function InterpretationResult({ result }: { readonly result: PublicationActivationResponse }): React.JSX.Element {
  const identity = result.interpretation.publicationIdentity;
  return <section className="inspection-section"><h3>Publication interpretation</h3><div className="summary-grid"><div><span>Resources</span><strong>{result.load.resourceCount}</strong></div><div><span>Realizations</span><strong>{result.interpretation.realizations.length}</strong></div><div><span>Relationships</span><strong>{result.interpretation.relationships.length}</strong></div><div><span>Limitations</span><strong>{result.interpretation.limitations.length}</strong></div></div><details><summary>Declared publication identity</summary>{identity ? <dl><dt>Identifier</dt><dd>{identity.declaredIdentifier}</dd><dt>Version</dt><dd>{identity.declaredVersion ?? "Not declared"}</dd><dt>Title</dt><dd>{identity.title ?? "Not declared"}</dd><dt>Source</dt><dd><code>{identity.provenance.resourcePath}{identity.provenance.location}</code></dd></dl> : <p>No supported explicit publication identity declaration was found.</p>}</details><details><summary>Interpretation limitations ({result.interpretation.limitations.length})</summary>{result.interpretation.limitations.length ? <ul>{result.interpretation.limitations.map((item, index) => <li key={`${item.code}:${index}`}><strong>{item.code}</strong>: {item.message}</li>)}</ul> : <p>No interpretation limitations were reported.</p>}</details></section>;
}

function ImplementationIdentity({ connection }: { readonly connection: ConnectionState }): React.JSX.Element {
  return <section className="inspection-section"><h3>Implementation identity</h3><dl><dt>Implementation</dt><dd>{connection.status === "connected" ? connection.info.implementationName : PC3_IMPLEMENTATION.implementationName}</dd><dt>Version</dt><dd>{connection.status === "connected" ? connection.info.implementationVersion : PC3_IMPLEMENTATION.implementationVersion}</dd><dt>Development pass</dt><dd>{connection.status === "connected" ? connection.info.developmentPass : PC3_IMPLEMENTATION.developmentPass}</dd><dt>Specification baseline</dt><dd>{PC3_IMPLEMENTATION.specificationBaseline}</dd><dt>Blueprint baseline</dt><dd>{PC3_IMPLEMENTATION.blueprintBaseline}</dd></dl></section>;
}

const REALIZATION_LAYERS: readonly { readonly id: RealizationLayer; readonly short: "IR" | "SR" | "DP"; readonly singular: string; readonly plural: string }[] = [
  { id: "implementation-representation", short: "IR", singular: "Implementation Representation", plural: "Implementation Representations" },
  { id: "service-realization", short: "SR", singular: "Service Realization", plural: "Service Realizations" },
  { id: "deployment-package", short: "DP", singular: "Deployment Package", plural: "Deployment Packages" }
];

function realizationLayerDescriptor(layer: RealizationLayer): (typeof REALIZATION_LAYERS)[number] {
  const descriptor = REALIZATION_LAYERS.find((item) => item.id === layer);
  if (!descriptor) throw new Error(`Unsupported realization layer: ${layer}`);
  return descriptor;
}

function compactPathwaySummary(pathway: RealizationPathwayView): string {
  const labels = pathway.steps.map((step) => step.identifier);
  return labels.length > 1 ? labels.join(" → ") : "Direct realization";
}

function compactRealizationIdentifier(identifier: string, publicationIdentifier: string | undefined, layer: RealizationLayer): string {
  if (!publicationIdentifier) return identifier;
  const layerMarker = layer === "implementation-representation" ? "RCI" : layer === "service-realization" ? "SR" : "DP";
  const prefix = `${publicationIdentifier}-${layerMarker}-`;
  return identifier.startsWith(prefix) && identifier.length > prefix.length ? identifier.slice(prefix.length) : identifier;
}

function endpointLabel(type: "implementation-representation" | "service-realization" | "deployment-package"): string {
  return type === "implementation-representation" ? "IR endpoint" : type === "service-realization" ? "Service endpoint" : "Deployment endpoint";
}

function ConnectionIndicator({ connection }: { readonly connection: ConnectionState }): React.JSX.Element {
  if (connection.status === "checking") return <p className="connection-status checking"><span aria-hidden="true" />Checking</p>;
  if (connection.status === "unavailable") return <p className="connection-status unavailable" title={connection.message}><span aria-hidden="true" />Unavailable · v{PC3_IMPLEMENTATION.implementationVersion}</p>;
  return <p className="connection-status connected" title={connection.info.implementationName}><span aria-hidden="true" />Connected · v{connection.info.implementationVersion} · {connection.info.developmentPass}</p>;
}
