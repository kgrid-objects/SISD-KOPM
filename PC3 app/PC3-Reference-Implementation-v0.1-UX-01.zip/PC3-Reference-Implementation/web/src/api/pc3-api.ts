import type {
  ActiveOperationalContextResponse,
  ApiErrorResponse,
  ApplicationInfoResponse,
  HealthResponse,
  PublicationActivationResponse,
  ExecutableRealizationMatrixResponse,
  PathwaySelectionResponse,
  SessionResponse,
  ExerciseAttemptResponse,
  ExerciseAttemptListResponse,
  RuntimeObservationResponse,
  RuntimeObservationListResponse,
  ExternalExecutionResponseInput,
  ExecutionInteractionCaptureResponse,
  ExecutionInteractionListResponse,
  ExecutionEvidenceResponse,
  ExecutionEvidenceListResponse,
  ExecutionAdapterListResponse,
  ExecuteExerciseAttemptInput,
  ExecuteExerciseAttemptResponse,
  ExecuteReferenceExerciseAttemptResponse,
  PrepareExerciseAttemptInput,
  ExecutionEnvironmentDescriptionListResponse,
  ExpectedOutcomeComparisonListResponse
} from "@pc3/shared";

async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(path, { method: "GET", headers: { Accept: "application/json" }, ...(signal ? { signal } : {}) });
  if (!response.ok) throw new Error(await errorMessage(response));
  return (await response.json()) as T;
}

async function errorMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as ApiErrorResponse;
    return body.error.message;
  } catch {
    return `PC3 API request failed with HTTP ${response.status}.`;
  }
}

export const pc3Api = {
  getHealth(signal?: AbortSignal): Promise<HealthResponse> {
    return getJson<HealthResponse>("/api/health", signal);
  },
  getApplicationInfo(signal?: AbortSignal): Promise<ApplicationInfoResponse> {
    return getJson<ApplicationInfoResponse>("/api/application", signal);
  },
  getExecutionAdapters(signal?: AbortSignal): Promise<ExecutionAdapterListResponse> {
    return getJson<ExecutionAdapterListResponse>("/api/execution-adapters", signal);
  },
  getExecutionEnvironments(sessionId: string): Promise<ExecutionEnvironmentDescriptionListResponse> {
    return getJson<ExecutionEnvironmentDescriptionListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/execution-environments`);
  },
  async createSession(): Promise<SessionResponse> {
    const response = await fetch("/api/sessions", { method: "POST", headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as SessionResponse;
  },
  getActiveContext(sessionId: string): Promise<ActiveOperationalContextResponse> {
    return getJson<ActiveOperationalContextResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/active-context`);
  },
  async activatePublication(sessionId: string, file: File, expectedActiveContextId?: string): Promise<PublicationActivationResponse> {
    const query = new URLSearchParams({ filename: file.name });
    if (expectedActiveContextId) query.set("expectedActiveContextId", expectedActiveContextId);
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/publications/activate?${query}`, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/zip" },
      body: file
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as PublicationActivationResponse;
  },
  getRealizationMatrix(sessionId: string): Promise<ExecutableRealizationMatrixResponse> {
    return getJson<ExecutableRealizationMatrixResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/realization-matrix`);
  },
  async selectPathway(sessionId: string, pathwayId: string, expectedActiveContextId: string): Promise<PathwaySelectionResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/realization-matrix/${encodeURIComponent(pathwayId)}/select?${query}`, {
      method: "POST", headers: { Accept: "application/json" }
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as PathwaySelectionResponse;
  },
  async prepareExerciseAttempt(sessionId: string, expectedActiveContextId: string, input: PrepareExerciseAttemptInput): Promise<ExerciseAttemptResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/exercise-attempts?${query}`, {
      method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify(input)
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as ExerciseAttemptResponse;
  },
  getExerciseAttempts(sessionId: string): Promise<ExerciseAttemptListResponse> {
    return getJson<ExerciseAttemptListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/exercise-attempts`);
  },
  async executeExerciseAttempt(sessionId: string, attemptId: string, expectedActiveContextId: string, input: ExecuteExerciseAttemptInput): Promise<ExecuteExerciseAttemptResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/exercise-attempts/${encodeURIComponent(attemptId)}/execute?${query}`, {
      method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify(input)
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as ExecuteExerciseAttemptResponse;
  },
  async executeReferenceExerciseAttempt(sessionId: string, attemptId: string, expectedActiveContextId: string): Promise<ExecuteReferenceExerciseAttemptResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/exercise-attempts/${encodeURIComponent(attemptId)}/execute-reference?${query}`, {
      method: "POST", headers: { Accept: "application/json" }
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as ExecuteReferenceExerciseAttemptResponse;
  },
  async receiveExecutionResponse(sessionId: string, attemptId: string, expectedActiveContextId: string, input: ExternalExecutionResponseInput): Promise<ExecutionInteractionCaptureResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/exercise-attempts/${encodeURIComponent(attemptId)}/execution-responses?${query}`, {
      method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" }, body: JSON.stringify(input)
    });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as ExecutionInteractionCaptureResponse;
  },
  getExecutionInteractions(sessionId: string, attemptId?: string): Promise<ExecutionInteractionListResponse> {
    const query = attemptId ? `?${new URLSearchParams({ attemptId })}` : "";
    return getJson<ExecutionInteractionListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/execution-interactions${query}`);
  },
  getObservationComparisons(sessionId: string, observationId?: string): Promise<ExpectedOutcomeComparisonListResponse> {
    const query = observationId ? `?${new URLSearchParams({ observationId })}` : "";
    return getJson<ExpectedOutcomeComparisonListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/observation-comparisons${query}`);
  },
  async saveRuntimeObservation(sessionId: string, observationId: string): Promise<void> {
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/runtime-observations/${encodeURIComponent(observationId)}/save`, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
    const blob = await response.blob();
    const disposition = response.headers.get("content-disposition") ?? "";
    const match = /filename="?([^";]+)"?/i.exec(disposition);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = match?.[1] ?? `pc3-runtime-observation-${observationId}.json`;
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  },
  async discardRuntimeObservation(sessionId: string, observationId: string, expectedActiveContextId: string): Promise<void> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/runtime-observations/${encodeURIComponent(observationId)}?${query}`, { method: "DELETE", headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
  },

  async attestExecutionEvidence(sessionId: string, observationId: string, expectedActiveContextId: string): Promise<ExecutionEvidenceResponse> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/runtime-observations/${encodeURIComponent(observationId)}/attest?${query}`, { method: "POST", headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
    return (await response.json()) as ExecutionEvidenceResponse;
  },
  getExecutionEvidence(sessionId: string): Promise<ExecutionEvidenceListResponse> {
    return getJson<ExecutionEvidenceListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/execution-evidence`);
  },
  async attestCurrentObservationCollection(sessionId: string, expectedActiveContextId: string): Promise<void> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/execution-evidence/attest-current?${query}`, { method: "POST", headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
    const blob = await response.blob();
    const disposition = response.headers.get("content-disposition") ?? "";
    const match = /filename="?([^";]+)"?/i.exec(disposition);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = match?.[1] ?? "pc3-observation-collection-attestation.json";
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  },
  async saveExecutionEvidence(sessionId: string, evidenceId: string): Promise<void> {
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/execution-evidence/${encodeURIComponent(evidenceId)}/save`, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
    const blob = await response.blob();
    const disposition = response.headers.get("content-disposition") ?? "";
    const match = /filename="?([^";]+)"?/i.exec(disposition);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = match?.[1] ?? `pc3-execution-evidence-${evidenceId}.json`;
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  },
  async discardExecutionEvidence(sessionId: string, evidenceId: string, expectedActiveContextId: string): Promise<void> {
    const query = new URLSearchParams({ expectedActiveContextId });
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/execution-evidence/${encodeURIComponent(evidenceId)}?${query}`, { method: "DELETE", headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(await errorMessage(response));
  },
  getRuntimeObservations(sessionId: string, attemptId?: string): Promise<RuntimeObservationListResponse> {
    const query = attemptId ? `?${new URLSearchParams({ attemptId })}` : "";
    return getJson<RuntimeObservationListResponse>(`/api/sessions/${encodeURIComponent(sessionId)}/runtime-observations${query}`);
  }
};
