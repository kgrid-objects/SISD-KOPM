# UI-07 Pass Report — Resolved Computational Exercise

Date: 2026-07-19  
Implementation: `0.0.0-ui-07` / `UI-07`  
Baseline: externally validated UI-06

## Outcome

PC3 now provides an immutable, non-executing review of exactly what a selected publication exercise means before an attempt can be created.

## Implemented

- Materializes Resolved Exercises through the existing domain resolver for each unique, explicitly applicable pairing with exactly one authoritative RTCM.
- Excludes absent, ambiguous, invalid, and non-applicable resolutions without inference.
- Selects the server-produced Resolved Exercise from the shared PTC/realization navigation state.
- Shows selected PTC, realization type and identifier, and authoritative RTCM.
- Shows canonical input and canonical Expected Outcome.
- Shows comparison type, value path, tolerance, required representation, and unit when declared.
- Shows invocation mode, entry point, argument order, canonical-input reference, media type, and field bindings.
- Shows raw-observation location, extraction, semantic outcome, comparison mapping, and raw-preservation requirement.
- Shows the external-execution boundary, runtime non-embedding disposition, external-environment requirements, and RTCM limitations.
- States prominently that review creates no Exercise Attempt and performs no execution.

## Accepted UKO 1.1 expectation

The previously verified accepted corpus contains 298 applicable pairings and 298 unique authoritative RTCMs. UI-07 therefore yields 298 immutable Resolved Exercises, while the 14 explicitly not-applicable pairings yield none.

## Verification

- Architectural dependency boundaries: passed.
- Type checking: passed.
- Server tests: 84 passed.
- Web tests: 56 passed.
- Shared tests: no test files, passed.
- Production build: passed.

## Boundary statement

Resolved Exercise review is interpretation and review only. It does not create or bind an Exercise Attempt, invoke an adapter, contact an environment, capture an observation, compare an outcome, or assert conformance.
