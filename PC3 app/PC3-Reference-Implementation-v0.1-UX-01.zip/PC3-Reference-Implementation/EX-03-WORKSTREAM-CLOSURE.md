# EX-03 Extended Invocation Support — Workstream Closure

Status: **closed; constituent passes externally accepted**  
Closure date: **2026-07-20**  
Terminal pass: **EX-03F — Negative Publication Test Case Invocation and Comparison**

## Delivered scope

EX-03 established a declaration-driven external invocation architecture through separately bounded and accepted passes:

- EX-03A — generic RTCM invocation planning;
- EX-03B — exact adapter capability resolution without fallback;
- EX-03C — constrained digest-pinned Docker environment provisioning;
- EX-03-NP1 — Python library/imported-function invocation with return-value Observation;
- EX-03D through EX-03D-C3 — declaration-driven C#/.NET 8 command-line invocation and corrections;
- EX-03E and EX-03E-C1 — bounded Python REST invocation and declared response comparison; and
- EX-03F — canonical negative Python REST invocation and semantic rejection comparison.

Together these passes prove CLI, library, and bounded HTTP interaction patterns across Python and one .NET CLI reference while preserving PTC, RTCM, Attempt, Interaction, Observation, Comparison, Attestation, publication immutability, and external-execution boundaries.

## Closure boundary

EX-03 closes without adding:

- negative CLI exit or library-exception comparison;
- C# library or negative invocation;
- Java, JavaScript, Rust, R, CQL, or other runtime adapters;
- additional REST runtimes or methods;
- gRPC, messaging, MCP, FHIR, notebook, browser, or streaming transports;
- Deployment Package connectors or Deployment Verification; or
- remote networking, endpoint exploration, production hosting, or runtime acquisition.

These capabilities are not implied defects in the closed workstream. Any future addition requires a separately named, bounded, specified, implemented, and externally accepted pass.

## Closure result

The reference implementation now has enough invocation breadth to demonstrate that PC3's architecture is publication-driven rather than tied to one command or one transport. Further adapter breadth is deferred in favor of operational refinement, reference-release hardening, and documentation of the exact supported and unsupported capability matrix.

The next action is to specify **UX-01 — Operational Refinement and Reference Release** before implementation.
