# UII-01 Pass Report

## Single-Source Test Case Selection

UII-01 implements the governing Test Case handling rule from the externally accepted ATT-01 baseline: the existing Publication Test Cases list is the only user-facing control that selects a PTC.

### Delivered behavior

- Removed the complete **Applicable realizations** block beneath the Test Cases list, including realization buttons and RTCM summaries.
- Removed the complete **Test case for [realization]** dropdown and RTCM summary from the Realizations collection.
- Removed the realization-driven effect that silently replaced the selected PTC with the first PTC applicable to a newly selected realization.
- Removed the obsolete helper, derived selection lists, and styles used only by those duplicate controls.
- Preserved the accepted publication-load initialization that selects the first declared PTC.
- Preserved direct PTC selection through the keyboard-accessible Publication Test Cases list.
- Preserved the selected PTC across IR, SR, DP, and realization-channel navigation.
- Continued to resolve the exact selected PTC/current realization pairing through the existing authoritative pairing index and immutable Resolved Exercise collection.
- Preserved explicit blocked behavior when the retained PTC and selected realization lack one authoritative applicable RTCM; no PTC or realization is substituted.
- Preserved readiness counts, applicability indexes, RTCM provenance, advanced inspection, legacy-input behavior, and the complete execution-through-attestation vertical slice.

### Selection boundary

Publication loading may initialize the first declared Test Case as accepted in UI-05-C1. After initialization, `selectedPtcId` changes only when the user activates an item in the Publication Test Cases list. Realization navigation changes realization context only.

### External verification path

1. Start PC3 and load the accepted UKO 1.1 publication.
2. Confirm the application opens on **Test Cases** and one Test Case is selected in the existing list.
3. Confirm no **Applicable realizations** section appears below the Test Cases list.
4. Select another Test Case from the list and note its identifier.
5. Open **Realizations** and confirm no **Test case for [realization]** dropdown appears.
6. Switch among IR, SR, and DP levels and select several realization channels.
7. Return to **Test Cases** and confirm the Test Case chosen in step 4 remains selected.
8. Select a realization that does not form one resolved exercise with that retained Test Case, if available, and confirm PC3 shows the bounded unavailable pairing rather than choosing another Test Case.
9. Confirm readiness counts and advanced applicability/RTCM inspection remain available.
10. Exercise the accepted canonical Python CLI pairing and confirm observation, comparison, and optional attestation behavior remain unchanged.

### Verification

Focused UI regression coverage asserts that only the Test Cases list changes `selectedPtcId`, both duplicate controls and their styles are absent, realization navigation contains no PTC mutation, exact pairing resolution remains, and unresolved-pairing blocking remains visible. `npm run verify` passes with architectural-boundary checks, TypeScript checks, **101 server tests**, **74 web tests**, and the production build.
