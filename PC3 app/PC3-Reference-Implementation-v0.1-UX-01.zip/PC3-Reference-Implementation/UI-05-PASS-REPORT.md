# UI-05 Pass Report — Publication Test Case Navigation

Date: 2026-07-19  
Implementation: `0.0.0-ui-05` / `UI-05`  
Baseline: externally validated PC3-PTC-04

## Outcome

PC3 now presents Publication Test Cases as the primary exercise-navigation objects for PTC-profile publications while preserving legacy standalone Input Object behavior.

## Implemented

- Replaces the Inputs collection with Test Cases only when `capabilityProfile.kind` is `ptc`.
- Lists each PTC by declared title, identifier, and classification.
- Presents declared purpose, canonical input, Expected Outcome, comparison type, and applicability counts.
- Supports PTC-first navigation from a test case to every explicitly applicable IR, SR, or DP realization.
- Supports realization-first navigation from a selected realization to every explicitly applicable PTC.
- Maintains one shared PTC/realization pairing state for both navigation directions.
- Resolves the same authoritative RTCM through `pairingToRtcmIdentifier`, regardless of navigation direction.
- Shows the resolved RTCM identifier in the navigation surface and its invocation, input-derivation, observation-derivation, and provenance details in the Detail Panel.
- Preserves UI-04 Inputs for the `legacy-input` profile.
- Preserves inputs and displays unresolved exercise authority for `ambiguous-mixed` without guessing.
- Does not promote a subordinate standalone input into the PTC navigation model.

## Accepted UKO 1.1 expectations

With `UKO-001-Version-1.1-Accepted.F.zip`, the accepted PC3-PTC-04 interpretation supplies:

| Projection | Expected UI-05 result |
| --- | ---: |
| Capability profile | `ptc` |
| Primary exercise collection | Test Cases |
| Publication Test Cases | 6 |
| Applicable realization pairings | 298 |
| Not-applicable pairings | 14 |
| Authoritative RTCMs | 298 |
| Realization endpoints represented | 52 |

The prior “No publication inputs declared” message is not rendered for this PTC-profile publication. Its canonical inputs are displayed within their owning PTCs.

## Acceptance-gate verification

- PTC-first and realization-first routes use the same `selectedPtcId`, selected realization endpoint, pairing key, and RTCM lookup.
- Legacy UI-04 input discovery, selection, content display, and provenance tests remain green.
- PTC profile replacement, declared-field display, bidirectional index use, and RTCM convergence have dedicated regression tests.
- Architectural dependency boundaries: passed.
- Type checking: passed.
- Server tests: 84 passed.
- Web tests: 48 passed.
- Shared tests: no test files, passed.
- Production build: passed.

## Boundary statement

UI-05 navigates and displays publication-declared exercise architecture. It does not yet create the immutable Resolved Computational Exercise, prepopulate an Exercise Attempt, execute a realization, compare an observation with the Expected Outcome, or assert conformance. Those remain later continuation-plan passes.

## External interaction check

The workspace sandbox did not permit the local preview server to bind a port. The packaged build therefore requires the established external verification workflow for visual and interactive acceptance.
