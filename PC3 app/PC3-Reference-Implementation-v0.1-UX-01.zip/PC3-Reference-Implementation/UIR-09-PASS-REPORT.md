# UIR-09 Pass Report — Dynamic Publication Load Progress

Status: **externally verified and accepted**  
Implementation identity: **0.0.0-uir-09 / UIR-09**  
Date: **2026-07-20**

## Objective

Make the several-second UKO loading interval visibly active by filling the existing Load button from left to right, without adding a modal, separate progress panel, or misleading numerical claim.

## Implemented result

- Uses the existing **Choose publication…** and **Load another…** button as the progress surface.
- Changes its label to `Loading <filename>…`, disables it, and retains `aria-busy="true"` throughout loading.
- Places a restrained blue progress fill behind the readable button label.
- Advances visual activity gradually while the server processes the publication, capped at 90 percent so elapsed time is never presented as completion.
- Advances to a known post-activation phase when activation returns.
- Reaches 100 percent only after realization-matrix preparation succeeds.
- Holds the completed fill for 180 milliseconds before restoring the normal **Load another…** action.
- Preserves the established failure state and compact error message if either activation or subsequent preparation fails.
- Keeps the control fully opaque while busy and honors reduced-motion preference by removing the fill transition.
- Shows no fabricated percentage text to the user.

## Boundary

The server does not expose byte-accurate processing progress, so the advancing portion is an activity estimate rather than a measured percentage. The important completion boundary is exact: 100 percent appears only after activation and matrix preparation finish. UIR-09 changes no acquisition, interpretation, atomic replacement, PTC/RTCM, execution, Observation, comparison, attestation, or UKO-immutability behavior.

## Automated verification

`npm run verify` passes completely:

- architectural dependency boundary check passed;
- server and web typechecks passed;
- 134 server tests passed;
- 115 web tests passed, including three focused UIR-09 assertions;
- shared package tests passed;
- production builds for shared, server, and web passed.

Focused UI coverage protects the below-completion cap, exact completion boundary, busy and disabled semantics, fill layering, readable label, reduced-motion behavior, and absence of numerical percentage text.

## External verification checklist

1. Start PC3 with no publication loaded and choose a UKO ZIP.
2. Confirm the Choose publication button becomes a disabled `Loading <filename>…` button.
3. Confirm the button visibly fills from left to right while loading and the label remains clearly readable.
4. Confirm the fill does not appear complete while PC3 is still waiting for activation.
5. Confirm it reaches the right edge when loading finishes and then becomes **Load another…**.
6. Load a replacement publication and confirm the same behavior occurs in the dashboard header.
7. If practical, attempt a malformed ZIP and confirm the normal failure message appears and the button does not remain stuck in its loading state.
8. Confirm no modal or separate loading panel has returned.

## External acceptance

UIR-09 passed external verification and was accepted on 2026-07-20.
