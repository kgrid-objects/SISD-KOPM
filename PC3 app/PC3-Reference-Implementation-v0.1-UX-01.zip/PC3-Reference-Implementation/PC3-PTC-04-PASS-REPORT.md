# PC3-PTC-04 Pass Report — Publication Capability Profiles and Compatibility

Date: 2026-07-19  
Implementation: `0.0.0-pc3-ptc-04` / `PC3-PTC-04`  
Baseline: externally validated PC3-ARCH-PTC-01 addenda and PC3-PTC-03-C1 implementation

## Outcome

PC3 now makes publication exercise authority explicit and deterministic while preserving backward compatibility and leaving the visible UI unchanged.

## Implemented profiles

- `ptc`: complete, valid PTC declarations govern exercise behavior; coexisting standalone Input Objects remain discoverable but subordinate.
- `legacy-input`: standalone Input Objects remain authoritative only when no explicit PTC architecture is declared.
- `ambiguous-mixed`: explicit PTC authority is incomplete or invalid; PC3 preserves both sources, reports the conflict, and does not guess.
- `none`: neither exercise capability is declared; PC3 invents none.

Each interpretation exposes its selected profile, exercise authority, capability dispositions, source counts, rationale, limitations, and declaration provenance. Detection uses explicit declaration structures and capabilities, not filenames, archive names, directory names, or bare version strings.

## Accepted UKO 1.1 verification

Source: `UKO-001-Version-1.1-Accepted.F.zip`

| Gate | Result |
| --- | ---: |
| Publication identity | `UKO-001` |
| Resources acquired | 2,983 |
| Implementation Representations | 14 |
| Service Realizations | 30 |
| Deployment Packages | 8 |
| Standalone Input Objects | 0 |
| Publication Test Cases | 6 |
| RTCMs | 298 |
| Applicable pairings | 298 |
| Not-applicable pairings | 14 |
| Complete realization readiness records | 52 |
| Capability profile | `ptc` |
| Exercise authority | `publication-test-cases` |
| Publication validation | `valid` |
| Validation issues | 0 |
| Interpretation limitations | 4 genuine unresolved references |

All four remaining limitations identify the publication-declared but unresolved `UKO-001-RCI-TYPESCRIPT-JAVASCRIPT-IR-001` reference. They do not affect PTC-profile selection, and PC3 leaves the declarations attributable and unchanged.

## Compatibility and regression verification

- Legacy UI-04 input-only fixture selects `legacy-input` and retains its input behavior.
- A valid coexistence fixture selects `ptc`, preserves its standalone input, and marks that input capability subordinate.
- Incomplete and invalid PTC fixtures select `ambiguous-mixed` with unresolved exercise authority.
- A capability-free fixture selects `none` without inference.
- Architectural dependency boundaries: passed.
- Type checking: passed.
- Server tests: 84 passed.
- Web tests: 45 passed.
- Shared tests: no test files, passed.
- Production build: passed.
- Visible UI source: unchanged except package version metadata.

## Boundary statement

Capability-profile selection establishes interpretation authority only. It does not execute realizations, establish runtime availability, assert scientific validity, repair publication declarations, or declare conformance.
