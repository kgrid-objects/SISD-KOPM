# ATT-01 Pass Report

## Attested PTC Exercise Evidence

ATT-01 extends the accepted evidence architecture over the complete PTC-bound vertical slice established by EX-01 through OBS-02.

### Delivered behavior

- Explicit user attestation remains the only act that creates Execution Evidence; observation and comparison do not automatically attest anything.
- PTC-scoped evidence records one explicit identity chain covering publication load and identifier, PTC, RTCM, realization, Exercise Attempt, Execution Interaction, Runtime Observation, and Expected Outcome comparison.
- The canonical or exploratory input disposition, source, exact media type and value, and independent input SHA-256 are retained.
- The immutable raw observation and the separate normalized, extracted, expected, and comparison representations are preserved without substitution.
- `pass`, `fail`, `indeterminate`, and `comparison-error` remain eligible evidence facts. Attestation does not repair or reinterpret them.
- External executor and environment descriptions remain in the complete provenance record.
- Exact PC3 implementation name, version `0.0.0-att-01`, and development pass `ATT-01` are disclosed.
- SHA-256 with `pc3-canonical-json-v1` covers the attested exercise record and PC3 identity.
- PTC evidence creation is rejected if its PTC/RTCM/realization binding, observation, interaction, or comparison identity is missing or inconsistent.
- The Pub Board exposes the complete bounded chain and digest before saving.
- Saving remains optional and external to the UKO, using Execution Evidence record schema `2.0`; discard removes only ephemeral evidence.
- Legacy non-PTC Runtime Observation evidence remains available with an explicit `runtime-observation-with-provenance` scope rather than being mislabeled as a complete PTC chain.

### Attestation boundary

PC3 attests only that it faithfully composed and integrity-bound the identified record. It does not attest publication conformance, realization conformance, computational correctness, scientific validity, safety, reproducibility, or independent verification. `cryptographicSignatureDisposition` remains `not-implemented`; the SHA-256 digest is an integrity digest, not a digital signature.

### External verification path

1. Start the application and load the accepted UKO 1.1 publication.
2. Select `UKO-001-SR-PYTHON-COMMAND-LINE` with `UKO-001-PTC-001`.
3. Prepare and run the canonical publication-declared reference exercise.
4. Confirm **Check** shows the immutable raw observation and its Expected Outcome comparison.
5. In **Execution Evidence**, select that observation and choose **Attest as Execution Evidence**.
6. Confirm the evidence summary shows the comparison status and a SHA-256 digest.
7. Open **Inspect attested record before saving** and verify publication, PTC, RTCM, realization, attempt, input disposition and hash, raw identity and hash, normalization disposition, comparison status and semantics, executor/environment, PC3 identity, covered-content label, and full digest.
8. Confirm the attestation language excludes conformance, correctness, scientific validity, and safety. A comparison `fail` must remain a `fail` inside the evidence.
9. Choose **Save** and confirm the downloaded JSON has `recordType: pc3-execution-evidence`, `recordSchemaVersion: 2.0`, version `0.0.0-att-01`, pass `ATT-01`, and the same evidence chain and digest.
10. Confirm saving does not alter the UKO. Discarding ephemeral evidence must leave the Runtime Observation and comparison intact.

### Verification

Automated coverage includes complete-chain creation and optional saving, required comparison linkage, mismatched-chain rejection, canonical input disposition and hashing, failed-comparison preservation, PC3-identity digest sensitivity, evidence immutability, legacy evidence compatibility, UI pre-save inspection, and all accepted predecessor behavior. `npm run verify` passes with architectural-boundary checks, TypeScript checks, **101 server tests**, **72 web tests**, and the production build.
