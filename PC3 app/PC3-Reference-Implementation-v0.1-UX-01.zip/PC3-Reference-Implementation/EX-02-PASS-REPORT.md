# EX-02 Pass Report

## First Complete Reference Execution

EX-02 completes the continuation plan's first deliberately narrow publication-driven execution path:

`UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE`

### Delivered behavior

- Execution begins only from an immutable canonical EX-01 attempt bound to the exact PTC, unique authoritative RTCM, and Python Command Line service realization.
- PC3 requires one explicit service declaration for that realization and its declared adapter asset; it does not infer either from filenames.
- The RTCM's ordered canonical fields are paired with the service declaration's ordered named CLI bindings. Missing fields, arity disagreement, ambiguity, non-CLI invocation, normalization, or a non-stdout observation contract blocks execution.
- The declared adapter and publication resources are copied into a temporary external workspace. The loaded UKO remains read-only and the workspace is removed after response capture.
- The existing local-process adapter launches `python3` without a shell and without substituting the canonical JSON through stdin.
- The immutable Execution Interaction records declaration provenance, adapter reference, concrete invocation, ordered field bindings, raw stdout, stderr, exit code, signal, timeout state, and outcome.
- Failed and indeterminate processes remain captured interactions. PC3 does not replace stderr with a synthetic response, repair output, normalize raw stdout, or convert an external failure into a PC3 success.
- Declared comparison type and tolerance are retained as `declared-not-yet-evaluated`. EX-02 does not implement OBS-01 observation scoping or OBS-02 comparison.
- The Pub Board presents a dedicated **Run publication-declared reference** action for the supported canonical pairing. The manual external-process surface remains available under progressive disclosure.

### Architectural boundary

PC3 coordinates and observes an external operating-system process. It does not execute realization code in the PC3 server process, mutate the UKO, provision the Python environment, authenticate realization identity, independently verify the result, evaluate comparison, assert scientific validity, or assert conformance.

### External verification path

1. Load and activate the accepted UKO 1.1 publication.
2. Select `UKO-001-SR-PYTHON-COMMAND-LINE` and `UKO-001-PTC-001`.
3. Prepare a **Canonical** attempt.
4. In Execute, confirm the **EX-02 reference path** card appears; no executable or arguments need to be entered.
5. Choose **Run publication-declared reference**.
6. Confirm Latest output contains the adapter's exact stdout and the outcome is completed, failed, or indeterminate as reported by the child process.
7. Confirm the reference action states that comparison is not yet evaluated.

### Verification

The repository suite includes successful reference execution, exact canonical argument construction, raw stdout preservation, exceptional exit/stderr retention, rejection of exploratory use, and all previously accepted tests. `npm run verify` passes with 92 server tests, 67 web tests, architectural-boundary checks, TypeScript checks, and the production build.

For a direct archive smoke test without opening a network listener, run `npm run smoke:ex02 -- /absolute/path/to/accepted-uko.zip`. The command reports the exact outcome, stdout, stderr, exit code, and constructed invocation. A failed child process is a successfully captured EX-02 interaction, not a PC3 transport failure.
