# PC3 Reference Implementation Baseline

Current baseline: **UX-01 — Operational Refinement and Reference Release**

EX-03 workstream status: **closed; constituent passes externally accepted**

UIR workstream status: **closed; UIR-01 through UIR-09 externally accepted**

Implementation identity: **0.1.0 / UX-01**

UX-01 status: **passed external verification and accepted on 2026-07-20**

PC3 v0.1 release status: **accepted on 2026-07-20**

UX-01 conservatively completes the specified v0.1 release-refinement scope: reviewed keyboard/accessibility behavior, indexed dense realization lookups, explicit exception and capability documentation, release-level session isolation regression, exact visible implementation disclosure, Accepted.F end-to-end verification, and completed release traceability. It adds no modality and changes no publication or computational semantics. See `UX-01-PASS-REPORT.md` and `docs/release/UX-01-RELEASE-VERIFICATION.md`.

SEC-01 status: **passed external verification and accepted on 2026-07-20**

SEC-01 bounds ZIP and directory acquisition by compressed bytes, resource count, per-resource bytes, aggregate expanded bytes, and safe portable paths before oversized resources are accepted. It preserves the accepted corpus, exact runtime matching, digest-pinned disposable Docker isolation, bounded output, and forced cleanup; proves absent runtime mappings cannot invoke an adapter; and suppresses temporary host mount paths from operational records. These controls reduce exposure and do not make an arbitrary publication or executable safe. See `SEC-01-PASS-REPORT.md` and `docs/security/SEC-01-BOUNDARIES.md`.

UIR-09 is the terminal UIR implementation baseline. The user-directed UIR workstream closed on 2026-07-20 after external acceptance of UIR-01 through UIR-09. UX-01 subsequently completed and closed the accepted PC3 v0.1 release gate; no additional v0.1 pass is implied or queued.

UIR-09 turns the existing publication Load button into a left-to-right visual activity indicator while loading. Its estimated motion remains capped below completion; it reaches 100 percent only after publication activation and realization-matrix preparation complete. The label stays readable, the busy button stays disabled and accessible, failure behavior is preserved, and reduced-motion preference is honored. UIR-09 passed external verification and was accepted on 2026-07-20.

UIR-08 makes IR, SR, and DP entries understandable without changing realization identity. It prefers explicitly declared publication titles, otherwise uses the complete identifier, and shortens only an exact active-publication/layer prefix within the Realization Level list. Rows use a compact two-line identity hierarchy with a fixed Exercise column; long pathway-chain prose moves out of the list while remaining in the Instrument Display and Detail Panel. Full identifiers remain accessible and unchanged everywhere else. UIR-08 passed external verification and was accepted on 2026-07-20.

UIR-07 gives the complete right-hand Instrument Display one restrained vacuum-fluorescent-display treatment: near-black glass, high-legibility cyan-white text, muted cyan labels, and amber/red reserved for exceptional status. It covers realization output, test-case and resolved-exercise review, legacy input display, observation inspection, and empty states. Prose remains conventionally readable, readout values use monospaced tabular forms, glow stays subtle, and there is no animation or new readout interaction. UIR-07 passed external verification and was accepted on 2026-07-20.

UIR-06 adds one accessible Open/Close windowshade to the loaded dashboard. The publication, readiness, control, and Load action remain visible in the permanent header band. The 12 numeric readouts, opportunity-coverage table, and four rounded status readouts collapse and reopen as one animated body, releasing vertical space so the panels below move upward. UIR-06 passed external verification and was accepted on 2026-07-20.

UIR-05 removes internal scrollbars and fixed list heights from Test Cases, Realizations, and Observations so all three collections expand naturally in page flow. It changes **Publication exercise authority** to **Test Level** and the Observations **Active collection** label to **Observation Level**. UIR-05 passed external verification and was accepted on 2026-07-20.

UIR-04 removes the modal publication loader and its dimmed backdrop. The empty console offers a direct **Choose publication…** action that opens the operating-system file chooser and loads immediately after selection; the active console offers **Load another…**. Loading and failure feedback remain compact, chooser cancellation is inert, and failed replacement preserves the active publication. The specified empty-shell instructional clutter is removed. UIR-04 passed external verification and was accepted on 2026-07-20.

UIR-03 relocates the complete Publication declarations checks-and-limitations presentation from above the left-hand collection tabs into the Detail Panel. This raises Test Cases, Realizations, and Observations to the top of the control panel without deleting declaration material. It also removes the visible **Normally closed** wording while preserving the Detail Panel's default closed behavior. UIR-03 passed external verification and was accepted on 2026-07-20.

UIR-02 changes the primary user-facing application-view heading from **Pub Board** to **Console View**. It changes no board structure, interaction, accessibility region, execution, observation, comparison, attestation, or publication semantics. UIR-02 passed external verification and was accepted on 2026-07-20.

UIR-01 is a user-directed short UI refinement implemented after the accepted EX-03 workstream. It moves the realization filter to the Realizations upper band as a single pressed-state **Limit** toggle and makes the filtered population exactly match rows whose blue Exercise actions are enabled. No invocation, observation, comparison, or publication semantics change. UIR-01 passed external verification and was accepted on 2026-07-20.

EX-03 closed on 2026-07-20 with EX-03F as its terminal pass. Additional invocation families remain deferred to separately named and specified future work.

EX-03F adds declaration-derived negative-condition planning and structured semantic rejection comparison to the accepted Python REST path. Accepted.F PTC-005 and PTC-006 become exercisable when the pinned Python environment is ready. PTC-004 remains disabled because its canonical PSD omission conflicts with its RTCM age omission. EX-03F passed external verification and was accepted on 2026-07-20.

EX-03E-C1 corrects the bounded Python REST path so the comparison extractor follows the explicit REST response mapping instead of imposing the CLI-shaped `result.risk` path. For accepted.F, `body.result` mapped from `implementation.result` resolves to response path `result`; the immutable raw response remains unchanged and the resulting numeric comparison may truthfully pass or fail. EX-03E-C1 passed external verification and was accepted.

The pass supports only a declared JSON `POST` route hosted from the publication's framework-neutral Python adapter inside the existing digest-pinned Python environment. It retains method, route, request mapping, status, headers, response body, adapter envelope and evidence, binding, implementation, environment, and cleanup provenance. It adds no remote networking, production hosting, other HTTP methods or languages, gRPC, messaging, MCP, or Deployment Package connector.

EX-03D-C3 corrects the externally observed .NET workload-integrity diagnostic that preceded otherwise successful adapter JSON on stdout. The container disables SDK-owned workload integrity checks, workload-update notifications, telemetry, and the SDK logo through documented .NET CLI environment controls. PC3 does not filter, trim, or rewrite adapter stdout. EX-03D-C3 passed external verification and was accepted on 2026-07-19.

EX-03D adds one declaration-driven C#/.NET 8 CLI Service Realization path through the accepted generic planner, exact adapter match, digest-pinned Docker provider, canonical Exercise, Observation, Comparison, Attestation, and UII-06 dashboard projection. Its external runs exposed the bridge launch-path, referenced-project restore, and SDK stdout-diagnostic defects corrected by EX-03D-C1, EX-03D-C2, and EX-03D-C3.

UII-06 adds a server-owned exact PTC–realization pairing projection and one compact dashboard matrix over the externally accepted EX-03-NP1 baseline. UII-06 passed external verification and was accepted on 2026-07-19.

EX-03-NP1 extends the externally accepted EX-03C baseline with explicit Python library-function invocation and return-value observation. EX-03-NP1 passed external verification and was accepted on 2026-07-19.

EX-03C provisions one constrained disposable Docker environment for an exactly resolved canonical CLI exercise using an explicitly mapped digest-pinned image. Docker and image readiness are operational state and never publication truth.

## Accepted predecessor: EX-03B — Adapter Capability Resolution

EX-03B resolves each immutable generic RTCM plan against explicit registered-adapter capabilities. Exactly one invocation-mode, realization-layer, observation-contract, and runtime match is required; zero and multiple matches remain bounded without registration-order preference or fallback. The retained execution record identifies the selected adapter, version, capability, canonical runtime, declared runtime requirement, launcher, and resolution basis.

EX-03B did not provision environments or add another runtime or transport. EX-03C now consumes that accepted capability result without changing its meaning.

## UII-05 — Dashboard Data Alignment

The upper dashboard permanently exposes twelve aligned numeric readouts: PTC Complete/Partial/None/N/A, RZN Complete/Partial/None/N/A, and the black IR/SR/DP/TOTAL pathway inventory. Each group retains its exact accepted data source and population, while every box shares one height, numeric baseline, lower-label baseline, and compact visual rhythm. The former completeness heading, context toggle, projection mode, disabled mode, and publication-reset state are removed. PTC-less publications retain an explained zero-valued PTC group, and responsive layouts wrap only complete four-box groups.

The prominent Exercise Model capability banner is removed from the left control panel. The bounded publication result is presented as **Declaration checks**, and the exercise-model classification is retained within the normally closed advanced publication details together with its authority and rationale.

## UII-04 — Observation Rendering (accepted prerequisite)

The Observations collection now renders the exact selected Runtime Observation as a read-only operational object. Its immutable identity and raw value, realization and PTC/RTCM scope, execution outcome, and exact separately stored comparison are directly inspectable. Engineering provenance, external-process diagnostics, environment assurance, and exactly associated Evidence remain progressively disclosed in the normally closed Detail Panel. Observation selection remains stable across collection switching, clears when stale or on publication replacement, and is never silently replaced by a newer Observation.

Observation history exists only in the left Observations collection. The redundant right-hand Session Observations and per-Observation Evidence panels, individual save/discard actions, and observation-by-observation attestation are removed; Latest output occupies the reclaimed space. One **Attest** action immediately left of the Observations count is PC3's sole formal save function and emits one integrity-bound artifact covering every current Observation. Inspection itself remains read-only and the formal artifact remains external to the UKO.

## UII-03 — One-Click Canonical Exercise from Realization Lists (accepted prerequisite)

Every visible IR, SR, and DP realization row now has one small, separate, accessible **Exercise** action. For the currently supported UKO-001 canonical CLI pairing, one click retains the Test Case selected in the sole Test Cases list, selects the target realization, prepares a fresh immutable publication-canonical attempt, executes through the accepted external reference path, captures a new Runtime Observation, and refreshes the separate Expected Outcome comparison. Repeated exercises preserve distinct history. Unsupported or unresolved pairings remain visible with disabled controls and accessible reasons but no persistent text beneath the buttons. The superseded right-hand Prepare and Run modules are removed, leaving the Instrument Display focused on results, observation history, and attestation. No new invocation mode is inferred, and saving or attestation is never automatic.

## UII-02 — Show Exercisable Realizations Toggle (accepted prerequisite)

One accessible On/Off filter at Realization Level switches between all pathways and only endpoints having a materialized Resolved Computational Exercise for the selected PTC. The filter applies across IR, SR, and DP, updates local counts, retains explicit empty/unavailable states, resets on publication replacement, and never changes the UII-01 Test Case selection or silently chooses a realization.

## UII-01 — Single-Source Test Case Selection (accepted prerequisite)

The Publication Test Cases list is the sole user-facing PTC selection surface. Applicable-realization buttons beneath that list, the realization-level Test Case dropdown, and realization-driven automatic PTC substitution are removed. Publication load may initialize the first declared PTC; afterward the selected PTC persists until the user selects another from the Test Cases list. Exact pairing resolution, blocked incompatible states, readiness, applicability indexes, progressive RTCM inspection, and all ATT-01 operational semantics remain intact.

## ATT-01 — Attested PTC Exercise Evidence (accepted prerequisite)

Explicit attestation preserves one complete immutable PTC exercise chain from publication and resolved PTC/RTCM/realization identities through the attempt, input disposition, external interaction and environment, raw observation, and separate comparison result. Each Evidence integrity digest covers that exercise record plus exact PC3 identity. UII-04 exposes this accepted infrastructure only through one formal collection artifact covering all current Observations. Attestation remains a faithful-record claim only and explicitly excludes conformance, correctness, scientific validity, safety, and independent verification.

## OBS-02 — Expected Outcome Comparison (accepted prerequisite)

A deterministic service now evaluates the accepted Python CLI reference observation against its canonical Expected Outcome. It retains raw, separately normalized, extracted, expected, and comparison representations and returns pass, fail, indeterminate, or comparison-error. The comparison never mutates the Runtime Observation and explicitly remains `comparison-result-not-conformance`.

## OBS-01 — PTC-Scoped Observation Capture (accepted prerequisite)

Runtime Observations now carry exact PTC/RTCM/realization scope when the originating attempt is publication-bound. A separately identified and hashed raw observation remains independently inspectable. RTCM extraction provenance and normalization declarations are retained without applying either, and properties are explicitly classified as directly observed, externally reported, or PC3-derived. Comparison remains OBS-02 work.

## EX-02 — First Complete Reference Execution (accepted prerequisite)

EX-02 adds one complete publication-driven vertical slice for `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE`. It resolves the canonical attempt's immutable PTC/RTCM/realization binding, constructs the CLI command from explicit RTCM and service declarations, invokes the declared adapter in a temporary external process, and immutably records raw and exceptional results without repair. Comparison semantics are preserved but not evaluated.

Verified predecessor: **PC3-PTC-02 — UKO 1.1 Discovery Architecture** (externally validated)

This baseline preserves the accepted four-component Pub Board shell, integrated main-screen Load action, and three-context Session Collection Panel.

## EX-01 — PTC-Bound Exercise Attempt Integration (accepted prerequisite)

The existing immutable Exercise Attempt is now attributable to a uniquely resolved PTC/realization/RTCM chain whenever PTC authority governs the publication. Its input snapshot records whether it came from the publication's canonical input or from an explicit exploratory user request. Canonical preparation uses the Resolved Exercise as authority and cannot be silently replaced by client-supplied content. Invalid, incomplete, absent, ambiguous, and non-applicable PTC resolutions are rejected before storage. Preparation remains distinct from execution, and execution continues through the existing external adapter boundary.

## UI-10 — Dashboard Exercise Completeness Projection

One four-state publication exercise-completeness projection now appears in the upper dashboard immediately before the IR, SR, DP, and Total realization matrix. A compact two-context control switches that same projection between realization and PTC aggregation without duplicating the boxes. Realization aggregation is the safe default and publication-load reset state. PTC aggregation is disabled unless the active capability profile is PTC-based. Publication validation and limitations remain in the Session Collection Panel without readiness-count duplication.

## UI-08 — Advanced Publication Inspection

Advanced publication information is available through nested, normally closed disclosures in the contextual Detail Panel. Inspection includes RTCM provenance and integrity attribution, explicit applicability basis, relationship and exercise-coverage indexes, declaration authority, validation issues, and grouped unresolved or conflicting information. RTCMs remain automatically resolved subordinate objects rather than primary navigation objects.

## UI-07 — Resolved Computational Exercise

Unique, applicable, authoritative PTC/realization/RTCM pairings are materialized by the publication domain manager as immutable Resolved Exercises. The UI review surface consumes these objects without reconstructing or guessing a resolution. It presents canonical input and Expected Outcome, comparison semantics, invocation and observation mappings, external-execution boundary, environment requirements, and limitations. Review is non-executing and does not create an Exercise Attempt.

## UI-06 — Exercise Readiness and Publication Validation

Publication declaration completeness is now projected independently by realization and by PTC, using complete, partial, none, and not-applicable states. Validation status, category checks, issues, and interpretation limitations are available through progressive disclosure. Readiness labels are explicitly scoped to publication declarations and remain separate from environment, deployment, health, engagement, execution, scientific-validity, and conformance concepts.

## UI-05 — Publication Test Case Navigation

For the `ptc` capability profile, Test Cases replace standalone Inputs as the primary publication exercise collection. A user may navigate PTC-first to an applicable realization or realization-first to an applicable PTC. Both directions converge on one explicit PTC/realization pairing and the same uniquely indexed RTCM. The display presents PTC purpose, classification, canonical input, Expected Outcome, comparison semantics, and applicability. The accepted UI-04 input experience remains intact for `legacy-input`; `ambiguous-mixed` preserves declared inputs while visibly withholding an authority decision.

## PC3-PTC-04 — Publication Capability Profiles and Compatibility

Publication interpretation exposes one deterministic capability profile: `ptc`, `legacy-input`, `ambiguous-mixed`, or `none`. Valid PTC declarations govern exercise behavior; coexisting standalone inputs remain discoverable but subordinate. Standalone inputs govern only when explicit PTC architecture is absent. Explicit incomplete or invalid PTC declarations preserve all discovered sources and surface unresolved authority without inference. Detection is based solely on declaration structure and capability evidence, never paths, filenames, archive names, or bare publication versions. This pass does not change the visible UI.

## UI-04 — Input Collection Foundation

The Inputs collection now presents publication-defined input objects as first-class, read-only session artifacts.

- PC3 Interpretation recognizes explicit `inputObjects`, `inputs`, singular `inputObject`, and input-object instance metadata declarations.
- Inline values and readable referenced resources are exposed without modifying the publication.
- Input declarations retain resource path, location, SHA-256, and interpretation basis.
- The Inputs collection count reflects interpreted publication inputs.
- Selecting an input displays its content in the Instrument Display and its declaration provenance in the Detail Panel.
- Metadata-only declarations remain visible without fabricated content.

Input editing, execution from a selected input, and observation lifecycle changes remain outside this pass.


## PC3-PTC-01 — UKO 1.1 Publication Model Foundation

The internal publication model now includes first-class, immutable representations for Publication Test Cases, canonical Input Objects, Expected Outcomes, PTC/realization applicability, RTCMs, Exercise Readiness, and Resolved Exercises. Discovery and UI transition remain deferred. Existing UI-04 behavior is preserved.


## PC3-PTC-02 — UKO 1.1 Discovery Architecture

PC3 Interpretation now discovers complete canonical PTC and authoritative RTCM declarations, explicit applicability, bidirectional PTC/realization indexes, unique pairing-to-RTCM resolution indexes, and derived realization exercise readiness. Discovery remains declaration-driven and does not promote suggestive paths into architectural meaning. The externally verified UI remains unchanged.


## PC3-PTC-03 — Publication Validation and Integrity

PC3 Interpretation now validates the discovered UKO 1.1 publication exercise architecture for referential integrity, applicability consistency, inventory synchronization, declaration completeness, and fixed publication invariants. Validation is declaration-only, provenance-bearing, deterministic, and non-repairing. It does not execute realizations or assert runtime success, scientific validity, or conformance. The visible UI remains unchanged.
