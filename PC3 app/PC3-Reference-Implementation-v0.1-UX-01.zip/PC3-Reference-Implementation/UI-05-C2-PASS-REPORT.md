# UI-05-C2 Pass Report — No-Capability Collection Correction

Date: 2026-07-19  
Implementation: `0.0.0-ui-05-c2` / `UI-05-C2`  
Baseline: UI-05-C1

## Correction

The profile-aware UI previously rendered Inputs for every publication that was not in the PTC profile. This incorrectly presented an empty Inputs collection when interpretation selected the `none` capability profile.

UI-05-C2 applies the complete profile mapping:

- `ptc`: Test Cases is present and opens initially.
- `legacy-input`: Inputs is present and opens initially.
- `ambiguous-mixed`: Inputs remains present as a preserved source with unresolved-authority messaging.
- `none`: neither Test Cases nor Inputs is rendered; the board opens on Realizations and visibly reports that no exercise capability is declared.

When no exercise collection exists, the remaining Realizations and Observations tabs occupy the collection selector without an empty third slot. UKO 1.1 PTC navigation and RTCM resolution are unchanged.

## Verification

- Architectural dependency boundaries: passed.
- Type checking: passed.
- Server tests: 84 passed.
- Web tests: 50 passed.
- Production build: passed.
