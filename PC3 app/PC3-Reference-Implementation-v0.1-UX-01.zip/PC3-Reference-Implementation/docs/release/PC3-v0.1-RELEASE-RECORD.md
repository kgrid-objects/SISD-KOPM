# PC3 v0.1 Release Record

Release identity: `0.1.0 / UX-01`  
Release date: 2026-07-20  
Status: **passed external verification and accepted**

PC3 v0.1 closes the planned reference-implementation work through UX-01. The accepted release includes publication loading and interpretation, PTC/RTCM resolution, exercise-opportunity projection, the bounded Python CLI/library/REST and .NET CLI reference paths, immutable Observation capture, Expected Outcome comparison, collection attestation, the accepted Console View, SEC-01 safety boundaries, and UX-01 release hardening.

Internal verification passed architectural boundaries, strict type checks, 143 server tests, 117 UI tests, shared-package checks, and production builds. Read-only Accepted.F verification recorded 2,983 resources, 6 PTCs, 52 realizations, 298 RTCMs and resolved exercises, 55 realization pathways, zero declaration errors, and an unchanged source archive hash.

External verification confirmed the visible `Connected · v0.1.0 · UX-01` identity and Docker-backed Python CLI PTC-001 execution. Its deterministic comparison correctly returned `fail` because the realization's observed `0.1687` differs from Accepted.F's canonical `0.17099497442391187` beyond the declared `1e-12` tolerance. That is a comparison result, not a PC3 release failure or conformance determination.

The optional verifier still asserts a `pass` comparison and therefore stops before its collection-attestation step for this pairing. The user explicitly accepted this bounded auxiliary-script limitation for v0.1. PC3 runtime behavior is unaffected.

Supported and unsupported capability boundaries remain those recorded in `PC3-v0.1-CAPABILITY-MATRIX.md`. No UKO content was changed in producing or verifying this release.
