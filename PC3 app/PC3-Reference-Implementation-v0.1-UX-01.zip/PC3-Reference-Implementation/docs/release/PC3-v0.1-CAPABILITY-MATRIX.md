# PC3 v0.1 Supported Capability Matrix

This matrix describes the bounded reference implementation. “Supported” means PC3 has an explicit implementation path when the publication declarations and local prerequisites match exactly. It is not a claim of UKO conformance, scientific validity, realization correctness, or universal runtime support.

## Publication and exercise handling

| Capability | v0.1 disposition | Boundary |
|---|---|---|
| Browser-loaded publication ZIP | Supported | Read-only acquisition with SEC-01 compressed, expanded, entry-count, per-resource, and path-safety limits. |
| Local publication directory through the loader CLI | Supported | Read-only regular files; symbolic links and unsafe paths are rejected. |
| PTC, applicability, RTCM, and resolved-exercise interpretation | Supported | Explicit authoritative declarations only; no filename or executable-behavior inference. |
| Legacy declared Input Objects | Preserved | Used as primary exercise authority only for the legacy capability profile. |
| IR, SR, and DP navigation | Supported | A visible realization is not necessarily exercisable. |
| Canonical PTC attempt, Observation, comparison, and collection attestation | Supported | Each step remains a distinct PC3 record; comparison is not a conformance decision. |
| Publication authoring, repair, or mutation | Not supported | PC3 does not write to the loaded publication. |

## Reference invocation capabilities

| Capability ID | Exact supported shape | Local prerequisite |
|---|---|---|
| `python-cli-stdout.v1` | Explicit CLI RTCM for an IR, SR, or DP; one matching realization declaration; scalar ordered bindings; immutable raw stdout | Docker daemon and the pinned Python 3.12 image already present |
| `python-library-return-value.v1` | Explicit Python library-function RTCM for an IR; declared source root, entry point, identity bindings, and JSON-transportable return | Docker daemon and the pinned Python 3.12 image already present |
| `python-http-response-body.v1` | Explicit Python REST SR; declared local POST JSON operation, binding, adapter, response mapping, and supported positive or declared-negative input | Docker daemon and the pinned Python 3.12 image already present |
| `dotnet8-cli-stdout.v1` | Explicit .NET 8 CLI SR; declared project, adapter entry point, implementation project/static-method binding, scalar CLI mapping, and raw stdout | Docker daemon and the pinned .NET SDK 8.0.422 image already present |

PC3 never pulls an image during publication activation. A missing daemon, missing pinned image, ambiguous declaration, unsupported realization type, or unsupported mapping leaves the exact Exercise action disabled with an attributable reason.

## Not implemented in v0.1

- MCP invocation or AI-agent orchestration;
- messaging publish, messaging request/reply, queues, topics, or other asynchronous transports;
- Java, JavaScript/Node.js, Rust, native-binary, browser, WASM, or arbitrary runtime adapters;
- C#/.NET library IR invocation or a generic .NET execution path;
- arbitrary HTTP methods, remote service calls, or generalized API exploration;
- dependency installation from publication content or automatic Docker image pulls;
- cryptographic signing, publication conformance determination, or scientific-result validation;
- persistence of sessions after the running PC3 server process ends.

These items may be added only through later bounded passes backed by adequate publication declarations. PC3 does not substitute a nearby supported modality.
