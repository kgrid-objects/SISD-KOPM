# UX-01 Release Verification

## Conservative review outcome

- **Accessibility and keyboard:** native buttons and disclosures remain in use; collection tabs, realization levels, and listboxes retain Arrow/Home/End traversal; current selections, busy state, disabled Exercise actions, live announcements, focus visibility, coarse-pointer sizing, and reduced-motion behavior remain explicit. Accessible region naming now consistently uses **Console View**.
- **Large-publication performance:** the realization list now builds memoized indexes for realization declarations, readiness, RTCMs, resolved PTC–realization exercises, and invocation-support assessments. Rendering no longer repeatedly scans the complete resolved-exercise population for every visible realization row. Accepted-corpus verification records activation time without imposing an unreliable machine-specific threshold.
- **Exceptional conditions:** `PC3-v0.1-EXCEPTION-GUIDE.md` records the user meaning of unavailable, unsupported, blocked, not applicable, unclassified, failed, indeterminate, comparison fail, and comparison error.
- **Isolation:** the release regression suite proves independent sessions retain independent publications, matrices, and selection state. Existing atomic replacement and stale-context tests remain mandatory.
- **Identity:** the header connection readout, `/api/health`, `/api/application`, saved records, comparisons, and attestations identify `0.1.0 / UX-01`.
- **Capability boundaries:** `PC3-v0.1-CAPABILITY-MATRIX.md` lists the exact supported adapters and the modalities intentionally absent from v0.1.

## Automated gates

Run the complete repository gate:

```sh
npm run verify
```

Run the Accepted.F corpus inspection without execution:

```sh
npm run verify:accepted-corpus -- /absolute/path/to/UKO-001-Version-1.1-Accepted.F.zip
```

With Docker running and the accepted pinned Python image present, run the complete release reference pathway:

```sh
npm run verify:accepted-corpus -- /absolute/path/to/UKO-001-Version-1.1-Accepted.F.zip --exercise
```

The complete mode proves publication load, the `UKO-001-PTC-001 × UKO-001-SR-PYTHON-COMMAND-LINE` canonical attempt, external execution, immutable Observation, Expected Outcome comparison, and current-Observation collection attestation. The script hashes the supplied ZIP before and after and fails if it changes.

## External visual check

1. Confirm the header shows `Connected · v0.1.0 · UX-01`.
2. Traverse collection tabs with Left/Right and realization/list choices with Arrow keys, Home, and End; activate the focused control with Space or Enter.
3. Confirm focus remains visibly outlined and disabled Exercise actions expose a reason through their accessible label and tooltip.
4. Load Accepted.F, exercise the Python CLI PTC-001 reference pairing, inspect the resulting Observation and comparison, then use **Attest** from Observation Level.
5. Confirm unsupported or unavailable pairings remain disabled and are not silently substituted.

Passing these checks establishes the bounded PC3 v0.1 reference-release gate. It does not establish publication conformance, realization conformance, scientific validity, or safety.
