# PC3 v0.1 Exceptional-Condition Guide

PC3 uses distinct status words because they mean different things. The interface and API preserve these distinctions.

| Status | User meaning | Appropriate response |
|---|---|---|
| **Unavailable** | A required local prerequisite or record is not currently present. | Inspect the stated prerequisite; for example, start Docker or install the exact pinned image. |
| **Unsupported** | The declared modality, runtime, realization type, or mapping is outside the v0.1 capability matrix. | Do not retry unchanged. Use a later PC3 capability pass or a publication with supported declarations. |
| **Blocked** | A declared PTC–realization opportunity cannot currently enable Exercise. This is not an execution failure. | Inspect the disabled Exercise action’s reason and the Detail Panel declarations. |
| **Not applicable** | The publication explicitly says the PTC–realization pair does not apply. | No exercise is expected for that pair. |
| **Unclassified** | The publication does not deterministically place the possible pair into applicable or not-applicable. | Inspect declaration limitations; PC3 does not guess. |
| **Failed execution** | An external process or declared adapter ran but reported or produced a failed outcome. | Inspect preserved stderr, exit status, and environment detail. |
| **Indeterminate execution** | PC3 cannot truthfully classify the external outcome as completed or failed. | Inspect the Interaction and environment record; do not infer a result. |
| **Comparison fail** | The extracted observation differs from the Expected Outcome under the declared comparison contract. | Review the immutable observation and comparison representations. This is not a conformance determination. |
| **Comparison error** | PC3 could not deterministically apply the declared extraction or comparison contract. | Review the declared paths, representations, and raw observation; the raw observation remains unchanged. |

API failures retain a stable error code, a plain-language message, and a request identifier. Unexpected internal failures disclose no stack trace or host path to the browser.
