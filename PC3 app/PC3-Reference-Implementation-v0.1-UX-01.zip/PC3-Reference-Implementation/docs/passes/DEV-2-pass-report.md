# DEV-2 Pass Report — Core Domain Model

## Objective

Establish the smallest framework-neutral type foundation that keeps the principal PC3 identities, truth categories, scope relationships, and architectural ownership boundaries distinguishable before workflows are implemented.

## Baseline

- Code baseline: externally verified DEV-1 ZIP supplied by the user
- Normative authority: PC3 v1.0 Specification, Pass 11.7 baseline
- Implementation architecture: PC3 Architecture Blueprint v1.0

## Scope performed

DEV-2 introduced scope-distinct identifiers and deliberately minimal immutable records for publication loading, IOR identity, active context, realization pathways, Environment Associations, Exercise Attempts, Runtime Observations, Execution Evidence attribution, and conformance disclosure. The records live in their owning backend modules and contain no React, Fastify, Docker, SQLite, or provider SDK types.

## Design discipline

- Publication Truth is represented through read-only sourced records.
- PC3 Interpretation references are separate from publication records.
- Runtime Observation and Execution Evidence are separate model types.
- Environment Association is explicitly a PC3-owned link, not an external environment control object.
- Exercise Attempt carries fixed request-context identity and does not direct execution in this pass.
- Optional fields and state vocabularies were kept minimal to avoid turning DEV-2 into a hidden specification pass.

## Verification

- Public-registry dependency installation
- Architectural boundary enforcement
- Strict TypeScript type checking
- Existing API and configuration tests
- New identifier and ISO-instant tests
- Server, shared, and web production builds
- Clean live startup and endpoint checks

## Deferred

Behavioral aggregates, repositories, commands, transitions, publication parsing, session management, UI exposure, provider integrations, evidence composition, and persistence remain assigned to later passes.

## Next pass

DEV-3 — Read-Only Publication Loading.
