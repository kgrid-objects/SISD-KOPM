# DEV-1 Change Summary

## Added

- Backend composition root and graceful lifecycle
- Validated environment configuration
- Typed API contracts and browser API client
- Application identity endpoint
- Bounded API errors with request IDs
- Browser/server connectivity display
- Executable backend tests
- Automated dependency-boundary enforcement
- DEV-1 pass, build, traceability, and architecture records

## Changed

- Implementation version advanced from `0.0.0-dev0` to `0.0.0-dev1`
- Browser shell advanced from static DEV-0 display to live backend-connected application shell
- Verification command now includes architectural boundary checks and executable tests

## Not changed

No PC3 publication, operation, environment, observation, evidence, persistence, or published-computation behavior was implemented.
