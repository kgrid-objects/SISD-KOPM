# DEV-7 Change Summary

- Added `ExerciseAttemptManager`.
- Expanded the Exercise Attempt domain record with immutable input and endpoint snapshots.
- Added Exercise Attempt shared API contracts.
- Added attempt preparation and listing endpoints.
- Added browser input editing and prepared-attempt history.
- Added lifecycle, stale-context, selection, immutability, and no-execution tests.
- Replaced residual “operational pathway” contract terminology with “realization pathway.”
- Updated implementation identity to DEV-7 / 0.0.0-dev7.
