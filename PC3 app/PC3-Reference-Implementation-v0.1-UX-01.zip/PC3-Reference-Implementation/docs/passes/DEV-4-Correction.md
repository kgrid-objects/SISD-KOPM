# DEV-4 Portability Correction

External developer verification identified two clean-install portability defects:

1. `scripts/check-boundaries.mjs` converted `import.meta.url` to a path using `.pathname`, leaving spaces percent-encoded as `%20` on macOS.
2. `npm run dev` assumed the generated `shared/dist` output already existed after `npm ci`.

Corrections:

- use Node's `fileURLToPath()` for portable filesystem conversion;
- build the shared workspace automatically before starting development servers;
- verify the repository from an extraction path containing spaces.

No PC3 domain behavior, publication interpretation, or IOR meaning changed.
