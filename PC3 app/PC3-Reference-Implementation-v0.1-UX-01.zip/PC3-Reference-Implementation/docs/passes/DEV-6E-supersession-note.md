# DEV-6E Supersession Note

DEV-6E introduced the correct operational-endpoint model but retained `disconnected realization fragment` as a purported architectural category. DEV-6F supersedes that treatment: an SR or DP without its required predecessor chain is a pathway-integrity issue or a publication relationship inconsistency, not a valid realization fragment.
