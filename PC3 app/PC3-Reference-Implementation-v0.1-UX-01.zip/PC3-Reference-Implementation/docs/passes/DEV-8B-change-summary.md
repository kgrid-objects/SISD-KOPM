# DEV-8B Change Summary

- DEV-8 manual record endpoint is retired with HTTP 410.
- New execution-response intake endpoint automatically captures observations.
- Runtime Observation status changed from durable-sounding `recorded` to `ephemeral`.
- Observation source is no longer user-entered; it comes from the response envelope.
- Received runtime payload is preserved directly rather than reconstructed as prose.
- Optional save produces an external PC3-authored JSON record.
- Discard removes only the session-ephemeral observation.
- Browser Step 4 now waits for and displays automatic observations.
