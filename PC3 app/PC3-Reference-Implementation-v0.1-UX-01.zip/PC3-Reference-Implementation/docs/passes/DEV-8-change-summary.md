# DEV-8 Change Summary

- New immutable Runtime Observation model.
- New Runtime Observation manager and REST API.
- Source attribution: user report or external-system report.
- Explicit `reported-not-verified` execution disposition.
- Multiple observations per Exercise Attempt.
- Context and attempt integrity enforcement.
- Fourth progressively disclosed UI workflow step.
- Added domain, API, and UI conformance tests.
