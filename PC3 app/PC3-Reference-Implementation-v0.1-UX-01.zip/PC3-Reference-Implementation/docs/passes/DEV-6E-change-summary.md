# DEV-6E Change Summary

- Replaced length-based pathway completeness with operational endpoint classification.
- Added selectable IR, SR, and DP endpoint pathways.
- Added IR coverage and endpoint-type counts.
- Added non-selectable disconnected realization fragment presentation.
- Added node-sequence deduplication.
- Updated API contracts, browser UI, tests, identity, and documentation.
