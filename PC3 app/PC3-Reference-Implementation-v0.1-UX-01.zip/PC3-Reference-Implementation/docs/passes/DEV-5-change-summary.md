# DEV-5 Change Summary

Added session creation, session closure, active-context inspection, atomic publication activation/replacement, stale-context rejection, active-context browser display, and isolated manager tests. Advanced implementation identity to `0.0.0-dev5`.
