# DEV-6 Change Summary

Added:
- ExecutableRealizationMatrixProjector
- RealizationSupportResolver port
- Matrix and pathway-selection APIs
- Active-context pathway selection
- Browser Matrix and selection UI
- Matrix and selection tests

Changed:
- Implementation identity to 0.0.0-dev6
- Shared API contracts
- Active-context response
- Traceability and architecture review
