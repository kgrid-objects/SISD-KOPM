# DEV-6F Change Summary

## Added
- Complementary SR binding and DP target relationship interpretation.
- Pathway hierarchy validation.
- Pathway-integrity issue model and browser presentation.
- Publication relationship inconsistency reporting.
- Regression coverage for complementary metadata relationships.

## Removed
- `disconnected-realization-fragment` as a valid Matrix entry category.
- Disconnected-fragment counts and language from API and browser views.

## Preserved
- Every IR, SR, and DP as a valid endpoint when its required predecessor chain is resolved.
- Read-only publication handling.
- Matrix-as-projection boundary.
- Selection/exercise separation.
