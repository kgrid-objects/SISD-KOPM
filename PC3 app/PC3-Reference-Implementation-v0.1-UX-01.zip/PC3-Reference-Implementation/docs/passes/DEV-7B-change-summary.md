# DEV-7B Change Summary

- Rebuilt the browser layout around a three-step task flow.
- Added concise active-publication and selected-pathway summaries.
- Added endpoint-layer filtering and a realization-pathway chooser.
- Added details-on-demand controls for publication context, pathway chains, attempts, IOR, declarations, limitations, diagnostics, and implementation identity.
- Removed the full always-visible Matrix table from the ordinary workflow.
- Added web progressive-disclosure tests.
- Updated implementation identity to DEV-7B / 0.0.0-dev7b.
- Updated README, baseline, architecture review, build status, and traceability.
