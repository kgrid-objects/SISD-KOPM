# DEV-3 Change Summary

Added:

- read-only Publication Source Adapter port;
- Publication Loader and bounded loading outcomes;
- local-directory and ZIP acquisition adapter;
- SHA-256 resource inventory;
- publication-load CLI;
- five publication-loading tests;
- DEV-3 documentation and traceability.

Changed:

- implementation identity to `0.0.0-dev3`;
- publication model to record resource inventory and loading failures;
- public dependency lockfile to include `fflate`.

Not changed:

- browser interaction;
- publication interpretation;
- IOR, session, exercise, environment, observation, evidence, or persistence workflows.
