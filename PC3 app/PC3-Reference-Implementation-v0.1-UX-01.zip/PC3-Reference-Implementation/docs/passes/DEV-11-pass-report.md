# DEV-11 Pass Report — External Execution Adapter Foundation

DEV-11 adds an execution-adapter contract, registry, capability metadata API, and one local-process STDIO reference adapter. The adapter transmits the immutable Exercise Attempt input to a separate child process and captures stdout, stderr, exit status, signal, timeout disposition, and environment identity. The captured result enters the accepted DEV-9/10 chain as an Execution Interaction and automatic ephemeral Runtime Observation.

Realization identity assurance is explicitly limited to `reported`. DEV-11 does not verify that the launched executable is the selected UKO realization, assess computational correctness, provision environments, introduce containers, or modify the publication.
