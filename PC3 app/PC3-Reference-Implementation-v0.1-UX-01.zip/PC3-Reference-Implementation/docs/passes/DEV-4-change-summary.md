# DEV-4 Change Summary

## Added

- Publication Interpreter and interpretation model
- JSON/YAML explicit-declaration support
- interpretation provenance and limitations
- IOR Manager, nodes, edges, and construction limitations
- transient browser ZIP source adapter
- publication interpretation API
- browser load-and-interpret interface
- interpreter, IOR, and endpoint tests
- ADR-0003

## Changed

- implementation identity advanced to `0.0.0-dev4`
- application composition now supplies clock and identifier services
- loader can retain acquired resources for immediate interpretation
- shared API contracts include interpretation and IOR views
- documentation and traceability updated

## Not changed

- no active publication context
- no Matrix or selection
- no exercise, environment, observation, evidence, or persistence behavior
