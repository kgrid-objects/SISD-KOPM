# DEV-2 Change Summary

## Added

- Scope-distinct branded identifiers for principal PC3-owned records
- Clock and identifier-generator ports
- Read-only publication identity, source-reference, and load-record foundations
- IOR, pathway, active-context, and Exercise Attempt boundary records
- Environment Association boundary record
- Runtime Observation boundary record
- Execution Evidence identity and attribution boundary record
- Conformance declaration boundary record
- Domain-model tests
- Externally verified developer setup documentation

## Updated

- Implementation identity to `0.0.0-dev2`
- Existing API identity tests
- README, traceability, pass records, and architectural review
- Public npm lockfile

## Removed

- macOS `__MACOSX` and AppleDouble packaging residue
- Generated dependency and build directories from the handoff archive

## Explicitly not implemented

No loading workflow, interpretation workflow, IOR construction, session management, pathway selection, external environment coordination, Runtime Observation intake, Execution Evidence generation, persistence, or new user interface behavior.
