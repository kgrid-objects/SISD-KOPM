# PC3 Developer Setup

Verified external developer baseline used for DEV-3:

- Apple Silicon macOS
- Homebrew 6.0.11
- Node.js 22.23.1
- npm 10.9.8
- Git 2.24.3 or later
- Python 3.11.4 or later
- Docker 29.6.1 or later (not required until Docker integration)

## Clean verification

```bash
npm ci
npm run verify
npm run dev
```

Open `http://localhost:5173` after `npm run dev`.

Dependency lockfiles SHALL resolve only through publicly accessible package registries. Do not edit `package-lock.json` by hand.

## DEV-3 external check

After `npm run verify`, test the loader against a local directory or ZIP using the command documented in the root README. Confirm the source remains unchanged.
