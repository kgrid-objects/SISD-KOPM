# DEV-8 Architecture Review

Runtime Observation is an observation record owned by PC3, not a runtime object and not a publication artifact. It is subordinate to its Exercise Attempt and active context.

The observation source is mandatory because PC3 must not convert an unattributed assertion into apparent execution truth. The `reported-not-verified` disposition prevents a recorded report from being mistaken for verified execution or formal Execution Evidence.

Multiple observations are permitted because one Exercise Attempt may receive retries, updates, or reports from more than one external source. DEV-8 does not decide equivalence, correctness, or evidentiary weight among those reports.
