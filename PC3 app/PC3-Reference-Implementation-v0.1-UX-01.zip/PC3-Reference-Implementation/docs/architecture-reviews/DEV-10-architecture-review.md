# DEV-10 Architecture Review

DEV-10 preserves the separation among the UKO publication, PC3, and the external execution environment.

The Runtime Observation remains the automatically captured account of an external response. Execution Evidence is a new PC3-authored evidentiary artifact created only by an explicit attestation act. It includes the observation and the provenance needed to interpret it independently of the active session.

The attestation is carefully bounded to faithful record composition. It does not convert unverified runtime reporting into a claim of correct execution. The SHA-256 digest protects the integrity of the packaged observation and provenance but is not represented as a cryptographic signature. Saving remains optional and external; no UKO content is written or modified.
