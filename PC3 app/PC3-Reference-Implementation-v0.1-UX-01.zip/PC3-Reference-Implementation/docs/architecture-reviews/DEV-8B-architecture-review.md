# DEV-8B Architecture Review

DEV-8B restores the correct division of responsibility.

The user does not reconstruct runtime facts that PC3 already receives. An external adapter owns execution interaction. PC3 owns intake and automatic observation capture. The active Runtime Observation remains ephemeral unless the user affirmatively saves a separate PC3-authored record.

This does not collapse the UKO, PC3, and execution environment into one system:

- the UKO supplies publication truth and is never modified;
- PC3 prepares attempts, receives responses, and preserves observations;
- the external environment performs execution;
- a saved observation record remains external and non-evidentiary.

The intake API is an architectural seam for later adapters, not an execution implementation.
