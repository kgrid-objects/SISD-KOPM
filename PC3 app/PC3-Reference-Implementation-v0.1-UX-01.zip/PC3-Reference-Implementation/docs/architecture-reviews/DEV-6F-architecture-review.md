# DEV-6F Architectural Review

| Invariant | Result |
|---|---|
| Every IR terminates a valid IR pathway | PASS |
| Every selectable SR pathway begins at an IR | PASS |
| Every selectable DP pathway passes through SR and IR | PASS |
| No realization-layer bypass is used | PASS |
| Missing predecessor chains are not treated as valid fragments | PASS |
| Publication relationships are derived from explicit declarations | PASS |
| Repository folder names are not architectural authority | PASS |
| Publication remains read-only | PASS |
| Matrix remains a projection over the IOR | PASS |
| Selection remains separate from exercise | PASS |
| Actual accepted UKO produces zero pathway-integrity issues | PASS |

The accepted UKO also contains four explicit JavaScript MCP references to `UKO-001-RCI-TYPESCRIPT-JAVASCRIPT-IR-001`, which is not a declared IR identifier. PC3 reports these as publication relationship inconsistencies without replacing the identifier or fabricating a relationship. The same SR remains pathway-connected through authoritative instance metadata.
