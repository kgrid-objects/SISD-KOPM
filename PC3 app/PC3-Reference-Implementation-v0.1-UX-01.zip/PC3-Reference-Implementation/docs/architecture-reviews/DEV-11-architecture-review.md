# DEV-11 Architecture Review

The local-process adapter belongs to PC3 as a boundary-coordination mechanism. The child process is the external execution environment. The adapter does not move runtime responsibility into PC3. Publication artifacts remain read-only, observations remain ephemeral, saving remains optional, and attestation retains its bounded DEV-10 meaning.
