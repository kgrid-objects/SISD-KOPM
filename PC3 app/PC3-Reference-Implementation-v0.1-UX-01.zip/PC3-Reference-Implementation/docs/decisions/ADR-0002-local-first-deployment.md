# ADR-0002: Local-First Deployment

**Status:** Accepted  
**Date:** 2026-07-16

PC3 shall be runnable locally throughout development. Development mode uses separate frontend and backend processes. A later production pass will compile the frontend and serve it from the backend as one application. Containerized web hosting follows successful local production operation.
