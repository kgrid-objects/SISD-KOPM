# ADR-0003 — Explicit Declaration Interpretation Profile

## Status

Accepted for the PC3 Architectural Reference Implementation DEV-4.

## Decision

The reference interpreter reads explicit JSON and YAML declaration documents and retains resource-path, resource-digest, and document-location provenance for every interpreted declaration. It recognizes a deliberately small set of neutral identity, realization, and relationship keys documented in the repository README.

Repository directory names, file placement, and filenames are not converted into architectural meaning in DEV-4. No provisional structure inference is implemented. Absence or incompatibility of explicit declarations produces visible interpretation limitations.

## Rationale

The PC3 specification gives declared relationships and metadata priority and permits repository structure only as a secondary discovery source. Beginning with explicit declarations protects Publication Truth, makes PC3 Interpretation auditable, and avoids publication-specific branching in the application core.

## Boundary

This profile is implementation-specific technical design. It is not a normative UKO metadata specification, publication conformance rule, or claim that all possible publication declarations are supported.
