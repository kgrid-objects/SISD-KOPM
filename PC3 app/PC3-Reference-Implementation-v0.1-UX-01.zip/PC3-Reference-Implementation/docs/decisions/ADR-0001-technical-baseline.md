# ADR-0001: DEV-0 Technical Baseline

**Status:** Accepted for the Architectural Reference Implementation v0.1  
**Date:** 2026-07-16

## Decision

Use a conventional modular-monolith web application with three build units:

1. React/Vite browser application (`web`)
2. TypeScript/Fastify backend (`server`)
3. Small framework-neutral contract package (`shared`)

Use npm workspaces, explicit internal module boundaries, constructor or composition-root dependency injection, SQLite in a later persistence pass, and Docker as the first external execution-environment provider in a later integration pass.

## Rationale

This is a mainstream, locally runnable web stack. It preserves a clear frontend/backend boundary while avoiding premature microservices and excessive package fragmentation.

## Constraints

- Domain modules may not depend on React, Fastify, Docker SDKs, or SQLite APIs.
- Publication access must remain read-only.
- External execution must occur outside the PC3 process.
- Technical choices do not redefine specification behavior or blueprint ownership.
