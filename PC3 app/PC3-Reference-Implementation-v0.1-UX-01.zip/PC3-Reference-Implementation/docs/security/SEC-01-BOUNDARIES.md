# SEC-01 Publication Intake and Execution Safety Boundaries

SEC-01 adds bounded defensive controls for PC3 v0.1 preparation. These controls reduce accidental and hostile resource use; they do not establish that a publication or its executable content is safe.

## Publication intake

Browser ZIP upload is limited to 256 MiB compressed by default. Before accepted entries are inflated, PC3 inspects ZIP metadata and applies these defaults:

- no more than 10,000 entries;
- no more than 512 MiB aggregate expanded bytes;
- no more than 192 MiB for one expanded entry;
- no absolute, parent-traversing, Windows-drive, null-containing, or portable case-colliding resource paths.

Local-directory acquisition applies the same count, aggregate, and per-resource bounds before reading each regular file. Symbolic-link roots and entries remain rejected. Archive parsing remains in memory and does not create filesystem links or preserve archive operating-system entry types.

Operators may lower the defaults with `PC3_MAX_UPLOAD_BYTES`, `PC3_MAX_PUBLICATION_RESOURCES`, `PC3_MAX_PUBLICATION_EXPANDED_BYTES`, and `PC3_MAX_PUBLICATION_RESOURCE_BYTES`. Raising them increases memory and denial-of-service exposure. Accepted.F requires more than 127 MB for its largest expanded resource, so the bounded 192 MiB per-resource default is intentional.

## Canonical reference execution

Supported canonical reference pathways require one exact registered adapter capability and one explicit digest-pinned Docker runtime mapping. An absent or ambiguous mapping disables execution; it never selects by registration order or falls back to host computation.

Disposable containers retain:

- network mode `none`;
- read-only root filesystem;
- read-only publication mount;
- all Linux capabilities dropped;
- `no-new-privileges`;
- non-root UID and GID `65532:65532`;
- bounded CPU, memory, swap, process count, temporary storage, and wall-clock time;
- forced container removal after completed, failed, or exceptional outcomes.

The .NET bridge retains a separately writable infrastructure mount because compilation requires build output. It remains inside the constrained container and is deleted by PC3 after the attempt. Python library and HTTP bridge mounts remain read-only.

External process stdout and stderr share a five-million-byte capture limit. Execution interactions independently reject response values above five million characters. PC3 does not expose its temporary host publication-mount path through operational environment records.

## Residual boundary

Docker isolation is defense in depth, not a security proof. PC3 v0.1 should be used on a controlled local workstation with trusted Docker administration. It does not authenticate realization identity, inspect executable intent, certify container-engine security, or establish publication, computational, scientific, or safety conformance.
