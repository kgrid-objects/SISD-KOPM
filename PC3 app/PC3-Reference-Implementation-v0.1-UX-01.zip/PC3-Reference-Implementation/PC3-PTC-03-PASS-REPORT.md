# PC3-PTC-03 Pass Report — Publication Validation and Integrity

## Baseline

`PC3-Reference-Implementation-v0.1-PC3-PTC-02` (externally validated)

## Result

PC3-PTC-03 transforms the declaration-driven UKO 1.1 publication exercise graph into a rigorously validated architectural model. Validation remains subordinate to Publication Truth, preserves the publication unchanged, and introduces no visible UI behavior change.

## Implemented

- Added a dedicated, immutable Publication Validation Report to PC3 Interpretation and its shared API contract.
- Validates five explicit lanes:
  - referential integrity;
  - applicability consistency;
  - inventory synchronization;
  - declaration completeness;
  - publication invariants.
- Detects duplicate PTC, RTCM, and applicability declarations before discovery collapses them into deterministic operational indexes.
- Validates RTCM references to canonical PTCs and executable realizations.
- Validates RTCM realization-layer agreement and canonical pairing keys.
- Resolves path-bearing declaration references against the ZIP resource inventory without extracting or modifying the publication.
- Requires every discovered realization/PTC pairing to have an explicit applicability determination.
- Requires every applicable pairing to possess exactly one authoritative applicable RTCM.
- Rejects applicable RTCMs for canonically non-applicable pairings.
- Synchronizes declared PTC applicability counts with enumerated applicability and the discovered realization inventory.
- Verifies that PTC, RTCM, bidirectional relationship, and pairing indexes remain synchronized with their source declarations.
- Validates required PTC and RTCM declaration content.
- Enforces the fixed architectural invariants that an RTCM:
  - does not embed runtime behavior;
  - preserves raw observations;
  - permits a failed comparison result;
  - does not assert conformance.
- Returns a bounded `not-applicable` result when no UKO 1.1 PTC architecture is declared, preserving the existing non-PTC interpretation path for the later compatibility pass.
- Updated the exact implementation identity to `0.0.0-pc3-ptc-03` / `PC3-PTC-03` throughout runtime metadata and evidence provenance.

## Validation semantics

The report status is one of:

- `valid` — all declaration-integrity checks passed;
- `valid-with-warnings` — no errors were found, but non-authoritative declarations were observed;
- `invalid` — one or more declaration-integrity errors were found;
- `not-applicable` — no PTC/RTCM architecture was discovered.

Every issue is categorized, severity-bearing, deterministic, and includes PTC, realization, RTCM, resource, and declaration-location provenance when available.

Publication validation does not:

- execute a realization;
- inspect runtime observations;
- claim runtime availability or success;
- establish scientific validity;
- assert conformance;
- repair, rewrite, or supplement publication declarations.

## Deliberately deferred

PC3-PTC-03 does not yet:

- select UKO 1.0 versus UKO 1.1 interaction modes;
- replace the Inputs collection with Test Cases;
- present validation, PTCs, readiness, or RTCM detail in the visible UI;
- execute resolved exercises;
- capture or compare PTC-scoped runtime observations.

Those responsibilities remain assigned to PC3-PTC-04 and subsequent roadmap passes.

## Verification

- Architectural dependency boundary check passed.
- TypeScript checks passed.
- Server tests: 74 passed.
- Web tests: 45 passed.
- Shared tests passed.
- Production build passed.
- Focused validation coverage includes:
  - a complete, valid declaration graph;
  - all five validation lanes failing independently within a malformed graph;
  - duplicate declarations retained for validation before deterministic discovery collapse;
  - bounded behavior when PTC validation is not applicable;
  - integration through Publication Interpretation and its API response.

The accepted UKO 1.1 corpus archive was not included with this handoff, so its previously reported 6 PTC / 52 realization / 298 RTCM corpus counts were not re-executed in this pass. The packaged implementation is ready for that external corpus validation.

Run `npm ci` and then `npm run verify` from the repository root.
